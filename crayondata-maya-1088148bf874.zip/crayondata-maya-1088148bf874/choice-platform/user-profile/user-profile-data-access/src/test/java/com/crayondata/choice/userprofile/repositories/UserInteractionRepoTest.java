/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.choice.userprofile.repositories;

import static org.junit.Assert.*;

import java.util.Calendar;
import java.util.Iterator;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.crayondata.choice.userprofile.UserInteraction;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:hsql-test-context.xml" })
public class UserInteractionRepoTest {

    @Autowired
    UserInteractionRepo repo;
    private UserInteraction record1;
    private UserInteraction record2;
    private UserInteraction record3;

    @Before
    public void setup() {
        record1 = new UserInteraction();
        record1.setChoiceBatchId(1);
        record1.setPerformer(1);
        record1.setItemId(1);

        record2 = new UserInteraction();
        record2.setChoiceBatchId(1);
        record2.setPerformer(1);
        record2.setItemId(2);

        record3 = new UserInteraction();
        record3.setChoiceBatchId(1);
        record3.setPerformer(1);
        record3.setItemId(3);

        repo.deleteAll();
        assertEquals(0, repo.count());
    }

    @Test
    public void testSaveAndRetrieveBack() {
        record1 = repo.save(record1);
        assertEquals(1, repo.count());

        record2 = repo.save(record2);
        record3 = repo.save(record3);
        assertEquals(3, repo.count());

        record1 = repo.save(record1);
        assertEquals(3, repo.count());

        Iterator<UserInteraction> allDataInter = repo.findAll().iterator();
        assertEquals(1, allDataInter.next().getItemId());
        assertEquals(2, allDataInter.next().getItemId());
        assertEquals(3, allDataInter.next().getItemId());
    }
}
