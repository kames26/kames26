/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.choice.userprofile.services;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.crayondata.choice.rateableitem.Category;
import com.crayondata.choice.userprofile.UserInteraction;
import com.crayondata.choice.userprofile.UserInteraction.InteractionType;
import com.crayondata.choice.userprofile.UserInteractionService;
import com.crayondata.choice.userprofile.repositories.UserInteractionRepo;

@Service
public class UserInteractionServiceImpl implements UserInteractionService {

    @Autowired
    UserInteractionRepo userInteractionRepo;

    @Override
    public Iterable<UserInteraction> getAllUserInteractions() {
        return userInteractionRepo.findAll();
    }

    @Override
    @Async
    public Iterable<UserInteraction> createUserInteractions(Iterable<UserInteraction> userInteractions) {
        return userInteractionRepo.save(userInteractions);
    }

    @Override
    public Iterable<UserInteraction> getByUserIdAndItemCategoryAndType(int userId, Category itemCategory,
            InteractionType... interactionTypes) {

        List<UserInteraction> result = new ArrayList<>();
        final Collection<UserInteraction> interactions = userInteractionRepo
                .findByPerformerAndCategory(userId, itemCategory);

        for (UserInteraction interaction : interactions) {
            for (InteractionType interactionType : interactionTypes) {
                if (interactionType == interaction.getType()) {
                    result.add(interaction);
                }
            }
        }

        return result;
    }

    @Override
    public Iterable<UserInteraction> getByUserIdAndItemCategoryAndTypeSinceDays(int userId,
            Category itemCategory, InteractionType interactionType, int daysSince) {
        // String time = String.format("[NOW-%dDAY/DAY TO NOW]", daysSince);
        Date date = new Date();
        Calendar c = Calendar.getInstance();
        c.setTime(date);
        c.add(Calendar.DAY_OF_MONTH, -daysSince);
        date = c.getTime();
        return userInteractionRepo.findByPerformerAndCategoryAndTypeAndTimestamp(userId, itemCategory,
                interactionType, date);
    }
}
