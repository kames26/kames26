/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.choice.userprofile.repositories;

import java.util.Collection;
import java.util.Date;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;

import com.crayondata.choice.rateableitem.Category;
import com.crayondata.choice.userprofile.UserInteraction;
import com.crayondata.choice.userprofile.UserInteraction.InteractionType;

public interface UserInteractionRepo extends PagingAndSortingRepository<UserInteraction, Integer> {
    @Override
    public Collection<UserInteraction> findAll();

    public Collection<UserInteraction> findByPerformerAndCategoryAndType(int performer, Category category,
            InteractionType interactionType);
    
    public Collection<UserInteraction> findByPerformerAndCategory(int performer, Category category);

    public Collection<UserInteraction> findByPerformerAndCategoryAndTypeAndTimestamp(int performer,
            Category category, InteractionType interactionType, Date timestamp);
    
    @Query(nativeQuery=true, value="DELETE FROM user_interaction_table where choice_batch_id=0")
    @Modifying
    @Transactional
    public void truncateMySQLTable();
}
