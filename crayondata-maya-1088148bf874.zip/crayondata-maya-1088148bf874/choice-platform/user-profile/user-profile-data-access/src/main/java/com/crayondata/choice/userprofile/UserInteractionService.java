/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.choice.userprofile;

import com.crayondata.choice.rateableitem.Category;
import com.crayondata.choice.userprofile.UserInteraction.InteractionType;

public interface UserInteractionService {

    /**
     * Lists down all the user interactions available in the system.
     *
     * @return
     */
    public Iterable<UserInteraction> getAllUserInteractions();

    /**
     *
     * @param userId
     *            User ID for which the interactions have to be retrieved
     * @param itemCategory
     *            Item category for which the interactions have to be retrieved
     * @param interactionType
     *            Type of the interaction
     * @param daysSince
     *            No. of days in the past from now when the interactions
     *            happened
     * @return
     */
    public Iterable<UserInteraction> getByUserIdAndItemCategoryAndTypeSinceDays(int userId,
            Category itemCategory, InteractionType interactionType, int daysSince);

    /**
     *
     * @param userId
     *            User ID for which the interactions have to be retrieved
     * @param itemCategory
     *            Item category for which the interactions have to be retrieved
     * @param interactionType
     *            Type of the interaction
     * @param buy
     * @return
     */
    public Iterable<UserInteraction> getByUserIdAndItemCategoryAndType(int userId, Category itemCategory,
            InteractionType... interactionType);

    Iterable<UserInteraction> createUserInteractions(Iterable<UserInteraction> userInteractions);
}
