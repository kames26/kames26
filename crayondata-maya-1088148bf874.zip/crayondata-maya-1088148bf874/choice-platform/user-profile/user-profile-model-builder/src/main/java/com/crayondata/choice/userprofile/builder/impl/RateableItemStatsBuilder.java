/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.choice.userprofile.builder.impl;

import static org.apache.commons.lang3.BooleanUtils.toInteger;

import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.Map;
import java.util.function.Consumer;

import org.apache.commons.math3.stat.Frequency;
import org.apache.commons.math3.stat.descriptive.StatisticalSummary;
import org.apache.commons.math3.stat.descriptive.SummaryStatistics;
import org.apache.commons.math3.stat.descriptive.SynchronizedSummaryStatistics;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.crayondata.choice.rateableitem.Category;
import com.crayondata.choice.rateableitem.CreativeWork;
import com.crayondata.choice.rateableitem.ItemSummary;
import com.crayondata.choice.rateableitem.LocalBusiness;
import com.crayondata.choice.rateableitem.RateableItem;
import com.crayondata.choice.userprofile.UserProfile;
import com.crayondata.choice.userprofile.UserProfile.UserModels;
import com.crayondata.choice.userprofile.model.AttributeWeightModel;
import com.crayondata.choice.userprofile.model.CategoryAttributeStatsTracker;
import com.crayondata.choice.userprofile.model.CategoryAttributeStatsTracker.CategoricalAttribute;
import com.crayondata.choice.userprofile.model.CategoryAttributeStatsTracker.NumericalAttribute;
import com.google.common.base.Predicates;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Iterables;
import com.google.common.collect.Iterators;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

@Component
public class RateableItemStatsBuilder {

	private static final Logger LOG = LoggerFactory.getLogger(RateableItemStatsBuilder.class);

	private static final CategoryAttributeStatsTracker EMPTY_CATEGORY_ATTRIBUTE_STATS_TRACKER = new CategoryAttributeStatsTracker(
			Category.OTHER, Maps.newHashMap(), Maps.newHashMap());

	public static CategoryAttributeStatsTracker computeForLocalBusinesses(Iterable<LocalBusiness> localBusinesses,
			Category cat) {
		if (Iterables.isEmpty(localBusinesses)) {
			return EMPTY_CATEGORY_ATTRIBUTE_STATS_TRACKER;
		}

		final CategoryAttributeStatsTracker result;
		switch (cat) {
		case RESTAURANT:
			result = computeForRestaurant(localBusinesses);
			break;
		case HOTEL:
			result = computeForHotel(localBusinesses);
			break;
		default:
			result = EMPTY_CATEGORY_ATTRIBUTE_STATS_TRACKER;
			break;
		}

		return result;
	}

	public static void updateUserModel(UserProfile profile, Iterable<? extends ItemSummary> items, Category cat) {
		AttributeWeightModel attributeModel = profile.getUserModels().get(UserModels.CrayonCatAttributeRecommender);
		CategoryAttributeStatsTracker statsTracker = attributeModel.getAttributeWeights(cat);
		Collection<LocalBusiness> localBusinesses = Lists.newArrayList();
		Collection<CreativeWork> creativeWorks = Lists.newArrayList();
		if (cat.isLocalBusiness())
			items.forEach(x -> localBusinesses.add((LocalBusiness) x));
		else
			items.forEach(x -> creativeWorks.add((CreativeWork) x));
		switch (cat) {
		case HOTEL:
			updateForHotel(statsTracker, localBusinesses);
			break;
		case RESTAURANT:
			updateForRestaurant(statsTracker, localBusinesses);
			break;
		case MOVIE:
			updateForMovies(statsTracker, creativeWorks);
			break;
		}
	}

	public static void updateForHotel(CategoryAttributeStatsTracker statsTracker,
			Iterable<LocalBusiness> localBusinesses) {

		StatisticalSummary aggregateRatingStatSummary = statsTracker.getNumericalAttributeStats()
				.get(NumericalAttribute.LOCAL_BUSINESS_AGGREGATE_RATING);
		Frequency amenitiesAttributeValueFequency = statsTracker
				.getAttributeValueWeights(CategoricalAttribute.amenities);
		localBusinesses.forEach(new Consumer<LocalBusiness>() {
			@Override
			public void accept(LocalBusiness localBusiness) {
				updateStatCounter(((SummaryStatistics) aggregateRatingStatSummary), localBusiness);
				for (String t : localBusiness.getAmenities()) {
					amenitiesAttributeValueFequency.addValue(t);
				}
			}
		});
	}

	private static CategoryAttributeStatsTracker computeForHotel(Iterable<LocalBusiness> localBusinesses) {

		final Category category = Category.HOTEL;

		final SynchronizedSummaryStatistics aggregateRatingStatSummary = new SynchronizedSummaryStatistics();

		final Frequency amenitiesAttributeValueFequency = new Frequency();

		localBusinesses.forEach(new Consumer<LocalBusiness>() {

			@Override
			public void accept(LocalBusiness localBusiness) {
				updateStatCounter(aggregateRatingStatSummary, localBusiness);
				for (String t : localBusiness.getAmenities()) {
					amenitiesAttributeValueFequency.addValue(t);
				}
			}
		});
		final CategoricalAttribute modelAttribute = CategoricalAttribute.amenities;
		final Map<CategoricalAttribute, Frequency> distinctAttrCount = Collections.singletonMap(modelAttribute,
				amenitiesAttributeValueFequency);

		final Map<NumericalAttribute, StatisticalSummary> numericalAttributeStats = ImmutableMap
				.of(NumericalAttribute.LOCAL_BUSINESS_AGGREGATE_RATING, aggregateRatingStatSummary);
		final CategoryAttributeStatsTracker modelAttrWeights = new CategoryAttributeStatsTracker(category,
				numericalAttributeStats, distinctAttrCount);
		return modelAttrWeights;
	}

	public static void updateForRestaurant(CategoryAttributeStatsTracker statsTracker,
			Iterable<LocalBusiness> localBusinesses) {

		StatisticalSummary aggregateRatingStatSummary = statsTracker.getNumericalAttributeStats()
				.get(NumericalAttribute.LOCAL_BUSINESS_AGGREGATE_RATING);

		Frequency cuisinesAttributeValueFequency = statsTracker.getAttributeValueWeights(CategoricalAttribute.cuisines);
		Frequency optionsAttributeValuesFrequency = statsTracker.getAttributeValueWeights(CategoricalAttribute.options);

		localBusinesses.forEach(new Consumer<LocalBusiness>() {
			@Override
			public void accept(LocalBusiness localBusiness) {
				updateStatCounter(((SummaryStatistics) aggregateRatingStatSummary), localBusiness);

				for (String t : localBusiness.getCuisines()) {
					cuisinesAttributeValueFequency.addValue(t);
				}
				for (String x : localBusiness.getOptions()) {
					optionsAttributeValuesFrequency.addValue(x);
				}
			}
		});
	}

	private static CategoryAttributeStatsTracker computeForRestaurant(Iterable<LocalBusiness> localBusinesses) {

		final Category category = Category.RESTAURANT;

		final Frequency cuisinesAttributeValueFequency = new Frequency();
		final Frequency optionsAttributeValuesFrequency = new Frequency();
		final Frequency isSpecialityFequency = new IsSpecialityFequency();

		final SynchronizedSummaryStatistics aggregateRatingStatSummary = new SynchronizedSummaryStatistics();

		localBusinesses.forEach(new Consumer<LocalBusiness>() {
			@Override
			public void accept(LocalBusiness localBusiness) {

				updateStatCounter((aggregateRatingStatSummary), localBusiness);

				isSpecialityFequency.addValue(toInteger(localBusiness.isSpeciality()));
				for (String t : localBusiness.getCuisines()) {
					cuisinesAttributeValueFequency.addValue(t);
				}
				for (String x : localBusiness.getOptions()) {
					optionsAttributeValuesFrequency.addValue(x);
				}
			}
		});

		final Map<CategoricalAttribute, Frequency> distinctAttrCount = ImmutableMap.of(CategoricalAttribute.cuisines,
				cuisinesAttributeValueFequency, CategoricalAttribute.speciality, isSpecialityFequency,
				CategoricalAttribute.options, optionsAttributeValuesFrequency);

		final Map<NumericalAttribute, StatisticalSummary> numericalAttributeStats = ImmutableMap
				.of(NumericalAttribute.LOCAL_BUSINESS_AGGREGATE_RATING, aggregateRatingStatSummary);
		final CategoryAttributeStatsTracker modelAttrWeights = new CategoryAttributeStatsTracker(category,
				numericalAttributeStats, distinctAttrCount);
		return modelAttrWeights;
	}

	public static CategoryAttributeStatsTracker computeForCreativeWorks(Iterable<CreativeWork> creativeWorks,
			Category cat) {
		if (Iterables.isEmpty(creativeWorks)) {
			return EMPTY_CATEGORY_ATTRIBUTE_STATS_TRACKER;
		}

		final CategoryAttributeStatsTracker result;
		switch (cat) {
		case MOVIE:
			result = computeForMovies(creativeWorks);
			break;
		default:
			throw new RuntimeException("Invalid CreativeWork" + cat);
		}

		return result;
	}

	public static void updateForMovies(CategoryAttributeStatsTracker statsTracker,
			Iterable<CreativeWork> creativeWorks) {

		StatisticalSummary aggregateRatingStatSummary = statsTracker.getNumericalAttributeStats()
				.get(NumericalAttribute.LOCAL_BUSINESS_AGGREGATE_RATING);
		Frequency genreFreqSummary = statsTracker.getAttributeValueWeights(CategoricalAttribute.genre);
		Frequency actorFreqSummary = statsTracker.getAttributeValueWeights(CategoricalAttribute.cast);
		Frequency directorFreqSummary = statsTracker.getAttributeValueWeights(CategoricalAttribute.director);

		creativeWorks.forEach(new Consumer<CreativeWork>() {
			@Override
			public void accept(CreativeWork creativeWork) {
				updateStatCounter(((SummaryStatistics) aggregateRatingStatSummary), creativeWork);
				for (String t : creativeWork.getGenre()) {
					genreFreqSummary.addValue(t);
				}
				for (String t : creativeWork.getCast()) {
					actorFreqSummary.addValue(t);
				}
				for (String t : creativeWork.getDirector()) {
					directorFreqSummary.addValue(t);
				}
			}
		});
	}

	private static CategoryAttributeStatsTracker computeForMovies(Iterable<CreativeWork> creativeWorks) {

		final Category category = Category.MOVIE;

		final Frequency genreFreqSummary = new Frequency();
		final Frequency actorFreqSummary = new Frequency();
		final Frequency directorFreqSummary = new Frequency();
		final SynchronizedSummaryStatistics aggregateRatingStatSummary = new SynchronizedSummaryStatistics();

		final Consumer<CreativeWork> action = new Consumer<CreativeWork>() {
			@Override
			public void accept(CreativeWork creativeWork) {
				updateStatCounter(aggregateRatingStatSummary, creativeWork);
				for (String t : creativeWork.getGenre()) {
					genreFreqSummary.addValue(t);
				}
				for (String t : creativeWork.getCast()) {
					actorFreqSummary.addValue(t);
				}
				for (String t : creativeWork.getDirector()) {
					directorFreqSummary.addValue(t);
				}
			}
		};
		creativeWorks.forEach(action);

		final Map<CategoricalAttribute, Frequency> distinctAttrCount = Maps.newHashMap();
		distinctAttrCount.put(CategoricalAttribute.genre, genreFreqSummary);
		distinctAttrCount.put(CategoricalAttribute.cast, actorFreqSummary);
		distinctAttrCount.put(CategoricalAttribute.director, directorFreqSummary);

		final Map<NumericalAttribute, StatisticalSummary> numericalAttributeStats = ImmutableMap
				.of(NumericalAttribute.LOCAL_BUSINESS_AGGREGATE_RATING, aggregateRatingStatSummary);
		final CategoryAttributeStatsTracker modelAttrWeights = new CategoryAttributeStatsTracker(category,
				numericalAttributeStats, distinctAttrCount);
		return modelAttrWeights;
	}

	static void updateStatCounter(final SummaryStatistics statSummary, RateableItem rateableItem) {
		if (statSummary == null) {
			LOG.warn("Ignoring item({}) as statSummary is null.", rateableItem);
			return;
		}

		if (rateableItem.getAggregateRating().orElse(0) > 0) {
			// TODO We have an issue with 0 values here, investigate, Liam
			statSummary.addValue(rateableItem.getAggregateRating().get());
		} else {
			LOG.debug("Ignoring item({}) with AggregateRating of {}", rateableItem.getId(), rateableItem.getAggregateRating());
		}
	}

	/**
	 * 
	 * We only want to use the value 1 in recommender query
	 *
	 */
	public static class IsSpecialityFequency extends Frequency {
		private static final long serialVersionUID = -8276996425782104029L;

		@Override
		public Iterator<Comparable<?>> valuesIterator() {
			return Iterators.filter(super.valuesIterator(), Predicates.equalTo(1L));
		}
	}
}
