/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.choice.userprofile.builder.impl;

import static com.crayondata.choice.userprofile.UserProfile.UserModels.CrayonCatAttributeRecommender;
import static com.crayondata.choice.userprofile.UserProfile.UserModels.CrayonNumAttributeRecommender;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.geo.Point;
import org.springframework.stereotype.Component;

import com.crayondata.choice.rateableitem.Category;
import com.crayondata.choice.rateableitem.CreativeWork;
import com.crayondata.choice.rateableitem.LocalBusiness;
import com.crayondata.choice.rateableitem.RateableItemDao;
import com.crayondata.choice.userprofile.UserInteraction;
import com.crayondata.choice.userprofile.UserInteraction.InteractionType;
import com.crayondata.choice.userprofile.UserProfile;
import com.crayondata.choice.userprofile.UserProfile.UserModels;
import com.crayondata.choice.userprofile.builder.IUserProfileBuilder;
import com.crayondata.choice.userprofile.model.AttributeWeightModel;
import com.crayondata.choice.userprofile.model.CategoryAttributeStatsTracker;
import com.crayondata.choice.userprofile.model.CrayonAttributeRecommenderUserModel;
import com.crayondata.choice.userprofile.util.GeoDistanceCalculator;
import com.google.common.base.Optional;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Iterables;
import com.google.common.collect.Maps;
import com.google.common.collect.Table;
import java.util.HashSet;
import java.util.Set;

@Component
public class UserProfileBuilder<T extends UserProfile> implements IUserProfileBuilder {

    private static final Logger LOG = LoggerFactory.getLogger(UserProfileBuilder.class);

    private static final double GEO_CENTROID_THRESHOLD = 0.5;

    private final RateableItemDao<CreativeWork> creativeWorkDAO;
    private final RateableItemDao<LocalBusiness> localBusinessDAO;

    @Autowired
    public UserProfileBuilder(RateableItemDao<LocalBusiness> localBusinessDAO,
            RateableItemDao<CreativeWork> creativeWorkDAO) {
        this.creativeWorkDAO = creativeWorkDAO;
        this.localBusinessDAO = localBusinessDAO;
    }

    @Override
    public UserProfile build(int userId,
            Table<Category, InteractionType, Iterable<UserInteraction>> userInteractions) {
        /** To avoid retrieving items more than once.. */
        Map<Category, Iterable<LocalBusiness>> localBusinesses = retriveAllLocalBusinesses(userInteractions);
        Map<Category, Iterable<CreativeWork>> creativeWorks = retriveAllCreativeWorks(userInteractions);
        final Map<UserModels, AttributeWeightModel> userModels = buildUserModels(localBusinesses,
                creativeWorks);
        UserProfile userProfile = new UserProfile(userId, userInteractions, userModels);
        computeAndUpdateCentroid(userProfile, localBusinesses);

        return userProfile;
    }

    private static Map<UserModels, AttributeWeightModel> buildUserModels(
            Map<Category, Iterable<LocalBusiness>> localBusinesses,
            Map<Category, Iterable<CreativeWork>> creativeWorks) {
        final CrayonAttributeRecommenderUserModel crayonAttributeModel = buildCrayonAttributeModel(
                localBusinesses, creativeWorks);
        Map<UserModels, AttributeWeightModel> result = ImmutableMap.of(CrayonCatAttributeRecommender,
                crayonAttributeModel, CrayonNumAttributeRecommender, crayonAttributeModel);

        return result;
    }

    private static void computeAndUpdateCentroid(UserProfile profile,
            Map<Category, Iterable<LocalBusiness>> localBusinessMap) {
        for (Category cat : localBusinessMap.keySet()) {
            Iterable<LocalBusiness> localBusinesses = localBusinessMap.get(cat);
            List<Double> latList = new ArrayList<>();
            List<Double> lonList = new ArrayList<>();
            Map<String, Set<String>> attributeMap = new HashMap<>();

            int missingCount = 0;
            double totalCount = 0;
            for (LocalBusiness item : localBusinesses) {
                totalCount++;
                // geo processing
                String geo = item.getGeo();
                if (geo == null || geo.isEmpty()) {
                    missingCount++;
                } else {
                    String[] tokens = geo.split(",");
                    if (tokens.length < 2) {
                        missingCount++; // Invalid geo
                    } else {
                        latList.add(Double.parseDouble(tokens[0]));
                        lonList.add(Double.parseDouble(tokens[1]));
                    }
                }
                // attribute processing
                if (cat.equals(Category.RESTAURANT)) {
                    Collection<String> cuisines = item.getCuisines();
                    if (cuisines != null && !cuisines.isEmpty()) {
                        Set<String> cuisineSet = attributeMap.getOrDefault("cuisine", new HashSet<>());
                        cuisineSet.addAll(cuisines);
                        attributeMap.putIfAbsent("cuisine", cuisineSet);
                    }
                }
            }
            Optional<Point> centroid = Optional.absent();
            double geoMissingRatio = missingCount / totalCount;
            if (geoMissingRatio < GEO_CENTROID_THRESHOLD && !latList.isEmpty() && !lonList.isEmpty()) {
                // centroid = calculateCentroid(latList, lonList);
                Map<String, List<Double>> filteredLatLon = getCentroidWithDistanceFilter(latList, lonList);
                centroid = calculateCentroid(filteredLatLon.get("lat"), filteredLatLon.get("lon"));
                if (centroid.isPresent()) {
                    double maxDistanceFromCentroid = getMaxDistanceFromCentroid(filteredLatLon.get("lat"),
                            filteredLatLon.get("lon"), centroid.get());
                    profile.setMaxDistance((int) Math.ceil(maxDistanceFromCentroid));
                }
            } else if (latList.isEmpty() || lonList.isEmpty()) {
                LOG.debug("Skipping geo centroid for:{} as there are no geo locations.", profile.getUserId());
            } else if (geoMissingRatio > GEO_CENTROID_THRESHOLD) {
                LOG.error("Skipping geo centroid for:{} based on migging geo ratio:{}", profile.getUserId(),
                        geoMissingRatio);
            }
            profile.getCentroidLocations().put(cat, centroid);
            // add attribute preferences
            attributeMap.entrySet().stream().forEach((entry) -> {
                profile.getUserAttributePreference().put(cat, entry.getKey(), entry.getValue());
            });
        }
    }

    private static Optional<Point> calculateCentroid(List<Double> latList, List<Double> lonList) {
        Optional<Point> centroid = Optional.absent();
        double meanLat = latList.stream().reduce((x, y) -> x + y).get() / latList.stream().count();
        double meanLon = lonList.stream().reduce((x, y) -> x + y).get() / lonList.stream().count();
        centroid = Optional.of(new Point(meanLat, meanLon));

        return centroid;
    }

    private static CrayonAttributeRecommenderUserModel buildCrayonAttributeModel(
            Map<Category, Iterable<LocalBusiness>> localBusinessMap,
            Map<Category, Iterable<CreativeWork>> creativeWorkMap) {

        final Map<Category, CategoryAttributeStatsTracker> catAttrWeights = new HashMap<>();

        for (Category category : UserModels.CrayonNumAttributeRecommender.SUPPORTED_CATEGORY_TYPES) {
            if (category.isLocalBusiness()) {
                final Iterable<LocalBusiness> localBusinesses = localBusinessMap.get(category);
                final CategoryAttributeStatsTracker modelAttrWeights = RateableItemStatsBuilder
                        .computeForLocalBusinesses(localBusinesses, category);
                catAttrWeights.put(category, modelAttrWeights);

            } else if (category == Category.MOVIE) {
                final Iterable<CreativeWork> creativeWorks = creativeWorkMap.get(category);
                final CategoryAttributeStatsTracker modelAttrWeights = RateableItemStatsBuilder
                        .computeForCreativeWorks(creativeWorks, category);
                catAttrWeights.put(category, modelAttrWeights);
            }
        }

        return new CrayonAttributeRecommenderUserModel(catAttrWeights, Maps.newHashMap());
    }

    private Map<Category, Iterable<LocalBusiness>> retriveAllLocalBusinesses(
            Table<Category, InteractionType, Iterable<UserInteraction>> userInteractions) {
        Map<Category, Iterable<LocalBusiness>> result = Maps.newHashMap();
        for (Category category : CrayonNumAttributeRecommender.SUPPORTED_CATEGORY_TYPES) {
            final Iterable<UserInteraction> categoryInteractions = userInteractions.get(category,
                    InteractionType.Like);
            if (category.isLocalBusiness()) {
                final Iterable<LocalBusiness> localBusinesses = retrieveLocalBusinesses(category,
                        categoryInteractions);
                result.put(category, localBusinesses);
            }
        }
        return result;
    }

    private Map<Category, Iterable<CreativeWork>> retriveAllCreativeWorks(
            Table<Category, InteractionType, Iterable<UserInteraction>> userInteractions) {
        Map<Category, Iterable<CreativeWork>> result = Maps.newHashMap();
        for (Category category : CrayonNumAttributeRecommender.SUPPORTED_CATEGORY_TYPES) {
            final Iterable<UserInteraction> categoryInteractions = userInteractions.get(category,
                    InteractionType.Like);
            if (category.isCreativeWork()) {
                final Iterable<CreativeWork> creativeWorks = retrieveCreativeWorks(category,
                        categoryInteractions);
                result.put(category, creativeWorks);
            }
        }

        return result;
    }

    private Iterable<LocalBusiness> retrieveLocalBusinesses(Category category,
            Iterable<UserInteraction> userLikes) {
        if (userLikes == null || Iterables.isEmpty(userLikes)) {
            LOG.debug("No interactions for LocalBusinesses category {}.", category);
            return Collections.emptyList();
        }

        Collection<Integer> itemIds = new ArrayList<>();
        userLikes.forEach(input -> itemIds.add(input.getItemId()));

        final Iterable<LocalBusiness> localBusinesses = localBusinessDAO.findAll(itemIds);
        return localBusinesses;
    }

    private Iterable<CreativeWork> retrieveCreativeWorks(Category category,
            Iterable<UserInteraction> userLikes) {
        if (userLikes == null || Iterables.isEmpty(userLikes)) {
            LOG.debug("No interactions for CreativeWorks category {}", category);
            return Collections.emptyList();
        }

        Collection<Integer> itemIds = new ArrayList<>();
        userLikes.forEach(input -> itemIds.add(input.getItemId()));

        final Iterable<CreativeWork> creativeWorks = creativeWorkDAO.findAll(itemIds);
        return creativeWorks;
    }

    private static Map<String, List<Double>> getCentroidWithDistanceFilter(List<Double> latList,
            List<Double> lonList) {
        final double thresholdLat = 1;
        final double thresholdLon = 1;
        Double minLat = null;
        Double maxLat = null;
        Double minLon = null;
        Double maxLon = null;

        List<Double> filteredLatList = new ArrayList<>(latList.size());
        List<Double> filteredLonList = new ArrayList<>(lonList.size());

        for (int i = 0; i < latList.size(); i++) {
            Double lat = latList.get(i);
            Double lon = lonList.get(i);

            // compare with min latitude
            if (minLat == null) {
                minLat = lat;
            } else if (lat < minLat - thresholdLat) {
                // System.out.println("Ignoring " + lat + "," + lon);
                continue;
            } else if (lat < minLat) {
                minLat = lat;
            }
            // compare with max latitude
            if (maxLat == null) {
                maxLat = lat;
            } else if (lat > maxLat + thresholdLat) {
                // System.out.println("Ignoring " + lat + "," + lon);
                continue;
            } else if (lat > maxLat) {
                maxLat = lat;
            }

            // compare with min longitude
            if (minLon == null) {
                minLon = lon;
            } else if (lon < minLon - thresholdLon) {
                // System.out.println("Ignoring " + lat + "," + lon);
                continue;
            } else if (lon < minLon) {
                minLon = lon;
            }
            // compare with max longitude
            if (maxLon == null) {
                maxLon = lon;
            } else if (lon > maxLon + thresholdLon) {
                // System.out.println("Ignoring " + lat + "," + lon);
                continue;
            } else if (lon > maxLon) {
                maxLon = lon;
            }

            filteredLatList.add(lat);
            filteredLonList.add(lon);
        }
        /*
         * System.out.println("MinLat " + minLat); System.out.println("MinLon "
         * + minLon); System.out.println("MaxLat " + maxLat);
         * System.out.println("MaxLon " + maxLon);
         */
        Map<String, List<Double>> latLonMap = new HashMap<>();
        latLonMap.put("lat", filteredLatList);
        latLonMap.put("lon", filteredLonList);
        return latLonMap;
    }

    private static double getMaxDistanceFromCentroid(List<Double> filteredLatList,
            List<Double> filteredLonList, Point centroid) {
        double centroidLat = centroid.getX();
        double centroidLon = centroid.getY();
        double maxDistance = 0;
        for (int i = 0; i < filteredLatList.size(); i++) {
            double distance = GeoDistanceCalculator.distance(filteredLatList.get(i), filteredLonList.get(i),
                    centroidLat, centroidLon, "K");
            if (distance > maxDistance) {
                maxDistance = distance;
            }
        }
        return maxDistance;
    }
}
