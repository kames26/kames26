/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.choice.userprofile.model;

import java.util.Map;
import java.util.Map.Entry;

import javax.annotation.concurrent.Immutable;

import org.apache.commons.math3.stat.descriptive.StatisticalSummary;

import com.crayondata.choice.rateableitem.Category;
import com.crayondata.choice.userprofile.model.CategoryAttributeStatsTracker.NumericalAttribute;
import com.google.common.base.MoreObjects;

@Immutable
public class CrayonAttributeRecommenderUserModel implements AttributeWeightModel {
    private final Map<Category, CategoryAttributeStatsTracker> attributeWeights;
    private final Map<String, String> modelParameters;

    public CrayonAttributeRecommenderUserModel(Map<Category, CategoryAttributeStatsTracker> attributeWeights,
            Map<String, String> modelParameters) {
        this.attributeWeights = attributeWeights;
        this.modelParameters = modelParameters;
    }

    @Override
    public Map<String, String> getModelParameters(Category category) {

        final CategoryAttributeStatsTracker catAttributeWeights = attributeWeights.get(category);

        for (Entry<NumericalAttribute, StatisticalSummary> modelParameter : catAttributeWeights
                .getNumericalAttributeStats().entrySet()) {
            final StatisticalSummary paramValue = modelParameter.getValue();
            if (paramValue.getMean() != Double.NaN) {
                modelParameters.put(modelParameter.getKey().toString(), String.valueOf(paramValue.getMean()));
            }
        }
        return modelParameters;
    }

    @Override
    public CategoryAttributeStatsTracker getAttributeWeights(Category category) {
        return attributeWeights.get(category);
    }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(this).add("attributeWeights", this.attributeWeights)
                .add("modelParameters", this.modelParameters).toString();
    }
}
