/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.choice.userprofile;

import static com.crayondata.choice.userprofile.UserInteraction.InteractionType.Like;

import java.time.Duration;
import java.time.Instant;
import java.util.Collections;
import java.util.Date;
import java.util.EnumSet;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.geo.Point;

import com.crayondata.choice.rateableitem.Category;
import com.crayondata.choice.userprofile.UserInteraction.InteractionType;
import com.crayondata.choice.userprofile.model.AttributeWeightModel;
import com.google.common.base.Function;
import com.google.common.base.MoreObjects;
import com.google.common.base.Optional;
import com.google.common.base.Predicate;
import com.google.common.collect.HashBasedTable;
import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Table;

public class UserProfile {

    private static final Logger LOG = LoggerFactory.getLogger(UserProfile.class);

    protected final int userId;
    private final UserInteractionsTable userInteractionsTable;
    private final Map<UserModels, AttributeWeightModel> userModels;

    private final Map<Category, Optional<Point>> centroidLocations;
    private final Table<Category, String, Iterable<String>> userAttributePreference;
    private int maxDistance = -1;

    public UserProfile(int userId,
            Table<Category, InteractionType, Iterable<UserInteraction>> userInteractions,
            Map<UserModels, AttributeWeightModel> userModels) {
        this.userId = userId;
        this.userInteractionsTable = new UserInteractionsTable(userInteractions);
        this.userModels = userModels;
        this.centroidLocations = Maps.newHashMap();
        this.userAttributePreference = HashBasedTable.create();
    }

    public int getUserId() {
        return userId;
    }

    public Table<Category, InteractionType, Iterable<UserInteraction>> getUserInteractions() {
        return this.userInteractionsTable.userInteractions;
    }

    public Table<Category, String, Iterable<String>> getUserAttributePreference() {
        return this.userAttributePreference;
    }

    public void logItemInteractions(Iterable<UserInteraction> interactions) {
        // TODO review and optimize
        for (UserInteraction userInteraction : interactions) {
            final Iterable<UserInteraction> userInteractionsForTypeAndCategory = userInteractionsTable
                    .get(userInteraction.getCategory(), userInteraction.getType());

            final Iterable<UserInteraction> userInteractionsForTypeAndCategoryUpdated = Iterables
                    .concat(userInteractionsForTypeAndCategory, Lists.newArrayList(userInteraction));
            this.userInteractionsTable.put(userInteraction.getCategory(), userInteraction.getType(),
                    userInteractionsForTypeAndCategoryUpdated);
            // TODO to update user models from here.. -Vivek (Done at the caller
            // side)
        }
        LOG.debug("Updated user profile for user {} with {} item interactions", userId,
                Iterables.size(interactions));
    }

    public Iterable<Integer> getUserLikes(Category cat) {
        final Iterable<UserInteraction> userLikeInteractions = userInteractionsTable.get(cat, Like);
        return Iterables.transform(userLikeInteractions, itemInteractionToItemId);
    }

    public Iterable<Integer> getItemsFromUserHistory(Category category, final Duration duration, Date choiceDate, 
            InteractionType... interactionTypes) {

        Iterable<Integer> recentInteractions = Lists.newArrayList();
        for (InteractionType interactionType : interactionTypes) {
            final Iterable<UserInteraction> userInteractions = userInteractionsTable.get(category,
                    interactionType);
            if (Iterables.isEmpty(userInteractions)) {
                LOG.debug("User {} has no item interactions of type {} for category {}", userId,
                        interactionType, category);
                continue;
            }

            final Iterable<UserInteraction> recentInteractionsForType = Iterables.filter(userInteractions,
                    new InteractionOccuredSinceSpecificDate(duration, choiceDate));

            final Iterable<Integer> recentInteractedItemsForType = Iterables
                    .transform(recentInteractionsForType, itemInteractionToItemId);
            recentInteractions = Iterables.concat(recentInteractions, recentInteractedItemsForType);
        }
        LOG.debug(
                "Returning {} item interactions for user {} of types {} for category {} that ocured within the past {}",
                Iterables.size(recentInteractions), userId, interactionTypes, category, duration);
        return recentInteractions;

    }

    private static final Function<UserInteraction, Integer> itemInteractionToItemId = new Function<UserInteraction, Integer>() {
        @Override
        public Integer apply(UserInteraction input) {
            return input.getItemId();
        }
    };

    public Map<UserModels, AttributeWeightModel> getUserModels() {
        return userModels;
    }

    public UserProfile mute() {
        return new MutedUserProfile(this);
    }

    private static final class InteractionOccuredSince implements Predicate<UserInteraction> {

        private final Duration duration;

        InteractionOccuredSince(Duration duration) {
            this.duration = duration;
        }

        @Override
        public boolean apply(UserInteraction input) {

            return input.getTimestamp().toInstant().isAfter(Instant.now().minus(duration));
        }
    }
    
    private static final class InteractionOccuredSinceSpecificDate implements Predicate<UserInteraction> {

        private final Duration duration;
		private Date date;

        InteractionOccuredSinceSpecificDate(Duration duration, Date date) {
            this.duration = duration;
			this.date = date;
        }

        @Override
        public boolean apply(UserInteraction input) {
        	
            return input.getTimestamp().toInstant().isAfter(Instant.ofEpochMilli(date.getTime()).minus(duration));
        }
    }

    private static class MutedUserProfile extends UserProfile {
        private MutedUserProfile(UserProfile userProfile) {
            super(userProfile.getUserId(), userProfile.getUserInteractions(), userProfile.getUserModels());
        }

        @Override
        public Iterable<Integer> getUserLikes(Category cat) {
            LOG.debug("returning empty collection for user likes as profile is muted for user {}", userId);
            return Collections.emptyList();
        }
    }

    public enum UserModels {
        CrayonNumAttributeRecommender, CrayonCatAttributeRecommender;

        // TODO, one for each model later when we add more
        public final EnumSet<Category> SUPPORTED_CATEGORY_TYPES = EnumSet.of(Category.RESTAURANT,
                Category.HOTEL, Category.MOVIE);
    }

    public Optional<AttributeWeightModel> getModel(UserModels userModel) {
        if (userModels.containsKey(userModel)) {
            return Optional.of(userModels.get(userModel));
        }
        LOG.debug("User {} does not have a model of type {}", userId, userModel);
        return Optional.absent();
    }

    public Map<Category, Optional<Point>> getCentroidLocations() {
        return centroidLocations;
    }

    public int getMaxDistance() {
        return maxDistance;
    }

    public void setMaxDistance(int maxDistance) {
        this.maxDistance = maxDistance;
    }

    private static class UserInteractionsTable {
        private final Table<Category, InteractionType, Iterable<UserInteraction>> userInteractions;

        public UserInteractionsTable(
                Table<Category, InteractionType, Iterable<UserInteraction>> userInteractionsTable) {
            this.userInteractions = userInteractionsTable;
        }

        Iterable<UserInteraction> get(Category category, InteractionType interactionType) {
            final Iterable<UserInteraction> userInteractionsForTypeAndCategory = this.userInteractions
                    .get(category, interactionType);
            if (userInteractionsForTypeAndCategory == null) {
                return Collections.emptyList();
            }
            return userInteractionsForTypeAndCategory;
        }

        public void put(Category category, InteractionType type, Iterable<UserInteraction> userInteractions) {
            this.userInteractions.put(category, type, userInteractions);
        }

        @Override
        public String toString() {
            return "UserInteractionsTable [userInteractions=" + userInteractions + "]";
        }
    }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(this).add("userId:", this.userId)
                .add("userLikes", this.userInteractionsTable).add("userModels", this.userModels).toString();
    }
}
