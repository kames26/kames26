/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.choice.userprofile;

import java.util.Collection;

/**
 * A generic Person class to store user details.
 * 
 * @author vivek
 *
 */
public class Person {

    /**
     * Could be the username
     */
    protected String name;
    /**
     * Could be a system generated id for the user.
     */
    protected String id;

    /* protected PostalAddress address; */

    /** Attributes part of address. */
    protected String addressCountry;

    protected String addressLocality;

    protected String addressCity;

    protected String addressRegion;

    protected String postOfficeBoxNumber;

    protected String postalCode;

    protected String streetAddress;

    /** Must be in the form Lat,String for sotring in Solr */
    protected String addressGeo;
    /** End of Attributes part of address. */

    protected String birthDate;

    /** TODO Should we model Place? */
    /* protected Place birthPlace; */
    /** Attributes part of address. */
    protected String birthCountry;

    protected String birthCity;

    /** End of Attributes part of address. */

    protected String email;

    /** First name */
    protected String givenName;

    /** Last name */
    protected String familyName;

    protected String gender;

    protected String globalLocationNumber;

    protected String jobTitle;

    protected String nationality;

    /** Reference to the spouce user id */
    protected String spouse;

    protected Collection<String> parents;

    protected Collection<String> children;

    protected Collection<String> sibilings;

    protected Collection<String> knows;

    protected Collection<String> follows;

    protected Collection<String> relatedTo;

    protected String weight;

    protected String telephone;

    /* protected Place workLocation; */
    protected String workCity;

    protected String workCountry;

    protected String worksFor;

    /** Must be in the form Lat, String for Solr */
    protected String workLocationGeo;
    protected String uuid;

    public String getName() {
        return name;
    }

    public String getId() {
        return id;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

    public String getUuid() {
        return uuid;
    }

    /*
     * public PostalAddress getAddress() { return address; }
     */

    public String getBirthDate() {
        return birthDate;
    }

    public String getEmail() {
        return email;
    }

    public String getGivenName() {
        return givenName;
    }

    public String getFamilyName() {
        return familyName;
    }

    public String getGender() {
        return gender;
    }

    public String getGlobalLocationNumber() {
        return globalLocationNumber;
    }

    public String getJobTitle() {
        return jobTitle;
    }

    public String getNationality() {
        return nationality;
    }

    public String getSpouse() {
        return spouse;
    }

    public Collection<String> getParents() {
        return parents;
    }

    public Collection<String> getChildren() {
        return children;
    }

    public Collection<String> getSibilings() {
        return sibilings;
    }

    public Collection<String> getKnows() {
        return knows;
    }

    public Collection<String> getFollows() {
        return follows;
    }

    public Collection<String> getRelatedTo() {
        return relatedTo;
    }

    public String getWeight() {
        return weight;
    }

    public String getTelephone() {
        return telephone;
    }

    public String getWorksFor() {
        return worksFor;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setId(String id) {
        this.id = id;
    }

    /*
     * public void setAddress(PostalAddress address) { this.address = address; }
     */

    public void setBirthDate(String birthDate) {
        this.birthDate = birthDate;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setGivenName(String givenName) {
        this.givenName = givenName;
    }

    public void setFamilyName(String familyName) {
        this.familyName = familyName;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public void setGlobalLocationNumber(String globalLocationNumber) {
        this.globalLocationNumber = globalLocationNumber;
    }

    public void setJobTitle(String jobTitle) {
        this.jobTitle = jobTitle;
    }

    public void setNationality(String nationality) {
        this.nationality = nationality;
    }

    public void setSpouse(String spouse) {
        this.spouse = spouse;
    }

    public void setParents(Collection<String> parents) {
        this.parents = parents;
    }

    public void setChildren(Collection<String> children) {
        this.children = children;
    }

    public void setSibilings(Collection<String> sibilings) {
        this.sibilings = sibilings;
    }

    public void setKnows(Collection<String> knows) {
        this.knows = knows;
    }

    public void setFollows(Collection<String> follows) {
        this.follows = follows;
    }

    public void setRelatedTo(Collection<String> relatedTo) {
        this.relatedTo = relatedTo;
    }

    public void setWeight(String weight) {
        this.weight = weight;
    }

    public void setTelephone(String telephone) {
        this.telephone = telephone;
    }

    public void setWorksFor(String worksFor) {
        this.worksFor = worksFor;
    }

    public String getAddressCountry() {
        return addressCountry;
    }

    public String getAddressLocality() {
        return addressLocality;
    }

    public String getAddressCity() {
        return addressCity;
    }

    public String getAddressRegion() {
        return addressRegion;
    }

    public String getPostOfficeBoxNumber() {
        return postOfficeBoxNumber;
    }

    public String getPostalCode() {
        return postalCode;
    }

    public String getStreetAddress() {
        return streetAddress;
    }

    public String getBirthCountry() {
        return birthCountry;
    }

    public String getBirthCity() {
        return birthCity;
    }

    public void setAddressCountry(String addressCountry) {
        this.addressCountry = addressCountry;
    }

    public void setAddressLocality(String addressLocality) {
        this.addressLocality = addressLocality;
    }

    public void setAddressCity(String addressCity) {
        this.addressCity = addressCity;
    }

    public void setAddressRegion(String addressRegion) {
        this.addressRegion = addressRegion;
    }

    public void setPostOfficeBoxNumber(String postOfficeBoxNumber) {
        this.postOfficeBoxNumber = postOfficeBoxNumber;
    }

    public void setPostalCode(String postalCode) {
        this.postalCode = postalCode;
    }

    public void setStreetAddress(String streetAddress) {
        this.streetAddress = streetAddress;
    }

    public void setBirthCountry(String birthCountry) {
        this.birthCountry = birthCountry;
    }

    public void setBirthCity(String birthCity) {
        this.birthCity = birthCity;
    }

    public String getAddressGeo() {
        return addressGeo;
    }

    public String getWorkCity() {
        return workCity;
    }

    public String getWorkCountry() {
        return workCountry;
    }

    public String getWorkLocationGeo() {
        return workLocationGeo;
    }

    public void setAddressGeo(String addressGeo) {
        this.addressGeo = addressGeo;
    }

    public void setWorkCity(String workCity) {
        this.workCity = workCity;
    }

    public void setWorkCountry(String workCountry) {
        this.workCountry = workCountry;
    }

    public void setWorkLocationGeo(String workLocationGeo) {
        this.workLocationGeo = workLocationGeo;
    }

    public Person() {}

    public void copyNonNullValuesFrom(Person from) {
        if (from.getName() != null && !from.getName().isEmpty()) this.name = from.getName();

        /*
         * if(from.getAddress() != null) this.address = from.getAddress();
         */

        if (from.getAddressCountry() != null) this.addressCountry = from.getAddressCountry();

        if (from.getAddressLocality() != null) this.addressLocality = from.getAddressLocality();

        if (from.getAddressCity() != null) this.addressCity = from.getAddressCity();

        if (from.getAddressRegion() != null) this.addressRegion = from.getAddressRegion();

        if (from.getPostOfficeBoxNumber() != null) this.postOfficeBoxNumber = from.getPostOfficeBoxNumber();

        if (from.getPostalCode() != null) this.postalCode = from.getPostalCode();

        if (from.getStreetAddress() != null) this.streetAddress = from.getStreetAddress();

        if (from.getAddressGeo() != null) this.addressGeo = from.getAddressGeo();

        if (from.getBirthCountry() != null) this.birthCountry = from.getBirthCountry();

        if (from.getBirthCity() != null) this.birthCity = from.getBirthCity();

        if (from.getBirthDate() != null) this.birthDate = from.getBirthDate();

        /*
         * if(from.getBirthPlace() != null) this.birthPlace =
         * from.getBirthPlace();
         */

        if (from.getEmail() != null) this.email = from.getEmail();

        if (from.getGivenName() != null) this.givenName = from.getGivenName();

        if (from.getFamilyName() != null) this.familyName = from.getFamilyName();

        if (from.getGender() != null) this.gender = from.getGender();

        if (from.getGlobalLocationNumber() != null)
            this.globalLocationNumber = from.getGlobalLocationNumber();

        if (from.getJobTitle() != null) this.jobTitle = from.getJobTitle();

        if (from.getNationality() != null) this.nationality = from.getNationality();

        if (from.getSpouse() != null) this.spouse = from.getSpouse();

        if (from.getParents() != null) this.parents = from.getParents();

        if (from.getChildren() != null) this.children = from.getChildren();

        if (from.getSibilings() != null) this.sibilings = from.getSibilings();

        if (from.getKnows() != null) this.knows = from.getKnows();

        if (from.getFollows() != null) this.follows = from.getFollows();

        if (from.getRelatedTo() != null) this.relatedTo = from.getRelatedTo();

        if (from.getWeight() != null) this.weight = from.getWeight();

        if (from.getTelephone() != null) this.telephone = from.getTelephone();

        if (from.getWorkCity() != null) this.workCity = from.getWorkCity();

        if (from.getWorkCountry() != null) this.workCountry = from.getWorkCountry();

        if (from.getWorkLocationGeo() != null) this.workLocationGeo = from.getWorkLocationGeo();

        if (from.getWorksFor() != null) this.worksFor = from.getWorksFor();
    }

    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("{id:" + this.id).append(", name:" + this.name).append(", givenName:" + this.givenName)
                .append(", familyName:" + this.familyName + "}");
        return builder.toString();
    }
}
