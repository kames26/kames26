/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.choice.userprofile;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.crayondata.choice.rateableitem.Category;

@Entity
@Table(name = "user_interaction_table")
public class UserInteraction {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    protected int id;

    @Enumerated(EnumType.STRING)
    @Column(name = "type")
    protected InteractionType type;

    @Column(name = "performer")
    protected int performer; // userId

    @Column(name = "location")
    protected String location;

    @Column(name = "choice_batch_id")
    protected int choiceBatchId;

    @Enumerated(EnumType.STRING)
    protected Category category;

    @Column(name = "item_id")
    protected int itemId;

    @Column(name = "name")
    protected String name;

    @Column(name = "timestamp")
    protected Date timestamp;

    public UserInteraction(InteractionType type, Category category, int performer, int itemId) {
        this.type = type;
        this.category = category;
        this.performer = performer;
        this.timestamp = new Date();
        this.itemId = itemId;
    }

    public UserInteraction() {}

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public InteractionType getType() {
        return type;
    }

    public void setType(InteractionType type) {
        this.type = type;
    }

    public int getPerformer() {
        return performer;
    }

    public void setPerformer(int performer) {
        this.performer = performer;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public int getChoiceBatchId() {
        return choiceBatchId;
    }

    public void setChoiceBatchId(int choiceBatchId) {
        this.choiceBatchId = choiceBatchId;
    }

    public Category getCategory() {
        return category;
    }

    public void setCategory(Category category) {
        this.category = category;
    }

    public int getItemId() {
        return itemId;
    }

    public void setItemId(int itemId) {
        this.itemId = itemId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Date getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(Date timestamp) {
        this.timestamp = timestamp;
    }

    @Override
    public String toString() {
        return "UserInteraction [id=" + id + ", type=" + type + ", performer=" + performer + ", location="
                + location + ", choiceBatchId=" + choiceBatchId + ", category=" + category + ", itemId="
                + itemId + ", name=" + name + ", timestamp=" + timestamp + "]";
    }

    public enum InteractionType {
        Like, Dislike, Later, WishList, Buy, Collected, Discarded
    }
}
