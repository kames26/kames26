/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.choice.userprofile.model;

import java.util.Map;

import org.apache.commons.math3.stat.Frequency;
import org.apache.commons.math3.stat.descriptive.StatisticalSummary;

import com.crayondata.choice.rateableitem.Category;
import com.crayondata.choice.userprofile.UserInteraction;
import com.google.common.base.Functions;
import com.google.common.base.MoreObjects;
import com.google.common.collect.Iterables;

public class CategoryAttributeStatsTracker {

    private final Map<NumericalAttribute, StatisticalSummary> numericalAttributeStats;
    private final Map<CategoricalAttribute, Frequency> distinctAttributeStats;
    private final Category category;

    public CategoryAttributeStatsTracker(Category category,
            Map<NumericalAttribute, StatisticalSummary> numericalAttributeStats,
            Map<CategoricalAttribute, Frequency> distinctAttrCount) {
        this.category = category;
        this.numericalAttributeStats = numericalAttributeStats;
        this.distinctAttributeStats = distinctAttrCount;
    }

    public void consume(Iterable<UserInteraction> userInteractions) {
        // TODO
        // To be triggered from UserProfile.logInteractions()
    }

    public Iterable<String> getAttributeNames() {
        return Iterables.concat(
                Iterables.transform(numericalAttributeStats.keySet(), Functions.toStringFunction()),
                Iterables.transform(distinctAttributeStats.keySet(), Functions.toStringFunction()));
    }

    public Frequency getAttributeValueWeights(String attributeName) {
        return getAttributeValueWeights(CategoricalAttribute.valueOf(attributeName));
    }

    public Frequency getAttributeValueWeights(CategoricalAttribute catAttr) {
        if (!distinctAttributeStats.containsKey(catAttr)) {
            distinctAttributeStats.put(catAttr, new Frequency());
        }
        return distinctAttributeStats.get(catAttr);
    }

    public Map<CategoricalAttribute, Frequency> getDistinctAttrCount() {
        return distinctAttributeStats;
    }

    public Map<NumericalAttribute, StatisticalSummary> getNumericalAttributeStats() {
        return this.numericalAttributeStats;
    }

    // TODO support giving a weight to the attribute itself as well as the
    // values
    public float getAttributeWeight(String attributeName) {
        /* return 1; */
        CategoricalAttribute attr = CategoricalAttribute.valueOf(attributeName);
        float result = 1;
        switch (attr) {
        case cuisines:
            result = 5;
            break;
        default:
            break;
        }

        return result;
    }

    public Category getCategory() {
        return category;
    }

    public enum CategoricalAttribute {
        cuisines("cuisine"), options, amenities, genre, cast, director, speciality("cuisine_count");

        private final String attributeFieldName;

        CategoricalAttribute() {
            this.attributeFieldName = this.name();
        }

        CategoricalAttribute(String attributeFieldName) {
            this.attributeFieldName = attributeFieldName;
        }

        public String getAttributeFieldName() {
            return attributeFieldName;
        }
    }

    //@formatter:off
    public enum NumericalAttribute {       
        LOCAL_BUSINESS_AGGREGATE_RATING("aggregaterating")
//        , 
//        LOCAL_BUSINESS_AMBIENCE_RATING("ambiencerating"), 
//        LOCAL_BUSINESS_FOOD_RATING("foodrating"), 
//        LOCAL_BUSINESS_SERVICE_RATING("servicerating"), 
//        LOCAL_BUSINESS_VALUE_RATING("valuerating"),
//        LOCAL_BUSINESS_CLEANLINESS_RATING("cleanlinessrating"), 
//        LOCAL_BUSINESS_LOCATION_RATING("locationrating")
        ;
        
        
        private final String attributeFieldName;
        NumericalAttribute(String attributeFieldName) {
            this.attributeFieldName = attributeFieldName;
        }

        public String getAttributeFieldName() {
            return attributeFieldName;
        }
    }
    //@formatter:on

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(this).add("category", this.category)
                .add("numericalAttributeStats", this.numericalAttributeStats)
                .add("distinctAttributeStats", this.distinctAttributeStats).toString();
    }
}
