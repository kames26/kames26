/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.choice.userprofile.builder.impl;

import static org.junit.Assert.assertNotNull;

import java.util.ArrayList;
import java.util.Collection;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

import com.crayondata.choice.rateableitem.Category;
import com.crayondata.choice.rateableitem.CreativeWork;
import com.crayondata.choice.rateableitem.LocalBusiness;
import com.crayondata.choice.rateableitem.MayaRestaurant;
import com.crayondata.choice.rateableitem.RateableItemDao;
import com.crayondata.choice.rateableitem.solr.LocalBusinessDAOImpl;
import com.crayondata.choice.userprofile.UserInteraction;
import com.crayondata.choice.userprofile.UserInteraction.InteractionType;
import com.crayondata.choice.userprofile.UserProfile;
import com.google.common.collect.HashBasedTable;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.Table;

@Ignore
public class UserProfileBuilderTest {

    private static final String SOLR_HOST_IP = "dev.buildmaya.com";
    private static final String SOLR_HOST_PORT = "8983";
    private static final int SOLR_CHUNK_SIZE = 100;
    private static final int TEST_USERID = 1234;

    private static RateableItemDao<LocalBusiness> localBusinessDAO = null;
    private static RateableItemDao<CreativeWork> creativeWorkDAO = null;

    private static int userId = 123456;

    private UserProfileBuilder<UserProfile> builder = null;

    private static ImmutableList<UserInteraction> testRestaurantUserInteractions = ImmutableList.of(
            new UserInteraction(InteractionType.Like, Category.RESTAURANT, TEST_USERID, 302386938),
            new UserInteraction(InteractionType.Like, Category.RESTAURANT, TEST_USERID, 302387038),
            new UserInteraction(InteractionType.Like, Category.RESTAURANT, TEST_USERID, 301828660),
            new UserInteraction(InteractionType.Like, Category.RESTAURANT, TEST_USERID, 300607003)
    /*
     * new UserInteraction(InteractionType.Like, Category.RESTAURANT,
     * 300006528), new UserInteraction(InteractionType.Like,
     * Category.RESTAURANT, 300044118), new
     * UserInteraction(InteractionType.Like, Category.RESTAURANT, 300026478),
     * new UserInteraction(InteractionType.Like, Category.RESTAURANT,
     * 300043488), new UserInteraction(InteractionType.Like,
     * Category.RESTAURANT, 300734847), new
     * UserInteraction(InteractionType.Like, Category.RESTAURANT, 300804946)
     */);

    @BeforeClass
    public static void setUpBeforeClass() throws Exception {
        /* SolrAccessorFactory saf = EmbeddedSolrAccessorFactory.create(); */

        localBusinessDAO = new LocalBusinessDAOImpl(null, null);
        assertNotNull(localBusinessDAO);

        /*
         * restaurants =
         * JsonToSolrBeanUtil.parseJsonFile(Resources.getResource(JSON_FILENAME)
         * , MayaRestaurant.class);
         */
        /*
         * TestItemProvider itemProvider = new TestItemProvider(); restaurants =
         * (Collection<MayaRestaurant>)
         * itemProvider.getTestItemsByCategory(Category.RESTAURANT);
         * 
         * restaurantIDs = createRestaurants(restaurants);
         */
    }

    private static Collection<Integer> createRestaurants(Collection<MayaRestaurant> restaurants) {
        Collection<Integer> restaurantIds = new ArrayList<>();
        for (MayaRestaurant restaurant : restaurants) {
            // MayaRestaurant createdObj =
            // restaurantDAO.createMayaRestaurant(restaurant);
            // restaurantIds.add(createdObj.getId());
        }
        return restaurantIds;
    }

    @AfterClass
    public static void tearDownAfterClass() throws Exception {

        /*
         * for (Integer id : restaurantIDs) {
         * restaurantDAO.deleteMayaRestaurantById(id); } restaurantDAO.close();
         */

    }

    @Before
    public void setUp() throws Exception {
        this.builder = new UserProfileBuilder<>(localBusinessDAO, creativeWorkDAO);
    }

    @After
    public void tearDown() throws Exception {}

    @Test
    public void testUserProfileBuilder() {
        /* fail("Not yet implemented"); */
    }

    @Test
    public void testBuild() {
        final Table<Category, InteractionType, Iterable<UserInteraction>> userLikes = HashBasedTable.create();
        userLikes.put(Category.RESTAURANT, InteractionType.Like, testRestaurantUserInteractions);

        UserProfile result = builder.build(userId, userLikes);
        System.out.println("UserProfile:" + result);
        assertNotNull(result);
    }
}
