/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.choice.userprofile;

import static com.crayondata.choice.rateableitem.Category.CROSS;
import static com.crayondata.choice.userprofile.UserInteraction.InteractionType.Dislike;
import static com.crayondata.choice.userprofile.UserInteraction.InteractionType.Later;
import static com.crayondata.choice.userprofile.UserInteraction.InteractionType.Like;
import static com.crayondata.choice.userprofile.UserInteraction.InteractionType.WishList;

import java.util.ArrayList;
import java.util.Collection;
import java.util.EnumSet;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.crayondata.choice.rateableitem.Category;
import com.crayondata.choice.userprofile.UserInteraction.InteractionType;
import com.crayondata.choice.userprofile.builder.IUserProfileBuilder;
import com.google.common.collect.HashBasedTable;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.Table;

@Component
public class UserProfileContextHolder<T extends UserProfile> implements IUserProfileContextHolder<T> {
    private static final Logger LOG = LoggerFactory.getLogger(UserProfileContextHolder.class);

    protected static final String CP_USER_PROFILE = "ChoicePlatformUserProfile";

    private final UserInteractionService userInteractionDAO;
    private final IUserProfileBuilder userProfileBuilder;

    @Autowired
    public UserProfileContextHolder(UserInteractionService userInteractionDAO,
            IUserProfileBuilder userProfileBuilder) {
        this.userInteractionDAO = userInteractionDAO;
        this.userProfileBuilder = userProfileBuilder;
    }

    /* (non-Javadoc)
     * @see com.crayondata.choice.userprofile.IUserProfileContextHolder#get(int)
     */
    @Override
    @Cacheable("userProfile")
    public T get(int userId) {
    	long startTime = System.currentTimeMillis();
        final ServletRequestAttributes attr = (ServletRequestAttributes) RequestContextHolder
                .getRequestAttributes();
        final T userProfile;
        if (attr == null) {
            final Table<Category, InteractionType, Iterable<UserInteraction>> userInteractions = loadInteractionsToBuildProfile(
                    userId);
            userProfile = buildUserProfile(userId, userInteractions);
            LOG.debug("Created new in-memory UserProfile for user {}", userId);
        } else {

            if (attr.getAttribute(CP_USER_PROFILE, RequestAttributes.SCOPE_SESSION) == null) {
                final Table<Category, InteractionType, Iterable<UserInteraction>> userInteractions = loadInteractionsToBuildProfile(
                        userId);

                userProfile = buildUserProfile(userId, userInteractions);
                LOG.debug("Created new in-memory UserProfile for user {}", userId);
                attr.setAttribute(CP_USER_PROFILE, userProfile, RequestAttributes.SCOPE_SESSION);
            } else {
                userProfile = (T) attr.getAttribute(CP_USER_PROFILE, RequestAttributes.SCOPE_SESSION);
            }
        }
        LOG.debug("Built user profile for userId {} within {} ms", userId, (System.currentTimeMillis()-startTime));
        return userProfile;
    }

    // TODO, refactor this, not a good solution IMHO - Liam
    /* (non-Javadoc)
     * @see com.crayondata.choice.userprofile.IUserProfileContextHolder#buildTempUserProfile(int, com.crayondata.choice.rateableitem.Category, java.lang.Iterable)
     */
    @Override
    public T buildTempUserProfile(int userId, Category cat, Iterable<Integer> itemIds) {
        final Table<Category, InteractionType, Iterable<UserInteraction>> userLikes = HashBasedTable.create();

        for (Category itemCategory : Category.values()) {
            Collection<UserInteraction> catInteractions;
            if (itemCategory.equals(cat)) {
                catInteractions = new ArrayList<>();
                for (Integer itemId : itemIds) {
                    UserInteraction interaction = new UserInteraction(Like, cat, userId,
                            itemId);
                    catInteractions.add(interaction);
                }
            } else
                catInteractions = ImmutableList.of();
            userLikes.put(itemCategory, Like, catInteractions);
        }

        T userProfile = buildUserProfile(userId, userLikes);
        LOG.debug("Creating temp user profile for user {} with items: {} for similarTo recommendation generation", userId, itemIds);
        LOG.debug("UserProfile: {}", userProfile);

        return userProfile;
    }

    /* (non-Javadoc)
     * @see com.crayondata.choice.userprofile.IUserProfileContextHolder#buildUserProfile(int, com.google.common.collect.Table)
     */
    @Override
    public T buildUserProfile(int userId,
            Table<Category, InteractionType, Iterable<UserInteraction>> userInteractions) {
        return (T) userProfileBuilder.build(userId, userInteractions);
    }

    protected final Table<Category, InteractionType, Iterable<UserInteraction>> loadInteractionsToBuildProfile(
            int userId) {
    	long startTime = System.currentTimeMillis();
        final Table<Category, InteractionType, Iterable<UserInteraction>> userInteractions = HashBasedTable
                .create();
        // TODO optimize with one DAO call, move into service first
        for (Category itemCategory : EnumSet.complementOf(EnumSet.of(CROSS))) {
            final Iterable<UserInteraction> userCategoryLikes = userInteractionDAO
                    .getByUserIdAndItemCategoryAndType(userId, itemCategory, Like, Dislike, Later, WishList);
            
            List<UserInteraction> likes = new ArrayList<>();
            List<UserInteraction> dislikes = new ArrayList<>();
            List<UserInteraction> laters = new ArrayList<>();
            List<UserInteraction> wishLists = new ArrayList<>();
            
            userCategoryLikes.forEach(interaction -> {
            	switch (interaction.getType()){
            		case Like : likes.add(interaction);
            		break;
            		case Dislike : dislikes.add(interaction);
            		break;
            		case Later : laters.add(interaction);
            		break;
            		case WishList : wishLists.add(interaction);
            		break;
            	}
            });
            
            userInteractions.put(itemCategory, Like, likes);
            userInteractions.put(itemCategory, Dislike, dislikes);
            userInteractions.put(itemCategory, Later, laters);
            userInteractions.put(itemCategory, WishList, wishLists);
        }
        LOG.debug("Loaded user interaction for user {} within {} ms", userId, (System.currentTimeMillis()-startTime));
        return userInteractions;
    }
}
