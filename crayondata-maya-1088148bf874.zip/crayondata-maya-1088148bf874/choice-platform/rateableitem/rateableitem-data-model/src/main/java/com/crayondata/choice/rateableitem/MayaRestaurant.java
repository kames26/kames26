/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.choice.rateableitem;

import java.util.Collection;

/**
 * Inherits all properties from LocalBusiness class.
 * 
 * @author vivek
 *
 */
public class MayaRestaurant extends LocalBusiness {
    protected Collection<String> contextTag;
    protected Collection<String> personaTag;
    protected Collection<String> populistTag;
    protected String dateTime;

    public MayaRestaurant() {}

    public String getDateTime() {
        return dateTime;
    }

    public void setDateTime(String dateTime) {
        this.dateTime = dateTime;
    }

    public Collection<String> getPersonaTag() {
        return returnCollection(personaTag);
    }

    public void setPersonaTag(Collection<String> personaTag) {
        this.personaTag = personaTag;
    }

    public Collection<String> getPopulistTag() {
        return returnCollection(populistTag);
    }

    public void setPopulistTag(Collection<String> populistTag) {
        this.populistTag = populistTag;
    }

    public Collection<String> getContextTag() {
        return returnCollection(contextTag);
    }

    public void setContextTag(Collection<String> contextTag) {
        this.contextTag = contextTag;
    }
    
    @Override
    public String toString() {
        return "MayaRestaurant [contextTag=" + contextTag + ", personaTag=" + personaTag + ", populistTag="
                + populistTag + ", super.toString()=" + super.toString() + "]";
    }
}
