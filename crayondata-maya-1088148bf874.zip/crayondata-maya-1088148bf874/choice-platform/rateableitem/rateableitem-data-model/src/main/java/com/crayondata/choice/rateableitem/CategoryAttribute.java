/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.choice.rateableitem;

/**
 * Data model object for storing different possible values of category attribute
 * values. Each of possible values of any category attribute will be stored
 * here. For example cuisine is a type of attribute and Chinese, Thai, Italian
 * could be different values. Each of it will have an entry here with following
 * values, category - Restaurant attributeType - cuisine attributeValue -
 * Chinese or Thai or Italian There will be 3 entries with each these attribute
 * value.
 *
 * @author vivek
 *
 */
public class CategoryAttribute {
    protected Integer id;

    protected Category category;

    protected String attributeType;

    protected String attributeValue;

    protected String description;

    public Integer getId() {
        return id;
    }

    public Category getCategory() {
        return category;
    }

    public String getAttributeType() {
        return attributeType;
    }

    public String getAttributeValue() {
        return attributeValue;
    }

    public String getDescription() {
        return description;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public void setCategory(Category category) {
        this.category = category;
    }

    public void setAttributeType(String attributeType) {
        this.attributeType = attributeType;
    }

    public void setAttributeValue(String attributeValue) {
        this.attributeValue = attributeValue;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public CategoryAttribute() {
        super();
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("{id: ").append(this.id).append(", category: ").append(this.category)
                .append(", attrType: ").append(this.attributeType).append(", attrVal: ")
                .append(this.attributeValue).append("}");
        return builder.toString();
    }
}
