/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.choice.rateableitem;

import java.util.Map;

import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Ordering;

public class ItemScores {

    private Map<String, Float> recommenderScores;
    private Map<String, Float> rawRecommenderScores;

    public Map<String, Float> getRecommenderScores() {
        return recommenderScores;
    }

    public Map<String, Float> getRawRecommenderScores() {
        return rawRecommenderScores;
    }

    public void setRecommenderScores(Map<String, Float> recommenderScores) {
        this.recommenderScores = ImmutableMap.<String, Float> builder().putAll(recommenderScores)
                .orderEntriesByValue(Ordering.natural().reverse()).build();
    }

    public void setRawRecommenderScores(Map<String, Float> rawRecommenderScores) {
        this.rawRecommenderScores = ImmutableMap.<String, Float> builder().putAll(rawRecommenderScores)
                .orderEntriesByValue(Ordering.natural().reverse()).build();
    }

    @Override
    public String toString() {
        return "ItemScores [recommenderScores=" + recommenderScores + ", rawRecommenderScores="
                + rawRecommenderScores + "]";
    }
}
