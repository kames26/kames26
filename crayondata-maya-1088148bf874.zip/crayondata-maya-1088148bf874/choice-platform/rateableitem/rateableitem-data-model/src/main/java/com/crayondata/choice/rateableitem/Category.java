/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.choice.rateableitem;

import java.util.EnumSet;

public enum Category {
    // TODO remove CROSS as it is only applicable to web tier
    RESTAURANT, HOTEL, MOVIE, OTHER, CROSS;

    public static Category parseCategory(String cat) {
        final Category result;
        if (cat.equalsIgnoreCase("RESTAURANT"))
            result = Category.RESTAURANT;
        else if (cat.equalsIgnoreCase("HOTEL"))
            result = Category.HOTEL;
        else if (cat.equalsIgnoreCase("MOVIE"))
            result = Category.MOVIE;
        else if (cat.equalsIgnoreCase("CROSS"))
            result = Category.CROSS;
        else {
            result = Category.OTHER;
        }
        return result;
    }

    public static EnumSet<Category> LOCAL_BUSINESS_TYPES = EnumSet.of(RESTAURANT, HOTEL, OTHER);

    public boolean isLocalBusiness() {
        return LOCAL_BUSINESS_TYPES.contains(this);
    }

    public boolean isCreativeWork() {
        if (this.equals(MOVIE)) {
            return true;
        }
        return false;
    }
}
