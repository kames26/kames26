/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.choice.rateableitem;

import java.util.Optional;

import com.google.gson.annotations.SerializedName;

public class ItemSummary {

	protected static final String CATEGORY_FIELD = "category";
	protected static final String IMAGE_FIELD = "image";
	protected static final String DESCRIPTION_FIELD = "description";
	protected static final String ID_FIELD = "id";
	protected static final String NAME_FIELD = "name";
	protected static final String ADDITIONAL_INFO_FIELD = "additional_info";
	protected static final String AGGREGATERATING_FIELD = "aggregaterating";

	protected int id;

	protected String name;

	protected String description;

	protected String image;

	protected String category;

	protected String additionalInfo;

	protected String externalCategory;

	@SerializedName(value = "aggregaterating")
	protected Integer aggregateRating;

	// TODO These fields are transient and should NOT be here. - Liam
	protected Optional<ItemScores> itemScores = Optional.of(new ItemScores());

	protected int choiceBatchId;
	protected String explanator;
	protected double score;

	protected boolean hasOffer;

	// Use a ScoredItem or something similar to:
	// com.crayondata.mayaconsumer.model.MayaItemSummary.UserItemView in web
	// tier.
	// The data tier should not know about the recommendation layer. We want to
	// cache these objects.
	public ItemSummary() {
	}

	public ItemSummary(int id, String name, String description, String image, Category category) {
		super();
		this.id = id;
		this.name = name;
		this.description = description;
		this.image = image;
		this.category = category.toString();
	}

	public Optional<ItemScores> getItemScores() {
		return itemScores;
	}

	public int getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	public String getDescription() {
		return description;
	}

	public String getImage() {
		return this.image;
	}

	public String getExplanator() {
		return explanator;
	}

	public int getChoiceBatchId() {
		return choiceBatchId;
	}

	public String getCategory() {
		return category;
	}

	public double getScore() {
		return score;
	}

	public void setId(int id) {
		this.id = id;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public void setImage(String image) {
		this.image = image;
	}

	public void setChoiceBatchId(int choiceBatchId) {
		this.choiceBatchId = choiceBatchId;
	}

	public void setExplanator(String explanator) {
		this.explanator = explanator;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public void setScore(double score) {
		this.score = score;
	}

	protected void setExternalCategory(String externalCategory) {
		this.externalCategory = externalCategory;
	}

	protected void setHasOffer(boolean hasOffer) {
		this.hasOffer = hasOffer;
	}

	public String getExternalCategory() {
		return externalCategory;
	}

	public boolean hasOffer() {
		return hasOffer;
	}

	public Optional<Integer> getAggregateRating() {
		return Optional.ofNullable(aggregateRating);
	}

	public void setAggregateRating(Integer aggregateRating) {
		this.aggregateRating = aggregateRating;
	}

	public String getAdditionalInfo() {
		return additionalInfo;
	}

	public void setAdditionalInfo(String additionalInfo) {
		this.additionalInfo = additionalInfo;
	}

	@Override
	public String toString() {
		return "ItemSummary [id=" + id + ", name=" + name + ", description=" + description + ", image=" + image
				+ ", category=" + category + ", additionalInfo=" + additionalInfo + ", externalCategory="
				+ externalCategory + ", itemScores=" + itemScores + ", choiceBatchId=" + choiceBatchId + ", explanator="
				+ explanator + ", score=" + score + ", hasOffer=" + hasOffer + "]";
	}
}
