/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.choice.rateableitem;

import java.util.Collection;
import java.util.Collections;

import com.google.gson.annotations.SerializedName;

public class LocalBusiness extends ItemSummary implements RateableItem {

	protected String address;

	@SerializedName(value = "addresscity")
	protected String addressCity;

	protected String geo;

	@SerializedName(value = "addresscountry")
	protected String addressCountry;

	protected String telephone;

	protected String email;

	protected String website;

	protected Collection<String> amenities;

	protected int brand;

	/* Hotel related rating used in attribute based model */
	@SerializedName(value = "cleanlinessrating")
	protected int cleanlinessRating;

	@SerializedName(value = "locationrating")
	protected int locationRating;
	/* Hotel related rating used in attribute based model end here */

	/* Restaurant related rating used in attribute based model */
	@SerializedName(value = "ambiencerating")
	protected int ambienceRating;

	@SerializedName(value = "foodrating")
	protected int foodRating;
	/* Restaurant related rating used in attribute based model end here */

	/* Common rating for both hotel and restaurants used in attribute model */
	@SerializedName(value = "servicerating")
	protected int serviceRating;

	@SerializedName(value = "valuerating")
	protected int valueRating;
	/*
	 * Common rating for both hotel and restaurants used in attribute model end
	 * here
	 */

	protected Collection<String> hstyle;

	protected Collection<String> cuisines;

	protected Collection<String> options;

	private Boolean specialty;

	@SerializedName(value = "pricerange")
	protected String priceRange;

	protected boolean isSpeciality;

	protected float sentiment;

	protected Collection<String> keywords;

	private double distance;

	public float getSentiment() {
		return sentiment;
	}

	public Collection<String> getKeywords() {
		return keywords;
	}

	public boolean isSpeciality() {
		return isSpeciality;
	}

	public Collection<String> getHstyle() {
		return returnCollection(hstyle);
	}

	public void setHstyle(Collection<String> hstyle) {
		this.hstyle = hstyle;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getAddressCity() {
		return addressCity;
	}

	public void setAddressCity(String addressCity) {
		this.addressCity = addressCity;
	}

	public String getGeo() {
		return geo;
	}

	public void setGeo(String geo) {
		this.geo = geo;
	}

	public String getAddressCountry() {
		return addressCountry;
	}

	public void setAddressCountry(String addressCountry) {
		this.addressCountry = addressCountry;
	}

	public String getTelephone() {
		return telephone;
	}

	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getWebsite() {
		return website;
	}

	public void setWebsite(String website) {
		this.website = website;
	}

	public Collection<String> getAmenities() {
		return returnCollection(amenities);
	}

	public void setAmenities(Collection<String> amenities) {
		this.amenities = amenities;
	}

	public int getBrand() {
		return brand;
	}

	public void setBrand(int brand) {
		this.brand = brand;
	}

	public Integer getCleanlinessRating() {
		return cleanlinessRating;
	}

	public void setCleanlinessRating(Integer cleanlinessRating) {
		this.cleanlinessRating = cleanlinessRating;
	}

	public Integer getLocationRating() {
		return locationRating;
	}

	public void setLocationRating(Integer locationRating) {
		this.locationRating = locationRating;
	}

	public Integer getAmbienceRating() {
		return ambienceRating;
	}

	public void setAmbienceRating(Integer ambienceRating) {
		this.ambienceRating = ambienceRating;
	}

	public Integer getServiceRating() {
		return serviceRating;
	}

	public void setServiceRating(Integer serviceRating) {
		this.serviceRating = serviceRating;
	}

	public Integer getValueRating() {
		return valueRating;
	}

	public void setValueRating(Integer valueRating) {
		this.valueRating = valueRating;
	}

	public Integer getFoodRating() {
		return foodRating;
	}

	public void setFoodRating(Integer foodRating) {
		this.foodRating = foodRating;
	}

	public Collection<String> getOptions() {
		return returnCollection(options);
	}

	public void setOptions(Collection<String> options) {
		this.options = options;
	}

	public Boolean getSpecialty() {
		return specialty;
	}

	public void setSpecialty(Boolean specialty) {
		this.specialty = specialty;
	}

	public String getPriceRange() {
		return priceRange;
	}

	public void setPriceRange(String priceRange) {
		this.priceRange = priceRange;
	}

	public Collection<String> getCuisines() {
		return returnCollection(cuisines);
	}

	public void setCuisines(Collection<String> cuisines) {
		this.cuisines = cuisines;
	}

	protected static <T> Collection<T> returnCollection(Collection<T> collection) {
		if (collection == null) {
			return Collections.emptyList();
		}
		return collection;
	}

	public double getDistance() {
		return distance;
	}

	public void setDistance(double distance) {
		this.distance = distance;
	}

	@Override
	public String toString() {
		return "LocalBusiness [address=" + address + ", addressCity=" + addressCity + ", geo=" + geo
				+ ", addressCountry=" + addressCountry + ", telephone=" + telephone + ", email=" + email + ", website="
				+ website + ", amenities=" + amenities + ", brand=" + brand + ", cleanlinessRating=" + cleanlinessRating
				+ ", locationRating=" + locationRating + ", ambienceRating=" + ambienceRating + ", foodRating="
				+ foodRating + ", serviceRating=" + serviceRating + ", valueRating=" + valueRating + ", hstyle="
				+ hstyle + ", aggregateRating=" + aggregateRating + ", cuisines=" + cuisines + ", options=" + options
				+ ", specialty=" + specialty + ", priceRange=" + priceRange + ", isSpeciality=" + isSpeciality
				+ ", sentiment=" + sentiment + ", keywords=" + keywords + ", distance=" + distance + ", toString()="
				+ super.toString() + "]";
	}
}
