/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.choice.rateableitem;

import java.util.Collection;
import java.util.Collections;

import com.google.gson.annotations.SerializedName;

public class CreativeWork extends ItemSummary implements RateableItem {

	@SerializedName(value = "datepublished")
	protected String datePublished;

	protected Collection<String> director;

	protected Collection<String> author;

	protected Collection<String> cast;

	@SerializedName(value = "timerequired")
	protected String timeRequired;

	protected Collection<String> genre;

	protected Collection<String> producer;

	@SerializedName(value = "filtrateScore")
	protected double fillRateScore;

	@SerializedName(value = "contentrating")
	protected String contentRating;

	public String getContentRating() {
		return contentRating;
	}

	public void setContentRating(String contentRating) {
		this.contentRating = contentRating;
	}

	@Override
	public int getId() {
		return id;
	}

	@Override
	public void setId(int id) {
		this.id = id;
	}

	public String getDatePublished() {
		return datePublished;
	}

	public void setDatePublished(String datePublished) {
		this.datePublished = datePublished;
	}

	public Collection<String> getDirector() {
		return returnCollection(director);
	}

	public void setDirector(Collection<String> director) {
		this.director = director;
	}

	public Collection<String> getAuthor() {
		return returnCollection(author);
	}

	public void setAuthor(Collection<String> author) {
		this.author = author;
	}

	public Collection<String> getCast() {
		return returnCollection(cast);
	}

	public void setCast(Collection<String> cast) {
		this.cast = cast;
	}

	public String getTimeRequired() {
		return timeRequired;
	}

	public void setTimeRequired(String timeRequired) {
		this.timeRequired = timeRequired;
	}

	public Collection<String> getProducer() {
		return returnCollection(producer);
	}

	public void setProducer(Collection<String> producer) {
		this.producer = producer;
	}

	public Collection<String> getGenre() {
		return returnCollection(genre);
	}

	public void setGenre(Collection<String> genre) {
		this.genre = genre;
	}

	private static <T> Collection<T> returnCollection(Collection<T> collection) {
		if (collection == null) {
			// System.err.println("This CreativeWork(" + getId() +
			// ") has a null collection: " + this);
			return Collections.emptyList();
		}
		return collection;
	}

	@Override
	public String toString() {
		return "CreativeWork [id=" + id + ", name=" + name + ", datePublished=" + datePublished + ", additionalInfo="
				+ additionalInfo + ", description=" + description + ", image=" + image + ", director=" + director
				+ ", author=" + author + ", cast=" + cast + ", category=" + category + ", timeRequired=" + timeRequired
				+ ", genre=" + genre + ", aggregateRating=" + aggregateRating + ", producer=" + producer
				+ ", fillRateScore=" + fillRateScore + ", contentRating=" + contentRating + ", itemScores=" + itemScores
				+ ", choiceBatchId=" + choiceBatchId + ", explanator=" + explanator + ", score=" + score + "]";
	}

	public CreativeWork() {
	}
}
