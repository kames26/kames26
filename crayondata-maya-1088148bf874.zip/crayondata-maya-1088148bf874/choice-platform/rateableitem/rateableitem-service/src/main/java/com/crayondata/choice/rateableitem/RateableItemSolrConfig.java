/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.choice.rateableitem;

import org.apache.solr.client.solrj.SolrClient;
import org.apache.solr.client.solrj.impl.HttpSolrClient;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.solr.server.SolrClientFactory;
import org.springframework.data.solr.server.support.MulticoreSolrClientFactory;

@Configuration
public class RateableItemSolrConfig {

    @Bean
    public SolrClientFactory solrClientFactory(@Value("${solr.server.host}") String solrHost,
            @Value("${solr.server.port}") String solrPort) {
        final String solrBaseUrl = String.format("http://%s:%s/solr/", solrHost, solrPort);
        final SolrClient solrClient = new HttpSolrClient(solrBaseUrl);
        final MulticoreSolrClientFactory factory = new MulticoreSolrClientFactory(solrClient, "LocalBusiness",
                "CreativeWork");
        return factory;
    }

    @Bean(name = "solrClientLocalBusiness")
    public SolrClient solrClientLocalBusiness(SolrClientFactory solrClientFactory) {
        return solrClientFactory.getSolrClient("LocalBusiness");
    }

    @Bean(name = "solrClientCreativeWork")
    public SolrClient solrClientCreativeWork(SolrClientFactory solrClientFactory) {
        return solrClientFactory.getSolrClient("CreativeWork");
    }
}
