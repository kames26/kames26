/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.choice.rateableitem;

import static com.crayondata.choice.rateableitem.Category.HOTEL;
import static com.crayondata.choice.rateableitem.Category.MOVIE;
import static com.crayondata.choice.rateableitem.Category.OTHER;
import static com.crayondata.choice.rateableitem.Category.RESTAURANT;
import static org.apache.solr.client.solrj.SolrRequest.METHOD.POST;

import java.io.IOException;
import java.net.URLDecoder;
import java.util.Collection;
import java.util.Collections;
import java.util.concurrent.TimeUnit;

import org.apache.solr.client.solrj.SolrClient;
import org.apache.solr.client.solrj.SolrQuery;
import org.apache.solr.client.solrj.SolrServerException;
import org.apache.solr.client.solrj.response.QueryResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.solr.core.RequestMethod;
import org.springframework.data.solr.core.SolrTemplate;
import org.springframework.data.solr.core.convert.SolrJConverter;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.crayondata.choice.rateableitem.solr.CreativeWorkBean;
import com.crayondata.choice.rateableitem.solr.LocalBusinessBean;
import com.google.common.base.Stopwatch;
import com.google.common.collect.ImmutableMap;

@Service
public class RateableItemService {

    private static final Logger LOG = LoggerFactory.getLogger(RateableItemService.class);

    private final SolrCoreAccessorFactory solrCoreAccessorFactory;

    @Autowired
    public RateableItemService(SolrCoreAccessorFactory solrCoreAccessorFactory) {
        this.solrCoreAccessorFactory = solrCoreAccessorFactory;
    }

    public <T extends RateableItem> Collection<? extends RateableItem> sendRecommenderQueryToSolr(
            Category category, SolrQuery solrQuery) {
        final Stopwatch sw = Stopwatch.createStarted();

        final SolrTemplate solrTemplate = getCoreAccessor(category);
        final Class<? extends RateableItem> entityClazz = getSolrEntityClass(category);

        try {
            final QueryResponse queryResponse = solrTemplate.getSolrClient().query(solrQuery, POST);

            final Collection<? extends RateableItem> results = solrTemplate
                    .convertQueryResponseToBeans(queryResponse, entityClazz);

            LOG.debug("{} | {} records | {}ms | {}", solrTemplate.getSolrCore(), results.size(),
                    sw.elapsed(TimeUnit.MILLISECONDS), URLDecoder.decode(solrQuery.toString(), "UTF-8"));
            return results;
        } catch (SolrServerException | IOException e) {
            LOG.warn("Problem sending query({}) to Solr", solrQuery, e);
            return Collections.emptyList();
        }
    }

    private SolrTemplate getCoreAccessor(Category category) {
        return this.solrCoreAccessorFactory.get(category);
    }

    private Class<? extends RateableItem> getSolrEntityClass(Category category) {
        if (category.isLocalBusiness()) {
            return LocalBusinessBean.class;
        }
        return CreativeWorkBean.class;
    }

    @Component
    public static class SolrCoreAccessorFactory {
        private final ImmutableMap<Category, SolrTemplate> coreAccessors;

        @Autowired
        public SolrCoreAccessorFactory(
                @Qualifier("solrClientLocalBusiness") SolrClient solrClientLocalBusiness,
                @Qualifier("solrClientCreativeWork") SolrClient solrClientCreativeWork) {

            final SolrTemplate localBusinessSolrTemplate = buildSolrTemplate(solrClientLocalBusiness);
            final SolrTemplate cwSolrTemplate = buildSolrTemplate(solrClientCreativeWork);

            this.coreAccessors = ImmutableMap.<Category, SolrTemplate> builder()
                    .put(HOTEL, localBusinessSolrTemplate).put(RESTAURANT, localBusinessSolrTemplate)
                    .put(OTHER, localBusinessSolrTemplate).put(MOVIE, cwSolrTemplate).build();
        }

        private static SolrTemplate buildSolrTemplate(SolrClient solrClient) {
            // TODO, request method should be POST
            final SolrTemplate rateableItemSolrTemplate = new SolrTemplate(solrClient);
            rateableItemSolrTemplate.setSolrConverter(new SolrJConverter());
            return rateableItemSolrTemplate;
        }

        SolrTemplate get(Category category) {
            return this.coreAccessors.get(category);
        }
    }
}
