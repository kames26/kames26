java -jar graph-generation-v2-0.1-SNAPSHOT.jar run.conf
/home/thien/Downloads/spark-1.5.2-bin-hadoop2.4/bin/spark-submit --class "com.crayondata.tg.data.adaptor.ItemDetailsToTGMapper"  spark_eval-0.0.1-SNAPSHOT.jar hdfs://localhost:9000/user/thien/rest_details_latest /home/thien/demo-2016-03-16/tg-output/niche /home/thien/demo-2016-03-16/tg-output/popular /home/thien/demo-2016-03-16/tg-output/discovery merge-output3
java -jar publish-solr-0.0.1-SNAPSHOT.jar morphline.conf merge-output3
