/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.export.solr;

import com.typesafe.config.Config;
import com.typesafe.config.ConfigFactory;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileStatus;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.kitesdk.morphline.api.Command;
import org.kitesdk.morphline.api.MorphlineContext;
import org.kitesdk.morphline.api.Record;
import org.kitesdk.morphline.base.Compiler;
import org.kitesdk.morphline.base.Fields;
import org.kitesdk.morphline.base.Notifications;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.URI;
import java.util.List;

public class ExportDriver {
    /**
     * Usage: java ... <morphlines.conf> <dataFile1> ... <dataFileN>
     *
     * @throws IOException
     */
    public static void main(String[] args) throws IOException {
        Path pt = new Path(args[0]);
        Configuration conf = new Configuration();
        FileSystem fs = FileSystem.get(URI.create(args[0]), conf);
        Reader reader = new InputStreamReader(fs.open(pt));
        Config morphlineConfig = ConfigFactory.parseReader(reader).resolve();
        List<? extends Config> newConfig = morphlineConfig.getConfigList("morphlines");
        Config firstConfig;
        if (newConfig.size() > 0) {
            firstConfig = newConfig.get(0);
        } else {
            System.err.println("No 'morphlines' available in the config file");
            return;
        }
        MorphlineContext context = new MorphlineContext.Builder().build();
        Command morphline = new Compiler().compile(firstConfig, context, null);
        FileStatus[] files = fs.listStatus(new Path(args[1]));
        // Process each input data file
        long start = System.currentTimeMillis();
        Notifications.notifyBeginTransaction(morphline);
        for (FileStatus file : files) {
            if (file.isFile() && file.getPath().getName().endsWith(".avro")) {
                InputStream in = fs.open(file.getPath());
                Record record = new Record();
                record.put(Fields.ATTACHMENT_BODY, in);
                morphline.process(record);
                in.close();
            }
        }
        Notifications.notifyCommitTransaction(morphline);
        Notifications.notifyShutdown(morphline);
        fs.close();
        long end = System.currentTimeMillis();
        System.out.println("Complete. Took: " + (end - start) + " ms");
    }
}
