/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.choice.rateableitem.solr;

import static org.junit.Assert.assertNotNull;

import java.io.File;
import java.io.IOException;
import java.io.StringReader;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.Arrays;
import java.util.Collection;
import java.util.concurrent.TimeUnit;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVPrinter;
import org.apache.solr.client.solrj.SolrClient;
import org.apache.solr.client.solrj.impl.HttpSolrClient;
import org.junit.Ignore;
import org.junit.Test;
import org.springframework.data.solr.core.SolrTemplate;
import org.springframework.data.solr.core.query.SimpleTermsQuery;
import org.springframework.data.solr.core.query.TermsQuery;
import org.springframework.data.solr.core.query.result.TermsFieldEntry;
import org.springframework.data.solr.core.query.result.TermsPage;

import com.crayondata.choice.rateableitem.Category;
import com.crayondata.choice.rateableitem.LocalBusiness;
import com.google.common.base.Charsets;
import com.google.common.base.Stopwatch;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.Iterables;
import com.google.common.io.Files;
import com.google.common.io.Resources;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.stream.JsonReader;

public class LocalBusinessDAOTest {

    private static final String localBusinessCoreUrl = "http://52.221.223.66:8983/solr/LocalBusiness";
    private static final String creativeWorkCoreUrl = "http://52.221.223.66:8983/solr/CreativeWork";

    private static LocalBusinessDAOImpl localBusinessDAOImpl = null;
    private Collection<LocalBusiness> localBusinesses;

    // @Before
    public void setUp() throws IOException {
//        SolrAccessorFactory saf = EmbeddedSolrAccessorFactory.create();
        localBusinessDAOImpl = new LocalBusinessDAOImpl(null, null);
        assertNotNull(localBusinessDAOImpl);

        final JsonReader localBusinessJsonReader = buildRateableItemJsonReader("localBusiness.json");
        final Gson gson = new GsonBuilder().create();
        final LocalBusiness[] localBusinessBeans = gson.fromJson(localBusinessJsonReader,
                LocalBusiness[].class);
        localBusinessJsonReader.close();
        this.localBusinesses = ImmutableList.copyOf(localBusinessBeans);
    }

    @Test
    @Ignore
    public void testGetAttributeValuesStartsWithFromTermsComponent() throws IOException {
        String categoryField = "cast";
        final String[] prefixes = new String[] { "to", "lia", "viv", "so", "pat", "bra", "To" };
        for (String prefix : prefixes) {
            getTermsStartsWith(categoryField, prefix);
        }
    }

    @Test
    @Ignore
    public void testGetAttributeValuesFromTermsComponent() throws IOException {

        File file = new File("./target/terms.csv");
        final Appendable out = Files.newWriter(file, Charset.defaultCharset());
        final CSVPrinter printer = CSVFormat.DEFAULT
                .withHeader("id", "category", "attributeType", "attributeValue").print(out);

        final String[] creativeWorkCategoryFields = new String[] { "cast", "director", "genre" };

        generateTermsCsvFromCore(Category.MOVIE, creativeWorkCategoryFields, creativeWorkCoreUrl, printer);
        final String[] localBusinessCategoryFields = new String[] { "cuisines", "type", "amenities" };

        generateTermsCsvFromCore(Category.RESTAURANT, localBusinessCategoryFields, localBusinessCoreUrl,
                printer);

        printer.close();
    }

    private static void getTermsStartsWith(String categoryField, final String prefix) throws IOException {
        final TermsQuery termsQuery = SimpleTermsQuery.queryBuilder().fields(categoryField)
                .limit(Integer.MAX_VALUE).prefix(prefix.toLowerCase()).build();
        final Stopwatch stopwatch = Stopwatch.createStarted();

        try (SolrClient solrClient = new HttpSolrClient(creativeWorkCoreUrl)) {
            final SolrTemplate solrTemplate = new SolrTemplate(solrClient);
            final TermsPage termsPage = solrTemplate.queryForTermsPage(termsQuery);

            System.out.println("Retrieving: " + Iterables.size(termsPage) + " terms for field("
                    + categoryField + ") and prefix: '" + prefix + "' took: "
                    + stopwatch.elapsed(TimeUnit.MILLISECONDS) + "ms");
            // termsPage.forEach(item -> System.out.println(item.getValue()));
        }
    }

    private static void generateTermsCsvFromCore(Category category, final String[] categoryFields,
            final String coreUrl, CSVPrinter printer) throws IOException {
        final TermsQuery termsQuery = SimpleTermsQuery.queryBuilder().fields(categoryFields)
                .limit(Integer.MAX_VALUE).build();
        final Stopwatch stopwatch = Stopwatch.createStarted();

        try (SolrClient solrClient = new HttpSolrClient(coreUrl)) {
            final SolrTemplate solrTemplate = new SolrTemplate(solrClient);
            final TermsPage termsPage = solrTemplate.queryForTermsPage(termsQuery);

            System.out.println("Downloading: " + Iterables.size(termsPage) + " terms for fields("
                    + Arrays.toString(categoryFields) + ") took: " + stopwatch.elapsed(TimeUnit.MILLISECONDS)
                    + "ms");

            int i = 0;

            for (TermsFieldEntry termsFieldEntry : termsPage) {
                printer.printRecord(i++, category, termsFieldEntry.getKey(), termsFieldEntry.getValue());
                // System.out.println("The value: '" +
                // termsFieldEntry.getValue() + "' occurs: "
                // + termsFieldEntry.getValueCount() + " times for field: " +
                // termsFieldEntry.getKey());
            }
        }
    }

    @Test
    @Ignore
    public void testGetLocalBusinessById() {
        LocalBusiness localBusiness = localBusinessDAOImpl.findOne(700000012);
        assertNotNull(localBusiness);
        for (LocalBusiness localBusinessTest : localBusinesses) {
            // assertEquals(localBusiness1, localBusiness);
            assertNotNull(localBusinessTest);

        }
    }

    private static JsonReader buildRateableItemJsonReader(String resourceName) throws IOException {

        final URL rateableItemJsonUrl = Resources.getResource(resourceName);
        final String rateableItemJson = Resources.toString(rateableItemJsonUrl, Charsets.UTF_8);
        final StringReader rateableItemReader = new StringReader(rateableItemJson);
        final JsonReader rateableItemJsonReader = new JsonReader(rateableItemReader);
        rateableItemJsonReader.setLenient(true);
        return rateableItemJsonReader;
    }
}
