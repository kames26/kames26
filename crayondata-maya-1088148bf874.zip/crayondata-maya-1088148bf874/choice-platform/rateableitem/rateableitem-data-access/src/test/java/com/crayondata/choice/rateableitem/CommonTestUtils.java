/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.choice.rateableitem;

import java.lang.reflect.InvocationTargetException;
import java.util.Collection;
import java.util.Map;

import org.apache.commons.beanutils.BeanUtils;

import com.google.common.collect.Sets;

public class CommonTestUtils {
    public static <T> boolean equalsCheck(T passed, T created, boolean ignoreId)
            throws IllegalAccessException, InvocationTargetException, NoSuchMethodException {
        Map<String, String> src = BeanUtils.describe(passed);
        Map<String, String> dest = BeanUtils.describe(created);

        /*
         * System.out.println("Src::" + src); System.out.println("Dest::" +
         * dest);
         */

        /* if(ignoreId){ */
        src.remove("id");
        dest.remove("id");
        // }
        src.remove("class");
        dest.remove("class");

        // Collection<String> srcVals = src.values();
        // Collection<String> destVals = dest.values();
        // srcVals.removeAll(destVals);
        Collection<String> diffVals = Sets.symmetricDifference(Sets.newHashSet(src.values()),
                Sets.newHashSet(dest.values()));
        if (!diffVals.isEmpty()) {
            System.err.println(
                    "Entities(" + src + " AND " + dest + ") do not match due to these values: " + diffVals);
        }
        return diffVals.isEmpty();
    }

}
