/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.choice.rateableitem;

import java.io.IOException;
import java.io.StringReader;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;

import javax.annotation.Nullable;

import com.crayondata.choice.userprofile.Person;
import com.crayondata.choice.userprofile.UserInteraction;
import com.crayondata.choice.userprofile.UserInteraction.InteractionType;
import com.google.common.base.Charsets;
import com.google.common.base.Preconditions;
import com.google.common.io.Resources;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.stream.JsonReader;

public class JsonToSolrBeanUtil {

    public static <T> Collection<T> parseJsonFile(URL jsonFile, Class<T> classRef) throws IOException {
        String text = Resources.toString(jsonFile, Charsets.UTF_8);
        return parseJsonFile(text, classRef);
    }

    private static <T> Collection<T> parseJsonFile(String jsonText, Class<T> classRef) {
        JsonParser parser = new JsonParser();
        JsonElement personList = parser.parse(jsonText);

        JsonArray beanArray = personList.getAsJsonArray();
        int size = beanArray.size();

        Collection<T> result = new ArrayList<>();
        for (int i = 0; i < size; i++) {
            JsonObject json = beanArray.get(i).getAsJsonObject();
            result.add(parseJsonToBean(json, classRef));
        }

        return result;
    }

    /**
     * Parses the given json object into the PersonBean object.
     *
     * @param json
     *            The input json object.
     * @return Returns the Bean object.
     */
    @Nullable
    private static <T> T parseJsonToBean(JsonObject json, Class<T> classRef) {

        final T result;

        if (classRef == CategoryAttribute.class) {
            CategoryAttribute bean = new CategoryAttribute();

            final String asString = json.get("category").getAsString();
            bean.setCategory(Category.valueOf(asString));
            bean.setAttributeType(json.get("attributeType").getAsString());
            bean.setAttributeValue(json.get("attributeValue").getAsString());
            bean.setDescription(json.get("description").getAsString());

            result = (T) bean;
        } else if (classRef == MayaRestaurant.class) {
            MayaRestaurant bean = new MayaRestaurant();

            bean.setName(json.get("name").getAsString());
            bean.setDescription(json.get("description").getAsString());

            bean.setAddressCountry(json.get("addresscountry").getAsString());
            bean.setTelephone(json.get("telephone").getAsString());

            result = (T) bean;
        } else if (classRef == MayaHotel.class) {
            MayaHotel bean = new MayaHotel();

            bean.setName(json.get("name").getAsString());
            bean.setDescription(json.get("description").getAsString());
            bean.setAddressCountry(json.get("addresscountry").getAsString());
            bean.setTelephone(json.get("telephone").getAsString());

            bean.setAmenities(extractMultipleValuesForField(json, "amenities"));
            result = (T) bean;
        } else if (classRef == MayaMovie.class) {
            MayaMovie bean = new MayaMovie();

            bean.setName(json.get("name").getAsString());
            bean.setDescription(json.get("description").getAsString());

            final Collection<String> director = extractMultipleValuesForField(json, "director");
            bean.setDirector(director);

            /*
             * final Collection<String> genreHigh =
             * extractMultipleValuesForField(json, "genre_High");
             * bean.setGenre_High(genreHigh);
             * 
             * final Collection<String> genreLow =
             * extractMultipleValuesForField(json, "genre_Low");
             * bean.setGenre_Low(genreLow);
             */

            result = (T) bean;
        } else if (classRef == UserInteraction.class) {
            UserInteraction bean = new UserInteraction();
            bean.setPerformer(json.get("performer").getAsInt());
            bean.setItemId(json.get("itemId").getAsInt());

            bean.setId(json.get("id").getAsInt());
            bean.setName(json.get("name").getAsString());
            /*
             * bean.setAlternateName(json.get("alternateName").getAsString());
             */

            /*
             * bean.setDescription(json.get("description").getAsString());
             * bean.setStartDate(json.get("startDate").getAsString());
             *
             * bean.setEndDate(json.get("endDate").getAsString());
             * bean.setDuration(json.get("duration").getAsString());
             */
            final String asString = json.get("type").getAsString();
            bean.setType(InteractionType.valueOf(asString));
            final String catAsString = json.get("itemCategory").getAsString();
            bean.setCategory(Category.valueOf(catAsString));
            /*
             * bean.setLocation(json.get("location").getAsString());
             * bean.setTimestamp(json.get("timestamp").getAsString());
             */

            result = (T) bean;
            // } else if (classRef == DeliveredChoices.class) {
            // DeliveredChoices bean = new DeliveredChoices();
            //
            // bean.setUserId(json.get("userId").getAsString());
            // bean.setItemId(json.get("itemId").getAsString());
            // bean.setChoiceBatchId(json.get("choiceBatchId").getAsInt());
            // bean.setNetScore(json.get("netScore").getAsDouble());
            //
            // result = (T) bean;

        } else if (classRef == Person.class) {
            Person bean = new Person();
            bean.setName(json.get("name").getAsString());
            bean.setUuid(json.get("uuid").getAsString());
            bean.setBirthDate(json.get("birthDate").getAsString());
            bean.setEmail(json.get("email").getAsString());
            bean.setGivenName(json.get("givenName").getAsString());
            bean.setFamilyName(json.get("familyName").getAsString());
            bean.setGender(json.get("gender").getAsString());
            bean.setJobTitle(json.get("jobTitle").getAsString());
            bean.setNationality(json.get("nationality").getAsString());
            bean.setWeight(json.get("weight").getAsString());
            bean.setTelephone(json.get("telephone").getAsString());
            bean.setAddressCountry(json.get("addressCountry").getAsString());
            bean.setAddressCity(json.get("addressCity").getAsString());
            bean.setPostalCode(json.get("postalCode").getAsString());
            bean.setBirthCountry(json.get("birthCountry").getAsString());
            bean.setWorkCity(json.get("workCity").getAsString());
            bean.setWorkCountry(json.get("workCountry").getAsString());

            result = (T) bean;
        } else {
            result = null;
        }

        return result;
    }

    private static Collection<String> extractMultipleValuesForField(JsonObject json, final String fieldName) {
        final JsonElement jsonElement = json.get(fieldName.toLowerCase());
        if (jsonElement == null) {
            System.err.println("No value found for field: " + fieldName);
            return Collections.emptyList();
        }
        if (!jsonElement.isJsonArray()) {
            System.err.println("Field: " + fieldName + " is not a valid JSON array: " + jsonElement);
            return Collections.emptyList();
        }

        final JsonArray jsonElementAsArray = jsonElement.getAsJsonArray();
        final Collection<String> strArrFromJsonArr = getStrArrFromJsonArr(jsonElementAsArray);
        return strArrFromJsonArr;
    }

    public static JsonReader buildRateableItemJsonReader(String resourceName) throws IOException {

        final URL rateableItemJsonUrl = Resources.getResource(resourceName);
        final String rateableItemJson = Resources.toString(rateableItemJsonUrl, Charsets.UTF_8);
        final StringReader rateableItemReader = new StringReader(rateableItemJson);
        final JsonReader rateableItemJsonReader = new JsonReader(rateableItemReader);
        rateableItemJsonReader.setLenient(true);
        return rateableItemJsonReader;
    }

    /**
     * Converting the json array into collection of strings.
     *
     * @param jsonArr
     * @return
     */
    private static Collection<String> getStrArrFromJsonArr(JsonArray jsonArr) {
        Preconditions.checkNotNull(jsonArr);

        final Collection<String> result = new ArrayList<>();
        for (JsonElement jsonElement : jsonArr) {
            result.add(jsonElement.getAsString());
        }

        return result;
    }
}
