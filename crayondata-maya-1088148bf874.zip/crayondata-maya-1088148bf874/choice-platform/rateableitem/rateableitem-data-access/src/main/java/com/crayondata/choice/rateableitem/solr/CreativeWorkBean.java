/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.choice.rateableitem.solr;

import java.util.Collection;
import java.util.Map;

import org.apache.solr.client.solrj.beans.Field;
import org.springframework.data.solr.core.query.SimpleField;

import com.crayondata.choice.rateableitem.CreativeWork;
import com.crayondata.choice.rateableitem.Scorable;
import com.google.common.base.Joiner;

public class CreativeWorkBean extends CreativeWork implements Scorable {

    private static final String CONTENTRATING_FIELD = "contentrating";
    private static final String GENRE_FIELD = "genre";

    private static final String TIMEREQUIRED_FIELD = "timerequired";
    private static final String DATE_PUBLISHED_FIELD = "datepublished";

    private static final String CAST_FIELD = "cast";
    private static final String AUTHOR_FIELD = "author";
    private static final String DIRECTOR_FIELD = "director";
    private static final String PRODUCER_FIELD = "producer";

    public static final SimpleField FIELD_LIST = new SimpleField(Joiner.on(',').join(ID_FIELD, CATEGORY_FIELD,
            NAME_FIELD, IMAGE_FIELD, DESCRIPTION_FIELD, ADDITIONAL_INFO_FIELD, CONTENTRATING_FIELD,
            GENRE_FIELD, AGGREGATERATING_FIELD, TIMEREQUIRED_FIELD, DATE_PUBLISHED_FIELD, CAST_FIELD,
            AUTHOR_FIELD, DIRECTOR_FIELD, PRODUCER_FIELD));

    @Field(ID_FIELD)
    @Override
    public void setId(int id) {
        this.id = id;
    }

    @Field(NAME_FIELD)
    @Override
    public void setName(String name) {
        this.name = name;
    }

    @Field(DATE_PUBLISHED_FIELD)
    @Override
    public void setDatePublished(String datePublished) {
        this.datePublished = datePublished;
    }

    @Field(DESCRIPTION_FIELD)
    @Override
    public void setDescription(String description) {
        this.description = description;
    }

    @Field(IMAGE_FIELD)
    @Override
    public void setImage(String image) {
        this.image = image;
    }

    @Field(DIRECTOR_FIELD)
    @Override
    public void setDirector(Collection<String> director) {
        this.director = director;
    }

    @Field(AUTHOR_FIELD)
    @Override
    public void setAuthor(Collection<String> author) {
        this.author = author;
    }

    @Field(CAST_FIELD)
    @Override
    public void setCast(Collection<String> cast) {
        this.cast = cast;
    }

    @Field(CATEGORY_FIELD)
    @Override
    public void setCategory(String category) {
        this.category = category;
    }

    @Field(TIMEREQUIRED_FIELD)
    @Override
    public void setTimeRequired(String timeRequired) {
        this.timeRequired = timeRequired;
    }

    @Field(AGGREGATERATING_FIELD)
    @Override
    public void setAggregateRating(Integer aggregateRating) {
        this.aggregateRating = aggregateRating;
    }

    @Field(PRODUCER_FIELD)
    @Override
    public void setProducer(Collection<String> producer) {
        this.producer = producer;
    }

    @Field(GENRE_FIELD)
    @Override
    public void setGenre(Collection<String> genre) {
        this.genre = genre;
    }

    @Override
    @Field(CONTENTRATING_FIELD)
    public void setContentRating(String contentRating) {
        this.contentRating = contentRating;
    }

    @Override
    @Field(_SCORE_FIELD)
    public void setRecommenderScores(Map<String, Float> recommenderScores) {
        super.getItemScores().get().setRecommenderScores(recommenderScores);
    }

    @Override
    @Field(_RAWSCORE_FIELD)
    public void setRawRecommenderScores(Map<String, Float> rawRecommenderScores) {
        super.getItemScores().get().setRawRecommenderScores(rawRecommenderScores);
    }

    @Field(ADDITIONAL_INFO_FIELD)
    @Override
    public void setAdditionalInfo(String additionalInfo) {
        this.additionalInfo = additionalInfo;
    }

    public CreativeWorkBean() {}
}
