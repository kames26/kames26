/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.choice.rateableitem;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.geo.Distance;
import org.springframework.data.solr.core.geo.Point;
import org.springframework.stereotype.Repository;

import com.google.common.base.Optional;

@Repository
public class ItemCatalogueDao {

    private static final Logger LOG = LoggerFactory.getLogger(ItemCatalogueDao.class);

    private final RateableItemDao<LocalBusiness> localBusinessDAO;
    private final RateableItemDao<CreativeWork> creativeWorkDAO;

    private final Distance AUTO_COMPLETE_DISTANCE = new Distance(25);

    @Autowired
    public ItemCatalogueDao(RateableItemDao<LocalBusiness> localBusinessDAO,
            RateableItemDao<CreativeWork> creativeWorkDAO) {
        this.localBusinessDAO = localBusinessDAO;
        this.creativeWorkDAO = creativeWorkDAO;
    }

    /**
     * Retrieves an item of given category matching the given id.
     *
     * @param category
     *            Category the item belongs to.ttr
     * @param itemID
     *            ID of the item to be returned.
     * @return An item of given category type. Returns null if category or the
     *         item is not available.
     */
    public Optional<RateableItem> getItemById(Category category, Integer itemID) {
        try {
            final RateableItem rateableItem;
            if (category.isLocalBusiness()) {
                rateableItem = localBusinessDAO.findOne(itemID);
            } else if (category.isCreativeWork()) {
                rateableItem = creativeWorkDAO.findOne(itemID);
            } else {
                rateableItem = null;
            }
            return Optional.fromNullable(rateableItem);
        } catch (Exception e) {
            LOG.warn("Problem enountered querying rateable item {} of category {} from repository.", itemID,
                    category, e);
            return Optional.absent();
        }
    }

    /**
     * Retrieves a set of items of given category matching the given list of
     * ids.
     *
     * @param category
     *            Category the item belongs to.ttr
     * @param itemID
     *            ID of the item to be returned.
     * @return An item of given category type. Returns null if category or the
     *         item is not available.
     */
    public Collection<RateableItem> getItemsByIdSet(Category category, Set<Integer> itemIDs) {
        final Collection<RateableItem> rateableItems;

        if (category.isLocalBusiness()) {
            final Iterable<LocalBusiness> result = localBusinessDAO.findAll(itemIDs);
            rateableItems = new ArrayList<>();
            result.forEach(input -> rateableItems.add(input));
        } else if (category.isCreativeWork()) {
            final Iterable<CreativeWork> result = creativeWorkDAO.findAll(itemIDs);
            rateableItems = new ArrayList<>();
            result.forEach(input -> rateableItems.add(input));
        } else {
            rateableItems = Collections.emptyList();
        }
        return rateableItems;
    }

    public Collection<String> getAttributeValuesByAttribute(Category category, String attributeType) {
        final Collection<String> attributeValuesList;
        if (category.isLocalBusiness()) {
            attributeValuesList = localBusinessDAO.getAttributeValuesByAttribute(category, attributeType);
        } else if (category.isCreativeWork()) {
            attributeValuesList = creativeWorkDAO.getAttributeValuesByAttribute(category, attributeType);
        } else {
            throw new RuntimeException("Invalid category: " + category);
        }
        return attributeValuesList;
    }

    public Collection<String> getAttributeValuesStartsWith(Category category, String attributeType,
            String startsWith) {
        final Collection<String> attributeValuesList;
        if (category.isLocalBusiness()) {
            attributeValuesList = localBusinessDAO.getAttributeValuesStartsWith(category, attributeType,
                    startsWith);
        } else if (category.isCreativeWork()) {
            attributeValuesList = creativeWorkDAO.getAttributeValuesStartsWith(category, attributeType,
                    startsWith);
        } else {
            throw new RuntimeException("Invalid category: " + category);
        }
        return attributeValuesList;
    }

    /**
     * Get the EntityDetails object with given category, startWith and location
     *
     * @param
     * @return
     */
    public Collection<? extends ItemSummary> getEntityDetailsByNameStartsWithAndLocation(Category category,
            String startsWith, Point location) {
        final Collection<? extends ItemSummary> itemsStartingWith;
        if (category.isLocalBusiness()) {
            itemsStartingWith = localBusinessDAO.findByNameStartsWith(category, startsWith, location,
                    AUTO_COMPLETE_DISTANCE);
        } else if (category.isCreativeWork()) {
            itemsStartingWith = creativeWorkDAO.findByNameStartsWith(category, startsWith);
        } else {
            throw new RuntimeException("Invalid category: " + category);
        }
        return itemsStartingWith;
    }
}
