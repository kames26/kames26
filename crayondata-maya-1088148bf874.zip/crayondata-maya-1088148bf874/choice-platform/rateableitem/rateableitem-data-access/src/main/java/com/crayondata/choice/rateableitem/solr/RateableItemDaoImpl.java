/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.choice.rateableitem.solr;

import java.io.Closeable;
import java.io.IOException;
import java.util.Collection;
import java.util.Collections;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import javax.annotation.Nullable;

import org.apache.commons.lang3.StringUtils;
import org.apache.solr.client.solrj.SolrClient;
import org.apache.solr.client.solrj.impl.HttpSolrClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.domain.Sort.Order;
import org.springframework.data.solr.core.SolrTemplate;
import org.springframework.data.solr.core.convert.SolrJConverter;
import org.springframework.data.solr.core.query.Criteria;
import org.springframework.data.solr.core.query.Field;
import org.springframework.data.solr.core.query.FilterQuery;
import org.springframework.data.solr.core.query.SimpleField;
import org.springframework.data.solr.core.query.SimpleFilterQuery;
import org.springframework.data.solr.core.query.SimpleTermsQuery;
import org.springframework.data.solr.core.query.SimpleTermsQuery.Builder;
import org.springframework.data.solr.core.query.TermsQuery;
import org.springframework.data.solr.core.query.result.TermsPage;

import com.crayondata.choice.rateableitem.Category;
import com.crayondata.choice.rateableitem.ItemSummary;
import com.crayondata.choice.rateableitem.RateableItemDao;
import com.google.common.base.Splitter;
import com.google.common.base.Stopwatch;
import com.google.common.base.Throwables;
import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;
import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Ordering;

abstract class RateableItemDaoImpl<T extends ItemSummary> implements RateableItemDao<T>, Closeable {

    private static final Logger LOG = LoggerFactory.getLogger(RateableItemDaoImpl.class);

    protected static final Splitter whitespaceSplitter = Splitter.onPattern("\\s+").trimResults();

    protected static final Field NAME_LOWERCASE_FIELD = new SimpleField("name_lowercase");
    private static final Field CATEGORY_FIELD = new SimpleField("category");
    protected static final Field GEO_FIELD = new SimpleField("geo");

    protected static final Sort sortByName = new Sort(
            new Order(Direction.ASC, NAME_LOWERCASE_FIELD.getName()));

    private final LoadingCache<Integer, T> itemDetailsCache;
    private final SolrClient httpSolrClient;

    protected final Class<T> entityClazz;

    protected final SolrTemplate solrTemplate;

    protected RateableItemDaoImpl(String coreName, Class<? extends T> entityClazz, String solrHost,
            String solrPort) {

        final String baseURL = getSolrServerUrl(solrHost, solrPort);
        final SolrClient solrClient = new HttpSolrClient(baseURL);
        this.entityClazz = (Class<T>) entityClazz;

        this.solrTemplate = new SolrTemplate(solrClient, coreName);
        this.solrTemplate.setSolrConverter(new SolrJConverter());
        this.solrTemplate.afterPropertiesSet();

        // Note: SolrTemplate is modifying the client we pass in
        this.httpSolrClient = solrTemplate.getSolrClient();

        final CacheLoader<Integer, T> detailsCacheLoader = new RateableItemCacheLoader();

        this.itemDetailsCache = CacheBuilder.newBuilder().expireAfterAccess(5, TimeUnit.MINUTES)
                .build(detailsCacheLoader);
    }

    @Override
    public T findOne(Integer id) {
        return itemDetailsCache.getUnchecked(id);
    }

    @Override
    public Iterable<T> findAll(Iterable<? extends Integer> itemIds) {
        try {
            final Map<Integer, T> items = itemDetailsCache.getAll(itemIds);
            return items.values();
        } catch (Exception e) {
            LOG.warn("Problem encountered loading items with Ids {}", itemIds, e);
            final Map<Integer, T> items = itemDetailsCache.getAllPresent(itemIds);
            /* return Collections.emptyList(); */
            return (items != null) ? items.values() : Collections.emptyList();
        }
    }

    @Override
    public void close() {
        try {
            httpSolrClient.close();
        } catch (IOException e) {
            LOG.warn("Problem encountered closing Solr connection: " + e.getMessage(), e);
            Throwables.propagate(e);
        }
    }

    @Override
    public Collection<String> getAttributeValuesByAttribute(Category category, String attributeType) {
        return getTermsStartsWith(category, attributeType, null);
    }

    @Override
    public Collection<String> getAttributeValuesStartsWith(Category category, String attributeType,
            String attrValStartsWith) {
        return getTermsStartsWith(category, attributeType, attrValStartsWith);
    }

    private Collection<String> getTermsStartsWith(Category category, String categoryField,
            @Nullable final String prefix) {
        // TODO Is category filter needed / working here?
        // final Criteria categoryCriteria = getCategoryCriteria(category);
        final Builder intermTermsQueryBuilder = SimpleTermsQuery.queryBuilder()
                // .withCriteria(categoryCriteria)
                .fields(categoryField).limit(Integer.MAX_VALUE);
        final TermsQuery termsQuery;
        if (prefix != null) {
            termsQuery = intermTermsQueryBuilder.prefix(prefix.toLowerCase()).build();
        } else {
            termsQuery = intermTermsQueryBuilder.build();
        }

        final Stopwatch stopwatch = Stopwatch.createStarted();

        final TermsPage termsPage = solrTemplate.queryForTermsPage(termsQuery);

        LOG.debug("Retrieving: {} terms for field({}) and prefix: '{}' took: {}ms", Iterables.size(termsPage),
                categoryField, prefix, stopwatch.elapsed(TimeUnit.MILLISECONDS));

        final Collection<String> termsStartingWith = Lists.newArrayList();
        termsPage.forEach(item -> termsStartingWith.add(item.getValue()));
        return Ordering.natural().sortedCopy(termsStartingWith);
    }

    private static Criteria getCategoryCriteria(Category category) {
        // Convert the all-caps category to same format in Solr data,
        final String categoryName = StringUtils.capitalize(category.name().toLowerCase());
        final Criteria categoryCriteria = Criteria.where(CATEGORY_FIELD).is(categoryName);
        return categoryCriteria;
    }

    protected static FilterQuery getCategoryFilterQuery(Category category) {
        // TODO get rid of this
        final Criteria categoryCriteria = getCategoryCriteria(category);
        final FilterQuery categoryFilterQuery = new SimpleFilterQuery(categoryCriteria);
        return categoryFilterQuery;
    }

    private final class RateableItemCacheLoader extends CacheLoader<Integer, T> {

        @Override
        public T load(Integer key) {
            return solrTemplate.getById(key, entityClazz);
        }

        @Override
        public Map<Integer, T> loadAll(Iterable<? extends Integer> keys) throws Exception {
            final Map<Integer, T> result = Maps.newHashMap();
            final Collection<Integer> newArrayList = Lists.newArrayList(keys);
            final Iterable<? extends T> items = solrTemplate.getById(newArrayList, entityClazz);
            items.forEach(input -> result.put(input.getId(), input));
            return result;
        }
    }

    private static String getSolrServerUrl(String solrHost, String solrPort) {
        return String.format("http://%s:%s/solr/", solrHost, solrPort);
    }
}
