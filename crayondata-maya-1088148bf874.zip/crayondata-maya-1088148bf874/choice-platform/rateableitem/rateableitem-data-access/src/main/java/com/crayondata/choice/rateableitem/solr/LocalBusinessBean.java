/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.choice.rateableitem.solr;

import java.util.Collection;
import java.util.Map;

import org.apache.solr.client.solrj.beans.Field;
import org.springframework.data.solr.core.query.SimpleField;

import com.crayondata.choice.rateableitem.ItemScores;
import com.crayondata.choice.rateableitem.LocalBusiness;
import com.crayondata.choice.rateableitem.Scorable;
import com.google.common.base.Joiner;

public class LocalBusinessBean extends LocalBusiness implements Scorable {

    private static final String WEBSITE_FIELD = "website";
    private static final String EMAIL_FIELD = "email";
    private static final String TELEPHONE_FIELD = "telephone";
    private static final String GEO_FIELD = "geo";
    private static final String ADDRESSCOUNTRY_FIELD = "addresscountry";
    private static final String ADDRESSCITY_FIELD = "addresscity";
    private static final String ADDRESS_FIELD = "address";

    private static final String CUISINE_FIELD = "cuisine";
    private static final String FOODRATING_FIELD = "foodrating";

    private static final String PRICE_FIELD = "price";
    private static final String OPTIONS_FIELD = "options";

    private static final String VALUERATING_FIELD = "valuerating";
    private static final String SERVICERATING_FIELD = "servicerating";
    private static final String AMBIENCERATING_FIELD = "ambiencerating";
    private static final String LOCATIONRATING_FIELD = "locationrating";
    private static final String CLEANLINESSRATING_FIELD = "cleanlinessrating";

    private static final String TYPE_FIELD = "type";
    private static final String STARS_FIELD = "stars";
    private static final String AMENITIES_FIELD = "amenities";

    private static final String DISTANCE_FIELD = "distance";
    private static final String EXTERNAL_CATEGORY_FIELD = "external_category";
    private static final String HAS_OFFER_FIELD = "hasOffer";

    // Fields below are not used I believe
    private static final String CUISINE_COUNT_FIELD = "cuisine_count";
    private static final String SENTIMENT_FIELD = "sentiment";
    private static final String KEYWORDS_FIELD = "keywords";

    // TODO, also only query hotel/rest fields depending on current category

    // private static final Iterable<String> COMMON_FIELDS =
    // ImmutableSet.of(ID_FIELD, CATEGORY_FIELD,
    // NAME_FIELD, IMAGE_FIELD, DESCRIPTION_FIELD, ADDITIONAL_INFO_FIELD);
    public static final SimpleField FIELD_LIST = new SimpleField(Joiner.on(',').join(ID_FIELD,
            CATEGORY_FIELD, NAME_FIELD, IMAGE_FIELD, DESCRIPTION_FIELD, ADDITIONAL_INFO_FIELD, AGGREGATERATING_FIELD, PRICE_FIELD,
            OPTIONS_FIELD, CUISINE_FIELD, FOODRATING_FIELD, VALUERATING_FIELD, SERVICERATING_FIELD,
            AMBIENCERATING_FIELD, TYPE_FIELD, LOCATIONRATING_FIELD, CLEANLINESSRATING_FIELD, STARS_FIELD,
            AMENITIES_FIELD, WEBSITE_FIELD, EMAIL_FIELD, TELEPHONE_FIELD, ADDRESSCOUNTRY_FIELD, GEO_FIELD,
            ADDRESSCITY_FIELD, ADDRESS_FIELD, DISTANCE_FIELD));

    @Field(ID_FIELD)
    @Override
    public void setId(int id) {
        this.id = id;
    }

    @Field(NAME_FIELD)
    @Override
    public void setName(String name) {
        this.name = name;
    }

    @Field(DESCRIPTION_FIELD)
    @Override
    public void setDescription(String description) {
        this.description = description;
    }

    @Field(IMAGE_FIELD)
    @Override
    public void setImage(String image) {
        this.image = image;
    }

    @Field(CATEGORY_FIELD)
    @Override
    public void setCategory(String category) {
        this.category = category;
    }

    @Field(HAS_OFFER_FIELD)
    @Override
    public void setHasOffer(boolean hasOffer) {
        super.setHasOffer(hasOffer);
    }

    @Field(EXTERNAL_CATEGORY_FIELD)
    @Override
    public void setExternalCategory(String externalCategory) {
        super.setExternalCategory(externalCategory);
    }

    @Field(ADDRESS_FIELD)
    @Override
    public void setAddress(String address) {
        this.address = address;
    }

    @Field(ADDRESSCITY_FIELD)
    @Override
    public void setAddressCity(String addressCity) {
        this.addressCity = addressCity;
    }

    @Field(GEO_FIELD)
    @Override
    public void setGeo(String geo) {
        this.geo = geo;
    }

    @Field(ADDRESSCOUNTRY_FIELD)
    @Override
    public void setAddressCountry(String addressCountry) {
        this.addressCountry = addressCountry;
    }

    @Field(TELEPHONE_FIELD)
    @Override
    public void setTelephone(String telephone) {
        this.telephone = telephone;
    }

    @Field(EMAIL_FIELD)
    @Override
    public void setEmail(String email) {
        this.email = email;
    }

    @Field(WEBSITE_FIELD)
    @Override
    public void setWebsite(String website) {
        this.website = website;
    }

    @Field(AMENITIES_FIELD)
    @Override
    public void setAmenities(Collection<String> amenities) {
        this.amenities = amenities;
    }

    @Field(STARS_FIELD)
    @Override
    public void setBrand(int brand) {
        this.brand = brand;
    }

    @Field(CLEANLINESSRATING_FIELD)
    public void setCleanlinessRating(int cleanlinessRating) {
        this.cleanlinessRating = cleanlinessRating;
    }

    @Field(LOCATIONRATING_FIELD)
    public void setLocationRating(int locationRating) {
        this.locationRating = locationRating;
    }

    @Field(TYPE_FIELD)
    @Override
    public void setHstyle(Collection<String> hstyle) {
        this.hstyle = hstyle;
    }

    @Field(AMBIENCERATING_FIELD)
    public void setAmbienceRating(int ambienceRating) {
        this.ambienceRating = ambienceRating;
    }

    @Field(SERVICERATING_FIELD)
    public void setServiceRating(int serviceRating) {
        this.serviceRating = serviceRating;
    }

    @Field(VALUERATING_FIELD)
    public void setValueRating(int valueRating) {
        this.valueRating = valueRating;
    }

    @Field(FOODRATING_FIELD)
    public void setFoodRating(int foodRating) {
        this.foodRating = foodRating;
    }

    @Field(AGGREGATERATING_FIELD)
    public void setAggregateRating(int aggregateRating) {
        this.aggregateRating = aggregateRating;
    }

    @Field(CUISINE_FIELD)
    @Override
    public void setCuisines(Collection<String> cuisines) {
        this.cuisines = cuisines;
    }

    @Field(OPTIONS_FIELD)
    @Override
    public void setOptions(Collection<String> options) {
        this.options = options;
    }

    @Field(PRICE_FIELD)
    @Override
    public void setPriceRange(String priceRange) {
        this.priceRange = priceRange;
    }

    @Override
    @Field(ADDITIONAL_INFO_FIELD)
    public void setAdditionalInfo(String additionalInfo) {
        this.additionalInfo = additionalInfo;
    }

    @Field(CUISINE_COUNT_FIELD)
    public void setCuisine_count(int cuisine_count) {
        this.isSpeciality = (cuisine_count == 1);
    }

    @Field(KEYWORDS_FIELD)
    public void setKeywords(Collection<String> keywords) {
        this.keywords = keywords;
    }

    @Field(SENTIMENT_FIELD)
    public void setSentiment(float sentiment) {
        this.sentiment = sentiment;
    }

    @Override
    @Field(_SCORE_FIELD)
    public void setRecommenderScores(Map<String, Float> recommenderScores) {
        final ItemScores recItemScores = super.getItemScores().get();
        recItemScores.setRecommenderScores(recommenderScores);
    }

    @Override
    @Field(_RAWSCORE_FIELD)
    public void setRawRecommenderScores(Map<String, Float> rawRecommenderScores) {
        final ItemScores recItemScores = super.getItemScores().get();
        recItemScores.setRawRecommenderScores(rawRecommenderScores);
    }

    @Override
    @Field(DISTANCE_FIELD)
    public void setDistance(double distance) {
        super.setDistance(distance);
    }
}
