/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.choice.rateableitem.solr;

import java.util.Collection;

import org.apache.commons.lang3.NotImplementedException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.geo.Distance;
import org.springframework.data.solr.core.geo.Point;
import org.springframework.data.solr.core.query.Criteria;
import org.springframework.data.solr.core.query.DistanceField;
import org.springframework.data.solr.core.query.FilterQuery;
import org.springframework.data.solr.core.query.SimpleFilterQuery;
import org.springframework.data.solr.core.query.SimpleQuery;
import org.springframework.data.solr.core.query.result.ScoredPage;
import org.springframework.stereotype.Repository;

import com.crayondata.choice.rateableitem.Category;
import com.crayondata.choice.rateableitem.LocalBusiness;

@Repository
public class LocalBusinessDAOImpl extends RateableItemDaoImpl<LocalBusiness> {

    private static final String DISTANCE_FIELD_ALIAS = "distance";

    @Autowired
    public LocalBusinessDAOImpl(@Value("${solr.server.host}") String solrHost,
            @Value("${solr.server.port}") String solrPort) {
        super("LocalBusiness", LocalBusinessBean.class, solrHost, solrPort);
    }

    @Override
    public Collection<LocalBusiness> findByNameStartsWith(Category category, String startsWith,
            Point location, Distance distance) {
        final Criteria startsWithCriteria = Criteria.where(NAME_LOWERCASE_FIELD)
                .startsWith(whitespaceSplitter.split(startsWith));

        final SimpleQuery query = new SimpleQuery(startsWithCriteria);

        final FilterQuery categoryFilterQuery = getCategoryFilterQuery(category);
        query.addFilterQuery(categoryFilterQuery);

        final FilterQuery locationFilterQuery = new SimpleFilterQuery(
                Criteria.where(GEO_FIELD).within(location, distance));
        query.addFilterQuery(locationFilterQuery);

        query.addSort(sortByName);

        query.addProjectionOnField(new DistanceField(DISTANCE_FIELD_ALIAS, GEO_FIELD.getName(), location));
        query.addProjectionOnField("*");

        final ScoredPage<LocalBusiness> result = solrTemplate.queryForPage(query, entityClazz);
        final Collection<LocalBusiness> results = result.getContent();
        return results;
    }

    @Override
    public Collection<LocalBusiness> findByNameStartsWith(Category category, String startsWith) {
        throw new NotImplementedException("LocalBusiness requires a location");
    }
}
