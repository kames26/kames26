/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.choice.userprofile;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.crayondata.recommender.Recommender;

/**
 * Will contain the details of every recommender involved in a choice
 * generation.
 * 
 */
@Entity
@Table(name = "recommender_details_table")
public class RecommenderDetail {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    protected Integer id;

    /** Will be the id of the DeliveredChoices table */
    @ManyToOne
    @JoinColumn(name="choice_id")
    protected DeliveredChoice choice;

    @Enumerated(EnumType.STRING)
    protected Recommender recommender;

    protected float score;

    protected float weight;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Recommender getRecommender() {
        return recommender;
    }

    public void setRecommender(Recommender recommender) {
        this.recommender = recommender;
    }

	public float getScore() {
		return score;
	}

	public void setScore(float score) {
		this.score = score;
	}

	public float getWeight() {
		return weight;
	}

	public void setWeight(float weight) {
		this.weight = weight;
	}
	
    @Override
    public String toString() {
        return "RecommenderDetails [id=" + id + ", choiceId=" + choice.getId() + ", recommender=" + recommender
                + ", score=" + score + ", weight=" + weight + "]";
    }

	public DeliveredChoice getChoice() {
		return choice;
	}

	public void setChoice(DeliveredChoice choice) {
		this.choice = choice;
	}
}
