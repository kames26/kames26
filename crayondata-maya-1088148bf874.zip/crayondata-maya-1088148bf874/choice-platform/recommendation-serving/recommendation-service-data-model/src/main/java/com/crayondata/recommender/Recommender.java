/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.recommender;

import java.util.EnumSet;

import com.google.common.base.Optional;

public enum Recommender {
    TGFIRSTHOPNICHE, TGFIRSTHOPPOPULAR, TGSECONDHOPDISCOVERY, ATTRIBUTE_NUMERICAL, ATTRIBUTE_CATEGORICAL, GEOSPATIAL, ENTERPRISETGFIRSTHOPNICHE, ENTERPRISETGFIRSTHOPPOPULAR, ENTERPRISETGSECONDHOPDISCOVERY, TOPRATEDITEM;

    private static final String POSTFIX_SCORE = "_score";
    private static final String RAW_POSTFIX_SCORE = "_rawscore";

    public String getScoreAlias() {
        return this.toString().toLowerCase().concat(POSTFIX_SCORE);
    }

    public String getRawScoreAlias() {
        return this.toString().toLowerCase().concat(RAW_POSTFIX_SCORE);
    }

    public static Optional<Recommender> fromScoreAlias(String scoreAlias) {
        final String recommenderName = scoreAlias.substring(0, scoreAlias.indexOf(POSTFIX_SCORE))
                .toUpperCase();
        if (recommenderName.equals("OVERALL")) {
            return Optional.absent();
        }
        return Optional.of(Recommender.valueOf(recommenderName));
    }

    public static Optional<Recommender> fromRawScoreAlias(String scoreAlias) {
        final String recommenderName = scoreAlias.substring(0, scoreAlias.indexOf(RAW_POSTFIX_SCORE))
                .toUpperCase();
        if (recommenderName.equals("OVERALL")) {
            return Optional.absent();
        }
        return Optional.of(Recommender.valueOf(recommenderName));
    }

    public final static EnumSet<Recommender> ALL = EnumSet.allOf(Recommender.class);

    public final static EnumSet<Recommender> INTERNAL = EnumSet.of(ENTERPRISETGFIRSTHOPNICHE,
            ENTERPRISETGFIRSTHOPPOPULAR, ENTERPRISETGSECONDHOPDISCOVERY);

    public final static EnumSet<Recommender> EXTERNAL = EnumSet.complementOf(INTERNAL);
}
