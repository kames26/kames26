/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.choice.userprofile;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name = "delivered_choice_table")
public class DeliveredChoice implements Comparable<DeliveredChoice>{
	
	@Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    protected Integer id;

	@Column(name="user_id")
    protected String userId;

	@Column(name="choice_collection_id")
    protected int choiceCollectionId;

	@Column(name="item_id")
    protected Integer itemId;
	
	@OneToMany(mappedBy="choice")
	protected List<RecommenderDetail> recommenderDetails = new ArrayList<>();
	
	@Column(name="item_name")
    protected String itemName;

    protected String location;

    @Column(name="net_score")
    protected double netScore;
    
    @Column(name="has_offer")
    protected boolean hasOffer;
    
    @Column(name="category")
    protected String category;
    
    @Column(name="external_category")
    protected String externalCategory;
    
    @Transient
    protected String description;
    
    @Transient
    protected String image;

    protected Date timestamp;
    protected Date choiceTimestamp;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public Integer getItemId() {
        return itemId;
    }

    public void setItemId(Integer itemId) {
        this.itemId = itemId;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public double getNetScore() {
        return netScore;
    }

    public void setNetScore(double netScore) {
        this.netScore = netScore;
    }

    public Date getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(Date timestamp) {
        this.timestamp = timestamp;
    }

    public Date getChoiceTimestamp() {
        return choiceTimestamp;
    }

    public void setChoiceTimestamp(Date timestamp) {
        this.choiceTimestamp = timestamp;
    }

    public DeliveredChoice() {

    }

    public DeliveredChoice(String userId, int choiceCollectionId, Integer itemId, String location,
            double netScore, Date timestamp, Date choiceTimestamp) {
        super();
        this.userId = userId;
        this.choiceCollectionId = choiceCollectionId;
        this.itemId = itemId;
        this.location = location;
        this.netScore = netScore;
        this.timestamp = timestamp;
        this.choiceTimestamp = choiceTimestamp;
    }

	public boolean isHasOffer() {
		return hasOffer;
	}

	public void setHasOffer(boolean hasOffer) {
		this.hasOffer = hasOffer;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getExternalCategory() {
		return externalCategory;
	}

	public void setExternalCategory(String externalCategory) {
		this.externalCategory = externalCategory;
	}

	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public int getChoiceCollectionId() {
		return choiceCollectionId;
	}

	public void setChoiceCollectionId(int choiceCollectionId) {
		this.choiceCollectionId = choiceCollectionId;
	}

	public List<RecommenderDetail> getRecommenderDetails() {
		return recommenderDetails;
	}

	public void setRecommenderDetails(List<RecommenderDetail> recommenderDetails) {
		this.recommenderDetails = recommenderDetails;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

    @Override
    public String toString() {
        return "DeliveredChoice [id=" + id + ", userId=" + userId + ", choiceCollectionId="
                + choiceCollectionId + ", itemId=" + itemId + ", recommenderDetails=" + recommenderDetails
                + ", itemName=" + itemName + ", location=" + location + ", netScore=" + netScore
                + ", hasOffer=" + hasOffer + ", category=" + category + ", externalCategory="
                + externalCategory + ", description=" + description + ", image=" + image + ", timestamp="
                + timestamp + ", choiceTimestamp=" + choiceTimestamp + "]";
    }

	@Override
	public int compareTo(DeliveredChoice o) {
		return Double.compare(this.getNetScore(), o.getNetScore());
	}
}
