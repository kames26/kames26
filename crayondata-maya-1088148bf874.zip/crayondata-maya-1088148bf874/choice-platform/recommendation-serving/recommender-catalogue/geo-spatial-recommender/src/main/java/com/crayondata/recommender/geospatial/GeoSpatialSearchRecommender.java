/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.recommender.geospatial;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.geo.Point;
import org.springframework.data.solr.core.query.Criteria;
import org.springframework.data.solr.core.query.DivideFunction;
import org.springframework.data.solr.core.query.Function;
import org.springframework.data.solr.core.query.GeoDistanceFunction;
import org.springframework.data.solr.core.query.SimpleQuery;

import com.crayondata.choice.rateableitem.Category;
import com.crayondata.choice.userprofile.UserProfile;
import com.crayondata.recommender.Recommender;
import com.crayondata.recommender.context.UserContext;
import com.crayondata.recommender.search.IRecommendBySearch;
import com.crayondata.recommender.search.IRecommendItems;
import com.google.common.base.Optional;

/* @Component */
public class GeoSpatialSearchRecommender implements IRecommendBySearch {

    private static final Logger LOG = LoggerFactory.getLogger(GeoSpatialSearchRecommender.class);

    // private static final String DistanceScoreTemplate =
    // "\n{!func}scale(div(1,add(1,geodist(%s,%s,%s))),0,1)";
    private static final Number ONE = new Integer(1);

    @Override
    public Optional<RecommenderSearchParameters> generateSearchSubQuery(UserContext userContext,
            UserProfile userProfile) {
        final Category category = userContext.getCategory();
        if (!category.isLocalBusiness()) {
            LOG.info("Skipping geo spatial for category: {}", category);
            return Optional.absent();
        }

        final Optional<Point> usersLocation = userContext.getLocation();
        if (!usersLocation.isPresent()) {
            LOG.info("Skipping geo spatial as users({}) location is not available", userContext.getUserId());
            return Optional.absent();
        }

        Criteria crit = new Criteria();
        Function addFunction = CrayonAddFunction.add(ONE)
                .to(GeoDistanceFunction.distanceFrom(IRecommendItems.GEO_FILED_NAME).to(usersLocation.get()));
        Function divFunction = DivideFunction.divide(ONE).by(addFunction);
        crit.function(divFunction);

        final SimpleQuery reference = new SimpleQuery(crit);
        return Optional.of(RecommenderSearchParameters.create(reference));
    }

    @Override
    public Recommender getName() {
        return Recommender.GEOSPATIAL;
    }

    @Override
    public String toString() {
        return getName().toString();
    }
}