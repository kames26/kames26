/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.recommender.geospatial;

import java.util.Arrays;

import org.springframework.data.solr.core.query.AbstractFunction;
import org.springframework.data.solr.core.query.Field;
import org.springframework.data.solr.core.query.Function;
import org.springframework.util.Assert;

public class CrayonAddFunction extends AbstractFunction {
    private static final String OPERATION = "add";

    private CrayonAddFunction(Object operand1, Object operand2) {
        super(Arrays.asList(operand1, operand2));
    }

    /**
     * creates new {@link Builder} for dividing value in field with given name
     * 
     * @param field must not be null
     * @return
     */
    public static Builder add(Field field) {
        Assert.notNull(field, "Field cannot be 'null' for add function.");

        return add(field.getName());
    }

    /**
     * creates new {@link Builder} for dividing value in field with given name
     * 
     * @param fieldname must not be empty
     * @return
     */
    public static Builder add(String fieldname) {
        Assert.hasText(fieldname, "Fieldname cannot be 'empty' for add function.");

        return new Builder(fieldname);
    }

    /**
     * creates new {@link Builder} for dividing given value
     * 
     * @param operand1
     * @return
     */
    public static Builder add(Number operand1) {
        return new Builder(operand1);
    }

    /**
     * creates new {@link Builder} for dividing value calculated by given {@link Function}
     * 
     * @param operand1
     * @return
     */
    public static Builder add(Function operand1) {
        return new Builder(operand1);
    }

    @Override
    public String getOperation() {
        return OPERATION;
    }

    public static class Builder {

        private Object dividend;

        public Builder(Object operand1) {
            Assert.notNull(operand1, "Dividend must not be 'null'");

            this.dividend = operand1;
        }

        /**
         * @param operand2 must not be null
         * @return
         */
        public CrayonAddFunction to(Number operand2) {
            return to((Object) operand2);
        }

        /**
         * @param operand2 must not be null
         * @return
         */
        public CrayonAddFunction to(Function operand2) {
            return to((Object) operand2);
        }

        /**
         * @param fieldname must not be empty
         * @return
         */
        public CrayonAddFunction to(String fieldname) {
            Assert.hasText(fieldname, "Fieldname for devide function must not be 'empty'.");

            return to((Object) fieldname);
        }

        /**
         * @param field must not be null
         * @return
         */
        public CrayonAddFunction to(Field field) {
            Assert.notNull(field, "Field must not be 'null'.");

            return to(field.getName());
        }

        private CrayonAddFunction to(Object operand2) {
            Assert.notNull(operand2, "Cannot divide by 'null'.");

            return new CrayonAddFunction(dividend, operand2);
        }
    }
}
