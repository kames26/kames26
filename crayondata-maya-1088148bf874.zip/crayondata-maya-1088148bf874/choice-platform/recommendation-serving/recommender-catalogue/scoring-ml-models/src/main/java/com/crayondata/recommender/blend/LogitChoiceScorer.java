/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.recommender.blend;

import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.mllib.classification.LogisticRegressionModel;
import org.apache.spark.mllib.classification.LogisticRegressionWithLBFGS;
import org.apache.spark.mllib.evaluation.BinaryClassificationMetrics;
import org.apache.spark.mllib.linalg.DenseVector;
import org.apache.spark.mllib.linalg.Vector;
import org.apache.spark.mllib.regression.LabeledPoint;

import com.crayondata.recommender.choice.UserChoiceRecord;

import scala.Tuple2;

/**
 * @author vivek
 */
public class LogitChoiceScorer {

    private String choiceFileUri;
    private String outputDir;

    public LogitChoiceScorer(String choiceFileUri, String outputDir) {
        this.choiceFileUri = choiceFileUri;
        this.outputDir = outputDir;
    }

    public static void main(String[] args) {
        SparkConf conf = new SparkConf().setAppName("Logistic Choice Scorer");
        conf.setIfMissing("spark.executor.memory", "64g");
        conf.setIfMissing("spark.num.executors", "1");
        // conf.setIfMissing("spark.executor.cores", "7");
        conf.setIfMissing("spark.total.executor.cores", "15");
        conf.setIfMissing("spark.storage.memoryFraction", "0.1");
        JavaSparkContext jc = new JavaSparkContext(conf);

        if (args.length < 2) {
            System.err.println("Usage: LogitChoiceScorer <choice-file-uri> <output-dir>");
            System.out.println("Usage: LogitChoiceScorer <choice-file-uri> <output-dir>");
            System.exit(0);
        }

        LogitChoiceScorer scorer = new LogitChoiceScorer(args[0], args[1]);
        scorer.scoreAndPersistRecords(jc);
    }

    public void scoreAndPersistRecords(JavaSparkContext jc) {
        JavaRDD<UserChoiceRecord> records = this.loadData(jc);
        LogisticRegressionModel model = this.buildModel(records);
        JavaRDD<UserChoiceRecord> scoredRecords = this.scoreItems(model, records);
        this.persistScoredRecords(scoredRecords);
    }

    public void persistScoredRecords(JavaRDD<UserChoiceRecord> scoredRecords) {
        scoredRecords.map(UserChoiceRecord::toString).saveAsTextFile(this.outputDir + "/scored_choices");
    }

    /**
     * Data format in the choice file,
     * userid, itemid, success (label), tg_rank, tg_score, pca_rank, pca_score
     *
     * @param jc
     */
    public JavaRDD<UserChoiceRecord> loadData(JavaSparkContext jc) {
        System.out.println("Loading choice data...");
        JavaRDD<String> input = jc.textFile(choiceFileUri).cache();
        JavaRDD<UserChoiceRecord> choiceRecords = input.map(UserChoiceRecord::parse);

        System.out.println(".. Loading data done..");

        return choiceRecords;
    }

    public LogisticRegressionModel buildModel(JavaRDD<UserChoiceRecord> choiceRecords) {
        System.out.println("Building model...");

        JavaRDD<LabeledPoint> input = choiceRecords.map(x -> {
            double label = (double) x.getSuccess();
            double[] features = new double[2];
            features[0] = x.getTgScore();
            features[1] = x.getPcaScore();
            Vector featureVec = new DenseVector(features);
            return new LabeledPoint(label, featureVec);
        });

        LogisticRegressionModel model = new LogisticRegressionWithLBFGS().setNumClasses(2).run(input.rdd());

        System.out.println("Model details...");
        System.out.println(model.intercept());
        System.out.println(model.numFeatures());
        System.out.println(model.weights());
        System.out.println(model.toString());

        System.out.println(" Model building completed..");

        return model;
    }

    public JavaRDD<UserChoiceRecord> scoreItems(LogisticRegressionModel model,
            JavaRDD<UserChoiceRecord> choiceRecords) {
        System.out.println("Scoring items..");
        choiceRecords = choiceRecords.map(x -> {
            double[] features = new double[2];
            features[0] = x.getTgScore();
            features[1] = x.getPcaScore();
            Vector featureVec = new DenseVector(features);
            double score = model.predict(featureVec);
            System.err.println("Predicted  Score ::" + score);
            x.setBlendedScore(score); // Setting the score..
            System.err.println("Predicted  Score ::::::" + x.getBlendedScore());
            return x;
        });
        System.out.println("Scoring items complete..");

        System.out.println("Computing AU ROC.. based on predictions..");
        JavaRDD<Tuple2<Object, Object>> predictionAndLabels = choiceRecords
                .map(x -> new Tuple2<>(x.getBlendedScore(), (double) x.getSuccess()));

        BinaryClassificationMetrics metrics = new BinaryClassificationMetrics(predictionAndLabels.rdd());
        double auROC = metrics.areaUnderROC();

        System.out.println("AU ROC: for the model prediction:" + auROC);

        return choiceRecords;
    }

}
