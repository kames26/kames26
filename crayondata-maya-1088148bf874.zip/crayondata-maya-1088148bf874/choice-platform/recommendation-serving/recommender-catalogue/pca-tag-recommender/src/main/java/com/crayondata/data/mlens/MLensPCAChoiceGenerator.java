/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.data.mlens;

import org.apache.spark.api.java.JavaSparkContext;

import com.crayondata.choice.generator.PCAChoiceGenerator;

/**
 * @author sundar
 */
public class MLensPCAChoiceGenerator extends PCAChoiceGenerator<Integer, Integer> {
    private static final long serialVersionUID = 8515366065713825447L;

    MLensPCAChoiceGenerator(JavaSparkContext sparkContext, String interactionDir, String outputDir,
            int numOfChoices, int numComponentsMin, int numComponentsMax) {
        super(sparkContext, interactionDir, outputDir, numOfChoices, numComponentsMin, numComponentsMax);
    }

    @Override
    public void readData() {
        userItemRDD = sparkContext.textFile(interactionDir).filter(MLensChoiceGenerator.INTR_DATA_FILTER_FN)
                .mapToPair(MLensChoiceGenerator::readInteractionData);
    }
}
