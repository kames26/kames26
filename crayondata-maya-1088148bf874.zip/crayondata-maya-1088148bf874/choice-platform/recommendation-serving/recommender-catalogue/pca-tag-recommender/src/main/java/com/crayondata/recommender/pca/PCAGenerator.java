/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.recommender.pca;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Map;

import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.mllib.linalg.DenseVector;
import org.apache.spark.mllib.linalg.Matrices;
import org.apache.spark.mllib.linalg.Matrix;
import org.apache.spark.mllib.linalg.SingularValueDecomposition;
import org.apache.spark.mllib.linalg.SparseVector;
import org.apache.spark.mllib.linalg.Vector;
import org.apache.spark.mllib.linalg.distributed.CoordinateMatrix;
import org.apache.spark.mllib.linalg.distributed.IndexedRow;
import org.apache.spark.mllib.linalg.distributed.IndexedRowMatrix;
import org.apache.spark.mllib.linalg.distributed.MatrixEntry;

import com.crayondata.recommender.pca.similarity.SimilarityUtil;
import com.google.common.collect.BiMap;
import com.google.common.collect.ImmutableBiMap;
import com.google.common.collect.Iterables;
import com.google.common.collect.Maps;

import scala.Tuple2;

/**
 * @author vivek
 */
public class PCAGenerator implements Serializable {

    private static final long serialVersionUID = 1L;

    private static final int PCA_MAX_COLS = 65535;
    private static final long SEED = 1000000;
    private static final double SIM_THRESHOLD = 0.25;
    private static final int PARTITIONS = 512;
    // Top N users for similarity
    private static final int TOP_N = 100;

    private Map<String, Integer> userIdToIndexMap;
    private Map<Integer, String> userIndexToIdMap;
    private Map<Integer, Integer> itemIdToIndexMap;
    private Map<Integer, Integer> itemIndexToIdMap;

    private IndexedRowMatrix pComponents;

    private IndexedRowMatrix userComponents;

    private Matrix sMatrix;

    public PCAGenerator() {
        userIdToIndexMap = Maps.newHashMap();
        itemIdToIndexMap = Maps.newHashMap();
        itemIndexToIdMap = Maps.newHashMap();
    }

    Integer getItemIndexToIdMap(Integer index) {
        return this.itemIndexToIdMap.get(index);
    }

    IndexedRowMatrix getPComponents() {
        return this.pComponents;
    }
    
    public JavaPairRDD<Integer, Vector> generatePCAWithTrain(JavaSparkContext sc,
            JavaPairRDD<String, List<Integer>> userTrainRdd, int nComponents){
    	/*userTrainRdd = applyColumnLimit(userTrainRdd, sc);*/

        JavaPairRDD<String, Integer> userItemRdd = userTrainRdd.flatMapValues(x -> x);
        JavaPairRDD<Integer, String> itemUserRdd = userItemRdd.mapToPair(Tuple2::swap);

        initUserIdMap(itemUserRdd);
        initItemIdMap(itemUserRdd);

        BiMap<Integer, Integer> itemBiMap = new ImmutableBiMap.Builder<Integer, Integer>()
                .putAll(itemIdToIndexMap).build();
        itemIndexToIdMap = itemBiMap.inverse();

        BiMap<String, Integer> userBiMap = new ImmutableBiMap.Builder<String, Integer>()
                .putAll(this.userIdToIndexMap).build();
        this.userIndexToIdMap = userBiMap.inverse();

        System.out.println("Item user Rdd count:" + itemUserRdd.count());
        IndexedRowMatrix matrix = constructMatrix(itemUserRdd);
        System.out.println("Matrix Dim: [" + matrix.numRows() + " x " + matrix.numCols() + "]");

        // PCA generation..
		/*Matrix pca = matrix.toRowMatrix().computePrincipalComponents(nComponents);
		IndexedRowMatrix components = matrix.multiply(pca);*/

        // Compute the top 4 singular values and corresponding singular vectors.
        SingularValueDecomposition<IndexedRowMatrix, Matrix> svd = matrix
                .computeSVD(nComponents, true, 1.0E-9d);
        IndexedRowMatrix components = svd.U();
        Vector s = svd.s();
        double[] data = s.toArray();
        for (int i = 0; i < data.length; i++) {
            System.out.println(".. s value:" + data[i] + " before sqrt");
            data[i] = Math.sqrt(data[i]);
            System.out.println(".. s value:" + data[i] + " after sqrt");
        }

        Vector sqrt = new DenseVector(data);

        Matrix sMat = Matrices.diag(sqrt).transpose();
        components = components.multiply(sMat);
	    /*svd.s();
	    svd.V();*/

        this.sMatrix = sMat;

        Matrix userMat = svd.V();
        int rowCount = userMat.numRows();
        int colCount = userMat.numCols();
        long startTime = System.currentTimeMillis();
        System.out.println("Starting user components computation...");
        System.out.printf("Row Count : %d and Col Count : %d\n", rowCount, colCount);
        List<MatrixEntry> matEntries = new ArrayList<>();
        for (int i = 0; i < rowCount; i++) {
            for (int j = 0; j < colCount; j++) {
                double val = userMat.apply(i, j);
                matEntries.add(new MatrixEntry(i, j, val));
            }
        }
        long endTime = System.currentTimeMillis();

        System.out.println("Time taken for user component matrix:" + (endTime - startTime));

        JavaRDD<MatrixEntry> matEntriesRdd = sc.parallelize(matEntries);
        CoordinateMatrix cMatrix = new CoordinateMatrix(matEntriesRdd.rdd());
        this.userComponents = cMatrix.toIndexedRowMatrix();

        this.pComponents = components;

        JavaPairRDD<Integer, Vector> itemPCA = components.rows().toJavaRDD().mapToPair(x -> {
            int itemIndex = (int) x.index();
            Integer itemId = this.itemIndexToIdMap.get(itemIndex);
            Vector pcaVal = x.vector();
            return new Tuple2<>(itemId, pcaVal);
        });
        // printPCA(itemPCA);
        return itemPCA;
    }

    public JavaPairRDD<Integer, Vector> generatePCA(JavaSparkContext sc,
            JavaPairRDD<String, Tuple2<List<Integer>, List<Integer>>> trainAndTest, int nComponents) {
        JavaPairRDD<String, List<Integer>> userTrainRdd = trainAndTest.mapValues(Tuple2::_1);
        return generatePCAWithTrain(sc, userTrainRdd, nComponents);
    }

    JavaPairRDD<String, Vector> generateUserPrefVectors() {
        JavaRDD<IndexedRow> rowsRdd = this.userComponents.rows().toJavaRDD();
        System.out.printf("Generating user pref vector from rows:%d\n", rowsRdd.count());
        JavaPairRDD<String, Vector> userPrefRdd = rowsRdd.mapToPair(x -> {
            int index = (int) x.index();
            Vector vector = x.vector();
            String userId = this.userIndexToIdMap.get(index);
            return new Tuple2<>(userId, vector);
        });
        System.out.println("Generating user pref vector done.. ");
        return userPrefRdd;
    }

    JavaPairRDD<String, Collection<Tuple2<String, Double>>> generateUserSimilarities() {
        IndexedRowMatrix userPrefMatrix = this.userComponents.multiply(this.sMatrix);
        JavaRDD<IndexedRow> rows = userPrefMatrix.rows().toJavaRDD().repartition(PARTITIONS);
        userPrefMatrix = new IndexedRowMatrix(rows.rdd());
        System.out.println("Started computing similarities");
        CoordinateMatrix similarities = userPrefMatrix.toCoordinateMatrix().transpose().toRowMatrix()
                .columnSimilarities(SIM_THRESHOLD);
        System.out.println("Computing similarities done");
        return SimilarityUtil.constructLookup(similarities, userIndexToIdMap, TOP_N);
    }
    
    JavaPairRDD<Integer, Collection<ScoredItem<Integer>>> generateItemSimilarities() {
        IndexedRowMatrix itemPcaMatrix = this.pComponents;
        JavaRDD<IndexedRow> rows = itemPcaMatrix.rows().toJavaRDD().repartition(PARTITIONS);
        itemPcaMatrix = new IndexedRowMatrix(rows.rdd());
        System.out.println("Started computing similarities");
        CoordinateMatrix similarities = itemPcaMatrix.toCoordinateMatrix().transpose().toRowMatrix()
                .columnSimilarities(SIM_THRESHOLD);
        System.out.println("Computing item similarities done");
        return SimilarityUtil.constructLookup(similarities, itemIndexToIdMap, TOP_N)
                .mapValues(tuples -> {
                    List<ScoredItem<Integer>> vals = new ArrayList<>();
                    tuples.forEach(x -> vals.add(new ScoredItem<>(x._1, x._2)));
                    return vals;
                });
    }

    private JavaPairRDD<String, List<Integer>> applyColumnLimit(
            JavaPairRDD<String, List<Integer>> userTrainRdd, JavaSparkContext sc) {

        long count = userTrainRdd.count();
        if (count <= PCA_MAX_COLS)
            return userTrainRdd; // Return as is.

        System.out.println(".. Sample will be returned from rdd with Number of entries:" + count);

        List<Tuple2<String, List<Integer>>> sample = userTrainRdd.takeSample(false, PCA_MAX_COLS, SEED);
        System.out.println("Take sample returned:" + sample.size());
        JavaPairRDD<String, List<Integer>> sampleRdd = sc.parallelize(sample).mapToPair(x -> x);
        System.out.println("Sample Count:" + sampleRdd.count());
        return sampleRdd;
    }

    private static void printPCA(JavaPairRDD<Integer, Vector> pca) {
        JavaRDD<String> toPrint = pca.map(x -> {
            int itemId = x._1;
            double[] data = x._2.toArray();
            StringBuilder builder = new StringBuilder();
            builder.append(itemId);
            for (double point : data) {
                builder.append(",").append(point);
            }
            return builder.toString();
        });
        toPrint.saveAsTextFile("output/pca");
    }

    private void initUserIdMap(JavaPairRDD<Integer, String> itemUserRdd) {
        List<String> userIds = itemUserRdd.values().distinct().collect();
        int size = userIds.size();
        for (int i = 0; i < size; i++) {
            userIdToIndexMap.put(userIds.get(i), i);
        }
    }

    private void initItemIdMap(JavaPairRDD<Integer, String> itemUserRdd) {
        List<Integer> itemIds = itemUserRdd.keys().distinct().collect();
        int size = itemIds.size();
        for (int i = 0; i < size; i++) {
            itemIdToIndexMap.put(itemIds.get(i), i);
        }
    }

    private IndexedRowMatrix constructMatrix(JavaPairRDD<Integer, String> itemUserRdd) {
        JavaPairRDD<Integer, Iterable<String>> itemUserGrouped = itemUserRdd.groupByKey();
        JavaPairRDD<Integer, Vector> itemVectors = itemUserGrouped.mapToPair(x -> {
            int[] indices = new int[Iterables.size(x._2)];
            int i = 0;
            for (String userId : x._2) {
                int userIndex = userIdToIndexMap.get(userId);
                indices[i++] = userIndex;
            }
            double[] values = new double[indices.length];
            Arrays.fill(values, 1);
            int card = userIdToIndexMap.size();
            Vector itemVec = new SparseVector(card, indices, values);
            return new Tuple2<>(x._1, itemVec);
        });

        JavaRDD<IndexedRow> indexedRows = itemVectors
                .map(x -> new IndexedRow(this.itemIdToIndexMap.get(x._1), x._2));
        return new IndexedRowMatrix(indexedRows.rdd());
    }
}
