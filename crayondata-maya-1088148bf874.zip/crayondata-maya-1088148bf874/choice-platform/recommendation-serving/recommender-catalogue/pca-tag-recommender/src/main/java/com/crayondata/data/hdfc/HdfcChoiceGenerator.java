/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.data.hdfc;

import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.Options;
import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.function.PairFunction;
import org.apache.spark.sql.DataFrame;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.RowFactory;
import org.apache.spark.sql.SQLContext;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.StructField;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.crayondata.choice.generator.BaseChoiceGenerator;
import com.crayondata.choice.generator.PCAChoiceGenerator;
import com.crayondata.choice.generator.PCASimChoiceGenerator;
import com.crayondata.choice.generator.TGChoiceGenerator;
import com.crayondata.recommender.pca.ScoredItem;
import com.crayondata.utils.CLIOptions;
import com.crayondata.utils.CommandLineOption;
import com.crayondata.utils.SparkConfUtils;

import scala.Tuple2;

/**
 * @author sundar
 */
public class HdfcChoiceGenerator {
    private static final Logger LOGGER = LoggerFactory.getLogger(HdfcChoiceGenerator.class);

    private static final Option TRXN_DIR = (Option) CLIOptions.OPT_TRXN_DIR.clone();
    static {
        TRXN_DIR.setRequired(true);
    }
    public static final Options CHOICE_GEN_CLI_OPTIONS = CommandLineOption
            .options(CLIOptions.OPT_TRXN_DIR, CLIOptions.OPT_OP_DIR, CLIOptions.OPT_MODELS,
                    CLIOptions.OPT_CHOICES, CLIOptions.OPT_TRXN_MERC_COL, CLIOptions.OPT_TRXN_CUST_COL,
                    CLIOptions.OPT_PARTITIONS);

    private SparkConf conf;
    private JavaSparkContext sc;
    private String transactionDir;
    private String outputDir;
    private int numOfChoices;
    private String merchantIdCol;
    private String customerIdCol;

    private HdfcChoiceGenerator(SparkConf conf, JavaSparkContext sc, String transactionDir,
            String outputDir, int numOfChoices, String merchantIdCol,
            String customerIdCol) {
        this.conf = conf;
        this.sc = sc;
        this.transactionDir = transactionDir;
        this.outputDir = outputDir;
        this.numOfChoices = numOfChoices;
        this.merchantIdCol = merchantIdCol;
        this.customerIdCol = customerIdCol;
    }

    public static void main(String[] args) {
        CommandLine line = CommandLineOption.parseArgs(CHOICE_GEN_CLI_OPTIONS, args, HdfcChoiceGenerator.class);

        String trxnDir = line.getOptionValue(TRXN_DIR.getOpt());
        String outputDir = line.getOptionValue(CLIOptions.OPT_OP_DIR.getOpt());
        int numOfChoices = Integer.valueOf(line.getOptionValue(CLIOptions.OPT_CHOICES.getOpt()));
        List<String> models = Arrays.asList(line.getOptionValue(CLIOptions.OPT_MODELS.getOpt()).split(","));
        String merchantIdField = line.getOptionValue(CLIOptions.OPT_TRXN_MERC_COL.getOpt(), "merchant_id");
        String customerIdField = line.getOptionValue(CLIOptions.OPT_TRXN_CUST_COL.getOpt(), "customer_id");
        String partitions = line.getOptionValue(CLIOptions.OPT_PARTITIONS.getOpt(), "100");

        SparkConf conf = new SparkConf().setAppName("HDFC Choice Generator - " + models);
        conf.set("spark.default.parallelism", partitions);
        SparkConfUtils.printSparkConf(conf);
        SparkConfUtils.logSparkConf(conf);

        JavaSparkContext sc = new JavaSparkContext(conf);
        sc.hadoopConfiguration().set("avro.mapred.ignore.inputs.without.extension", "false");
        sc.hadoopConfiguration().set("mapreduce.fileoutputcommitter.marksuccessfuljobs", "false");
        HdfcChoiceGenerator cg = new HdfcChoiceGenerator(conf, sc, trxnDir, outputDir, numOfChoices,
                merchantIdField, customerIdField);

        for (String model : models) {
            cg.runModel(model);
        }

        sc.stop();
    }

    private void runModel(String modelStr) {
        String modelOutputDir = Paths.get(outputDir, modelStr).toString();
        BaseChoiceGenerator<Long, Long> model;
        int tgPairsToTake = conf
                .getInt("spark.crayon.model.tg.top.tg.pairs", TGChoiceGenerator.DEFAULT_TOP_TG_PAIRS);
        int components = conf
                .getInt("spark.crayon.model.pca.components", PCAChoiceGenerator.DEFAULT_COMPONENTS_MIN);
        switch (modelStr) {
        /*case "tag":
            model = new HdfcUserAttrTagChoiceGenerator(sc, transactionDir, modelOutputDir, numOfChoices,
                    merchantDetailsDir);
            break;
        case "taggraph":
            model = new HdfcItemTagGraphChoiceGenerator(sc, transactionDir, merchantDetailsDir,
                    modelOutputDir, numOfChoices, tgPairsToTake);
            break;*/
        case "tg":
            model = new HdfcTGChoiceGenerator(sc, transactionDir, modelOutputDir, numOfChoices,
                    tgPairsToTake, merchantIdCol, customerIdCol);
            break;
        case "pca":
            model = new HdfcPCAChoiceGenerator(sc, transactionDir, modelOutputDir, numOfChoices, components,
                    merchantIdCol, customerIdCol);
            break;
        case "pca_item_sim":
            model = new HdfcPCAItemSimChoiceGenerator(sc, transactionDir, modelOutputDir, numOfChoices, components,
                    merchantIdCol, customerIdCol);
            break;
        default:
            LOGGER.error("Model '{}' is not valid. Skipping", modelStr);
            return;
        }
        model.run();
    }
    
    static class HdfcPCAItemSimChoiceGenerator extends PCASimChoiceGenerator<Long, Long> {
        private static final long serialVersionUID = 4554339684570222926L;

        private SQLContext sqlContext;
        private String merchantIdCol;
        private String customerIdCol;

        HdfcPCAItemSimChoiceGenerator(JavaSparkContext sparkContext, String interactionDir, String outputDir,
                int numOfChoices, int components, String merchantIdCol, String customerIdCol) {
            super(sparkContext, interactionDir, outputDir, numOfChoices, components, components);
            this.sqlContext = new SQLContext(sparkContext);
            this.merchantIdCol = merchantIdCol;
            this.customerIdCol = customerIdCol;
        }

        @Override
        public void readData() {
            userItemRDD = readTrxnData(sqlContext, interactionDir, customerIdCol, merchantIdCol);
        }

        @Override
        public void saveChoices() {
            String choiceOutputDir = Paths.get(outputDir, "choices").toString();
            saveUserChoices(sqlContext, choiceOutputDir, userChoices.get(getNumComponentsMin()));
        }
    }

    static class HdfcPCAChoiceGenerator extends PCAChoiceGenerator<Long, Long> {
        private static final long serialVersionUID = 4554339684570222926L;

        private SQLContext sqlContext;
        private String merchantIdCol;
        private String customerIdCol;

        HdfcPCAChoiceGenerator(JavaSparkContext sparkContext, String interactionDir, String outputDir,
                int numOfChoices, int components, String merchantIdCol, String customerIdCol) {
            super(sparkContext, interactionDir, outputDir, numOfChoices, components, components);
            this.sqlContext = new SQLContext(sparkContext);
            this.merchantIdCol = merchantIdCol;
            this.customerIdCol = customerIdCol;
        }

        @Override
        public void readData() {
            userItemRDD = readTrxnData(sqlContext, interactionDir, customerIdCol, merchantIdCol);
        }

        @Override
        public void saveChoices() {
            String choiceOutputDir = Paths.get(outputDir, "choices").toString();
            saveUserChoices(sqlContext, choiceOutputDir, userChoices.get(getNumComponentsMin()));
        }
    }

    static class HdfcTGChoiceGenerator extends TGChoiceGenerator<Long, Long> {
        private static final long serialVersionUID = -4854244493640619649L;

        private SQLContext sqlContext;
        private String merchantIdCol;
        private String customerIdCol;

        HdfcTGChoiceGenerator(JavaSparkContext sparkContext, String interactionDir, String outputDir,
                int numOfChoices, int topTGPairsToTake, String merchantIdCol, String customerIdCol) {
            super(sparkContext, interactionDir, outputDir, numOfChoices, topTGPairsToTake);
            this.sqlContext = new SQLContext(sparkContext);
            this.merchantIdCol = merchantIdCol;
            this.customerIdCol = customerIdCol;
        }

        @Override
        public void readData() {
            userItemRDD = readTrxnData(sqlContext, interactionDir, customerIdCol, merchantIdCol);
        }

        @Override
        public void saveChoices() {
            String choiceOutputDir = Paths.get(outputDir, "choices").toString();
            saveUserChoices(sqlContext, choiceOutputDir, userChoices);
        }
    }

    /*static class HdfcItemTagGraphChoiceGenerator extends ItemTagGraphChoiceGenerator<Long, Long> {
        private static final long serialVersionUID = -4416410095072242426L;

        HdfcItemTagGraphChoiceGenerator(JavaSparkContext sparkContext, String interactionDir,
                String itemAttrDir, String outputDir, int numOfChoices, int topTGPairsToTake) {
            super(sparkContext, interactionDir, itemAttrDir, outputDir, numOfChoices, topTGPairsToTake);
        }

        @Override
        public void readData() {
            itemAttr = sparkContext.textFile(itemAttrDir).filter(MERC_DATA_FILTER_FN)
                    .mapToPair(MERC_DATA_READ_FN);
            userItemRDD = sparkContext.textFile(interactionDir).filter(TRXN_DATA_FILTER_FN)
                    .mapToPair(TRXN_DATA_READ_FN);
        }
    }

    static class HdfcUserAttrTagChoiceGenerator extends UserAttrTagChoiceGenerator<Long, Long> {
        private static final long serialVersionUID = -3433621175405169191L;
        
        private SQLContext sqlContext;
        private String merchantIdCol;
        private String customerIdCol;
        private String tagCol;

        HdfcUserAttrTagChoiceGenerator(JavaSparkContext sparkContext, String interactionDir, String outputDir,
                int numOfChoices, String itemAttrDir) {
            super(sparkContext, interactionDir, outputDir, numOfChoices, itemAttrDir);
            this.sqlContext = new SQLContext(sparkContext);
        }

        @Override
        public void readData() {
            *//*itemAttr = sparkContext.textFile(itemAttrDir).filter(MERC_DATA_FILTER_FN)
                    .mapToPair(MERC_DATA_READ_FN);
            userItemRDD = sparkContext.textFile(interactionDir).filter(TRXN_DATA_FILTER_FN)
                    .mapToPair(TRXN_DATA_READ_FN);*//*
            userItemRDD = sqlContext.read().format("com.databricks.spark.avro").load(interactionDir)
                    .select(customerIdCol, merchantIdCol).toJavaRDD()
                    .mapToPair(TRXN_READ_FN);
        }
    }*/

    // @formatter:off
    /*static final Function<String, Boolean> MERC_DATA_FILTER_FN = (String line) -> line.split("\t").length >= 2;
    static final Function<String, Boolean> TRXN_DATA_FILTER_FN = (String line) -> line.split("\t").length >= 2;

    static final PairFunction<String, Long, List<String>> MERC_DATA_READ_FN = (String line) -> {
        String[] tokens = line.split("\t");
        List<String> tags = Arrays.stream(tokens[1].split(","))
                .map(String::trim)
                .filter(t -> t.length() > 0)
                .collect(Collectors.toList());
        return new Tuple2<>(Long.valueOf(tokens[0]), tags);
    };

    static final PairFunction<String, Long, Long> TRXN_DATA_READ_FN = (String line) -> {
        String[] tokens = line.split("\t");
        return new Tuple2<>(Long.valueOf(tokens[0]), Long.valueOf(tokens[1]));
    };*/

    private static <U, I> void saveUserChoices(SQLContext sqlContext, String outputDir,
            JavaPairRDD<U, List<ScoredItem<I>>> userChoices) {
        List<StructField> fields = new ArrayList<>();
        fields.add(DataTypes.createStructField("customer_id", DataTypes.LongType, false));
        fields.add(DataTypes.createStructField("merchant_id", DataTypes.LongType, false));
        fields.add(DataTypes.createStructField("score", DataTypes.DoubleType, false));

        JavaRDD<Row> choiceRow = userChoices.flatMapValues(x -> x).map(x -> RowFactory
                .create(new Object[] { x._1(), x._2().getItemId(), x._2().getScore() }));
        DataFrame affDF = sqlContext.createDataFrame(choiceRow, DataTypes.createStructType(fields));
        affDF.write().parquet(outputDir);
    }

    private static JavaPairRDD<Long, Long> readTrxnData(SQLContext sqlContext, String path, String userIdCol,
            String merchantIdCol) {
        return sqlContext.read().format("com.databricks.spark.avro").load(path)
                .select(userIdCol, merchantIdCol).toJavaRDD().mapToPair(TRXN_READ_FN).distinct();
    }

    private static final PairFunction<Row, Long, Long> TRXN_READ_FN = (Row row) -> new Tuple2<>(row.getLong(0), row.getLong(1));
    // @formatter:on
}
