/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.recommender.mlens;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;

import com.crayondata.recommender.mlens.RatingFileExplorer.ItemRating;
import com.google.common.collect.Iterables;

import scala.Tuple2;

/**
 * @author vivek
 */
public class RatingFileUniqTest implements Serializable {

    private static final long serialVersionUID = 1L;
    private static final String fileUri = "/home/vivek/GroupLens/movie-lens/Latest-Jan2017/ml-10M100K/ratings.dat";

    public static void main(String[] args) {
        SparkConf conf = new SparkConf().setAppName("Movie Lens Rating File explorer");
        conf.setIfMissing("spark.executor.memory", "64g");
        conf.setIfMissing("spark.num.executors", "1");
        // conf.setIfMissing("spark.executor.cores", "7");
        conf.setIfMissing("spark.executor.cores", "15");
        conf.setIfMissing("spark.storage.memoryFraction", "0.1");
        JavaSparkContext sc = new JavaSparkContext(conf);
        JavaRDD<String> fileText = sc.textFile(fileUri).cache();
        JavaPairRDD<Integer, ItemRating> userItemRating = fileText.mapToPair(x -> {
            String[] tokens = x.split("::");
            int userId = Integer.parseInt(tokens[0]);
            int itemId = Integer.parseInt(tokens[1]);
            float rating = Float.parseFloat(tokens[2]);
            long timestamp = Long.parseLong(tokens[3]);
            return new Tuple2<>(userId, new ItemRating(itemId, rating, timestamp));
        });
        System.out.println("Rating count: " + userItemRating.count());
        System.out.println("Unique user count: " + userItemRating.keys().distinct().count());

        JavaPairRDD<Integer, Integer> userItemIdRdd = userItemRating
                .mapToPair(x -> new Tuple2<>(x._1, x._2.getItemId()));

        JavaPairRDD<Integer, Iterable<Integer>> userItemGrouped = userItemIdRdd.groupByKey();
        JavaPairRDD<Integer, Integer> userItemCountRdd = userItemGrouped.mapToPair(x -> {
            Set<Integer> uniqItems = new HashSet<>();
            Iterables.addAll(uniqItems, x._2);
            return new Tuple2<>(x._1, uniqItems.size());
        });

        Integer uniqItemCount = userItemCountRdd.map(x -> x._2).fold(0, (x, y) -> x + y);
        System.out.println("Unique items rated by all users:" + uniqItemCount);
    }
}
