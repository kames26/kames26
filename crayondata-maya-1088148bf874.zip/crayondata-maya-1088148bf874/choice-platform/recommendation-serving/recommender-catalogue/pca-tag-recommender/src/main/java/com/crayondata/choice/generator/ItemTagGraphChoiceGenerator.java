/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.choice.generator;

import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.function.Function2;
import org.apache.spark.storage.StorageLevel;

import com.crayondata.recommender.pca.ScoredItem;

import scala.Tuple2;

/**
 * @author sundar
 */
public abstract class ItemTagGraphChoiceGenerator<U, I> extends BaseChoiceGenerator<U, I> {

    private static final long serialVersionUID = 2771602111816299856L;

    private int topTGPairsToTake;

    protected String itemAttrDir;
    protected JavaPairRDD<U, I> userItemRDD;
    protected JavaPairRDD<I, List<String>> itemAttr;
    private JavaPairRDD<I, List<ScoredItem<I>>> tgPairs;

    public ItemTagGraphChoiceGenerator(JavaSparkContext sparkContext, String interactionDir,
            String itemAttrDir, String outputDir, int numOfChoices, int topTGPairsToTake) {
        super(sparkContext, interactionDir, outputDir, numOfChoices);
        this.itemAttrDir = itemAttrDir;
        this.topTGPairsToTake = topTGPairsToTake;
    }

    @Override
    public void runModel() {
        Map<I, Integer> attrLenMap = itemAttr.mapValues(List::size).collectAsMap();
        JavaPairRDD<String, I> attrToItem = itemAttr.flatMapValues(x -> x).mapToPair(Tuple2::swap);

        JavaPairRDD<Tuple2<I, I>, Integer> pairCountRDD = attrToItem.join(attrToItem).mapToPair(Tuple2::_2)
                .filter(x -> !x._1.equals(x._2)).mapToPair(x -> new Tuple2<>(x, 1))
                .persist(StorageLevel.DISK_ONLY())
                .reduceByKey((x, y) -> x + y);

        JavaPairRDD<I, Tuple2<I, Double>> allTgPairs = pairCountRDD.mapToPair(x -> {
            I item1Id = x._1._1;
            I item2Id = x._1._2;
            Integer pairCount = x._2;
            Integer item1Count = attrLenMap.get(item1Id);
            Integer item2Count = attrLenMap.get(item2Id);
            double score = (pairCount * 1.0) / (item1Count + item2Count);
            return new Tuple2<>(item1Id, new Tuple2<>(item2Id, score));
        }).persist(StorageLevel.DISK_ONLY());

        tgPairs = TGChoiceGenerator.getTopNTGPairs(allTgPairs, topTGPairsToTake).persist(StorageLevel.DISK_ONLY());
    }

    @Override
    public void saveModelData() {
        String outputPath = Paths.get(outputDir, "tag-graph-pairs").toString();
        tgPairs.flatMapValues(x -> x)
                .map(x -> x._1 + "\t" + x._2.getItemId() + "\t" + x._2.getScore())
                .saveAsTextFile(outputPath);
    }

    @Override
    public void generateChoices() {
        userChoices = TGChoiceGenerator.generateChoices(userItemRDD, tgPairs, numOfChoices)
                .persist(StorageLevel.DISK_ONLY());
    }

    private Function2<List<ScoredItem<I>>, ScoredItem<I>, List<ScoredItem<I>>> addEntryFn = (v1, v2) -> {
        v1.add(v2);
        return v1;
    };

    private Function2<List<ScoredItem<I>>, List<ScoredItem<I>>, List<ScoredItem<I>>> combineFn = (v1, v2) -> {
        List<ScoredItem<I>> r = new ArrayList<>(v1.size() + v2.size());
        r.addAll(v1);
        r.addAll(v2);
        return r;
    };
}
