/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.data.hdfc;

import java.util.ArrayList;
import java.util.List;

import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.function.PairFunction;
import org.apache.spark.sql.DataFrame;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.RowFactory;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.StructField;
import static org.apache.spark.sql.functions.*;

import scala.Tuple2;

import com.crayondata.choice.merger.BaseChoiceMerger;

public class HdfcChoiceMerger extends BaseChoiceMerger<Long, Long> {

    private static final long serialVersionUID = -268335441389811797L;

    HdfcChoiceMerger(JavaSparkContext sc, String uri1, String uri2, String opUri) {
        super(sc, uri1, uri2, opUri);
    }

    @Override
    public void readData() {
        choicesFromModel1 = sqlContext.read().parquet(modelInputURI1)
                .select("merchant_id", "customer_id", "score").sort(desc("score")).javaRDD()
                .mapToPair(CHOICE_READ_FN);
        choicesFromModel2 = sqlContext.read().parquet(modelInputURI2)
                .select("merchant_id", "customer_id", "score").sort(desc("score")).javaRDD()
                .mapToPair(CHOICE_READ_FN);
    }
    
    @Override
    public void saveData() {
            List<StructField> fields = new ArrayList<>();
            fields.add(DataTypes.createStructField("customer_id", DataTypes.LongType, false));
            fields.add(DataTypes.createStructField("merchant_id", DataTypes.LongType, false));
            fields.add(DataTypes.createStructField("model1_score", DataTypes.DoubleType, false));
            fields.add(DataTypes.createStructField("model1_rank", DataTypes.LongType, false));
            fields.add(DataTypes.createStructField("model2_score", DataTypes.DoubleType, false));
            fields.add(DataTypes.createStructField("model2_rank", DataTypes.LongType, false));

            JavaRDD<Row> choiceRow = joinedRDD.map(x -> {
            
            Long customer = x._1._1;
            Long merchant = x._1._2;
            Double model1_score = 0.0;
            Long model1_rank = (long) 0;
            Double model2_score = 0.0;
            Long model2_rank = (long) 0;
            
            if(x._2._1.isPresent()){
                model1_score = x._2._1.get()._1;
                model1_rank = x._2._1.get()._2;           
            }
            
            if(x._2._2.isPresent()){
                model2_score = x._2._2.get()._1;
                model2_rank = x._2._2.get()._2;           
            }
            
            return RowFactory           
            .create(new Object[] { customer, merchant, model1_score,model1_rank,model2_score,model2_rank});
            });
            DataFrame affDF = sqlContext.createDataFrame(choiceRow, DataTypes.createStructType(fields));
            affDF.write().parquet(outputURI);
        }
    

    private static final PairFunction<Row, Tuple2<Long, Long>, Double> CHOICE_READ_FN = (Row row) -> new Tuple2<>(
            new Tuple2<>(row.getLong(0), row.getLong(1)), row.getDouble(2));

    public static void main(String[] args) {

        SparkConf conf = new SparkConf().setAppName("ChoiceMerger application")
                //.setMaster("local[2]").set("spark.executor.memory", "1g");
                 .set("spark.executor.memory", "64g").set("spark.num.executors", "1")
                 .set("spark.total.executor.cores",
                         "36").set("spark.storage.memoryFraction", "0.1");
        JavaSparkContext sc = new JavaSparkContext(conf);
        HdfcChoiceMerger merger = new HdfcChoiceMerger(sc, args[0], args[1], args[2]);
        merger.run();
    }
}
