/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.recommender.choice;

import java.io.Serializable;

/**
 * @author vivek
 */
public class UserChoiceRecord implements Serializable {
    private static final long serialVersionUID = -2323994796669823665L;
    private String userId;
    private int itemId;
    private int success;
    private int tgRank;
    private double tgScore;
    private int pcaRank;
    private double pcaScore;
    private double blendedScore;
    private final String choiceId;

    public UserChoiceRecord(String userId, int itemId, int success, int tgRank, double tgScore, int pcaRank,
            double pcaScore) {
        super();
        this.userId = userId;
        this.itemId = itemId;
        this.success = success;
        this.tgRank = tgRank;
        this.tgScore = tgScore;
        this.pcaRank = pcaRank;
        this.pcaScore = pcaScore;
        this.choiceId = itemId + "::" + userId;
    }

    public String toString() {
        return userId + "," + itemId + "," + success + "," + blendedScore + "," + tgRank + "," + tgScore + ","
                + pcaRank + "," + pcaScore;
    }

    /**
     * Input format
     * userId, itemId, success, tgRank, tgScore, pcaRank, pcaScore
     *
     * @param input
     */
    public static UserChoiceRecord parse(String input) {
        String tokens[] = input.split(",");

        String userId = tokens[0];
        int itemId = Integer.parseInt(tokens[1]);
        int success = Integer.parseInt(tokens[2]);
        int tgRank = Integer.parseInt(tokens[3]);
        double tgScore = Double.parseDouble(tokens[4]);
        int pcaRank = Integer.parseInt(tokens[5]);
        double pcaScore = Double.parseDouble(tokens[6]);

        return new UserChoiceRecord(userId, itemId, success, tgRank, tgScore, pcaRank, pcaScore);
    }

    public String getChoiceId() {
        return choiceId;
    }

    public String getUserId() {
        return userId;
    }

    public int getItemId() {
        return itemId;
    }

    public int getSuccess() {
        return success;
    }

    public void setSuccess(int success) {
        this.success = success;
    }

    public int getTgRank() {
        return tgRank;
    }

    public double getTgScore() {
        return tgScore;
    }

    public int getPcaRank() {
        return pcaRank;
    }

    public double getPcaScore() {
        return pcaScore;
    }

    public double getBlendedScore() {
        return blendedScore;
    }

    public void setBlendedScore(double blendedScore) {
        this.blendedScore = blendedScore;
    }

}
