/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.choice.generator;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.spark.SparkConf;
import org.apache.spark.SparkContext;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.sql.DataFrame;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.RowFactory;
import org.apache.spark.sql.SQLContext;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.StructField;

import scala.Tuple2;
import scala.Tuple4;
import scala.Tuple5;
import scala.Tuple6;

import com.clearspring.analytics.util.Lists;

public class DecileCalculator {
    
    private static final Logger log = Logger.getLogger(DecileCalculator.class);
    private String testTransactions;
    private String choiceData;
    protected SQLContext sqlContext;
    protected String outputDir;
    protected String merchantId;
    protected String cutomerID;
    private static final int partitions = 500;

    public DecileCalculator(SparkContext sparkContext, String testTransactions, String choiceData, String outputDir,
            String merchant, String cusomterId) {
        this.testTransactions = testTransactions;
        this.choiceData = choiceData;
        this.sqlContext = new SQLContext(sparkContext);
        this.sqlContext.sparkContext().hadoopConfiguration().set("avro.mapred.ignore.inputs.without.extension",
                "false");
        this.sqlContext.sparkContext().hadoopConfiguration().set("mapreduce.fileoutputcommitter.marksuccessfuljobs",
                "false");
        this.merchantId = merchant;
        this.cutomerID = cusomterId;
        this.outputDir = outputDir;
    }

    public static void main(String[] args) {

        SparkConf config = new SparkConf().setAppName("BackTesting");
        SparkContext sparkContext = new SparkContext(config);

        Logger.getLogger("org").setLevel(Level.ERROR);
        Logger.getLogger("akka").setLevel(Level.ERROR);

        if (args.length != 5) {
            log.error("Provide <Test Transactions in Avro>  <Choice Data> <Output Path> <Mechant_Field_Name>"
                    + " Customer_Id_Field_Name>");
            System.exit(1);
        }

        String testTransactions = args[0];
        String choiceData = args[1];
        String outputDir = args[2];
        String merchantField = args[3];
        String customerIdField = args[4];

        long startTime = System.currentTimeMillis();
        DecileCalculator dc = new DecileCalculator(sparkContext, testTransactions, choiceData, outputDir, merchantField,
                customerIdField);
        dc.processData();

        long stopTime = System.currentTimeMillis();
        log.info("Took: " + (stopTime - startTime) + " ms");
    }

    public void processData() {
        // load transactions and test transactions data
        JavaPairRDD<Long, Long> testTransactions = loadTransactionData(this.testTransactions).distinct();

        // join choice data
        JavaPairRDD<Tuple2<Long, Long>, Double> choices = loadChoiceData();

        // add transaction flag by checking with latest transaction
        JavaRDD<Tuple4<Long, Long, Double, Boolean>> flagedChoices = combineTestTransactionsWithChoices(
                testTransactions, choices);

        // normalizing affinity scores on merchant level
        JavaRDD<Tuple6<Long, Long, Double, Boolean, Double, String>> noralizedAffinity = normalizingAffinity(
                flagedChoices);
        
        HashMap<Long, Tuple2<String, String>> merchantNameCat  = loadMerchantNameCat();

        // saving output
        saveNormalizedAffinity(noralizedAffinity, merchantNameCat, outputDir);

    }

    public JavaPairRDD<Tuple2<Long, Long>, Double> loadChoiceData() {
        DataFrame df = sqlContext.read().parquet(choiceData).select("merchant_id", "customer_id",
                "avg_affinity");
        return df.javaRDD().mapToPair(row -> new Tuple2<>(new Tuple2<>(row.getLong(0), row.getLong(1)), row.getDouble(2)));

    }
    
    public HashMap<Long, Tuple2<String, String>> loadMerchantNameCat() {
        DataFrame df = sqlContext.read().parquet(choiceData).select("merchant_id", "merchant_name", "merchant_cat");
        
        return new HashMap<Long, Tuple2<String, String>>(df.toJavaRDD()
                .mapToPair(row -> new Tuple2<>(row.getLong(0), new Tuple2<>(row.getString(1), row.getString(2))))
                .distinct().collectAsMap());
    }
    

    public JavaPairRDD<Long, Long> loadTransactionData(String transactionPath) {
        DataFrame df = sqlContext.read().format("com.databricks.spark.avro").load(transactionPath).select(merchantId,
                cutomerID);
        return df.toJavaRDD().mapToPair(row -> new Tuple2<>((long) row.getInt(0), (long) row.getInt(1)));
    }

    public JavaRDD<Tuple4<Long, Long, Double, Boolean>> combineTestTransactionsWithChoices(
            JavaPairRDD<Long, Long> testTransactions, JavaPairRDD<Tuple2<Long, Long>, Double> choices) {

        JavaPairRDD<Tuple2<Long, Long>, Integer> transactions = testTransactions
                .mapToPair(record -> new Tuple2<>(record, 1));

        JavaRDD<Tuple4<Long, Long, Double, Boolean>> joinedResult = choices.leftOuterJoin(transactions)
                .map(record -> new Tuple4<>(record._1._2(), record._1._1(), record._2._1(), record._2._2.isPresent()));
        return joinedResult;
    }

    public static JavaRDD<Tuple6<Long, Long, Double, Boolean, Double, String>> normalizingAffinity(
            JavaRDD<Tuple4<Long, Long, Double, Boolean>> flagedChoices) {

        class Record implements Serializable, Comparable<Record> {
            private static final long serialVersionUID = 1L;
            private double affinity;
            private long customer_id;

            public Record(double affinity, long customer_id) {
                this.affinity = affinity;
                this.customer_id = customer_id;
            }

            @Override
            public int compareTo(Record o) {
                int compAffinity = Double.compare(this.affinity, o.affinity);
                if (compAffinity != 0)
                    return compAffinity;
                else
                    return Long.compare(this.customer_id, o.customer_id);

            }
        }

        JavaPairRDD<Tuple4<Long, Long, Double, Boolean>, Long> sortedValues = flagedChoices
                .sortBy(record -> new Record(record._3(), record._1()), false, partitions).zipWithIndex();

        long maxRank = sortedValues.count();
        JavaRDD<Tuple5<Long, Long, Double, Boolean, Double>> percentile = sortedValues
                .map(record -> new Tuple5<>(record._1._1(), record._1._2(), record._1._3(), record._1._4(),
                        ((maxRank - record._2()) * 100.0) / maxRank));

        String[] percentileRangle = { "0-10", "10-20", "20-30", "30-40", "40-50", "50-60", "60-70", "70-80", "80-90",
                "90-100" };

        return percentile.map(record -> {
            int decile_range;
            double percentileValue = record._5();
            if (percentileValue >= 90)
                decile_range = 9;
            else if (percentileValue >= 80)
                decile_range = 8;
            else if (percentileValue >= 70)
                decile_range = 7;
            else if (percentileValue >= 60)
                decile_range = 6;
            else if (percentileValue >= 50)
                decile_range = 5;
            else if (percentileValue >= 40)
                decile_range = 4;
            else if (percentileValue >= 30)
                decile_range = 3;
            else if (percentileValue >= 20)
                decile_range = 2;
            else if (percentileValue >= 10)
                decile_range = 1;
            else
                decile_range = 0;
            return new Tuple6<>(record._1(), record._2(), record._3(), record._4(), record._5(),
                    percentileRangle[decile_range]);
        });
    }

    public void saveNormalizedAffinity(JavaRDD<Tuple6<Long, Long, Double, Boolean, Double, String>> normalizedAffinity,
            HashMap<Long, Tuple2<String, String>> merchantNameCat, String outputPath) {

        List<StructField> fields = Lists.newArrayList();
        fields.add(DataTypes.createStructField("customer_id", DataTypes.LongType, false));
        fields.add(DataTypes.createStructField("merchant_id", DataTypes.LongType, false));
        fields.add(DataTypes.createStructField("merchant_name", DataTypes.StringType, false));
        fields.add(DataTypes.createStructField("merchant_cat", DataTypes.StringType, false));
        fields.add(DataTypes.createStructField("affinity_score", DataTypes.DoubleType, false));
        fields.add(DataTypes.createStructField("txn_flag", DataTypes.BooleanType, false));
        fields.add(DataTypes.createStructField("percentile", DataTypes.DoubleType, false));
        fields.add(DataTypes.createStructField("affinity_group", DataTypes.StringType, false));

        JavaRDD<Row> affRow = normalizedAffinity.map(x -> RowFactory.create(new Object[] { x._1(), x._2(),
                merchantNameCat.get(x._2())._1(), merchantNameCat.get(x._2())._2(), x._3(), x._4(), x._5(), x._6() }));
        DataFrame affDF = sqlContext.createDataFrame(affRow, DataTypes.createStructType(fields));
        affDF.write().parquet(outputPath);

    }
}
