/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.choice.generator;

import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.api.java.function.Function2;
import org.apache.spark.mllib.linalg.DenseMatrix;
import org.apache.spark.mllib.linalg.DenseVector;
import org.apache.spark.mllib.linalg.Matrices;
import org.apache.spark.mllib.linalg.Matrix;
import org.apache.spark.mllib.linalg.SingularValueDecomposition;
import org.apache.spark.mllib.linalg.SparseVector;
import org.apache.spark.mllib.linalg.Vector;
import org.apache.spark.mllib.linalg.distributed.CoordinateMatrix;
import org.apache.spark.mllib.linalg.distributed.IndexedRow;
import org.apache.spark.mllib.linalg.distributed.IndexedRowMatrix;
import org.apache.spark.mllib.linalg.distributed.MatrixEntry;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.crayondata.recommender.pca.ScoredItem;
import com.crayondata.utils.MaxHeap;
import com.google.common.collect.Iterables;

import scala.Tuple2;

/**
 * @author sundar
 */
public abstract class PCAChoiceGenerator<U, I> extends BaseChoiceGenerator<U, I> {

    private static final long serialVersionUID = 2134660828698797850L;
    private static final Logger LOGGER = LoggerFactory.getLogger(PCAChoiceGenerator.class);

    public static final int DEFAULT_COMPONENTS_MIN = 3;
    public static final int DEFAULT_COMPONENTS_MAX = 10;

    // Following are initialized from constructor
    protected int numComponentsMin;
    protected int numComponentsMax;

    // Following are variables used while processing
    protected JavaPairRDD<U, I> userItemRDD;
    private Map<U, Integer> userIdToIndexMap;
    private Map<Integer, U> userIndexToIdMap;
    private Map<I, Integer> itemIdToIndexMap;
    protected Map<Integer, I> itemIndexToIdMap;
    protected Map<Integer, SingularValueDecomposition<IndexedRowMatrix, Matrix>> numComponentsToMatrix;
    protected Map<Integer, JavaPairRDD<U, List<ScoredItem<I>>>> userChoices;

    public PCAChoiceGenerator(JavaSparkContext sparkContext, String interactionDir, String outputDir,
            int numOfChoices, int numComponentsMin, int numComponentsMax) {
        super(sparkContext, interactionDir, outputDir, numOfChoices);
        this.numComponentsMin = numComponentsMin;
        this.numComponentsMax = numComponentsMax;
    }

    public int getNumComponentsMin() {
        return numComponentsMin;
    }

    public int getNumComponentsMax() {
        return numComponentsMax;
    }

    @Override
    public void runModel() {
        initIdIndexMaps();
        IndexedRowMatrix matrix = constructMatrix();
        LOGGER.info("Matrix Dimensions: [{}, {}]", matrix.numRows(), matrix.numCols());

        numComponentsToMatrix = new HashMap<>();
        for (int numComponents = numComponentsMin; numComponents <= numComponentsMax; numComponents++) {
            LOGGER.info("Computing SVD with {} components", numComponents);
            SingularValueDecomposition<IndexedRowMatrix, Matrix> svd = matrix
                    .computeSVD(numComponents, true, 1.0E-9d);
            numComponentsToMatrix.put(numComponents, svd);
            /*Vector data = getSqrtVector(svd.s());
            // ?? sMatrix
            Matrix sMatrix = Matrices.diag(data).transpose();
            // ?? pComponents
            IndexedRowMatrix componentsMatrix = svd.U().multiply(sMatrix);
            Matrix userMatrix = svd.V();

            List<MatrixEntry> matrixEntries = new ArrayList<>(userMatrix.numRows() * userMatrix.numCols());
            for (int i = 0; i < userMatrix.numRows(); i++) {
                for (int j = 0; j < userMatrix.numCols(); j++) {
                    matrixEntries.add(new MatrixEntry(i, j, userMatrix.apply(i, j)));
                }
            }
            JavaRDD<MatrixEntry> matrixEntriesRDD = sparkContext.parallelize(matrixEntries);
            // ?? userComponents
            IndexedRowMatrix userComponents = new CoordinateMatrix(matrixEntriesRDD.rdd()).toIndexedRowMatrix();*/
        }
    }

    @Override
    public void saveModelData() {
        // Do nothing for now
    }

    @Override
    public void generateChoices() {
        JavaPairRDD<U, Set<I>> userItemSetRdd = userItemRDD
                .combineByKey(createSetAggregateFunction(), createSetValueCombinerFunction(),
                        createSetCombinerCombinerFunction()).persist(StorageLevel.DISK_ONLY());

        userChoices = new HashMap<>();
        for (int numComponents = numComponentsMin; numComponents <= numComponentsMax; numComponents++) {
            SingularValueDecomposition<IndexedRowMatrix, Matrix> svd = numComponentsToMatrix
                    .get(numComponents);
            JavaPairRDD<U, Vector> userPreferenceVector = generateUserPreferenceVector(svd);
            Matrix pComponents = generatePComponentsMatrix(svd).toBlockMatrix().toLocalMatrix();

            JavaPairRDD<U, Tuple2<Vector, Set<I>>> userItemPrefVector = userPreferenceVector
                    .join(userItemSetRdd);

            final int components = numComponents;
            JavaPairRDD<U, List<ScoredItem<I>>> choices = userItemPrefVector
                    .mapToPair(x -> generateChoicesForUser(pComponents, x, components))
                    .persist(StorageLevel.DISK_ONLY());
            userChoices.put(numComponents, choices);
        }
    }

    @Override
    public void saveChoices() {
        for (int numComponents = numComponentsMin; numComponents <= numComponentsMax; numComponents++) {
            String subDir = String.format("choices-components-%02d", numComponents);
            String outputDir = Paths.get(this.outputDir, subDir).toString();
            userChoices.get(numComponents).flatMapValues(x -> x)
                    .map(x -> x._1 + "\t" + x._2.getItemId() + "\t" + x._2.getScore())
                    .saveAsTextFile(outputDir);
        }
    }

    // Builds the index->id & id->index map used to fill matrices
    private void initIdIndexMaps() {
        List<U> userIds = userItemRDD.keys().distinct().collect();
        // userIdToIndexMap = new ImmutableBiMap.Builder<String, Integer>().build();
        userIdToIndexMap = new HashMap<>();
        userIndexToIdMap = new HashMap<>();
        for (int i = 0; i < userIds.size(); i++) {
            userIdToIndexMap.put(userIds.get(i), i);
            userIndexToIdMap.put(i, userIds.get(i));
        }
        // userIndexToIdMap = userIdToIndexMap.inverse();

        List<I> itemIds = userItemRDD.values().distinct().collect();
        // itemIdToIndexMap = new ImmutableBiMap.Builder<Integer, Integer>().build();
        itemIdToIndexMap = new HashMap<>();
        itemIndexToIdMap = new HashMap<>();
        for (int i = 0; i < itemIds.size(); i++) {
            itemIdToIndexMap.put(itemIds.get(i), i);
            itemIndexToIdMap.put(i, itemIds.get(i));
        }
        // itemIndexToIdMap = itemIdToIndexMap.inverse();
    }

    private IndexedRowMatrix constructMatrix() {
        JavaPairRDD<I, Iterable<U>> itemUserGrouped = userItemRDD.mapToPair(Tuple2::swap)
                .groupByKey();
        JavaPairRDD<I, Vector> itemVectors = itemUserGrouped.mapToPair(itemGroup -> {
            int[] userIdIndices = new int[Iterables.size(itemGroup._2)];
            int i = 0;
            for (U userId : itemGroup._2) {
                int userIndex = userIdToIndexMap.get(userId);
                userIdIndices[i++] = userIndex;
            }

            double[] values = new double[userIdIndices.length];
            Arrays.fill(values, 1);

            int card = userIdToIndexMap.size();

            Vector itemVec = new SparseVector(card, userIdIndices, values);
            return new Tuple2<>(itemGroup._1, itemVec);
        });
        JavaRDD<IndexedRow> indexedRows = itemVectors
                .map(x -> new IndexedRow(this.itemIdToIndexMap.get(x._1), x._2));
        return new IndexedRowMatrix(indexedRows.rdd());
    }

    private Vector getSqrtVector(Vector v) {
        double[] data = v.toArray();
        for (int i = 0; i < data.length; i++) {
            data[i] = Math.sqrt(data[i]);
        }
        return new DenseVector(data);
    }

    private JavaPairRDD<U, Vector> generateUserPreferenceVector(
            SingularValueDecomposition<IndexedRowMatrix, Matrix> svd) {
        IndexedRowMatrix userComponents = generateUserComponentsMatrix(svd);
        JavaRDD<IndexedRow> rowsRDD = userComponents.rows().toJavaRDD();
        return rowsRDD.mapToPair(row -> {
            int index = (int) row.index();
            Vector vector = row.vector();
            U userId = this.userIndexToIdMap.get(index);
            return new Tuple2<>(userId, vector);
        });
    }

    private IndexedRowMatrix generateUserComponentsMatrix(
            SingularValueDecomposition<IndexedRowMatrix, Matrix> svd) {
        Matrix userMatrix = svd.V();

        List<MatrixEntry> matrixEntries = new ArrayList<>(userMatrix.numRows() * userMatrix.numCols());
        for (int i = 0; i < userMatrix.numRows(); i++) {
            for (int j = 0; j < userMatrix.numCols(); j++) {
                matrixEntries.add(new MatrixEntry(i, j, userMatrix.apply(i, j)));
            }
        }
        JavaRDD<MatrixEntry> matrixEntriesRDD = sparkContext.parallelize(matrixEntries);
        // ?? userComponents
        return new CoordinateMatrix(matrixEntriesRDD.rdd()).toIndexedRowMatrix();
    }

    private IndexedRowMatrix generatePComponentsMatrix(
            SingularValueDecomposition<IndexedRowMatrix, Matrix> svd) {
        Vector data = getSqrtVector(svd.s());
        Matrix sMatrix = Matrices.diag(data).transpose();
        return svd.U().multiply(sMatrix);
    }

    private Tuple2<U, List<ScoredItem<I>>> generateChoicesForUser(Matrix pComponents,
            Tuple2<U, Tuple2<Vector, Set<I>>> itemPrefVector, int numComponents) {
        U userId = itemPrefVector._1;
        Vector taste = itemPrefVector._2._1;
        Set<I> userTransactionSet = itemPrefVector._2._2;

        DenseMatrix tasteVector = new DenseMatrix(1, taste.size(), taste.toArray());

        if (taste.size() != numComponents) {
            System.err.println("Choices are not generated for: user with vector card:" + taste.size());
            return new Tuple2<>(userId, new LinkedList<>());
        }

        MaxHeap<ScoredItem<I>> topChoices = new MaxHeap<>(numOfChoices);
        Matrix itemScores = pComponents.multiply(tasteVector.transpose());
        for (int i = 0; i < pComponents.numRows(); i++) {
            I itemId = itemIndexToIdMap.get(i);
            if (userTransactionSet.contains(itemId))
                continue;
            double score = itemScores.apply(i, 0);
            ScoredItem<I> item = new ScoredItem<>(itemId, score);
            topChoices.include(item);
        }
        return new Tuple2<>(userId, topChoices.getAll());
    }

    private static <T> Function<T, Set<T>> createSetAggregateFunction() {
        return x -> {
            Set<T> l = new HashSet<>();
            l.add(x);
            return l;
        };
    }

    private static <T> Function2<Set<T>, T, Set<T>> createSetValueCombinerFunction() {
        return (x, y) -> {
            x.add(y);
            return x;
        };
    }

    private static <T> Function2<Set<T>, Set<T>, Set<T>> createSetCombinerCombinerFunction() {
        return (x, y) -> {
            Set<T> newSet = new HashSet<>();
            newSet.addAll(x);
            newSet.addAll(y);
            return newSet;
        };
    }
}
