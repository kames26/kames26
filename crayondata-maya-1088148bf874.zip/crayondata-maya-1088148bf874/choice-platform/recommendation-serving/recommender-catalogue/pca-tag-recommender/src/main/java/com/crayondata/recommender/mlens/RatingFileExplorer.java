/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.recommender.mlens;

import java.io.Serializable;
import java.util.Comparator;

import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;

import com.google.common.collect.Iterables;

import scala.Tuple2;

/**
 * @author vivek
 */
public class RatingFileExplorer implements Serializable {

    private static final long serialVersionUID = 1L;
    private static final String fileUri = "/home/vivek/GroupLens/movie-lens/Latest-Jan2017/ml-10M100K/ratings.dat";

    private static final int MIN_INTERACTIONS = 10;

    public static void main(String[] args) {
        SparkConf conf = new SparkConf().setAppName("Movie Lens Rating File explorer");
        conf.setIfMissing("spark.executor.memory", "64g");
        conf.setIfMissing("spark.num.executors", "1");
        // conf.setIfMissing("spark.executor.cores", "7");
        conf.setIfMissing("spark.executor.cores", "15");
        conf.setIfMissing("spark.storage.memoryFraction", "0.1");
        JavaSparkContext sc = new JavaSparkContext(conf);
        JavaRDD<String> fileText = sc.textFile(fileUri).cache();
        JavaPairRDD<Integer, ItemRating> userItemRating = fileText.mapToPair(x -> {
            String[] tokens = x.split("::");
            int userId = Integer.parseInt(tokens[0]);
            int itemId = Integer.parseInt(tokens[1]);
            float rating = Float.parseFloat(tokens[2]);
            long timestamp = Long.parseLong(tokens[3]);
            return new Tuple2<>(userId, new ItemRating(itemId, rating, timestamp));
        });
        System.out.println("Rating count: " + userItemRating.count());
        System.out.println("Unique user count: " + userItemRating.keys().distinct().count());

        JavaPairRDD<Integer, ItemRating> filtered = userItemRating.filter(x -> x._2.getRating() >= 3);

        System.out.println("Filtered --> Rating count:" + filtered.count());
        System.out.println("Filtered --> Unique user count:" + filtered.keys().distinct().count());

        JavaPairRDD<Integer, Iterable<ItemRating>> filteredGrouped = filtered.groupByKey();
        JavaPairRDD<Integer, Iterable<ItemRating>> userMinIntrFiltered = filteredGrouped.filter(x -> Iterables.size(x._2) >= MIN_INTERACTIONS);
        JavaPairRDD<Integer, ItemRating> userMinIntrFilteredTrans = userMinIntrFiltered.flatMapValues(x -> x);

        System.out.println("Filtered (UserMinIntr) --> Rating count:" + userMinIntrFilteredTrans.count());
        System.out.println(
                "Filtered (UserMinIntr) --> Unique user count:" + userMinIntrFilteredTrans.keys().distinct()
                        .count());
        JavaPairRDD<Integer, Integer> userIntrCount = userMinIntrFilteredTrans
                .mapToPair(x -> new Tuple2<>(x._1, 1)).reduceByKey((x, y) -> x + y);
        int minIntrCount = userIntrCount.values().min(new SerializableComparator());
        int maxIntrCount = userIntrCount.values().max(new SerializableComparator());
        int intrCountSum = userIntrCount.values().fold(0, (x, y) -> x + y);
        int userCount = (int) userIntrCount.keys().count();
        float avgIntrCount = (intrCountSum * 1.0f) / userCount;

        System.out.println("Min interaction:" + minIntrCount);
        System.out.println("Max interaction:" + maxIntrCount);
        System.out.println("Avg interaction:" + avgIntrCount);

        JavaRDD<String> toPrint = userMinIntrFilteredTrans.map(x -> {
            int userId = x._1;
            int itemId = x._2.getItemId();
            float rating = x._2.getRating();
            long timestamp = x._2.getTimestamp();
            return userId + "::" + itemId + "::" + rating + "::" + timestamp;
        });
        toPrint.saveAsTextFile("ouput_mlens_rating");
    }

    static class SerializableComparator implements Comparator<Integer>, Serializable {
        private static final long serialVersionUID = 1L;
        @Override
        public int compare(Integer o1, Integer o2) {
            return o1.compareTo(o2);
        }
    }

    static class ItemRating implements Serializable {
        private static final long serialVersionUID = 1L;
        private int itemId;
        private float rating;
        private long timestamp;

        long getTimestamp() {
            return timestamp;
        }

        public int getItemId() {
            return itemId;
        }

        public void setItemId(int itemId) {
            this.itemId = itemId;
        }

        float getRating() {
            return rating;
        }

        ItemRating(int itemId, float rating, long timestamp) {
            this.itemId = itemId;
            this.rating = rating;
            this.timestamp = timestamp;
        }
    }
}
