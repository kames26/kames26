/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.data.citi;

import org.apache.spark.api.java.JavaSparkContext;

import com.crayondata.choice.generator.ItemTagGraphChoiceGenerator;

/**
 * @author sundar
 */
public class CitiItemTagGraphChoiceGenerator extends ItemTagGraphChoiceGenerator<Long, String> {
    private static final long serialVersionUID = 627178115469904344L;

    CitiItemTagGraphChoiceGenerator(JavaSparkContext sparkContext, String interactionDir,
            String itemAttrDir, String outputDir, int numOfChoices, int numTopTGPairs) {
        super(sparkContext, interactionDir, itemAttrDir, outputDir, numOfChoices, numTopTGPairs);
    }

    @Override
    public void readData() {
        itemAttr = sparkContext.textFile(itemAttrDir).filter(CitiChoiceGenerator.ATTR_DATA_FILTER_FN)
                .mapToPair(CitiChoiceGenerator.ATTR_DATA_READ_FN);
        userItemRDD = sparkContext.textFile(interactionDir).filter(CitiChoiceGenerator.INTR_DATA_FILTER_FN)
                .mapToPair(CitiChoiceGenerator.INTR_DATA_READ_FN);
    }
}
