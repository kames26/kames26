/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.data.kotak;

import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.Options;
import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.function.PairFunction;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SQLContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.crayondata.choice.generator.BaseChoiceGenerator;
import com.crayondata.choice.generator.ItemTagGraphChoiceGenerator;
import com.crayondata.choice.generator.TGChoiceGenerator;
import com.crayondata.choice.generator.UserAttrTagChoiceGenerator;
import com.crayondata.utils.CLIOptions;
import com.crayondata.utils.CommandLineOption;
import com.crayondata.utils.SparkConfUtils;

import scala.Tuple2;

/**
 * @author sundar
 */
public class KotakChoiceGenerator {
    private static final Logger LOGGER = LoggerFactory.getLogger(KotakChoiceGenerator.class);

    // @formatter:off
    private static final Option MERC_DIR = (Option) CLIOptions.OPT_MERC_DIR.clone();
    static {
        MERC_DIR.setRequired(true);
    }
    private static final Options CLI_OPTIONS = CommandLineOption
            .options(CLIOptions.OPT_TRXN_DIR, CLIOptions.OPT_TRXN_MERC_COL, CLIOptions.OPT_TRXN_CUST_COL,
                    MERC_DIR, CLIOptions.OPT_MERC_MERC_COL, CLIOptions.OPT_MERC_TAG_COL,
                    CLIOptions.OPT_OP_DIR, CLIOptions.OPT_MODELS,
                    CLIOptions.OPT_CHOICES, CLIOptions.OPT_PARTITIONS );
    // @formatter:on

    private SparkConf conf;
    private JavaSparkContext sc;
    private String transactionDir;
    private String merchantDir;
    private String outputDir;
    private int numOfChoices;
    private String trxnMercIdCol;
    private String trxnCustIdCol;
    private String mercMercIdCol;
    private String mercTagCol;

    private KotakChoiceGenerator(SparkConf conf, JavaSparkContext sc, String transactionDir,
            String merchantDir, String outputDir, int numOfChoices, String trxnMercIdCol,
            String trxnCustIdCol, String mercMercIdCol, String mercTagCol) {
        this.conf = conf;
        this.sc = sc;
        this.transactionDir = transactionDir;
        this.merchantDir = merchantDir;
        this.outputDir = outputDir;
        this.numOfChoices = numOfChoices;
        this.trxnMercIdCol = trxnMercIdCol;
        this.trxnCustIdCol = trxnCustIdCol;
        this.mercMercIdCol = mercMercIdCol;
        this.mercTagCol = mercTagCol;
    }

    public static void main(String[] args) {
        CommandLine line = CommandLineOption.parseArgs(CLI_OPTIONS, args, KotakChoiceGenerator.class);

        String trxnDir = line.getOptionValue(CLIOptions.OPT_TRXN_DIR.getOpt());
        String mercDir = line.getOptionValue(MERC_DIR.getOpt());
        String outputDir = line.getOptionValue(CLIOptions.OPT_OP_DIR.getOpt());
        int numOfChoices = Integer.valueOf(line.getOptionValue(CLIOptions.OPT_CHOICES.getOpt()));
        List<String> models = Arrays.asList(line.getOptionValue(CLIOptions.OPT_MODELS.getOpt()).split(","));
        String trxnMercIdField = line.getOptionValue(CLIOptions.OPT_TRXN_MERC_COL.getOpt(), "merchant_id");
        String trxnCustIdField = line.getOptionValue(CLIOptions.OPT_TRXN_CUST_COL.getOpt(), "customer_id");
        String mercMercIdField = line.getOptionValue(CLIOptions.OPT_MERC_MERC_COL.getOpt(), "merchant_id");
        String mercTagField = line.getOptionValue(CLIOptions.OPT_MERC_TAG_COL.getOpt(), "tags");
        String partitions = line.getOptionValue(CLIOptions.OPT_PARTITIONS.getOpt(), "100");

        SparkConf conf = new SparkConf().setAppName("Kotak Choice Generator - " + models);
        conf.set("spark.default.parallelism", partitions);
        SparkConfUtils.printSparkConf(conf);
        SparkConfUtils.logSparkConf(conf);

        JavaSparkContext sc = new JavaSparkContext(conf);
        sc.hadoopConfiguration().set("avro.mapred.ignore.inputs.without.extension", "false");
        sc.hadoopConfiguration().set("mapreduce.fileoutputcommitter.marksuccessfuljobs", "false");
        KotakChoiceGenerator cg = new KotakChoiceGenerator(conf, sc, trxnDir, mercDir, outputDir,
                numOfChoices, trxnMercIdField, trxnCustIdField, mercMercIdField, mercTagField);

        for (String model : models) {
            cg.runModel(model);
        }

        sc.stop();
    }

    private void runModel(String modelStr) {
        String modelOutputDir = Paths.get(outputDir, modelStr).toString();
        BaseChoiceGenerator<String, String> model;
        int tgPairsToTake = conf
                .getInt("spark.crayon.model.tg.top.tg.pairs", TGChoiceGenerator.DEFAULT_TOP_TG_PAIRS);
        switch (modelStr) {
        case "tag":
            model = new KotakUserAttrTagChoiceGenerator(sc, transactionDir, modelOutputDir, numOfChoices,
                    merchantDir, trxnMercIdCol, trxnCustIdCol, mercMercIdCol, mercTagCol);
            break;
        case "taggraph":
            model = new KotakItemTagGraphChoiceGenerator(sc, transactionDir, merchantDir, modelOutputDir,
                    numOfChoices, tgPairsToTake, trxnMercIdCol, trxnCustIdCol, mercMercIdCol, mercTagCol);
            break;
        case "tg":
            model = new KotakTGChoiceGenerator(sc, transactionDir, modelOutputDir, numOfChoices,
                    tgPairsToTake, trxnMercIdCol, trxnCustIdCol);
            break;
        default:
            LOGGER.error("Model '{}' is not valid. Skipping", modelStr);
            return;
        }
        model.run();
    }

    static class KotakTGChoiceGenerator extends TGChoiceGenerator<String, String> {
        private static final long serialVersionUID = 8063719117390697026L;

        private SQLContext sqlContext;
        private String trxnMercIdCol;
        private String trxnCustIdCol;

        KotakTGChoiceGenerator(JavaSparkContext sparkContext, String interactionDir, String outputDir,
                int numOfChoices, int topTGPairsToTake, String trxnMercIdCol, String trxnCustIdCol) {
            super(sparkContext, interactionDir, outputDir, numOfChoices, topTGPairsToTake);
            this.sqlContext = new SQLContext(sparkContext);
            this.trxnMercIdCol = trxnMercIdCol;
            this.trxnCustIdCol = trxnCustIdCol;
        }

        @Override
        public void readData() {
            userItemRDD = readTrxnData(sqlContext, interactionDir, trxnCustIdCol, trxnMercIdCol);
        }
    }

    static class KotakItemTagGraphChoiceGenerator extends ItemTagGraphChoiceGenerator<String, String> {
        private static final long serialVersionUID = 8079086661303734435L;

        private SQLContext sqlContext;
        private String trxnMercIdCol;
        private String trxnCustIdCol;
        private String mercMercIdCol;
        private String mercTagCol;

        KotakItemTagGraphChoiceGenerator(JavaSparkContext sparkContext, String interactionDir,
                String itemAttrDir, String outputDir, int numOfChoices, int topTGPairsToTake,
                String trxnMercIdCol, String trxnCustIdCol, String mercMercIdCol, String mercTagCol) {
            super(sparkContext, interactionDir, itemAttrDir, outputDir, numOfChoices, topTGPairsToTake);
            this.sqlContext = new SQLContext(sparkContext);
            this.trxnMercIdCol = trxnMercIdCol;
            this.trxnCustIdCol = trxnCustIdCol;
            this.mercMercIdCol = mercMercIdCol;
            this.mercTagCol = mercTagCol;
        }

        @Override
        public void readData() {
            itemAttr = readMercData(sqlContext, itemAttrDir, mercMercIdCol, mercTagCol);
            userItemRDD = readTrxnData(sqlContext, interactionDir, trxnCustIdCol, trxnMercIdCol);
        }
    }

    static class KotakUserAttrTagChoiceGenerator extends UserAttrTagChoiceGenerator<String, String> {
        private static final long serialVersionUID = -2169477975921621887L;

        private SQLContext sqlContext;
        private String trxnMercIdCol;
        private String trxnCustIdCol;
        private String mercMercIdCol;
        private String mercTagCol;

        KotakUserAttrTagChoiceGenerator(JavaSparkContext sparkContext, String interactionDir,
                String outputDir, int numOfChoices, String itemAttrDir, String trxnMercIdCol,
                String trxnCustIdCol, String mercMercIdCol, String mercTagCol) {
            super(sparkContext, interactionDir, outputDir, numOfChoices, itemAttrDir);
            this.sqlContext = new SQLContext(sparkContext);
            this.trxnMercIdCol = trxnMercIdCol;
            this.trxnCustIdCol = trxnCustIdCol;
            this.mercMercIdCol = mercMercIdCol;
            this.mercTagCol = mercTagCol;
        }

        @Override
        public void readData() {
            userItemRDD = readTrxnData(sqlContext, interactionDir, trxnCustIdCol, trxnMercIdCol);
            itemAttr = readMercData(sqlContext, itemAttrDir, mercMercIdCol, mercTagCol);
        }
    }

    // @formatter:off
    private static JavaPairRDD<String, String> readTrxnData(SQLContext sqlContext, String path, String userIdCol,
            String merchantIdCol) {
        return sqlContext.read().format("com.databricks.spark.avro").load(path)
                .select(userIdCol, merchantIdCol).toJavaRDD().mapToPair(TRXN_READ_FN).distinct();
    }

    private static final PairFunction<Row, String, String> TRXN_READ_FN = (Row row) -> new Tuple2<>(row.getString(0), row.getString(1));

    private static JavaPairRDD<String, List<String>> readMercData(SQLContext sqlContext, String path, String mercIdCol, String tagCol) {
        return sqlContext.read().format("com.databricks.spark.avro").load(path)
                .select(mercIdCol, tagCol).toJavaRDD().mapToPair(MERC_TAG_READ_FN);
    }
    // @formatter:on

    private static final PairFunction<Row, String, List<String>> MERC_TAG_READ_FN = (Row row) -> new Tuple2<>(
            row.getString(0), row.isNullAt(1) ?
            new ArrayList<>() :
            Arrays.stream(row.getString(1).split(",")).map(String::trim).filter(t -> t.length() > 0)
                    .collect(Collectors.toList()));
}
