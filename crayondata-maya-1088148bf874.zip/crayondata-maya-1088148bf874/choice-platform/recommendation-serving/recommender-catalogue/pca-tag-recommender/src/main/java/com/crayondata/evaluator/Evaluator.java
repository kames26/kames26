/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.evaluator;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.api.java.function.Function2;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.crayondata.utils.SparkConfUtils;

import scala.Tuple2;

/**
 * @author sundar
 */
public class Evaluator {
    private final static Logger LOGGER = LoggerFactory.getLogger(Evaluator.class);

    private final static String USER_ACCURACY_FILE = "PerUserAccuracy";
    // private final static String USER_CHOICES_FILE = "UserChoices";

    // Functions used to aggregate elements into a list
    private static <T> Function<T, List<T>> createListAggregateFunction() {
        return x -> {
            List<T> l = new ArrayList<>();
            l.add(x);
            return l;
        };
    }

    private static <T> Function2<List<T>, T, List<T>> createListValueCombinerFunction() {
        return (x, y) -> {
            x.add(y);
            return x;
        };
    }

    private static <T> Function2<List<T>, List<T>, List<T>> createListCombinerCombinerFunction() {
        return (x, y) -> {
            List<T> newList = new ArrayList<>(x.size() + y.size());
            newList.addAll(x);
            newList.addAll(y);
            return newList;
        };
    }

    private JavaSparkContext sparkContext;
    private String testDataDir;
    private String choicesDir;
    private String outputDir;
    private int startNChoices;
    private int endNChoices;

    public Evaluator(JavaSparkContext sparkContext, String testDataDir, String choicesDir, String outputDir,
            int startNChoices, int endNChoices) {
        this.sparkContext = sparkContext;
        this.testDataDir = testDataDir;
        this.choicesDir = choicesDir;
        this.outputDir = outputDir;
        this.startNChoices = startNChoices;
        this.endNChoices = endNChoices;
    }

    public static void main(String[] args) {
        SparkConf conf = new SparkConf().setAppName("Choices Evaluator");
        SparkConfUtils.printSparkConf(conf);
        SparkConfUtils.logSparkConf(conf);
        conf.setIfMissing("spark.executor.memory", "64g");
        conf.setIfMissing("spark.num.executors", "1");
        // conf.setIfMissing("spark.executor.cores", "7");
        conf.setIfMissing("spark.executor.cores", "15");
        conf.setIfMissing("spark.storage.memoryFraction", "0.1");
        SparkConfUtils.printSparkConf(conf);
        SparkConfUtils.logSparkConf(conf);

        if (args.length < 5) {
            System.err.println("Usage: " + Evaluator.class + " <test-data-dir> <choices-dir> <output-dir> "
                    + "<start-n> <end-n>");
            System.exit(1);
        }

        JavaSparkContext sparkContext = new JavaSparkContext(conf);

        String testDataDir = args[0];
        String choicesDir = args[1];
        String outputDir = args[2];
        int startN = Integer.valueOf(args[3]);
        int endN = Integer.valueOf(args[4]);

        Evaluator evaluator = new Evaluator(sparkContext, testDataDir, choicesDir, outputDir, startN, endN);
        evaluator.evaluateAndSaveMetrics();
        sparkContext.stop();
    }

    private void evaluateAndSaveMetrics() {
        // Step 1 - Read data
        // 1-a) Reading test data. user to list<item>
        JavaPairRDD<String, List<Integer>> testData = readTestData();
        // 1-b) Reading choice data. user to list<choice> ordered by priority
        JavaPairRDD<String, List<Integer>> choiceData = readChoiceData();

        for (int numChoices = startNChoices; numChoices <= endNChoices; numChoices++) {
            // Step 2 - Evaluate UserMetrics for each n
            JavaPairRDD<String, ChoiceMetrics> metrics = computeMetrics(testData, choiceData, numChoices);
            // Step 3 - Save UserMetrics for each n
            savePerUserMetrics(metrics, numChoices);
            // Step 4 - Compute overall metrics for each n
            ChoiceMetrics overallMetrics = computeOverallMetrics(metrics);
            // @formatter:off
            System.out.println("Average accuracy across all users for " + numChoices + " choices is " + overallMetrics.getAccuracy());
            System.out.println("Average coverage across all users for " + numChoices + " choices is " + overallMetrics.getCoverage());
            LOGGER.info("Average accuracy across all users for " + numChoices + " choices is " + overallMetrics.getAccuracy());
            LOGGER.info("Average coverage across all users for " + numChoices + " choices is " + overallMetrics.getCoverage());
            // @formatter:on
        }
    }

    private ChoiceMetrics computeOverallMetrics(JavaPairRDD<String, ChoiceMetrics> metrics) {
        ChoiceMetrics sum = metrics.values().fold(new ChoiceMetrics(), ChoiceMetrics::addMetrics);
        double accuracyMean = sum.getMatchCount() / sum.getChoiceCount();
        double coverageMean = sum.getMatchCount() / sum.getItemCount();
        return new ChoiceMetrics(accuracyMean, coverageMean, 0, 0, 0);
    }

    private void savePerUserMetrics(JavaPairRDD<String, ChoiceMetrics> metrics, int numChoices) {
        JavaRDD<String> toPrint = metrics.map(input -> input._1 + "," + input._2.toString());
        String subDir = "numChoices-" + String.format("%02d", numChoices);
        Path opPath = Paths.get(this.outputDir, USER_ACCURACY_FILE, subDir);
        toPrint.saveAsTextFile(opPath.toString());
    }

    protected JavaPairRDD<String, List<Integer>> readTestData() {
        return sparkContext.textFile(testDataDir).mapToPair(line -> {
            String[] tokens = line.split("\t");
            return new Tuple2<>(tokens[0], Integer.valueOf(tokens[1]));
        }).combineByKey(createListAggregateFunction(), createListValueCombinerFunction(),
                createListCombinerCombinerFunction());
    }

    protected JavaPairRDD<String, List<Integer>> readChoiceData() {
        return sparkContext.textFile(choicesDir).mapToPair(line -> {
            String[] tokens = line.split("\t");
            return new Tuple2<>(tokens[0], Integer.valueOf(tokens[1]));
        }).combineByKey(createListAggregateFunction(), createListValueCombinerFunction(),
                createListCombinerCombinerFunction());
    }

    private JavaPairRDD<String, ChoiceMetrics> computeMetrics(JavaPairRDD<String, List<Integer>> testData,
            JavaPairRDD<String, List<Integer>> choiceData, int numChoices) {
        JavaPairRDD<String, Tuple2<List<Integer>, List<Integer>>> userToItemsAndChoices = testData
                .join(choiceData);

        return userToItemsAndChoices.mapToPair(input -> {
            List<Integer> items = input._2._1;
            List<Integer> choices = input._2._2;
            int choiceCount = choices.size();
            if (choiceCount > numChoices) {
                choices = choices.subList(0, numChoices);
                choiceCount = numChoices;
            }

            final Map<Integer, Boolean> itemMap = items.stream().collect(Collectors.toMap(i -> i, i -> true));
            final int matchCount = (int) choices.stream().filter(itemMap::containsKey).count();
            final int itemCount = items.size();
            double accuracy = 0.0;
            double coverage = (matchCount * 1.0) / itemCount;
            if (choiceCount > 0)
                accuracy = (matchCount * 1.0) / choiceCount;

            ChoiceMetrics choiceMetrics = new ChoiceMetrics(accuracy, coverage, choiceCount, itemCount,
                    matchCount);
            return new Tuple2<>(input._1, choiceMetrics);
        });
    }

    /*private JavaPairRDD<String, List<ScoredItem>> readUserScoredItemData() {
        return sparkContext.textFile(choicesDir).mapToPair(line -> {
            String[] tokens = line.split("::");
            String userId = tokens[0];
            int itemId = Integer.valueOf(tokens[1]);
            double score = Double.valueOf(tokens[2]);
            int count = Integer.valueOf(tokens[3]);
            double maxScore = Double.valueOf(tokens[4]);
            return new Tuple2<>(userId, new ScoredItem(itemId, score, count, maxScore));
        }).combineByKey(createListAggregateFunction(), createListValueCombinerFunction(),
                createListCombinerCombinerFunction());
    }*/
}
