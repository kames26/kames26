/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.choice.evaluator;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.PriorityQueue;

import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;

import scala.Tuple2;

import com.crayondata.recommender.pca.ScoredItem;
import com.crayondata.utils.SparkConfUtils;

public class TopNChoiceGen {
	
	private static int n = 5;

	public static void main(String[] args) {
		SparkConf conf = new SparkConf().setAppName("Top N choice gen");
        conf.set("spark.default.parallelism", "256");
        SparkConfUtils.printSparkConf(conf);
        SparkConfUtils.logSparkConf(conf);

        JavaSparkContext sc = new JavaSparkContext(conf);

        JavaRDD<String> text = sc.textFile("cust_activity_choices_1.csv").cache();
        JavaPairRDD<String, ScoredActivity> custActivities =   
        	text.mapToPair(x -> {
        	String[] tokens = x.split(",");
        	String custId = tokens[0];
        	String activityType = tokens[1];
        	double score = Double.parseDouble(tokens[5]);
        	String custUuid = tokens[6];
        	
        	return new Tuple2<>(custId, new ScoredActivity(custId, activityType, score, custUuid));
        });
        
        JavaPairRDD<String, Iterable<ScoredActivity>> custGrouped = 
        	custActivities.groupByKey();
        
        JavaPairRDD<String, List<ScoredActivity>> custTopNChoices =   
        	custGrouped.mapToPair(x -> {
            PriorityQueue<ScoredActivity> topNChoicesQ = new PriorityQueue<>(n);
            List<ScoredActivity> topNChoices = new LinkedList<>();

            for (ScoredActivity tuple : x._2) {
            	ScoredActivity scoredItem = tuple;
                if (topNChoicesQ.size() < n)
                    topNChoicesQ.add(scoredItem);
                else {
                    double minScore = topNChoicesQ.peek().getScore();
                    if (scoredItem.getScore() > minScore) {
                        // Remove min and add
                        topNChoicesQ.remove();
                        topNChoicesQ.add(scoredItem);
                    }// else ignore.
                }
            }

            int rank = 1;
            while (!topNChoicesQ.isEmpty()) {
            	ScoredActivity s = topNChoicesQ.remove();
            	s.setRank(rank++);
                topNChoices.add(0, s);
            }

            return new Tuple2<>(x._1, topNChoices);
        });
        	
        	
        JavaRDD<ScoredActivity>  activitiesRdd = custTopNChoices.flatMapToPair(x -> {
        		String custId = x._1;
        		List<ScoredActivity> items = x._2;
        		List<Tuple2<String, ScoredActivity>> tuples = new ArrayList<>();
        		for(ScoredActivity item : items){
        			tuples.add(new Tuple2<>(custId, item));
        		}
        		return tuples;
        	}).map(x -> x._2);
        JavaRDD<String> toPrint = activitiesRdd.map(x -> {
        	StringBuilder buf = new StringBuilder();
        	
        	buf.append(x.getCustUuid()+",")
        	.append(x.getCustId()+",")
        	.append(x.getActityType()+",")
        	.append(x.getScore()+",")
        	.append(x.getRank()+",");
        	
        	return buf.toString();
        }
        		);
        
        toPrint.saveAsTextFile("output");
	}
	
	static class ScoredActivity implements Serializable, Comparable<ScoredActivity>{
		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;
		private String custId;
		private String actityType;
		private Double score;
		private String custUuid;
		private int rank;
		public ScoredActivity(String custId, String actityType, 
				double score, String custUuid) {
			super();
			this.custId = custId;
			this.actityType = actityType;
			this.score = score;
			this.custUuid = custUuid;
		}
		public String getCustId() {
			return custId;
		}
		public String getActityType() {
			return actityType;
		}
		public double getScore() {
			return score;
		}
		
		public String getCustUuid(){
			return this.custUuid;
		}
		
		public int getRank(){
			return this.rank;
		}
		
		public void setRank(int rank){
			this.rank = rank;
		}
		@Override
		public int compareTo(ScoredActivity o) {
			return this.score.compareTo(o.score);
		}
	}

}
