/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.choice.merger;

import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.SQLContext;

import scala.Tuple2;

import com.google.common.base.Optional;

public abstract class BaseChoiceMerger <U extends Comparable<U>, I extends Comparable<I>> implements ChoiceMerger<U,I>{
    
    private static final long serialVersionUID = -8931896565760370654L;

    protected String modelInputURI1;
    protected String modelInputURI2;
    protected String outputURI;
    protected JavaSparkContext sparkContext;
    protected SQLContext sqlContext;
    protected JavaPairRDD<Tuple2<U, I>, Double> choicesFromModel1;
    protected JavaPairRDD<Tuple2<U, I>, Double> choicesFromModel2;
    protected JavaPairRDD<Tuple2<U, I>, Tuple2<Optional<Tuple2<Double, Long>>, Optional<Tuple2<Double, Long>>>> joinedRDD ;
        
    protected BaseChoiceMerger(JavaSparkContext sc, String uri1, String uri2, String opUri) {
        modelInputURI1 = uri1;
        modelInputURI2 = uri2;
        outputURI = opUri;
        sparkContext = sc;
        sqlContext = new SQLContext(sparkContext);
    }

    @Override
    public void mergeChoices() {
        JavaPairRDD<Tuple2<U, I>, Tuple2<Double, Long>> rankedChoicesFromModel1 = rankChoices(choicesFromModel1);
        rankedChoicesFromModel1.saveAsTextFile(outputURI + "/rankedChoices1");
        JavaPairRDD<Tuple2<U, I>, Tuple2<Double, Long>> rankedChoicesFromModel2 = rankChoices(choicesFromModel2);
        rankedChoicesFromModel2.saveAsTextFile(outputURI + "/rankedChoices2");
        joinedRDD = rankedChoicesFromModel1.fullOuterJoin(rankedChoicesFromModel2);
        //joinedRDD.map(f-> f._2._1)
    }

    JavaPairRDD<Tuple2<U, I>, Tuple2<Double, Long>> rankChoices(JavaPairRDD<Tuple2<U, I>, Double> choices){
        JavaPairRDD<Tuple2<U, I>, Tuple2<Double, Long>> rankedChoices = choices.zipWithIndex().mapToPair(row -> {
           return new Tuple2<>(new Tuple2<>(row._1._1._1,row._1._1._2), new Tuple2<>(row._1._2,row._2)); 
        });
       return rankedChoices;
    }
 }
