/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.utils;

import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.function.Function;

import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;

import scala.Tuple2;

/**
 * @author sundar
 */
public class DataSplitter {

    public final static float TRAIN_RATIO = 0.6f;

    /**
     * 1. Filter for minimum interaction count.
     * 2. Create train and test split with 80% and 20% data respectively
     * for every user.
     *
     * @param userItemRdd         User-Item data-set
     * @param minInteractionCount Minimum interaction count of users to be considered
     * @return Train & test data-set
     */
    public static <U, I> JavaPairRDD<U, Tuple2<List<I>, List<I>>> createTrainTestSplit(
            final JavaPairRDD<U, I> userItemRdd, final int minInteractionCount) {
        JavaPairRDD<U, Iterable<I>> userGrouped = userItemRdd.groupByKey();
        JavaPairRDD<U, Iterable<I>> filtered = userGrouped
                .filter(x -> Iterables.size(x._2) >= minInteractionCount);

        return filtered.mapToPair(x -> {
            Set<I> uniqueItemIds = new HashSet<>();
            Iterables.addAll(uniqueItemIds, x._2);
            Iterator<I> idItr = uniqueItemIds.iterator();

            int size = uniqueItemIds.size();
            int trainSize = (int) (size * TRAIN_RATIO);

            List<I> train = Lists.newArrayListWithCapacity(trainSize);
            for (int i = 0; i < trainSize && idItr.hasNext(); i++)
                train.add(idItr.next());

            List<I> test = Lists.newArrayListWithCapacity(size - trainSize);
            while (idItr.hasNext())
                test.add(idItr.next());

            return new Tuple2<>(x._1, new Tuple2<>(train, test));
        });
    }

    // TODO: Move this to a IO-based class
    public static <U, T> void persistTestAndTrain(
            JavaPairRDD<U, Tuple2<List<T>, List<T>>> trainAndTest, String outputDir) {
        JavaPairRDD<U, List<T>> train = trainAndTest.mapValues(Tuple2::_1);
        JavaPairRDD<U, List<T>> test = trainAndTest.mapValues(Tuple2::_2);

        Function<Tuple2<U, T>, String> concat = x -> x._1.toString() + "\t" + x._2.toString();
        train.flatMapValues(x -> x).map(concat).saveAsTextFile(outputDir + "/train/");
        test.flatMapValues(x -> x).map(concat).saveAsTextFile(outputDir + "/test/");
    }

    public static void main(String[] args) {
        SparkConf conf = new SparkConf().setAppName("Data Split - Train & Test");
        // Print the spark conf to console & log for debugging
        SparkConfUtils.printSparkConf(conf);
        SparkConfUtils.logSparkConf(conf);

        if (args.length < 3) {
            System.err.println(
                    "Usage: " + DataSplitter.class + " <input> <output> <min-interaction-count> [separator]");
            System.err.println("Default separator : tab");
            System.exit(1);
        }

        final String inputDir = args[0];
        final String outputDir = args[1];
        final int interactionCount = Integer.valueOf(args[2]);
        final String separator = args.length >= 4 ? args[3] : "\t";

        JavaSparkContext sc = new JavaSparkContext(conf);
        JavaRDD<String> fileText = sc.textFile(inputDir).cache();
        JavaPairRDD<String, String> userItemRdd = fileText.filter(x -> x.split(separator).length >= 2)
                .mapToPair(x -> {
                    String[] tokens = x.split(separator);
                    return new Tuple2<>(tokens[0], tokens[1]);
                });
        JavaPairRDD<String, Tuple2<List<String>, List<String>>> trainAndTest = createTrainTestSplit(
                userItemRdd.mapToPair(Tuple2::swap), interactionCount);
        persistTestAndTrain(trainAndTest, outputDir);
        sc.stop();
    }
}
