/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.evaluator;

import java.io.Serializable;

/**
 * @author sundar
 */
public class ChoiceMetrics implements Serializable {

    private static final long serialVersionUID = 7938998318587847383L;

    private double accuracy;
    private double coverage;
    private int choiceCount;
    private int itemCount;
    private int matchCount;

    public ChoiceMetrics() {
    }

    public ChoiceMetrics(double accuracy, double coverage, int choiceCount, int itemCount, int matchCount) {
        this.accuracy = accuracy;
        this.coverage = coverage;
        this.choiceCount = choiceCount;
        this.itemCount = itemCount;
        this.matchCount = matchCount;
    }

    public double getAccuracy() {
        return accuracy;
    }

    public double getCoverage() {
        return coverage;
    }

    public int getChoiceCount() {
        return choiceCount;
    }

    public int getItemCount() {
        return itemCount;
    }

    public int getMatchCount() {
        return matchCount;
    }

    public ChoiceMetrics addMetrics(ChoiceMetrics that) {
        double accuracy = this.accuracy + (that != null ? that.accuracy : 0);
        double coverage = this.coverage + (that != null ? that.coverage : 0);
        int choiceCount = this.choiceCount + (that != null ? that.choiceCount : 0);
        int itemCount = this.itemCount + (that != null ? that.itemCount : 0);
        int matchCount = this.matchCount + (that != null ? that.matchCount : 0);
        return new ChoiceMetrics(accuracy, coverage, choiceCount, itemCount, matchCount);
    }

    @Override
    public String toString() {
        return accuracy + "\t" + coverage + "\t" + choiceCount + "\t" + itemCount + "\t" + matchCount;
    }
}
