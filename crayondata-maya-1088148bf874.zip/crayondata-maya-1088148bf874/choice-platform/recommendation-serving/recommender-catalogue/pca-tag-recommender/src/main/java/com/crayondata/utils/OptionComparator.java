/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.utils;

import java.util.Comparator;

import org.apache.commons.cli.Option;

/**
 * @author sundar
 */
public class OptionComparator implements Comparator {
    @Override
    public int compare(Object o1, Object o2) {
        Option opt1 = (Option) o1;
        Option opt2 = (Option) o2;

        int compareVal =
                opt1.isRequired() == opt2.isRequired() ? 0 : opt1.isRequired() && !opt2.isRequired() ? -1 : 1;
        if (compareVal != 0)
            return compareVal;

        if (opt1.getOpt() != null && opt1.getOpt() != null)
            compareVal = opt1.getOpt().compareToIgnoreCase(opt2.getOpt());

        if (compareVal != 0)
            return compareVal;

        return opt1.getLongOpt().compareToIgnoreCase(opt2.getLongOpt());
    }
}
