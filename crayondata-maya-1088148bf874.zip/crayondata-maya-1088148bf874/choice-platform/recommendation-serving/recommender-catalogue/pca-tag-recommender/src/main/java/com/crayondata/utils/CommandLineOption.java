/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.utils;

import java.io.PrintWriter;
import java.io.StringWriter;

import org.apache.commons.cli.BasicParser;
import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.HelpFormatter;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.OptionBuilder;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.ParseException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.crayondata.data.hdfc.HdfcChoiceGenerator;

/**
 * @author sundar
 */
public class CommandLineOption {
    private static final Logger LOGGER = LoggerFactory.getLogger(CommandLineOption.class);

    public static Option getOption(boolean required, String opt, String longOpt,
            String argName, String desc) {
        OptionBuilder.withArgName(argName);
        OptionBuilder.hasArg();
        OptionBuilder.withDescription(desc);
        OptionBuilder.withLongOpt(longOpt);
        OptionBuilder.isRequired(required);
        return OptionBuilder.create(opt);
    }

    public static Options options(Option... options) {
        Options cliOptions = new Options();
        for (Option o : options)
            cliOptions.addOption(o);
        return cliOptions;
    }


    public static CommandLine parseArgs(Options options, String[] args, Class className) {
        CommandLine line = null;
        try {
            CommandLineParser parser = new BasicParser();
            line = parser.parse(options, args);
        } catch (ParseException e) {
            HelpFormatter formatter = new HelpFormatter();
            formatter.setOptionComparator(new OptionComparator());
            StringWriter stringWriter = new StringWriter();
            PrintWriter pw = new PrintWriter(stringWriter);
            // e.printStackTrace(pw);
            formatter.printHelp(pw, HelpFormatter.DEFAULT_WIDTH, className.getName(), null,
                    options, HelpFormatter.DEFAULT_LEFT_PAD, HelpFormatter.DEFAULT_DESC_PAD, null, true);
            pw.flush();
            pw.close();
            LOGGER.info(stringWriter.toString());
            throw new IllegalArgumentException(e);
        }
        return line;
    }
}
