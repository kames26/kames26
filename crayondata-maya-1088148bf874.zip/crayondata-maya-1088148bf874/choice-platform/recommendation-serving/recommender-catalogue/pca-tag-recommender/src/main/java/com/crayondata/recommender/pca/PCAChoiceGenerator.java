/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.recommender.pca;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.Random;
import java.util.stream.Collectors;

import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.mllib.linalg.DenseMatrix;
import org.apache.spark.mllib.linalg.DenseVector;
import org.apache.spark.mllib.linalg.Matrix;
import org.apache.spark.mllib.linalg.Vector;
import org.apache.spark.storage.StorageLevel;
import org.junit.Assert;

import com.clearspring.analytics.util.Lists;
import com.crayondata.recommender.tg.TGChoiceGenerator;

import scala.Tuple2;

/**
 * @author vivek
 */
public class PCAChoiceGenerator implements Serializable {

    private static final long serialVersionUID = 1L;
    // private int nComponents;
    // private int nChoices;

    public JavaPairRDD<String, List<ScoredItem<Integer>>> generateChoices(JavaSparkContext sc,
            JavaPairRDD<String, Tuple2<List<Integer>, List<Integer>>> trainAndTest, int nComponents,
            int nChoices, Map<Integer, Vector> itemPCAMap, PCAGenerator pcaGen) {
		// JavaPairRDD<String, Vector> userPrefVectors = generateUserPrefVectors(trainAndTest, itemPCAMap, nComponents);
        JavaPairRDD<String, Vector> userPrefVectors = pcaGen.generateUserPrefVectors();
        Matrix pComponents = pcaGen.getPComponents().toBlockMatrix().toLocalMatrix();
        final int itemCount = pComponents.numRows();
        PriorityQueue<ScoredItem<Integer>> topNChoices = new PriorityQueue<>(nChoices);
        JavaPairRDD<String, Map<Integer, Boolean>> userTrainMapRdd = trainAndTest
                .mapValues(x -> x._1.stream().collect(Collectors.toMap(y -> y, y -> true)));

        JavaPairRDD<String, Tuple2<Vector, Map<Integer, Boolean>>> userTrainPrefVector = userPrefVectors
                .join(userTrainMapRdd);

        // Generating choices & return
        return userTrainPrefVector.mapToPair(x -> {
            String userId = x._1;
            Vector taste = x._2._1;
            Map<Integer, Boolean> userTrainMap = x._2._2;
            int trainSize = userTrainMap.size();
            DenseMatrix tasteVec = new DenseMatrix(1, taste.size(), taste.toArray());
            System.err.println("Size of taste pref of user: " + taste.size());
            if (taste.size() == nComponents) {
                DenseMatrix transposed = tasteVec.transpose();
                Matrix itemScores = pComponents.multiply(transposed);
                int skipCount = 0;
                for (int i = 0; i < itemCount; i++) {
                    double score = itemScores.apply(i, 0);
                    Integer itemId = pcaGen.getItemIndexToIdMap(i);
                    if (userTrainMap.containsKey(itemId)) {
                        skipCount++;
                        continue;
                    }
                    ScoredItem<Integer> item = new ScoredItem<>(itemId, score);
                    if (topNChoices.size() < nChoices)
                        topNChoices.add(item);
                    else {
                        double minScore = topNChoices.peek().getScore();
                        if (item.getScore() > minScore) {
                            // Remove min and add
                            topNChoices.remove();
                            topNChoices.add(item);
                        } // else ignore.
                    }
                }
                System.err.printf("TrainCount: %d, SkipCount: %d for user: %s \n", trainSize, skipCount,
                        userId);
            } else
                System.err.println("Choices are not generated for: user with vector card:" + taste.size());
            List<ScoredItem<Integer>> choices = new LinkedList<>();
            while (!topNChoices.isEmpty()) {
                choices.add(0, topNChoices.remove());
            }
            return new Tuple2<>(userId, choices);
        }).persist(StorageLevel.MEMORY_AND_DISK());
    }

    public JavaPairRDD<String, List<ScoredItem<Integer>>> generateUserSimChoices(JavaSparkContext sc,
            JavaPairRDD<String, Tuple2<List<Integer>, List<Integer>>> trainAndTest, int nComponents,
            int nChoices, Map<Integer, Vector> itemPCAMap, PCAGenerator pcaGen) {

        JavaPairRDD<String, Collection<Tuple2<String, Double>>> similarUsers = pcaGen
                .generateUserSimilarities();
        JavaPairRDD<String, Tuple2<String, Double>> simUsersFlat = similarUsers.flatMapValues(x -> x);
        /*similarUsers.flatMapToPair(x -> {
            String userFromId = x._1;
            Collection<Tuple2<String, Tuple2<String, Double>>> tuples = new ArrayList<>();
            x._2.forEach(y -> tuples.add(new Tuple2<>(userFromId, y)));
            return tuples.iterator();
        });*/

        JavaPairRDD<String, Tuple2<String, Double>> userToKeyRdd = simUsersFlat
                .mapToPair(x -> new Tuple2<>(x._2._1, new Tuple2<>(x._1, x._2._2)));
        JavaPairRDD<String, List<Integer>> train = trainAndTest.mapValues(Tuple2::_1);
        JavaPairRDD<String, Tuple2<Tuple2<String, Double>, List<Integer>>> simUserItems = userToKeyRdd
                .join(train);
        JavaPairRDD<String, Tuple2<Double, List<Integer>>> simUserChoices = simUserItems
                .mapToPair(x -> new Tuple2<>(x._2._1._1, new Tuple2<>(x._2._1._2, x._2._2)));
        JavaPairRDD<String, List<ScoredItem<Integer>>> simUserWeightedChoices = simUserChoices.mapToPair(x -> {
            List<Integer> itemIds = x._2._2;
            Double score = x._2._1;
            List<ScoredItem<Integer>> result = new ArrayList<>();
            itemIds.forEach(y -> result.add(new ScoredItem<>(y, score)));
            return new Tuple2<>(x._1, result);
        });

        JavaPairRDD<String, Iterable<List<ScoredItem<Integer>>>> groupedChoices = simUserWeightedChoices.groupByKey();
        JavaPairRDD<String, Tuple2<Iterable<List<ScoredItem<Integer>>>, List<Integer>>> weightedChoicesWithTrain = groupedChoices
                .join(train);

        return weightedChoicesWithTrain.mapToPair(x -> {
            Map<Integer, Boolean> trainItemMap = x._2._2.stream()
                    .collect(Collectors.toMap(y -> y, y -> true));

            String userId = String.valueOf(x._1);
            List<ScoredItem<Integer>> allScoredItems = new ArrayList<>();
            x._2._1.forEach(allScoredItems::addAll);

            Map<Integer, Double> itemScores = allScoredItems.parallelStream().collect(Collectors
                    .groupingBy(ScoredItem::getItemId, Collectors.summingDouble(ScoredItem::getScore)));

            PriorityQueue<ScoredItem<Integer>> topNChoices = new PriorityQueue<>(nChoices);

            int trainSize = trainItemMap.size();
            int skipCount = 0;
            for (Integer itemId : itemScores.keySet()) {
                if (trainItemMap.containsKey(itemId)) {
                    skipCount++;
                    continue;
                }
                Double score = itemScores.get(itemId);
                ScoredItem<Integer> scoredItem = new ScoredItem<>(itemId, score);
                if (topNChoices.size() < nChoices)
                    topNChoices.add(scoredItem);
                else {
                    double minScore = topNChoices.peek().getScore();
                    if (scoredItem.getScore() > minScore) {
                        // Remove min and add
                        topNChoices.remove();
                        topNChoices.add(scoredItem);
                    }// else ignore.
                }
            }

            System.err.printf(".. TrainCount:%d, SkipCount:%d for user:%s \n", trainSize, skipCount, userId);

            List<ScoredItem<Integer>> choices = new LinkedList<>();
            while (!topNChoices.isEmpty()) {
                choices.add(0, topNChoices.remove());
            }
            return new Tuple2<>(userId, choices);
        });
    }
    
    public JavaPairRDD<String, List<ScoredItem<Integer>>> generateItemSimChoicesForTrain(JavaSparkContext sc,
            JavaPairRDD<String, List<Integer>> train, int nComponents,
            int nChoices, Map<Integer, Vector> itemPCAMap, PCAGenerator pcaGen) {

    	JavaPairRDD<Integer, Collection<ScoredItem<Integer>>> similarItems = pcaGen
    			.generateItemSimilarities();
    	JavaPairRDD<Integer, Tuple2<Integer, Double>> simItemsFlat = similarItems.flatMapValues(x -> x).mapToPair(
    			x -> new Tuple2<>(x._1, new Tuple2<>(x._2.getItemId(), x._2.getScore())));
    	/*similarUsers.flatMapToPair(x -> {
            String userFromId = x._1;
            Collection<Tuple2<String, Tuple2<String, Double>>> tuples = new ArrayList<>();
            x._2.forEach(y -> tuples.add(new Tuple2<>(userFromId, y)));
            return tuples.iterator();
        });*/

    	JavaPairRDD<Integer, Tuple2<Integer, Double>> itemsSimRdd = simItemsFlat
    			.mapToPair(x -> new Tuple2<>(x._2._1, new Tuple2<>(x._1, x._2._2)));
    	JavaPairRDD<Integer, List<ScoredItem<Integer>>> scoredItemsRdd = TGChoiceGenerator.getTopNTGPairs(itemsSimRdd,
    			TGChoiceGenerator.TOP_N);
    	TGChoiceGenerator tgChoiceGen = new TGChoiceGenerator();
    	JavaPairRDD<String, List<ScoredItem<Integer>>> userChoices =
    			tgChoiceGen.generateChoicesForTrainWithoutCollect(scoredItemsRdd, train, nChoices);
    	
    	return userChoices;

    }
    
    public JavaPairRDD<String, List<ScoredItem<Integer>>> generateItemSimChoices(JavaSparkContext sc,
            JavaPairRDD<String, Tuple2<List<Integer>, List<Integer>>> trainAndTest, int nComponents,
            int nChoices, Map<Integer, Vector> itemPCAMap, PCAGenerator pcaGen) {

    	JavaPairRDD<Integer, Collection<ScoredItem<Integer>>> similarItems = pcaGen
    			.generateItemSimilarities();
    	JavaPairRDD<Integer, Tuple2<Integer, Double>> simItemsFlat = similarItems.flatMapValues(x -> x).mapToPair(
    			x -> new Tuple2<>(x._1, new Tuple2<>(x._2.getItemId(), x._2.getScore())));
    	/*similarUsers.flatMapToPair(x -> {
            String userFromId = x._1;
            Collection<Tuple2<String, Tuple2<String, Double>>> tuples = new ArrayList<>();
            x._2.forEach(y -> tuples.add(new Tuple2<>(userFromId, y)));
            return tuples.iterator();
        });*/

    	JavaPairRDD<Integer, Tuple2<Integer, Double>> itemsSimRdd = simItemsFlat
    			.mapToPair(x -> new Tuple2<>(x._2._1, new Tuple2<>(x._1, x._2._2)));
    	JavaPairRDD<Integer, List<ScoredItem<Integer>>> scoredItemsRdd = TGChoiceGenerator.getTopNTGPairs(itemsSimRdd,
    			TGChoiceGenerator.TOP_N);
    	TGChoiceGenerator tgChoiceGen = new TGChoiceGenerator();
    	JavaPairRDD<String, List<ScoredItem<Integer>>> userChoices =
    			tgChoiceGen.generateChoicesWithoutCollect(scoredItemsRdd, trainAndTest, nChoices);
    	
    	return userChoices;

    }


    private JavaPairRDD<String, Vector> generateUserPrefVectors(
            JavaPairRDD<String, Tuple2<List<Integer>, List<Integer>>> trainAndTest,
            Map<Integer, Vector> itemPCAMap, int nComponents) {
        JavaPairRDD<String, List<Integer>> userTrainItems = trainAndTest.mapValues(Tuple2::_1);

        return userTrainItems.mapToPair(x -> {
            String userId = x._1;
            List<Integer> itemIds = x._2;
            List<Vector> itemVectors = Lists.newArrayList();
            for (Integer itemId : itemIds) {
                Vector itemVec = itemPCAMap.get(itemId);
                if (itemVec != null)
                    itemVectors.add(itemVec);
            }

            //System.err.println("Item vectors for user:" + itemVectors);

            double[] componentSum = new double[nComponents];
            Arrays.fill(componentSum, 0);
            for (int i = 0; i < nComponents; i++) {
                for (Vector itemVec : itemVectors) {
                    componentSum[i] += itemVec.apply(i);
                    // Math.abs(itemVec.toArray()[i]);
                }
            }
            for (int i = 0; i < nComponents; i++) {
                componentSum[i] /= itemIds.size();
            }

            Vector userVec = new DenseVector(componentSum);
            // System.err.println(" Vector created for user:" + userVec);
            return new Tuple2<>(userId, userVec);
        });
    }

    static void testTopNComputeLogic() {
        int nChoices = 20;
        PriorityQueue<ScoredItem<Integer>> topNChoices = new PriorityQueue<>(nChoices);
        int itemCount = 1000;
        Random rand = new Random();
        for (int i = 0; i < itemCount; i++) {
            int itemId = rand.nextInt(itemCount) + 1;
            ScoredItem<Integer> item = new ScoredItem<>(itemId, (double) itemId);
            if (topNChoices.size() < nChoices)
                topNChoices.add(item);
            else {
                double minScore = topNChoices.peek().getScore();
                if (item.getScore() > minScore) {
                    // Remove min and add
                    topNChoices.remove();
                    topNChoices.add(item);
                }// else ignore.
            }
        }
        // Top n choices
        List<Integer> choiceItemIds = new LinkedList<>();
        while (!topNChoices.isEmpty()) {
            choiceItemIds.add(0, topNChoices.remove().getItemId());
        }
        //System.out.println("ChoiceItemIds:" + choiceItemIds);
        for (int i = 1; i < nChoices; i++) {
            Assert.assertTrue(choiceItemIds.get(i) <= choiceItemIds.get(i - 1));
        }
    }

}
