/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.utils;

import org.apache.spark.SparkConf;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import scala.Tuple2;

public class SparkConfUtils {
    private static final Logger LOGGER = LoggerFactory.getLogger(SparkConfUtils.class);

    public static void printSparkConf(SparkConf conf) {
        System.out.println("===== Spark Configuration =====");
        for (Tuple2<String, String> c : conf.getAll()) {
            System.out.println(c._1 + " : " + c._2);
        }
        System.out.println("===== End =====");
    }

    public static void logSparkConf(SparkConf conf) {
        LOGGER.info("===== Spark Configuration =====");
        for (Tuple2<String, String> c : conf.getAll()) {
            LOGGER.info(c._1 + " : " + c._2);
        }
        LOGGER.info("===== End =====");
    }
}
