/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.recommender.pca.similarity;

import java.io.Serializable;
import java.util.Collection;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;

import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.mllib.linalg.distributed.CoordinateMatrix;

import com.crayondata.recommender.pca.ScoredItem;

import scala.Tuple2;

/**
 * @author vivek
 */
public class SimilarityUtil {

    public static <T> JavaPairRDD<T, Collection<Tuple2<T, Double>>> constructLookup(
            CoordinateMatrix similarities, Map<Integer, T> indexToIdMap, int topN) {
        JavaPairRDD<T, Tuple2<T, Double>> oneToTwoMap = similarities.entries().toJavaRDD()
                .mapToPair(x -> {
                    T id1 = indexToIdMap.get((int) x.i());
                    T id2 = indexToIdMap.get((int) x.j());
                    Double val = x.value();
                    return new Tuple2<>(id1, new Tuple2<>(id2, val));
                });
        return constructScoreLookupFrom(oneToTwoMap, topN);
    }

    public static <T> JavaPairRDD<T, Collection<Tuple2<T, Double>>> constructScoreLookupFrom(
            JavaPairRDD<T, Tuple2<T, Double>> oneToTwoMap, int topN) {
        System.out.printf("Number of similarities: %d\n", oneToTwoMap.count());
        JavaPairRDD<T, Tuple2<T, Double>> filtered = oneToTwoMap.filter(x -> {
            boolean retVal = true;
            if (x._1 == null || x._2 == null || x._2._1 == null || x._2._2 == null)
                retVal = false;
            return retVal;
        });
        System.out.printf("Number of similarities filtered: %d\n", filtered.count());

        JavaPairRDD<T, Iterable<Tuple2<T, Double>>> oneScoresMap = filtered.groupByKey();
        System.out.printf("Count after group by: %d\n", oneScoresMap.count());

        JavaPairRDD<T, Collection<Tuple2<T, Double>>> lookupTable = oneScoresMap.mapToPair(x -> {
            PriorityQueue<Tuple2<T, Double>> topNUsers = new PriorityQueue<>(topN, new SerializableTupleComparator<>());
            x._2.forEach(y -> {
                if (topNUsers.size() < topN)
                    topNUsers.add(y);
                else {
                    double minScore = topNUsers.peek()._2;
                    if (y._2 > minScore) {
                        // Remove min and add
                        topNUsers.remove();
                        topNUsers.add(y);
                    }// else ignore.
                }
            });
            List<Tuple2<T, Double>> ordered = new LinkedList<>();
            while (!topNUsers.isEmpty())
                ordered.add(0, topNUsers.remove());
            return new Tuple2<>(x._1, ordered);
        });

        System.out.printf("Count of entries in lookup table :%d\n", lookupTable.count());

        return lookupTable.cache();
    }

    public static class SerializableTupleComparator<T>
            implements Comparator<Tuple2<T, Double>>, Serializable {
        private static final long serialVersionUID = 1L;
        @Override
        public int compare(Tuple2<T, Double> o1, Tuple2<T, Double> o2) {
            return o2._2.compareTo(o1._2);
        }
    }
}
