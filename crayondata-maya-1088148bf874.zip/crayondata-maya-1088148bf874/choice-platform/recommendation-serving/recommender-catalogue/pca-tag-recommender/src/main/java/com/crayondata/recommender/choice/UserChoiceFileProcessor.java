/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.recommender.choice;

import java.io.Serializable;

import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;

import com.crayondata.recommender.pca.ScoredItem;
import com.google.common.base.Optional;

import scala.Tuple2;

/**
 * @author vivek
 */
public class UserChoiceFileProcessor implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String tgChoiceFileUri;
	private String pcaChoiceFileUri;
	private String outputDir;
	
	public static void main(String[] args) {
		
		SparkConf conf = new SparkConf().setAppName("Movie Lens Choice file processor application")
				.set("spark.executor.memory", "64g").set("spark.num.executors", "1")
				.set("spark.total.executor.cores", "36")
				.set("spark.storage.memoryFraction", "0.1");
		JavaSparkContext sc = new JavaSparkContext(conf);
		
		UserChoiceFileProcessor processor = new UserChoiceFileProcessor(args[0], args[1], args[2]);
		processor.processFilesAndJoin(sc);
	}

	public UserChoiceFileProcessor(String tgChoiceFileUri,
			String pcaChoiceFileUri, String outputDir) {
		super();
		this.tgChoiceFileUri = tgChoiceFileUri;
		this.pcaChoiceFileUri = pcaChoiceFileUri;
		this.outputDir = outputDir;
	}

	public void processFilesAndJoin(JavaSparkContext sc){
		JavaRDD<String> tgFile = sc.textFile(tgChoiceFileUri).cache();
		JavaPairRDD<String, UserChoiceDetails> tgChoicesRdd = parseUserChoiceDetails(tgFile);
		
		JavaRDD<String> pcaFile = sc.textFile(pcaChoiceFileUri).cache();
		JavaPairRDD<String, UserChoiceDetails> pcaChoicesRdd = parseUserChoiceDetails(pcaFile);
		
		JavaPairRDD<String, Tuple2<Optional<UserChoiceDetails>,
		 Optional<UserChoiceDetails>>>  joined = 
		 tgChoicesRdd.fullOuterJoin(pcaChoicesRdd);
		
		// userId, itemId, success (1|0), tg_rank, tg_score, pca_rank, pca_score
		JavaRDD<String> toPrint = joined.map(x -> {
			String choiceId = x._1;
			int success = 0;
			int tg_rank = 0; double tg_score = 0.0;
			int pca_rank = 0; double pca_score = 0.0; double pcaRawScore = 0.0;
			String userId=null; int itemId=0;
			double tgRawScore = 0.0; int tgCount=0; double tgMaxScore = 0.0;
			
			Optional<UserChoiceDetails> tgChoice = x._2._1;
			if(tgChoice.isPresent()){
				UserChoiceDetails choiceDetails = tgChoice.get();
				success = choiceDetails.getSuccess();
				tg_rank = choiceDetails.getRank();
				tg_score = choiceDetails.getScore();
				userId = choiceDetails.getUserId();
				itemId = choiceDetails.getItemId();
				if(choiceDetails.getDetails().isPresent()){
					ScoredItem<Integer> scoredItem = choiceDetails.getDetails().get();
					tgRawScore = scoredItem.getScore();
					tgCount = scoredItem.getCount();
					tgMaxScore = scoredItem.getMaxScore();
				}
			}
			Optional<UserChoiceDetails> pcaChoice = x._2._2;
			if(pcaChoice.isPresent()){
				UserChoiceDetails choiceDetails = pcaChoice.get();
				success = choiceDetails.getSuccess();
				pca_rank = choiceDetails.getRank();
				pca_score = choiceDetails.getScore();
				userId = choiceDetails.getUserId();
				itemId = choiceDetails.getItemId();if(choiceDetails.getDetails().isPresent()){
					ScoredItem<Integer> scoredItem = choiceDetails.getDetails().get();
					pcaRawScore = scoredItem.getScore();
				}
			}
			
			StringBuilder builder = new StringBuilder();
			builder.append(userId+",")
				.append(itemId+",")
				.append(success+",")
				.append(tg_rank+",")
				.append(tg_score+",")
				.append(tgRawScore+",")
				.append(tgCount+",")
				.append(tgMaxScore+",")
				.append(pca_rank+",")
				.append(pca_score+",")
				.append(pcaRawScore);
			
			return builder.toString();
		});
		
		toPrint.saveAsTextFile(outputDir+"/MergedChoices/");
	}
	
	private JavaPairRDD<String, UserChoiceDetails> parseUserChoiceDetails(JavaRDD<String> input){
		JavaPairRDD<String, UserChoiceDetails> userToChoicesRdd = input.mapToPair(x -> {
			String[] tokens = x.split(",");
			String userId = tokens[0];
			int itemId = Integer.parseInt(tokens[1]);
			int success = Integer.parseInt(tokens[2]);
			String modelType = tokens[3];
			int rank = Integer.parseInt(tokens[4]);
			double score = Double.parseDouble(tokens[5]);
			UserChoiceDetails choiceDetails = new UserChoiceDetails(userId, itemId, rank, score, modelType, success);
			
			if(tokens.length > 5){
				double tgRawScore = 
						(tokens[6] != null && !tokens[6].isEmpty() 
						&& !tokens[6].equals("null"))?Double.parseDouble(tokens[6]):-1.0; 
				int count = 
						(tokens[7] != null && !tokens[7].isEmpty() 
						&& !tokens[7].equals("null"))?
						Integer.parseInt(tokens[7]):-1;
				double tgMaxScore = 
						(tokens[8] != null && !tokens[8].isEmpty() 
						&& !tokens[8].equals("null"))?
						Double.parseDouble(tokens[8]):-1.0;
				ScoredItem<Integer> scoredItem = new ScoredItem<>(itemId, tgRawScore);
				scoredItem.setCount(count);
				scoredItem.setMaxScore(tgMaxScore);
				choiceDetails.setDetails(scoredItem);
			}
			
			return new Tuple2<>(choiceDetails.getChoiceId(), choiceDetails);
		});
		
		return userToChoicesRdd;
	}
}
