/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.data.sbi;

import org.apache.spark.api.java.JavaSparkContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.crayondata.choice.generator.UserAttrTagChoiceGenerator;

/**
 * @author sundar
 */
public class SbiUserAttrTagChoiceGenerator extends UserAttrTagChoiceGenerator<String, String> {
    private static final long serialVersionUID = -6275770400235057293L;
    private static final Logger LOGGER = LoggerFactory.getLogger(SbiUserAttrTagChoiceGenerator.class);

    SbiUserAttrTagChoiceGenerator(JavaSparkContext sparkContext, String interactionDir, String outputDir,
            int numOfChoices, String itemAttrDir) {
        super(sparkContext, interactionDir, outputDir, numOfChoices, itemAttrDir);
    }

    @Override
    public void readData() {
        itemAttr = sparkContext.textFile(itemAttrDir).filter(SbiChoiceGenerator.ATTR_DATA_FILTER_FN)
                .filter(SbiChoiceGenerator.ATTR_DATA_TAG_FILTER_FN)
                .mapToPair(SbiChoiceGenerator.ATTR_DATA_READ_FN);
        LOGGER.info("Num of Items: {}", itemAttr.count());
        userItemRDD = sparkContext.textFile(interactionDir).filter(SbiChoiceGenerator.INTR_DATA_FILTER_FN)
                .mapToPair(SbiChoiceGenerator.INTR_DATA_READ_FN);
    }
}
