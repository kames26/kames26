/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.utils;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.google.common.base.Optional;

import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaSparkContext;

import scala.Tuple2;

import com.crayondata.recommender.pca.EvalScoredItem;
import com.crayondata.recommender.pca.ScoredItem;
/**
 * 
 * @author vivek
 *
 */
public class MergeUtil implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public static void main(String[] args) {

	}
	
	public MergeUtil(){
		
	}
	
	public JavaPairRDD<String, ArrayList<EvalScoredItem>> mergeChoicesWithTrain(JavaPairRDD<String, List<ScoredItem<Integer>>> choices,
			JavaPairRDD<String, Tuple2<List<Integer>, List<Integer>>> trainAndTest,
			JavaSparkContext sc){
		JavaPairRDD<String, List<Integer>> train = trainAndTest.mapToPair(x -> 
			new Tuple2<>(x._1, x._2._1));
		
		JavaPairRDD<String, ScoredItem<Integer>> choicesFlat = choices.flatMapToPair(x -> {
			List<Tuple2<String, ScoredItem<Integer>>> tuples = new ArrayList<>();
			for(ScoredItem<Integer> item : x._2){
				tuples.add(new Tuple2<>(x._1+"__"+item.getItemId(), item));
			}
			
			return tuples;
		});
		
		JavaPairRDD<String, Integer> trainFlat = train.flatMapToPair(x -> {
			List<Tuple2<String, Integer>> tuples = new ArrayList<>();
			
			for(Integer itemId : x._2){
				tuples.add(new Tuple2<>(x._1+"__"+itemId, itemId));
			}
			
			return tuples;
		});
		
		// Key is userId__itemId
		JavaPairRDD<String, Tuple2<ScoredItem<Integer>, Optional<Integer>>> joined = 
			choicesFlat.leftOuterJoin(trainFlat);
		JavaPairRDD<String, EvalScoredItem> evalPairsRdd =   
				joined.mapToPair(x -> {
					String userId = x._1;
					ScoredItem<Integer> scoredItem = x._2._1;
					Optional<Integer> optItemId = x._2._2;

					boolean takenup = false;
					if(optItemId.isPresent())
						takenup = true;

					return new Tuple2<>(userId, new EvalScoredItem(scoredItem, takenup));
				});
		
		JavaPairRDD<String, EvalScoredItem> userEvalPairsRdd = evalPairsRdd.mapToPair(x -> {
			String[] tokens = x._1.split("__");
			String userId = tokens[0];
			
			return new Tuple2<>(userId, x._2);
		});
		
		
		JavaPairRDD<String, ArrayList<EvalScoredItem>>  groupedByUsers =
				userEvalPairsRdd.aggregateByKey(new ArrayList<EvalScoredItem>(), (list, x) -> {
					ArrayList<EvalScoredItem> result = new ArrayList<>();
					result.addAll(list);
					result.add(x);
					return result;
				}, (list1, list2) -> {
					ArrayList<EvalScoredItem> result = new ArrayList<>();
					result.addAll(list1);
					result.addAll(list2);

					return result;
				});
		
		return groupedByUsers;
	}

}
