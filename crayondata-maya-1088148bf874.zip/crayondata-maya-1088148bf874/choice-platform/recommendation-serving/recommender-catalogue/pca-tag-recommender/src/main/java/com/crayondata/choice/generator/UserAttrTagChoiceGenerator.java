/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.choice.generator;

import java.nio.file.Paths;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.crayondata.recommender.pca.ScoredItem;
import com.crayondata.utils.Average;
import com.crayondata.utils.MaxHeap;

import scala.Tuple2;

/**
 * @author sundar
 */
public abstract class UserAttrTagChoiceGenerator<U, I> extends BaseChoiceGenerator<U, I> {

    private static final long serialVersionUID = -3418211018353984849L;
    private static final Logger LOGGER = LoggerFactory.getLogger(UserAttrTagChoiceGenerator.class);

    protected String itemAttrDir;

    // Following are variables used while processing
    protected JavaPairRDD<U, I> userItemRDD;
    protected JavaPairRDD<I, List<String>> itemAttr;
    private JavaPairRDD<U, Tuple2<String, Double>> userPrefVector;

    public UserAttrTagChoiceGenerator(JavaSparkContext sparkContext, String interactionDir, String outputDir,
            int numOfChoices, String itemAttrDir) {
        super(sparkContext, interactionDir, outputDir, numOfChoices);
        this.itemAttrDir = itemAttrDir;
    }

    @Override
    public void runModel() {
        // swap user-item dataset to item-user dataset
        JavaPairRDD<I, U> itemUserRDD = userItemRDD.mapToPair(Tuple2::swap);
        // join item-user dataset with item-attr dataset
        // get user-attr dataset
        // flatmap attr to a name-score pair where score is 1 / sqrt(len(tags))
        // convert <user, <attr, score>> dataset to <<user, attr>, score> dataset
        JavaPairRDD<Tuple2<U, String>, Double> userTagsScore = itemUserRDD.join(itemAttr)
                .mapToPair(x -> x._2).flatMapValues(itemAttrs -> {
                    double score = 1 / Math.sqrt(itemAttrs.size());
                    return itemAttrs.stream().map(attr -> new Tuple2<>(attr, score))
                            .collect(Collectors.toList());
                }).mapToPair(x -> new Tuple2<>(new Tuple2<>(x._1, x._2._1), x._2._2));
        // for each <user, attr> pair calculate the average of scores
        Average zeroVal = new Average(0, 0);
        JavaPairRDD<Tuple2<U, String>, Double> userTagScoreAvg = userTagsScore
                .aggregateByKey(zeroVal, Average.ADD_AND_COUNT, Average.COMBINE)
                .mapValues(Average::avg);
        // convert <<user, attr>, score> dataset to <user, <attr, score>> dataset
        userPrefVector = userTagScoreAvg.mapToPair(x -> new Tuple2<>(x._1._1, new Tuple2<>(x._1._2, x._2())))
                .persist(StorageLevel.DISK_ONLY());
    }

    @Override
    public void saveModelData() {
        userPrefVector.map(x -> x._1 + "\t" + x._2._1 + "\t" + x._2._2)
                .saveAsTextFile(Paths.get(outputDir, "user_pref_vector").toString());
    }

    @Override
    public void generateChoices() {
        // convert <user, <attr, score>> dataset to <attr, <user, score>> dataset
        JavaPairRDD<String, Tuple2<U, Double>> userAttrScore = userPrefVector
                .mapToPair(x -> new Tuple2<>(x._2._1, new Tuple2<>(x._1, x._2._2)));
        // flatmap attributes and swap to get <attr, item> dataset
        JavaPairRDD<String, I> attrItems = itemAttr.flatMapValues(x -> x).mapToPair(Tuple2::swap);
        // join <attr, <user, score>> dataset with <attr, item> dataset
        // take <<user, score>, item> data
        // convert to <<user, item>, score> data
        // add scores of <user, item> pair
        // convert to <user, <item, score>> dataset
        JavaPairRDD<U, Tuple2<I, Double>> userItemScore = userAttrScore.join(attrItems)
                .mapToPair(Tuple2::_2).mapToPair(x -> new Tuple2<>(new Tuple2<>(x._1._1, x._2), x._1._2))
                .reduceByKey((x, y) -> x + y)
                .mapToPair(x -> new Tuple2<>(x._1._1, new Tuple2<>(x._1._2, x._2)));
        // for each user, take top choices based on score
        userChoices = userItemScore.groupByKey().mapValues(itemScores -> {
            MaxHeap<ScoredItem<I>> choices = new MaxHeap<>(numOfChoices);
            for (Tuple2<I, Double> itemScore : itemScores) {
                choices.include(new ScoredItem<>(itemScore._1, itemScore._2));
            }
            return choices.getAll();
        });
        userChoices = userChoices.persist(StorageLevel.DISK_ONLY());
    }
}
