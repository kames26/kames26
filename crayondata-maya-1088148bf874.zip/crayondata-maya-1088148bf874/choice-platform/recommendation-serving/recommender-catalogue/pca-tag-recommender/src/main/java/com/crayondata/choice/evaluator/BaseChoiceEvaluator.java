/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.choice.evaluator;

import java.io.Serializable;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.api.java.function.Function2;
import org.apache.spark.sql.DataFrame;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.RowFactory;
import org.apache.spark.sql.SQLContext;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.StructField;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.clearspring.analytics.util.Lists;
import com.crayondata.evaluator.ChoiceMetrics;
import com.crayondata.utils.PercentileInfo;

import scala.Tuple2;
import scala.Tuple4;
import scala.Tuple5;
import scala.Tuple6;

/**
 * @author saravana
 */
public abstract class BaseChoiceEvaluator<U extends Comparable<U>, I extends Comparable<I>>
        implements ChoiceEvaluator {
    private static final long serialVersionUID = -8931896565760370077L;
    private static final Logger LOGGER = LoggerFactory.getLogger(BaseChoiceEvaluator.class);
    private static final String USER_ACCURACY_FILE = "PerUserAccuracy";

    protected JavaSparkContext sparkContext;
    protected SQLContext sqlContext;
    protected String testDataDir;
    protected String choicesDir;
    protected String outputDir;
    JavaPairRDD<U, ChoiceMetrics> metrics;

    protected JavaPairRDD<U, I> testTransactions;
    protected JavaPairRDD<Tuple2<U, I>, Double> choices;
    // protected JavaPairRDD<Tuple2<U, I>, Double, Double, String> choiceDecileMetric;

    protected int partitions;
    protected int startNChoices;
    protected int endNChoices;
    protected int incrChoices;
    protected String merchantField;
    protected String customerIdField;

    public BaseChoiceEvaluator(JavaSparkContext sparkContext, String testDataDir, String choicesDir,
            String outputDir, int startNChoices, int endNChoices, int incrChoices, String merchantIdField,
            String customerIdField) {
        this.sparkContext = sparkContext;
        this.sqlContext = new SQLContext(sparkContext);
        this.testDataDir = testDataDir;
        this.choicesDir = choicesDir;
        this.outputDir = outputDir;
        this.startNChoices = startNChoices;
        this.endNChoices = endNChoices;
        this.incrChoices = incrChoices;
        this.merchantField = merchantIdField;
        this.customerIdField = customerIdField;
    }

    @Override
    public void decileCalculator() {
        // add transaction flag by checking with latest transaction
        // <Item, User, Score, TakenUp>
        JavaRDD<Tuple4<I, U, Double, Boolean>> flaggedChoices = combineTestTransactionsWithChoices();

        // normalizing affinity scores on merchant level
        // <Item, User, Score, TakenUp, Rank, DecileRange>
        JavaRDD<Tuple6<I, U, Double, Boolean, Double, String>> normalizedScore = normalizingScore(
                flaggedChoices);

        // saving output
        String output = Paths.get(outputDir, "BackTesting").toString();
        saveNormalizedScoreMetrics(normalizedScore, output);
    }

    @Override
    public void evaluateAndSaveChoiceMetrics() {
        Map<Integer, Double> accMap = new HashMap<>();
        Map<Integer, Double> covMap = new HashMap<>();
        for (int numChoices = startNChoices; numChoices <= endNChoices; numChoices += incrChoices) {
            // Step 2 - Evaluate UserMetrics for each n
            Function2<List<I>, I, List<I>> aggFn = (v1, v2) -> {
                v1.add(v2);
                return v1;
            };
            Function2<List<I>, List<I>, List<I>> combFn = (v1, v2) -> {
                List<I> t = new ArrayList<>();
                t.addAll(v1);
                t.addAll(v2);
                return t;
            };
            JavaPairRDD<U, List<I>> aggregatedTestData = testTransactions
                    .aggregateByKey(new ArrayList<>(), aggFn, combFn);
            JavaPairRDD<U, List<I>> aggregatedChoicesData = choices.mapToPair(x -> x._1)
                    .aggregateByKey(new ArrayList<>(), aggFn, combFn);
            JavaPairRDD<U, ChoiceMetrics> metrics = computeMetrics(aggregatedTestData, aggregatedChoicesData,
                    numChoices);
            // Step 3 - Save UserMetrics for each n
            savePerUserMetrics(metrics, numChoices);
            // Step 4 - Compute overall metrics for each n
            ChoiceMetrics overallMetrics = computeOverallMetrics(metrics);

            accMap.put(numChoices, overallMetrics.getAccuracy());
            covMap.put(numChoices, overallMetrics.getCoverage());
            String msg1 = String.format("Average accuracy across all users for %d choices is %f", numChoices,
                    overallMetrics.getAccuracy());
            String msg2 = String.format("Average coverage across all users for %d choices is %f", numChoices,
                    overallMetrics.getCoverage());
            System.out.println(msg1);
            System.out.println(msg2);
            LOGGER.info(msg1);
            LOGGER.info(msg2);
        }

        System.out.println("Average Accuracy: " + accMap);
        System.out.println("Average Coverage: " + covMap);
        LOGGER.info("Average Accuracy: " + accMap);
        LOGGER.info("Average Coverage: " + covMap);
    }

    private ChoiceMetrics computeOverallMetrics(JavaPairRDD<U, ChoiceMetrics> metrics) {
        ChoiceMetrics sum = metrics.values().fold(new ChoiceMetrics(), ChoiceMetrics::addMetrics);
        double accuracyMean = sum.getMatchCount() / sum.getChoiceCount();
        double coverageMean = sum.getMatchCount() / sum.getItemCount();
        return new ChoiceMetrics(accuracyMean, coverageMean, 0, 0, 0);
    }

    private void savePerUserMetrics(JavaPairRDD<U, ChoiceMetrics> metrics) {
        JavaRDD<String> toPrint = metrics.map(input -> input._1 + "," + input._2.toString());
        Path opPath = Paths.get(this.outputDir, USER_ACCURACY_FILE);
        toPrint.saveAsTextFile(opPath.toString());
    }

    private void savePerUserMetrics(JavaPairRDD<U, ChoiceMetrics> metrics, int numChoices) {
        JavaRDD<String> toPrint = metrics.map(input -> input._1 + "," + input._2.toString());
        String subDir = "numChoices-" + String.format("%02d", numChoices);
        Path opPath = Paths.get(this.outputDir, USER_ACCURACY_FILE, subDir);
        toPrint.saveAsTextFile(opPath.toString());
    }

    private JavaPairRDD<U, ChoiceMetrics> computeMetrics(JavaPairRDD<U, List<I>> testData,
            JavaPairRDD<U, List<I>> choiceData, int numChoices) {
        JavaPairRDD<U, Tuple2<List<I>, List<I>>> userToItemsAndChoices = testData.join(choiceData);

        return userToItemsAndChoices.mapToPair(input -> {
            List<I> items = input._2._1;
            List<I> choices = input._2._2;
            int choiceCount = choices.size();
            if (choiceCount > numChoices) {
                choices = choices.subList(0, numChoices);
                choiceCount = numChoices;
            }

            final Map<I, Boolean> itemMap = items.stream().collect(Collectors.toMap(i -> i, i -> true));
            final int matchCount = (int) choices.stream().filter(itemMap::containsKey).count();
            final int itemCount = items.size();
            double accuracy = 0.0;
            double coverage = (matchCount * 1.0) / itemCount;
            if (choiceCount > 0)
                accuracy = (matchCount * 1.0) / choiceCount;

            ChoiceMetrics choiceMetrics = new ChoiceMetrics(accuracy, coverage, choiceCount, itemCount,
                    matchCount);
            return new Tuple2<>(input._1, choiceMetrics);
        });
    }

    private JavaRDD<Tuple4<I, U, Double, Boolean>> combineTestTransactionsWithChoices() {
        JavaPairRDD<Tuple2<U, I>, Integer> transactions = testTransactions
                .mapToPair(record -> new Tuple2<>(record, 1));

        return choices.leftOuterJoin(transactions)
                .map(record -> new Tuple4<>(record._1._2(), record._1._1(), record._2._1(),
                        record._2._2.isPresent()));
    }

    private JavaRDD<Tuple6<I, U, Double, Boolean, Double, String>> normalizingScore(
            JavaRDD<Tuple4<I, U, Double, Boolean>> flaggedChoices) {

        JavaPairRDD<Tuple4<I, U, Double, Boolean>, Long> sortedValues = flaggedChoices
                .sortBy(record -> new Record<>(record._3(), record._1()), false, partitions).zipWithIndex();

        long maxRank = sortedValues.count();
        JavaRDD<Tuple5<I, U, Double, Boolean, Double>> percentile = sortedValues
                .map(record -> new Tuple5<>(record._1._1(), record._1._2(), record._1._3(), record._1._4(),
                        ((maxRank - record._2()) * 100.0) / maxRank));

        return percentile
                .map(record -> new Tuple6<>(record._1(), record._2(), record._3(), record._4(), record._5(),
                        PercentileInfo.findDecileRange(record._5())));
    }

    public void saveNormalizedScoreMetrics(
            JavaRDD<Tuple6<I, U, Double, Boolean, Double, String>> normalizedAffinity, String outputPath) {

        List<StructField> fields = Lists.newArrayList();
        fields.add(DataTypes.createStructField("customer_id", DataTypes.LongType, false));
        fields.add(DataTypes.createStructField("merchant_id", DataTypes.LongType, false));
        fields.add(DataTypes.createStructField("score", DataTypes.DoubleType, false));
        fields.add(DataTypes.createStructField("txn_flag", DataTypes.BooleanType, false));
        fields.add(DataTypes.createStructField("percentile", DataTypes.DoubleType, false));
        fields.add(DataTypes.createStructField("affinity_group", DataTypes.StringType, false));

        JavaRDD<Row> affRow = normalizedAffinity
                .map(x -> RowFactory.create(new Object[] { x._1(), x._2(), x._3(), x._4(), x._5(), x._6() }));
        DataFrame affDF = sqlContext.createDataFrame(affRow, DataTypes.createStructType(fields));
        affDF.write().parquet(outputPath);
    }

    static class Record<T extends Comparable<T>> implements Serializable, Comparable<Record<T>> {
        private static final long serialVersionUID = -4794997981205355269L;

        private double score;
        private T customerId;

        public Record(double score, T customerId) {
            this.score = score;
            this.customerId = customerId;
        }

        @Override
        public int compareTo(Record<T> o) {
            int compAffinity = Double.compare(this.score, o.score);
            if (compAffinity != 0)
                return compAffinity;
            else
                return this.customerId.compareTo(o.customerId);
        }
    }

    private static <T> Function<T, List<T>> createListAggregateFunction() {
        return x -> {
            List<T> l = new ArrayList<>();
            l.add(x);
            return l;
        };
    }

    private static <T> Function2<List<T>, T, List<T>> createListValueCombinerFunction() {
        return (x, y) -> {
            x.add(y);
            return x;
        };
    }

    private static <T> Function2<List<T>, List<T>, List<T>> createListCombinerCombinerFunction() {
        return (x, y) -> {
            List<T> newList = new ArrayList<>(x.size() + y.size());
            newList.addAll(x);
            newList.addAll(y);
            return newList;
        };
    }
}
