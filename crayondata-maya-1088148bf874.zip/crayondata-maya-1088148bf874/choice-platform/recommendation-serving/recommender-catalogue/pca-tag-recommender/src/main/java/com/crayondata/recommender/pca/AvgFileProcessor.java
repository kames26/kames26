/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.recommender.pca;

import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;

/**
 * @author vivek
 */
public class AvgFileProcessor {

    private static final String fileUri = "mlens_out_13_Apr_17/mlens_tg_pca_avg_accuracy_coverage.txt";
    private static final String output = "mlens_out_13_Apr_17/output";

    public static void main(String[] args) {
        SparkConf conf = new SparkConf().setAppName("Choice Accuracy file processing app");
        conf.setIfMissing("spark.executor.memory", "64g");
        conf.setIfMissing("spark.num.executors", "1");
        // conf.setIfMissing("spark.executor.cores", "7");
        conf.setIfMissing("spark.total.executor.cores", "15");
        conf.setIfMissing("spark.storage.memoryFraction", "0.1");
        JavaSparkContext sc = new JavaSparkContext(conf);

        JavaRDD<String> text = sc.textFile(fileUri).cache();
        JavaRDD<String> toPrint = text.map(x -> {
            // Average accuracy across users:0.023603 at 6 components: 20
            String[] tokens = x.split(" \t ");
            int components = Integer.parseInt(tokens[1].split(" ")[1]);
            // Average accuracy across users:0.023603 at 6
            String[] firstHalfTokens = tokens[0].split(" ");
            String metricName = firstHalfTokens[1];
            double metricVal = Double.parseDouble(firstHalfTokens[3].split(":")[1]);
            int nChoices = Integer.parseInt(firstHalfTokens[5]);
            return metricName + "," + nChoices + "," + components + "," + metricVal;
        });
        // MetricName, nChoices, nComponents, MetricVal
        toPrint.saveAsTextFile(output);
    }

}
