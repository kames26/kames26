/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.data.hdfc;

import org.apache.commons.cli.CommandLine;
import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.function.PairFunction;
import org.apache.spark.sql.Row;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.crayondata.choice.evaluator.BaseChoiceEvaluator;
import com.crayondata.utils.CLIOptions;
import com.crayondata.utils.CommandLineOption;
import com.crayondata.utils.SparkConfUtils;

import scala.Tuple2;

/**
 * @author sundar
 */
public class HdfcChoiceEvaluator extends BaseChoiceEvaluator<Long, Long> {
    private static final long serialVersionUID = -268335441389811757L;
    private static final Logger LOGGER = LoggerFactory.getLogger(HdfcChoiceEvaluator.class);

    public static final org.apache.commons.cli.Options EVAL_CLI_OPTIONS = CommandLineOption
            .options(CLIOptions.OPT_TRXN_DIR, CLIOptions.OPT_CHOICE_DIR, CLIOptions.OPT_OP_DIR,
                    CLIOptions.OPT_CHOICE_START, CLIOptions.OPT_CHOICE_END, CLIOptions.OPT_CHOICE_INCR,
                    CLIOptions.OPT_TRXN_MERC_COL, CLIOptions.OPT_TRXN_CUST_COL, CLIOptions.OPT_PARTITIONS);

    public HdfcChoiceEvaluator(JavaSparkContext sparkContext, String testDataDir, String choicesDir,
            String outputDir, String merchantIdField, String customerIdField, int startNChoices,
            int endNChoices, int incrChoices) {
        super(sparkContext, testDataDir, choicesDir, outputDir, startNChoices, endNChoices, incrChoices,
                merchantIdField, customerIdField);
    }

    public static void main(String[] args) {
        CommandLine line = CommandLineOption.parseArgs(EVAL_CLI_OPTIONS, args, HdfcChoiceEvaluator.class);

        String testDir = line.getOptionValue(CLIOptions.OPT_TRXN_DIR.getOpt());
        String choiceDir = line.getOptionValue(CLIOptions.OPT_CHOICE_DIR.getOpt());
        String outputDir = line.getOptionValue(CLIOptions.OPT_OP_DIR.getOpt());
        int choiceStart = Integer.valueOf(line.getOptionValue(CLIOptions.OPT_CHOICE_START.getOpt()));
        int choiceEnd = Integer.valueOf(line.getOptionValue(CLIOptions.OPT_CHOICE_END.getOpt()));
        int choiceIncr = Integer.valueOf(line.getOptionValue(CLIOptions.OPT_CHOICE_INCR.getOpt(), "1"));
        String merchantIdField = line.getOptionValue(CLIOptions.OPT_TRXN_MERC_COL.getOpt(), "merchant_id");
        String customerIdField = line.getOptionValue(CLIOptions.OPT_TRXN_CUST_COL.getOpt(), "customer_id");
        String partitions = line.getOptionValue(CLIOptions.OPT_PARTITIONS.getOpt(), "100");

        SparkConf conf = new SparkConf().setAppName("HDFC Choice Evaluator - " + choiceDir);
        conf.set("spark.default.parallelism", partitions);
        SparkConfUtils.printSparkConf(conf);
        SparkConfUtils.logSparkConf(conf);

        JavaSparkContext sc = new JavaSparkContext(conf);
        sc.hadoopConfiguration().set("avro.mapred.ignore.inputs.without.extension", "false");
        sc.hadoopConfiguration().set("mapreduce.fileoutputcommitter.marksuccessfuljobs", "false");
        HdfcChoiceEvaluator evaluator = new HdfcChoiceEvaluator(sc, testDir, choiceDir, outputDir,
                merchantIdField, customerIdField, choiceStart, choiceEnd, choiceIncr);
        evaluator.run();
        sc.stop();
    }

    @Override
    public void readData() {
        testTransactions = sqlContext.read().format("com.databricks.spark.avro")
                .load(testDataDir)
                .select(merchantField, customerIdField)
                .toJavaRDD()
                .mapToPair(TRXN_READ_FN).distinct();
        choices = sqlContext.read().parquet(choicesDir)
                .select("merchant_id", "customer_id", "score")
                .javaRDD()
                .mapToPair(CHOICE_READ_FN);
    }

    private static final PairFunction<Row, Long, Long> TRXN_READ_FN = (Row row) -> new Tuple2<>(
            row.getLong(0), row.getLong(1));
    private static final PairFunction<Row, Tuple2<Long, Long>, Double> CHOICE_READ_FN = (Row row) -> new Tuple2<>(
            new Tuple2<>(row.getLong(0), row.getLong(1)), row.getDouble(2));
}
