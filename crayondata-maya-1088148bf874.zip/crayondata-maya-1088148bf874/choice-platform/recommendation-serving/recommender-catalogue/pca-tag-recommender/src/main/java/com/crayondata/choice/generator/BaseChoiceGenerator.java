/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.choice.generator;

import java.util.List;

import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaSparkContext;

import com.crayondata.recommender.pca.ScoredItem;

/**
 * @author sundar
 */
public abstract class BaseChoiceGenerator<U, I> implements ChoiceGenerator {

    private static final long serialVersionUID = -8931896565760370077L;

    protected transient JavaSparkContext sparkContext;
    protected String interactionDir;
    protected String outputDir;
    protected int numOfChoices;

    public BaseChoiceGenerator(JavaSparkContext sparkContext, String interactionDir, String outputDir,
            int numOfChoices) {
        this.sparkContext = sparkContext;
        this.interactionDir = interactionDir;
        this.outputDir = outputDir;
        this.numOfChoices = numOfChoices;
    }

    protected JavaPairRDD<U, List<ScoredItem<I>>> userChoices;

    public void saveChoices() {
        userChoices.flatMapValues(x -> x).map(x -> x._1 + "\t" + x._2.getItemId() + "\t" + x._2.getScore())
                .saveAsTextFile(outputDir + "/choices");
    }
}
