/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.recommender.pca;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.mllib.linalg.Vector;
import org.apache.spark.storage.StorageLevel;

import com.crayondata.recommender.choice.UserChoiceDetails;
import com.crayondata.recommender.tg.TGChoiceGenerator;
import com.crayondata.utils.DataSplitter;
import com.crayondata.utils.SparkConfUtils;
import com.google.common.base.Optional;

import scala.Tuple2;
import scala.Tuple3;
import scala.Tuple5;

/**
 * @author vivek
 */
public class PCAChoicesEvaluator implements Serializable {

    private static final long serialVersionUID = 1L;

    private final static String USER_ACCURACY_FILE = "PerUserAccuracy";
    private final static String USER_CHOICES_FILE = "UserChoices";
    public final static int MIN_INTERACTION_COUNT = 10;

    protected String interactionFileUri = "data/movie_review";
    protected int tillN = 20; // Evaluated from 6 till atN value.
    protected int partitions = 64;
    protected String outputDir = "output_tg/accuracy";
    protected int nComponents = 20;

    private int startN = 6;

    public void setStartN(int startN) {
        this.startN = startN;
    }

    public PCAChoicesEvaluator() {
    }

    public PCAChoicesEvaluator(String interactionFileUri, int atN, String outputDir, int nComponents) {
        this.interactionFileUri = interactionFileUri;
        this.tillN = atN;
        this.outputDir = outputDir;
        this.nComponents = nComponents;
    }

    public static void main(String[] args) {
        SparkConf conf = new SparkConf().setAppName("PCA Choice Evaluation application");
        // These configurations are supposed to be provided via
        // spark-defaults.conf or command-line options.
        // If not provided, set these values
        conf.setIfMissing("spark.executor.memory", "64g");
        conf.setIfMissing("spark.num.executors", "1");
        // conf.set("spark.executor.cores", "7");
        conf.setIfMissing("spark.total.executor.cores", "15");
        conf.setIfMissing("spark.storage.memoryFraction", "0.1");

        // Print the spark conf to console & log for debugging
        SparkConfUtils.printSparkConf(conf);
        SparkConfUtils.logSparkConf(conf);

        JavaSparkContext sc = new JavaSparkContext(conf);
        PCAChoicesEvaluator pcaChoicesEval;

        if (args.length < 4) {
            System.out.println(
                    "Usage: PCAChoicesEvaluator <interaction-file> <tillN> <output-dir> <nComponents>");
            System.out.println("Using default values....");
            pcaChoicesEval = new PCAChoicesEvaluator();
            // System.exit(1);
        } else {
            final String interactionFile = args[0];
            final int tillN = Integer.valueOf(args[1]);
            final String outputDir = args[2];
            final int nComponents = Integer.valueOf(args[3]);
            pcaChoicesEval = new PCAChoicesEvaluator(interactionFile, tillN, outputDir, nComponents);
        }
        // pcaChoicesEval.evalChoices(sc);
        pcaChoicesEval.evalTGChoices(sc);
    }

    // Generate and evaluate TG choices
    public void evalTGChoices(JavaSparkContext sc) {
        JavaRDD<String> fileText = sc.textFile(interactionFileUri, partitions).cache();
        // @formatter:off
        JavaPairRDD<Integer, String> itemUserRdd = fileText
                .filter(x -> x.split("\t").length >= 2)
                .mapToPair(x -> {
                    String[] tokens = x.split("\t");
                    return new Tuple2<>(Integer.parseInt(tokens[0]), tokens[1]);
                });
        JavaPairRDD<String, Tuple2<List<Integer>, List<Integer>>> trainAndTest = DataSplitter.createTrainTestSplit(itemUserRdd.mapToPair(Tuple2::swap), MIN_INTERACTION_COUNT);
        // @formatter:on

        TGChoiceGenerator tgGenerator = new TGChoiceGenerator();
        JavaPairRDD<Integer, Tuple2<Integer, Double>> tgScoresRdd = tgGenerator.generateTG(trainAndTest);
        System.out.println("Generating and evaluating choices for till n:" + tillN);
        JavaPairRDD<String, List<ScoredItem<Integer>>> userChoices = tgGenerator
                .generateChoices(tgScoresRdd, trainAndTest, tillN);
        evaluateTillN(trainAndTest, userChoices, getChoiceItemIds(userChoices), sc, 0, tillN);
        System.out.println(
                "Generating and evaluating choices for till n:" + tillN + " completed successfully..!!");
    }

    // Generate and evaluate PCA choices
    public void evalChoices(JavaSparkContext sc) {
        JavaRDD<String> fileText = sc.textFile(interactionFileUri, partitions).cache();
        // @formatter:off
        JavaPairRDD<Integer, String> itemUserRdd = fileText
                .filter(x -> x.split("\t").length >= 2)
                .mapToPair(x -> {
                    String[] tokens = x.split("\t");
                    return new Tuple2<>(Integer.parseInt(tokens[0]), tokens[1]);
                });
        JavaPairRDD<String, Tuple2<List<Integer>, List<Integer>>> trainAndTest = DataSplitter.createTrainTestSplit(itemUserRdd.mapToPair(Tuple2::swap), MIN_INTERACTION_COUNT);
        // Save the train & test data sets
        persistTestAndTrain(trainAndTest);
        // @formatter:on

        for (int nComponents = 20; nComponents < 40; nComponents++) {
            System.err.println("Generating for nComponents:" + nComponents + " tillN:" + tillN);
            PCAGenerator pcaGen = new PCAGenerator();
            Map<Integer, Vector> pcaMap = pcaGen.generatePCA(sc, trainAndTest, nComponents).collectAsMap();
            PCAChoiceGenerator choiceGen = new PCAChoiceGenerator();
            JavaPairRDD<String, List<ScoredItem<Integer>>> userChoices = choiceGen
                    .generateChoices(sc, trainAndTest, nComponents, tillN, pcaMap, pcaGen);
            evaluateTillN(trainAndTest, userChoices, getChoiceItemIds(userChoices), sc, nComponents, tillN);
            System.err.println("Generating for nComponents:" + nComponents + " tillN:" + tillN + "  done!!");
        }
    }

    protected void evaluateTillN(JavaPairRDD<String, Tuple2<List<Integer>, List<Integer>>> trainAndTest,
            JavaPairRDD<String, List<ScoredItem<Integer>>> userChoices,
            JavaPairRDD<String, List<Integer>> userChoiceItems, JavaSparkContext sc, int nComponents,
            int tillN) {
        userChoices = userChoices.persist(StorageLevel.MEMORY_AND_DISK());
        persistChoices(trainAndTest, userChoices, sc, nComponents);
        for (int atN = startN; atN <= tillN; atN++) {
            evaluateAndPrintStats(trainAndTest, userChoiceItems, sc, nComponents, atN);
        }
    }

    private void persistChoices(JavaPairRDD<String, Tuple2<List<Integer>, List<Integer>>> trainAndTest,
            JavaPairRDD<String, List<ScoredItem<Integer>>> userChoices, JavaSparkContext sc, int nComponents) {
        System.out.println("Persisting choices...");

        final String modelType = nComponents > 0 ? "pca" : "tg";

        JavaPairRDD<String, List<Integer>> test = trainAndTest.mapValues(Tuple2::_2);
        JavaPairRDD<String, Tuple2<List<Integer>, List<ScoredItem<Integer>>>> userToItemsAndChoices = test
                .join(userChoices);

        JavaPairRDD<String, UserChoiceDetails> userChoiceDetailsRdd = userToItemsAndChoices
                .flatMapToPair(x -> {
                    List<Tuple2<String, UserChoiceDetails>> tuples = new ArrayList<>();
                    String userId = x._1;
                    List<ScoredItem<Integer>> choices = x._2._2;
                    // Test data-set map
                    final Map<Integer, Boolean> testItemMap = x._2._1.stream()
                            .collect(Collectors.toMap(i -> i, i -> true));

                    int rank = 1;
                    for (ScoredItem<Integer> choice : choices) {
                        Integer itemId = choice.getItemId();
                        int success = testItemMap.containsKey(itemId) ? 1 : 0;
                        double score = 1 / (1 + Math.log(rank)); // Score function
                        UserChoiceDetails userChoice = new UserChoiceDetails(userId, itemId, rank, score,
                                modelType, success);
                        userChoice.setDetails(choice);
                        tuples.add(new Tuple2<>(userChoice.getChoiceId(), userChoice));
                        rank++;
                    }

                    return tuples;
                });

        // userId, itemId, success (1|0), modelType (pca|tg), rank, score
        JavaRDD<String> toPrint = userChoiceDetailsRdd.map(x -> x._2.getDetailsToPrint());
        String outputPath = this.outputDir + "/choices/" + nComponents + "/";
        toPrint.saveAsTextFile(outputPath + USER_CHOICES_FILE);
        System.out.println("Persisting choices complete..");
    }

    private void evaluateAndPrintStats(JavaPairRDD<String, Tuple2<List<Integer>, List<Integer>>> trainAndTest,
            JavaPairRDD<String, List<Integer>> userChoices, JavaSparkContext sc, int nComponents, int atN) {
        JavaPairRDD<String, List<Integer>> userToTestItems = trainAndTest.mapValues(Tuple2::_2);
        JavaPairRDD<String, List<Integer>> userToTrainItems = trainAndTest.mapValues(Tuple2::_1);
        JavaPairRDD<String, Tuple2<List<Integer>, List<Integer>>> userToItemsAndChoices = userToTestItems
                .join(userChoices);

        JavaPairRDD<String, Tuple2<Double, Double>> userMetrics = userToItemsAndChoices.mapToPair(input -> {
            List<Integer> items = input._2._1;
            List<Integer> choices = input._2._2;
            int choiceCount = choices.size();
            if (choiceCount > atN) {
                choices = choices.subList(0, atN);
                choiceCount = atN;
            }

            final Map<Integer, Boolean> itemMap = items.stream().collect(Collectors.toMap(i -> i, i -> true));
            final long matchCount = choices.stream().filter(itemMap::containsKey).count();
            final long itemCount = items.size();
            double accuracy = 0.0;
            double coverage = (matchCount * 1.0) / itemCount;
            if (choiceCount > 0)
                accuracy = (matchCount * 1.0) / choiceCount;

            return new Tuple2<>(input._1, new Tuple2<>(accuracy, coverage));
        });

        JavaPairRDD<String, Tuple3<Integer, Integer, Integer>> userRawMetrics = userToItemsAndChoices
                .mapToPair(input -> {
                    List<Integer> items = input._2._1;
                    List<Integer> choices = input._2._2;
                    int choiceCount = choices.size();
                    if (choiceCount > atN) {
                        choices = choices.subList(0, atN);
                        choiceCount = atN;
                    }
                    final Map<Integer, Boolean> itemMap = items.stream()
                            .collect(Collectors.toMap(i -> i, i -> true));
                    final int matchCount = (int) choices.stream().filter(itemMap::containsKey).count();
                    final int itemCount = items.size();

                    return new Tuple2<>(input._1, new Tuple3<>(choiceCount, itemCount, matchCount));
                });

        // persistRawMetrics(userRawMetrics, userToTestItems, userToTrainItems);
        persistComputedMetrics(userMetrics, userToTestItems, userToTrainItems, userRawMetrics, nComponents,
                atN);
    }

    private void persistComputedMetrics(JavaPairRDD<String, Tuple2<Double, Double>> userMetrics,
            JavaPairRDD<String, List<Integer>> usersToItems,
            JavaPairRDD<String, List<Integer>> trainUsersToItems,
            JavaPairRDD<String, Tuple3<Integer, Integer, Integer>> userRawMetrics, int nComponents, int atN) {

        JavaPairRDD<String, Integer> testUsersToItemCount = usersToItems.mapValues(List::size);
        JavaPairRDD<String, Integer> trainUsersToItemCount = trainUsersToItems.mapValues(List::size);

        JavaPairRDD<String, Tuple2<Integer, Optional<Integer>>> usersToOptItemCount = testUsersToItemCount
                .leftOuterJoin(trainUsersToItemCount);
        JavaPairRDD<String, String> usersToItemCount = usersToOptItemCount.mapToPair(x -> {
            Tuple2<Integer, Integer> result = new Tuple2<>(x._2._1, 0);
            if (x._2._2.isPresent())
                result = new Tuple2<>(x._2._1, x._2._2.get());
            return new Tuple2<>(x._1, result._1 + "," + result._2);
        });

        JavaPairRDD<String, Tuple2<Tuple2<String, Tuple2<Double, Double>>, Tuple3<Integer, Integer, Integer>>> joined = usersToItemCount
                .join(userMetrics).join(userRawMetrics);
        // accuracy, coverage, choiceCount, itemCount, matchCount
        JavaPairRDD<String, Tuple5<Double, Double, Integer, Integer, Integer>> userMetricsRdd = joined
                .mapToPair(x -> {
                    String userId = x._1;
                    Tuple5<Double, Double, Integer, Integer, Integer> metrics = new Tuple5<>(x._2._1._2._1,
                            x._2._1._2._2, x._2._2._1(), x._2._2._2(), x._2._2._3());
                    return new Tuple2<>(userId, metrics);
                });

        Tuple3<Integer, Integer, Integer> zeroValue = new Tuple3<>(0, 0, 0);
        Tuple3<Integer, Integer, Integer> sums = userRawMetrics.values().fold(zeroValue, (x, y) -> {
            int choiceCount = x._1() + y._1();
            int itemCount = x._2() + y._2();
            int matchCount = x._3() + y._3();

            return new Tuple3<>(choiceCount, itemCount, matchCount);
        });
        double accuracyMean = sums._3() / (1.0 * sums._1());
        double coverageMean = sums._3() / (1.0 * sums._2());

        // @formatter:off
        System.out.printf("Average accuracy across users:%f at %d \t components: %d\n", accuracyMean, atN, nComponents);
        System.out.printf("Average coverage across users:%f at %d \t components: %d\n", coverageMean, atN, nComponents);

        System.err.printf("Average accuracy across users:%f at %d \t components: %d\n", accuracyMean, atN, nComponents);
        System.err.printf("Average coverage across users:%f at %d \t components: %d\n", coverageMean, atN, nComponents);
        // @formatter:on

        JavaRDD<String> toPrint = userMetricsRdd.map(input -> {
            return input._1 + "," + input._2._1() + "," + input._2._2() + "," + input._2._3() + "," + input._2
                    ._4() + "," + input._2._5();
        });
        String outputPath = this.outputDir + "/" + atN + "/" + nComponents + "/";
        toPrint.saveAsTextFile(outputPath + USER_ACCURACY_FILE);

    }

    protected static JavaPairRDD<String, List<Integer>> getChoiceItemIds(
            JavaPairRDD<String, List<ScoredItem<Integer>>> userChoices) {
        return userChoices.mapToPair(choice -> {
            List<Integer> itemIds = new ArrayList<>(choice._2.size());
            choice._2.forEach(y -> itemIds.add(y.getItemId()));
            return new Tuple2<>(choice._1, itemIds);
        });
    }

    protected void persistTestAndTrain(
            JavaPairRDD<String, Tuple2<List<Integer>, List<Integer>>> trainAndTest) {
        System.out.println("Persisting train and test");
        JavaPairRDD<String, List<Integer>> train = trainAndTest.mapValues(Tuple2::_1);
        JavaPairRDD<String, List<Integer>> test = trainAndTest.mapValues(Tuple2::_2);

        Function<Tuple2<String, Integer>, String> concat = x -> x._1 + "," + x._2;
        train.flatMapValues(x -> x).map(concat).saveAsTextFile(this.outputDir + "/choices/train/");
        test.flatMapValues(x -> x).map(concat).saveAsTextFile(this.outputDir + "/choices/test/");
        System.out.println("Persisting train and test complete.. ");
    }
}
