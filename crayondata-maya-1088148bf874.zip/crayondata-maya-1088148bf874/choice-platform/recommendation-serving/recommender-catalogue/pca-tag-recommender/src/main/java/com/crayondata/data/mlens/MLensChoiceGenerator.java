/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.data.mlens;

import java.nio.file.Paths;
import java.util.Arrays;
import java.util.List;

import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.function.Function;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.crayondata.choice.generator.ItemTagGraphChoiceGenerator;
import com.crayondata.choice.generator.PCAChoiceGenerator;
import com.crayondata.choice.generator.TGChoiceGenerator;
import com.crayondata.choice.generator.UserAttrTagChoiceGenerator;
import com.crayondata.utils.SparkConfUtils;

import scala.Tuple2;

/**
 * @author sundar
 */
public class MLensChoiceGenerator {

    private static final Logger LOGGER = LoggerFactory.getLogger(MLensChoiceGenerator.class);

    public static void main(String[] args) {
        if (args.length < 4) {
            System.err.println("Usage: " + MLensChoiceGenerator.class + " <interaction-dir> "
                    + " <output-dir> <numOfChoices> <models>");
            System.exit(1);
        }

        String interactionDir = args[0];
        String outputDir = args[1];
        int numOfChoices = Integer.valueOf(args[2]);
        List<String> models = Arrays.asList(args[3].split(","));

        SparkConf conf = new SparkConf().setAppName("MLens Choice Generator - " + args[3]);
        SparkConfUtils.printSparkConf(conf);
        SparkConfUtils.logSparkConf(conf);

        JavaSparkContext sc = new JavaSparkContext(conf);

        if (models.contains("tag")) {
            String userPrefOutDir = Paths.get(outputDir, "user_tag_pref_model").toString();
            String itemsDir = conf.get("spark.crayon.model.tag.items");
            if (itemsDir == null) {
                System.err.println(
                        "Items file/dir (spark.crayon.model.tag.items) is not set. Skipping Tag Model");
            } else {
                UserAttrTagChoiceGenerator<Integer, Integer> attrChoiceGenerator = new MLensUserAttrTagChoiceGenerator(sc,
                        interactionDir, userPrefOutDir, numOfChoices, itemsDir);
                attrChoiceGenerator.run();
            }
        }

        if (models.contains("taggraph")) {
            String tgOutDir = Paths.get(outputDir, "tag_graph_model").toString();
            String itemsDir = conf.get("spark.crayon.model.tag.items");
            int numTopTGPairs = conf
                    .getInt("spark.crayon.model.tg.top.tg.pairs", TGChoiceGenerator.DEFAULT_TOP_TG_PAIRS);
            if (itemsDir == null) {
                System.err.println(
                        "Items file/dir (spark.crayon.model.tag.items) is not set. Skipping Item Tag Model");
            } else {
                ItemTagGraphChoiceGenerator<Integer, Integer> itemTagGraphChoiceGenerator = new MLensItemTagGraphChoiceGenerator(
                        sc, interactionDir, itemsDir, tgOutDir, numOfChoices, numTopTGPairs);
                itemTagGraphChoiceGenerator.run();
            }
        }

        if (models.contains("tg")) {
            String tgOutDir = Paths.get(outputDir, "tg_model").toString();
            int numTopTGPairs = conf
                    .getInt("spark.crayon.model.tg.top.tg.pairs", TGChoiceGenerator.DEFAULT_TOP_TG_PAIRS);
            LOGGER.info("TG Top Pairs: {}", numTopTGPairs);
            TGChoiceGenerator<Integer, Integer> tgChoiceGenerator = new MLensTGChoiceGenerator(sc, interactionDir, tgOutDir,
                    numOfChoices, numTopTGPairs);
            tgChoiceGenerator.run();
        }

        if (models.contains("pca")) {
            String pcaOutDir = Paths.get(outputDir, "pca_model").toString();
            int numComponentsMin = conf.getInt("spark.crayon.model.pca.components.min",
                    PCAChoiceGenerator.DEFAULT_COMPONENTS_MIN);
            int numComponentsMax = conf.getInt("spark.crayon.model.pca.components.max",
                    PCAChoiceGenerator.DEFAULT_COMPONENTS_MAX);
            LOGGER.info("PCA Components Min: {}, Max: {}", numComponentsMin, numComponentsMax);
            PCAChoiceGenerator<Integer, Integer> pcaChoiceGenerator = new MLensPCAChoiceGenerator(sc, interactionDir, pcaOutDir,
                    numOfChoices, numComponentsMin, numComponentsMax);
            pcaChoiceGenerator.run();
        }
        sc.stop();
    }

    static Tuple2<Integer, Integer> readInteractionData(String line) {
        String[] tokens = line.split("\t");
        return new Tuple2<>(Integer.valueOf(tokens[0]), Integer.valueOf(tokens[1]));
    }

    private static String[] ITEM_HEADERS = { "movie_id", "movie_title", "release_date", "video_release_date",
            "imdb_url", "unknown", "Action", "Adventure", "Animation", "Children's", "Comedy", "Crime",
            "Documentary", "Drama", "Fantasy", "Film-Noir", "Horror", "Musical", "Mystery", "Romance",
            "Sci-Fi", "Thriller", "War", "Western" };

    static final Function<String, Boolean> INTR_DATA_FILTER_FN = (String line) ->
            line.split("\t").length >= 2;

    static final Function<String, Boolean> ATTR_DATA_FILTER_FN = (String line) ->
            line.split("::").length >= 3;

    static Tuple2<Integer, List<String>> readItemAttrData(String line) {
        String[] cells = line.split("::");
        int itemId = Integer.valueOf(cells[0]);
        List<String> genres = Arrays.asList(cells[2].split("\\|"));
        return new Tuple2<>(itemId, genres);
    }

    /*static Tuple2<Integer, List<String>> readItemAttrData(String line) {
        String[] cells = line.split("\\|");
        int itemId = Integer.valueOf(cells[0]);
        List<String> genres = new ArrayList<>();
        for (int i = 5; i < ITEM_HEADERS.length; i++) {
            if ("1".equals(cells[i])) {
                genres.add(ITEM_HEADERS[i]);
            }
        }
        return new Tuple2<>(itemId, genres);
    }*/
}
