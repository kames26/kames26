/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.utils;

import java.util.LinkedList;
import java.util.PriorityQueue;

import com.crayondata.recommender.pca.ScoredItem;

/**
 * Heap data structure to hold the top items
 *
 * @author sundar
 */
public class MaxHeap<T extends ScoredItem<?>> {
    private PriorityQueue<T> top;
    private int n;

    public MaxHeap(int n) {
        this.top = new PriorityQueue<>(n);
        this.n = n;
    }

    /*public MaxHeap(int n, Comparator<T> comparator) {
        this.n = n;
        this.top = new PriorityQueue<>(n, comparator);
    }*/

    public void include(T elem) {
        if (top.size() < n)
            top.add(elem);
        else {
            double minScore = top.peek().getScore();
            if (elem.getScore() > minScore) {
                top.remove();
                top.add(elem);
            }
        }
    }

    public LinkedList<T> getAll() {
        LinkedList<T> elements = new LinkedList<>();
        while (!top.isEmpty()) {
            elements.add(0, top.remove());
        }
        return elements;
    }
}
