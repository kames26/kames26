/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.utils;

import java.io.Serializable;

import org.apache.spark.api.java.function.Function2;

/**
 * @author sundar
 */
public class Average implements Serializable {
    private static final long serialVersionUID = -2244021566644156061L;

    private double total;
    private int count;

    public Average(double total, int count) {
        this.total = total;
        this.count = count;
    }

    public Average include(double val) {
        this.total += val;
        this.count += 1;
        return this;
    }

    public double avg() {
        return this.total / this.count;
    }

    public Average combine(Average that) {
        this.total += that.total;
        this.count += that.count;
        return this;
    }

    public static final Function2<Average, Double, Average> ADD_AND_COUNT = Average::include;
    public static final Function2<Average, Average, Average> COMBINE = Average::combine;
}
