/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.utils;

/**
 * @author sundar
 */
public class PercentileInfo {

    private static final String[] PERCENTILE_RANGE = { "0-10", "10-20", "20-30", "30-40", "40-50", "50-60",
            "60-70", "70-80", "80-90", "90-100" };

    public static String findDecileRange(double percentile) {
        int decileRange;
        if (percentile >= 90)
            decileRange = 9;
        else if (percentile >= 80)
            decileRange = 8;
        else if (percentile >= 70)
            decileRange = 7;
        else if (percentile >= 60)
            decileRange = 6;
        else if (percentile >= 50)
            decileRange = 5;
        else if (percentile >= 40)
            decileRange = 4;
        else if (percentile >= 30)
            decileRange = 3;
        else if (percentile >= 20)
            decileRange = 2;
        else if (percentile >= 10)
            decileRange = 1;
        else
            decileRange = 0;
        return PERCENTILE_RANGE[decileRange];
    }

}
