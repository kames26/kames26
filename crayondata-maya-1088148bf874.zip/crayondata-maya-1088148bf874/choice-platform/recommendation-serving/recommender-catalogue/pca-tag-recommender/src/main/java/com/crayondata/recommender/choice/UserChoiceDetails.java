/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.recommender.choice;

import java.io.Serializable;

import com.crayondata.recommender.pca.ScoredItem;
import com.google.common.base.Optional;

/**
 * @author vivek
 */
public class UserChoiceDetails implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String userId;
	private int itemId;
	private int rank;
	private double score;
	private String modelType;
	private int success;	//Indicating whether matched or not.  1 - true; 0 - false
	
	private Optional<ScoredItem<Integer>> details;
	
	private final String choiceId;
	
	public UserChoiceDetails(String userId, int itemId, int rank, double score,
			String modelType, int success) {
		super();
		this.userId = userId;
		this.itemId = itemId;
		this.rank = rank;
		this.score = score;
		this.modelType = modelType;
		this.success = success;
		this.choiceId = itemId + "::" + userId; 
		this.details = Optional.absent();
	}
	
	public Optional<ScoredItem<Integer>> getDetails() {
		return details;
	}
	public void setDetails(Optional<ScoredItem<Integer>> details) {
		this.details = details;
	}
	public void setDetails(ScoredItem<Integer> details) {
		this.details = Optional.of(details);
	}

	public String getChoiceId(){
		return this.choiceId;
	}
	
	public int getSuccess() {
		return success;
	}
	public void setSuccess(int success) {
		this.success = success;
	}

	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public int getItemId() {
		return itemId;
	}
	public void setItemId(int itemId) {
		this.itemId = itemId;
	}
	public int getRank() {
		return rank;
	}
	public void setRank(int rank) {
		this.rank = rank;
	}
	public double getScore() {
		return score;
	}
	public void setScore(double score) {
		this.score = score;
	}
	public String getModelType() {
		return modelType;
	}
	public void setModelType(String modelType) {
		this.modelType = modelType;
	}
	
	@Override
    public String toString() {
        return "UserChoiceDetails{" + "userId='" + userId + '\'' + ", itemId=" + itemId + ", rank=" + rank
                + ", score=" + score + ", modelType='" + modelType + '\'' + ", success=" + success
                + ", details=" + details + ", choiceId='" + choiceId + '\'' + '}';
    }

    public String getDetailsToPrint() {
        StringBuilder builder = new StringBuilder();
        builder.append(userId);
        builder.append(",").append(itemId);
        builder.append(",").append(success);
        builder.append(",").append(modelType);
        builder.append(",").append(rank);
        builder.append(",").append(score);
        if (details.isPresent()) {
            ScoredItem<Integer> choiceDetails = details.get();
            builder.append(",").append(choiceDetails.getScore());
            builder.append(",").append(choiceDetails.getCount());
            builder.append(",").append(choiceDetails.getMaxScore());
        }
        return builder.toString();
    }
	
	
}
