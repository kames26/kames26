/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.recommender.pca;

import java.io.Serializable;

public class ScoredItem<I> implements Comparable<ScoredItem<I>>, Serializable {

    private static final long serialVersionUID = 271075891307208479L;

    public enum ModelType {
        tg, pca
    }

    private I itemId;
    private Double score;
    private Integer count;
    private Double maxScore;
    private ModelType modelType;

    public ScoredItem(I itemId, Double score) {
        super();
        this.itemId = itemId;
        this.score = score;
    }

    public I getItemId() {
        return itemId;
    }

    public void setItemId(I itemId) {
        this.itemId = itemId;
    }

    public Double getScore() {
        return score;
    }

    public Integer getCount() {
        return count;
    }

    public void setCount(Integer count) {
        this.count = count;
    }

    public Double getMaxScore() {
        return maxScore;
    }

    public void setMaxScore(Double maxScore) {
        this.maxScore = maxScore;
    }

    public ModelType getModelType() {
        return modelType;
    }

    @Override
    public int compareTo(ScoredItem<I> o) {
        return this.score.compareTo(o.score);
    }


}
