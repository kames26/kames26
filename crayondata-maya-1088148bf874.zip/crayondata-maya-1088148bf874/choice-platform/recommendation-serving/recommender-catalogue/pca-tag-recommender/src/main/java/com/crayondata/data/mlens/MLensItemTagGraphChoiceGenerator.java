/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.data.mlens;

import org.apache.spark.api.java.JavaSparkContext;

import com.crayondata.choice.generator.ItemTagGraphChoiceGenerator;

/**
 * @author sundar
 */
public class MLensItemTagGraphChoiceGenerator extends ItemTagGraphChoiceGenerator<Integer, Integer> {
    private static final long serialVersionUID = 7344861274452999005L;

    MLensItemTagGraphChoiceGenerator(JavaSparkContext sparkContext, String interactionDir,
            String itemAttrDir, String outputDir, int numOfChoices, int numTopTGPairs) {
        super(sparkContext, interactionDir, itemAttrDir, outputDir, numOfChoices, numTopTGPairs);
    }

    @Override
    public void readData() {
        itemAttr = sparkContext.textFile(itemAttrDir).filter(MLensChoiceGenerator.ATTR_DATA_FILTER_FN)
                .mapToPair(MLensChoiceGenerator::readItemAttrData);
        userItemRDD = sparkContext.textFile(interactionDir).filter(MLensChoiceGenerator.INTR_DATA_FILTER_FN)
                .mapToPair(MLensChoiceGenerator::readInteractionData);
    }
}
