/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.choice.generator;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.PriorityQueue;
import java.util.stream.Collectors;

import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.mllib.linalg.DenseVector;
import org.apache.spark.mllib.linalg.Matrices;
import org.apache.spark.mllib.linalg.Matrix;
import org.apache.spark.mllib.linalg.SingularValueDecomposition;
import org.apache.spark.mllib.linalg.Vector;
import org.apache.spark.mllib.linalg.distributed.CoordinateMatrix;
import org.apache.spark.mllib.linalg.distributed.IndexedRow;
import org.apache.spark.mllib.linalg.distributed.IndexedRowMatrix;

import scala.Tuple2;

import com.crayondata.recommender.pca.ScoredItem;import com.crayondata.recommender.pca.similarity.SimilarityUtil;
import com.crayondata.recommender.tg.TGChoiceGenerator;
import com.google.common.collect.Iterables;


/**
 * 
 * @author vivek
 *
 */
public abstract class PCASimChoiceGenerator<U,I> extends PCAChoiceGenerator<U, I> {

	// Input data.. to be populated by readData
	//protected JavaPairRDD<U, I> userItemRDD;
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static final double SIM_THRESHOLD = 0.25;
    private static final int PARTITIONS = 512;
    // Top N users for similarity
    private static final int TOP_N = 100;
	
	
	protected Map<Integer, JavaPairRDD<U, List<ScoredItem<I>>>> userChoices;

	public PCASimChoiceGenerator(JavaSparkContext sparkContext, String interactionDir, String outputDir,
			int numOfChoices, int numComponentsMin, int numComponentsMax) {
		super(sparkContext, interactionDir, outputDir, numOfChoices, 
				numComponentsMin, numComponentsMax);
	}
	
	@Override
	public void generateChoices(){
		JavaPairRDD<U, List<I>> trainRdd =
				userItemRDD.groupByKey().mapToPair(x -> {
			List<I> items = new ArrayList<>();
			Iterables.addAll(items, x._2);
			return new Tuple2<>(x._1, items);
		});
		
		userChoices = new HashMap<>();
		for (int numComponents = numComponentsMin; numComponents <= numComponentsMax; numComponents++) {
			SingularValueDecomposition<IndexedRowMatrix, Matrix> svd = super.numComponentsToMatrix
	                    .get(numComponents);
			
			IndexedRowMatrix itemComponents = computeItemPCA(svd, sparkContext);
			
					

			JavaPairRDD<U, List<ScoredItem<I>>> choices = 
					generateItemSimChoices(itemComponents, trainRdd, numOfChoices);
			userChoices.put(numComponents, choices);
		}
	}
	
	JavaPairRDD<U, List<ScoredItem<I>>> generateItemSimChoices(IndexedRowMatrix itemComponents,
			JavaPairRDD<U, List<I>> trainRdd,
			int nChoices){
		JavaPairRDD<I, Collection<ScoredItem<I>>> similarItems = 
				generateItemSimilarities(itemComponents);
		
		JavaPairRDD<I, Tuple2<I, Double>> simItemsFlat = similarItems.flatMapValues(x -> x).mapToPair(
    			x -> new Tuple2<>(x._1, new Tuple2<>(x._2.getItemId(), x._2.getScore())));
    	/*similarUsers.flatMapToPair(x -> {
            String userFromId = x._1;
            Collection<Tuple2<String, Tuple2<String, Double>>> tuples = new ArrayList<>();
            x._2.forEach(y -> tuples.add(new Tuple2<>(userFromId, y)));
            return tuples.iterator();
        });*/

    	JavaPairRDD<I, Tuple2<I, Double>> itemsSimRdd = simItemsFlat
    			.mapToPair(x -> new Tuple2<>(x._2._1, new Tuple2<>(x._1, x._2._2)));
    	JavaPairRDD<I, List<ScoredItem<I>>> scoredItemsRdd = getTopNPairs(itemsSimRdd,
    			TGChoiceGenerator.TOP_N);
    	TGChoiceGenerator tgChoiceGen = new TGChoiceGenerator();
    	JavaPairRDD<U, List<ScoredItem<I>>> userChoices =
    			generateChoicesForTrainWithoutCollect(scoredItemsRdd, trainRdd, nChoices);
    	
    	return userChoices;

	}
	
	private JavaPairRDD<U, List<ScoredItem<I>>> generateChoicesForTrainWithoutCollect(
			JavaPairRDD<I, List<ScoredItem<I>>> scoredItemsRdd,
			JavaPairRDD<U, List<I>> train, int nChoices) {


    	JavaPairRDD<I, U> itemUserMap = train.flatMapValues(x -> x).mapToPair(Tuple2::swap);

        JavaPairRDD<U, List<ScoredItem<I>>> userToScoredItems = itemUserMap.join(scoredItemsRdd).mapToPair(Tuple2::_2);
        JavaPairRDD<U, Iterable<List<ScoredItem<I>>>> userScoredItemsGrouped = userToScoredItems.groupByKey();

        JavaPairRDD<U, Map<I, Boolean>> trainItemMapRdd = train
                .mapValues(x -> x.stream().collect(Collectors.toMap(y -> y, y -> true)));

        JavaPairRDD<U, Tuple2<Iterable<List<ScoredItem<I>>>, Map<I, Boolean>>> userScoredItemsTrain = userScoredItemsGrouped
                .join(trainItemMapRdd);

        return userScoredItemsTrain.mapToPair(x -> {
            //String userId = String.valueOf(x._1);
        	U userId = x._1;
            Iterable<List<ScoredItem<I>>> scoredItemLists = x._2._1;
            Map<I, Boolean> trainItemMap = x._2._2;
            List<ScoredItem<I>> allScoredItems = new ArrayList<>();
            for (List<ScoredItem<I>> similarItems : scoredItemLists) {
                allScoredItems.addAll(similarItems);
            }

            Map<I, Double> itemScores = allScoredItems.parallelStream().collect(Collectors
                    .groupingBy(ScoredItem::getItemId, Collectors.summingDouble(ScoredItem<I>::getScore)));

            Map<I, Long> itemCounts = allScoredItems.parallelStream()
                    .collect(Collectors.groupingBy(ScoredItem::getItemId, Collectors.counting()));

            Map<I, Optional<ScoredItem<I>>> itemMaxScores = allScoredItems.parallelStream().collect(
                    Collectors.groupingBy(ScoredItem<I>::getItemId,
                            Collectors.maxBy(new SerializableScoredItemComparator<I>())));

            PriorityQueue<ScoredItem<I>> topNChoices = new PriorityQueue<>(nChoices);

            int trainSize = trainItemMap.size();
            int skipCount = 0;
            for (I itemId : itemScores.keySet()) {
            	// TODO skipping repeat items commented.. This logic can be reused for marking repeat choices.
                /*if (trainItemMap.containsKey(itemId)) {
                    skipCount++;
                    continue;
                }*/
                Double score = itemScores.get(itemId);
                ScoredItem<I> scoredItem = new ScoredItem<I>(itemId, score);
                scoredItem.setCount(itemCounts.get(itemId).intValue());
                Optional<ScoredItem<I>> maxScoreItem = itemMaxScores.get(itemId);
                maxScoreItem.ifPresent(scoredItem1 -> scoredItem.setMaxScore(scoredItem1.getScore()));
                if (topNChoices.size() < nChoices)
                    topNChoices.add(scoredItem);
                else {
                    double minScore = topNChoices.peek().getScore();
                    if (scoredItem.getScore() > minScore) {
                        // Remove min and add
                        topNChoices.remove();
                        topNChoices.add(scoredItem);
                    }// else ignore.
                }
            }

            System.err.printf("TrainCount: %d, SkipCount: %d for user: %s \n", trainSize, skipCount, userId);

            List<ScoredItem<I>> choices = new LinkedList<>();
            while (!topNChoices.isEmpty()) {
                choices.add(0, topNChoices.remove());
            }

            return new Tuple2<>(userId, choices);
        });
	
	}

	
	 public JavaPairRDD<I, List<ScoredItem<I>>> getTopNPairs(
	            JavaPairRDD<I, Tuple2<I, Double>> tg, int n) {
	        JavaPairRDD<I, Iterable<Tuple2<I, Double>>> tgGrouped = tg.groupByKey();

	        return tgGrouped.mapToPair(x -> {
	            PriorityQueue<ScoredItem<I>> topNChoicesQ = new PriorityQueue<>(n);
	            List<ScoredItem<I>> topNChoices = new LinkedList<>();

	            for (Tuple2<I, Double> tuple : x._2) {
	                ScoredItem<I> scoredItem = new ScoredItem<>(tuple._1, tuple._2);
	                if (topNChoicesQ.size() < n)
	                    topNChoicesQ.add(scoredItem);
	                else {
	                    double minScore = topNChoicesQ.peek().getScore();
	                    if (scoredItem.getScore() > minScore) {
	                        // Remove min and add
	                        topNChoicesQ.remove();
	                        topNChoicesQ.add(scoredItem);
	                    }// else ignore.
	                }
	            }

	            while (!topNChoicesQ.isEmpty()) {
	                topNChoices.add(0, topNChoicesQ.remove());
	            }

	            return new Tuple2<>(x._1, topNChoices);
	        });
	    }
	
	JavaPairRDD<I, Collection<ScoredItem<I>>> generateItemSimilarities(IndexedRowMatrix pComponents) {
        IndexedRowMatrix itemPcaMatrix = pComponents;
        JavaRDD<IndexedRow> rows = itemPcaMatrix.rows().toJavaRDD().repartition(PARTITIONS);
        itemPcaMatrix = new IndexedRowMatrix(rows.rdd());
        System.out.println("Started computing similarities");
        CoordinateMatrix similarities = itemPcaMatrix.toCoordinateMatrix().transpose().toRowMatrix()
                .columnSimilarities(SIM_THRESHOLD);
        System.out.println("Computing item similarities done");
        return SimilarityUtil.constructLookup(similarities, itemIndexToIdMap, TOP_N)
                .mapValues(tuples -> {
                    List<ScoredItem<I>> vals = new ArrayList<>();
                    tuples.forEach(x -> vals.add(new ScoredItem<>(x._1, x._2)));
                    return vals;
                });
    }
	
	public IndexedRowMatrix computeItemPCA(SingularValueDecomposition<IndexedRowMatrix, Matrix> svd,
			JavaSparkContext sc){
		IndexedRowMatrix components = svd.U();
        Vector s = svd.s();
        double[] data = s.toArray();
        for (int i = 0; i < data.length; i++) {
            System.out.println(".. s value:" + data[i] + " before sqrt");
            data[i] = Math.sqrt(data[i]);
            System.out.println(".. s value:" + data[i] + " after sqrt");
        }

        Vector sqrt = new DenseVector(data);

        Matrix sMat = Matrices.diag(sqrt).transpose();
        components = components.multiply(sMat);
        
        return components;
        
	    /*svd.s();
	    svd.V();*/

        //this.sMatrix = sMat;

        /** TODO to move this to user similarity when reqd */
        /*Matrix userMat = svd.V();
        int rowCount = userMat.numRows();
        int colCount = userMat.numCols();
        long startTime = System.currentTimeMillis();
        System.out.println("Starting user components computation...");
        System.out.printf("Row Count : %d and Col Count : %d\n", rowCount, colCount);
        List<MatrixEntry> matEntries = new ArrayList<>();
        for (int i = 0; i < rowCount; i++) {
            for (int j = 0; j < colCount; j++) {
                double val = userMat.apply(i, j);
                matEntries.add(new MatrixEntry(i, j, val));
            }
        }
        long endTime = System.currentTimeMillis();

        System.out.println("Time taken for user component matrix:" + (endTime - startTime));*/

        //JavaRDD<MatrixEntry> matEntriesRdd = sc.parallelize(matEntries);
        //CoordinateMatrix cMatrix = new CoordinateMatrix(matEntriesRdd.rdd());
        //this.userComponents = cMatrix.toIndexedRowMatrix();

        //this.pComponents = components;

        /*JavaPairRDD<I, Vector> itemPCA = components.rows().toJavaRDD().mapToPair(x -> {
            int itemIndex = (int) x.index();
            I itemId = super.itemIndexToIdMap.get(itemIndex);
            Vector pcaVal = x.vector();
            return new Tuple2<>(itemId, pcaVal);
        });*/
        // printPCA(itemPCA);
        
	}
	
	 static class SerializableScoredItemComparator<I> implements Serializable, Comparator<ScoredItem<I>> {
	        private static final long serialVersionUID = 7449795817403753966L;

	        @Override
	        public int compare(ScoredItem<I> o1, ScoredItem<I> o2) {
	            return o1.getScore().compareTo(o2.getScore());
	        }
	    }

}
