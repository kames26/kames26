/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.recommender.tg;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.PriorityQueue;
import java.util.stream.Collectors;

import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;

import com.crayondata.recommender.pca.ScoredItem;
import com.google.common.collect.Iterables;
import com.google.common.collect.Maps;

import scala.Tuple2;

/**
 * @author vivek
 */
public class TGChoiceGenerator {

    public static final int TOP_N = 100;
    public static final int INTERACTION_HISTORY_CAP = 500;

    /**
     * Loads the TG data from the given directory
     *
     * @param inputDir Directory containing the TG files
     * @param sc       Spark context used to read files
     * @return Taste Graph ScoredItem data
     */
    public JavaPairRDD<Integer, List<ScoredItem<Integer>>> loadTGFromFile(String inputDir, JavaSparkContext sc) {
        JavaRDD<String> text = sc.textFile(inputDir).cache();

        JavaPairRDD<Integer, ScoredItem<Integer>> itemTgPairs = text.mapToPair(x -> {
            String[] tokens = x.split(",");
            int itemFromId = Integer.parseInt(tokens[0]);
            int itemToId = Integer.parseInt(tokens[1]);
            double score = Double.parseDouble(tokens[2]);
            return new Tuple2<>(itemFromId, new ScoredItem<>(itemToId, score));
        });

        System.out.println(itemTgPairs.count() + " pairs loaded from:" + inputDir);

        JavaPairRDD<Integer, Iterable<ScoredItem<Integer>>> itemGrouped = itemTgPairs.groupByKey();
        JavaPairRDD<Integer, List<ScoredItem<Integer>>> scoredTg = itemGrouped.mapValues(x -> {
            List<ScoredItem<Integer>> itemList = new ArrayList<>();
            Iterables.addAll(itemList, x);
            return itemList;
        });
        System.out.println("Scored TG has entries for " + scoredTg.count() + " items");

        int totalPairs = scoredTg.map(x -> x._2.size()).fold(0, (x, y) -> x + y);
        System.out.println("Total number of paris loaded are: " + totalPairs);

        return scoredTg;
    }

    /**
     * 1. Generates co-occurrence count.
     * 2. Generates count for each item.
     * 3. Generates TG score for each pair, with function: n12/(n1+n2)
     *
     * @param trainAndTest Train and test data-set
     * @return Taste Graph
     */
    public <T> JavaPairRDD<Integer, Tuple2<Integer, Double>> generateTG(
            JavaPairRDD<T, Tuple2<List<Integer>, List<Integer>>> trainAndTest) {
        JavaPairRDD<T, Integer> userItemRdd = trainAndTest.mapValues(Tuple2::_1).flatMapValues(x -> x);
        Map<Integer, Long> itemCountMap = userItemRdd.mapToPair(Tuple2::swap).countByKey()
                .entrySet().stream().collect(Collectors.toMap(Map.Entry::getKey, v -> (long) v.getValue()));

        JavaPairRDD<T, Tuple2<Integer, Integer>> joined = userItemRdd.join(userItemRdd);

        JavaPairRDD<Tuple2<Integer, Integer>, Integer> pairCountRdd = joined.map(x -> x._2)
                .filter(x -> (x._1.intValue() != x._2.intValue())).mapToPair(x -> new Tuple2<>(x, 1))
                .reduceByKey((x, y) -> x + y);
        long pairCounts = pairCountRdd.count();
        System.out.println("Number of pairs identified: " + pairCounts);

        return pairCountRdd.mapToPair(x -> {
            Integer item1Id = x._1._1;
            Integer item2Id = x._1._2;
            Integer pairCount = x._2;
            Long item1Count = itemCountMap.get(item1Id);
            Long item2Count = itemCountMap.get(item2Id);
            double score = (pairCount * 1.0) / (item1Count + item2Count);
            return new Tuple2<>(item1Id, new Tuple2<>(item2Id, score));
        });
    }

    /*public JavaPairRDD<Integer, List<ScoredItem>> generateTGScoredItems(
            JavaPairRDD<String, Tuple2<List<Integer>, List<Integer>>> trainAndTest, String outputDir) {
        JavaPairRDD<String, List<Integer>> train = trainAndTest.mapValues(Tuple2::_1);
        JavaPairRDD<String, Integer> userItemRdd = train.flatMapValues(x -> x);
        JavaPairRDD<Integer, String> itemUserRdd = userItemRdd.mapToPair(Tuple2::swap);
        JavaPairRDD<Integer, Integer> itemCountRdd = itemUserRdd.mapToPair(x -> new Tuple2<>(x._1, 1))
                .reduceByKey((x, y) -> x + y);
        Map<Integer, Integer> itemCountMap = itemCountRdd.collectAsMap();

        JavaPairRDD<String, Tuple2<Integer, Integer>> joined = userItemRdd.join(userItemRdd);

        JavaRDD<Tuple2<Integer, Integer>> filtered = joined.map(x -> x._2)
                .filter(x -> (x._1.intValue() != x._2.intValue()));

        JavaPairRDD<Tuple2<Integer, Integer>, Integer> pairs = filtered.mapToPair(x -> new Tuple2<>(x, 1));
        JavaPairRDD<Tuple2<Integer, Integer>, Integer> pairCountRdd = pairs.reduceByKey((x, y) -> x + y);
        long pairCounts = pairCountRdd.count();
        System.out.println("Number of pairs identified: " + pairCounts);

        JavaPairRDD<Integer, Tuple2<Integer, Integer>> itemPairCountRdd = pairCountRdd
                .mapToPair(x -> new Tuple2<>(x._1._1, new Tuple2<>(x._1._2, x._2)));

        JavaPairRDD<Integer, Tuple2<Integer, Double>> tgScoresRdd = itemPairCountRdd.mapToPair(x -> {
            Integer item1Id = x._1;
            Integer item2Id = x._2._1;
            Integer pairCount = x._2._2;
            Integer item1Count = itemCountMap.get(item1Id);
            Integer item2Count = itemCountMap.get(item2Id);
            double score = (pairCount * 1.0) / (item1Count + item2Count);
            return new Tuple2<>(item1Id, new Tuple2<>(item2Id, score));
        });

        JavaPairRDD<Integer, List<ScoredItem>> topNTGPairs = getTopNTGPairs(tgScoresRdd, topN);
        int totalPairCount = topNTGPairs.map(x -> x._2.size()).fold(0, (x, y) -> x + y);
        System.out.println("Total pair count after topN:" + totalPairCount);

        persistTopNTGPairs(topNTGPairs, outputDir);

        return topNTGPairs;
    }

    public JavaPairRDD<Integer, List<ScoredItem>> generateTGIntUserId(
            JavaPairRDD<Integer, Tuple2<List<Integer>, List<Integer>>> trainAndTest, String outputDir) {
        JavaPairRDD<Integer, List<Integer>> train = trainAndTest.mapValues(Tuple2::_1);
        JavaPairRDD<Integer, Integer> userItemRdd = train.flatMapValues(x -> x);
        JavaPairRDD<Integer, Integer> itemUserRdd = userItemRdd.mapToPair(Tuple2::swap);
        JavaPairRDD<Integer, Integer> itemCountRdd = itemUserRdd.mapToPair(x -> new Tuple2<>(x._1, 1))
                .reduceByKey((x, y) -> x + y);
        Map<Integer, Integer> itemCountMap = itemCountRdd.collectAsMap();

        JavaPairRDD<Integer, Tuple2<Integer, Integer>> joined = userItemRdd.join(userItemRdd);

        JavaRDD<Tuple2<Integer, Integer>> filtered = joined.map(x -> x._2)
                .filter(x -> (x._1.intValue() != x._2.intValue()));

        JavaPairRDD<Tuple2<Integer, Integer>, Integer> pairs = filtered.mapToPair(x -> new Tuple2<>(x, 1));
        JavaPairRDD<Tuple2<Integer, Integer>, Integer> pairCountRdd = pairs.reduceByKey((x, y) -> x + y);
        long pairCounts = pairCountRdd.count();
        System.out.println("Number of pairs identified: " + pairCounts);

        JavaPairRDD<Integer, Tuple2<Integer, Integer>> itemPairCountRdd = pairCountRdd
                .mapToPair(x -> new Tuple2<>(x._1._1, new Tuple2<>(x._1._2, x._2)));

        JavaPairRDD<Integer, Tuple2<Integer, Double>> tgScoresRdd = itemPairCountRdd.mapToPair(x -> {
            Integer item1Id = x._1;
            Integer item2Id = x._2._1;
            Integer pairCount = x._2._2;
            Integer item1Count = itemCountMap.get(item1Id);
            Integer item2Count = itemCountMap.get(item2Id);
            double score = (pairCount * 1.0) / (item1Count + item2Count);
            return new Tuple2<>(item1Id, new Tuple2<>(item2Id, score));
        });

        JavaPairRDD<Integer, List<ScoredItem>> topNTGPairs = getTopNTGPairs(tgScoresRdd, topN);
        int totalPairCount = topNTGPairs.map(x -> x._2.size()).fold(0, (x, y) -> x + y);
        System.out.println("Total pair count after topN: " + totalPairCount);

        persistTopNTGPairs(topNTGPairs, outputDir);

        return topNTGPairs;
    }*/

    /**
     * 1. Generates co-occurrence count.
     * 2. Generates count for each item.
     * 3. Generates tg score for each pair, with function: n12/(n1+n2)
     *
     * @param trainAndTest Train and test data-set
     * @param outputDir    Output directory to store the result
     * @return TG Scored Items
     */
    public <T> JavaPairRDD<Integer, List<ScoredItem<Integer>>> generateTGScoredItems(
            JavaPairRDD<T, Tuple2<List<Integer>, List<Integer>>> trainAndTest, String outputDir) {
        JavaPairRDD<Integer, Tuple2<Integer, Double>> tgScoresRdd = generateTG(trainAndTest);

        JavaPairRDD<Integer, List<ScoredItem<Integer>>> topTGPairs = getTopNTGPairs(tgScoresRdd, TOP_N);
        int totalPairCount = topTGPairs.map(x -> x._2.size()).fold(0, (x, y) -> x + y);
        System.out.println("Total pair count after topN: " + totalPairCount);
        persistTopNTGPairs(topTGPairs, outputDir);
        return topTGPairs;
    }

    private void persistTopNTGPairs(JavaPairRDD<Integer, List<ScoredItem<Integer>>> topNTGPairs, String outputDir) {
        topNTGPairs.flatMapValues(x -> x).map(x -> x._1 + "," + x._2.getItemId() + "," + x._2.getScore())
                .saveAsTextFile(outputDir + "/tg/");
    }

    /**
     * Generates nChoices for every user.
     *
     * @param tg           Taste Graph data
     * @param trainAndTest Train and Test data
     * @param nChoices     Number of choices
     * @return User Choices
     */
    public JavaPairRDD<String, List<ScoredItem<Integer>>> generateChoices(
            JavaPairRDD<Integer, Tuple2<Integer, Double>> tg,
            JavaPairRDD<String, Tuple2<List<Integer>, List<Integer>>> trainAndTest, int nChoices) {
        Map<Integer, Iterable<Tuple2<Integer, Double>>> tgScoresMap = tg.groupByKey().collectAsMap();
        JavaPairRDD<String, List<Integer>> train = trainAndTest.mapValues(Tuple2::_1);
        return train.mapValues(interactions -> {
            Map<Integer, Double> itemScores = aggregateScoresForChoices(interactions, tgScoresMap);
            return topNChoices(itemScores, nChoices);
        });
    }

    private static Map<Integer, Double> aggregateScoresForChoices(List<Integer> interactions,
            Map<Integer, Iterable<Tuple2<Integer, Double>>> tgScoresMap) {
        Map<Integer, Double> scores = Maps.newHashMap();
        interactions.forEach(intr -> {
            Iterable<Tuple2<Integer, Double>> similarItems = tgScoresMap.get(intr);
            similarItems.forEach(similar -> {
                double existingScore = scores.getOrDefault(similar._1, 0.0);
                scores.put(similar._1, existingScore + similar._2);
            });
        });
        return scores;
    }

    private static List<ScoredItem<Integer>> topNChoices(Map<Integer, Double> itemScores, int n) {
        PriorityQueue<ScoredItem<Integer>> topNChoices = new PriorityQueue<>(n);
        for (Integer itemId : itemScores.keySet()) {
            Double score = itemScores.get(itemId);
            ScoredItem<Integer> scoredItem = new ScoredItem<>(itemId, score);
            if (topNChoices.size() < n)
                topNChoices.add(scoredItem);
            else {
                double minScore = topNChoices.peek().getScore();
                if (scoredItem.getScore() > minScore) {
                    // Remove min and add
                    topNChoices.remove();
                    topNChoices.add(scoredItem);
                }// else ignore.
            }
        }

        List<ScoredItem<Integer>> choices = new LinkedList<>();
        while (!topNChoices.isEmpty()) {
            choices.add(0, topNChoices.remove());
        }
        return choices;
    }

    /*public JavaPairRDD<String, List<ScoredItem>> generateChoicesIntUserIdWithoutCollect(
            JavaPairRDD<Integer, List<ScoredItem>> topNTGPairs,
            JavaPairRDD<Integer, Tuple2<List<Integer>, List<Integer>>> trainAndTest, int nChoices) {
        JavaPairRDD<Integer, List<Integer>> train = trainAndTest.mapValues(Tuple2::_1);
        JavaPairRDD<Integer, Integer> itemUserMap = train.flatMapValues(x -> x).mapToPair(Tuple2::swap);

        JavaPairRDD<Integer, Tuple2<Integer, List<ScoredItem>>> itemUserScoredItems = itemUserMap
                .join(topNTGPairs);
        JavaPairRDD<Integer, List<ScoredItem>> userToScoredItems = itemUserScoredItems.mapToPair(x -> x._2);

        JavaPairRDD<Integer, Iterable<List<ScoredItem>>> userScoredItemsGrouped = userToScoredItems
                .groupByKey();

        JavaPairRDD<Integer, Map<Integer, Boolean>> trainItemMapRdd = train
                .mapValues(x -> x.stream().collect(Collectors.toMap(y -> y, y -> true)));

        JavaPairRDD<Integer, Tuple2<Iterable<List<ScoredItem>>, Map<Integer, Boolean>>> userScoredItemsTrain = userScoredItemsGrouped
                .join(trainItemMapRdd);

        JavaPairRDD<String, List<ScoredItem>> userChoices = userScoredItemsTrain.mapToPair(x -> {
            String userId = String.valueOf(x._1);
            Iterable<List<ScoredItem>> scoredItemLists = x._2._1;
            Map<Integer, Boolean> trainItemMap = x._2._2;
            List<ScoredItem> allScoredItems = new ArrayList<>();
            for (List<ScoredItem> similarItems : scoredItemLists) {
                allScoredItems.addAll(similarItems);
            }

            Map<Integer, Double> itemScores = allScoredItems.parallelStream().collect(Collectors
                    .groupingBy(ScoredItem::getItemId, Collectors.summingDouble(ScoredItem::getScore)));
            
            *//*int interactionCount = Iterables.size(scoredItemLists);
            int index = 0;
            Map<Integer, Double> itemScores = Maps.newHashMap();
            for(List<ScoredItem> similarItems : scoredItemLists){
                if (index >= INTERACTION_HISTORY_CAP) {
                    System.err.println("Skipping additional interactions with size:" + interactionCount);
                    break;
                }
                
                for (ScoredItem itemScore : similarItems) {
                    Integer simItemId = itemScore.getItemId();
                    Double score = itemScore.getScore();
                    Double existingScore = 0.0;
                    if (itemScores.containsKey(simItemId)) {
                        existingScore = itemScores.get(simItemId);
                    }
                    itemScores.put(simItemId, existingScore+score);
                }
                index++;
            }*//*

            PriorityQueue<ScoredItem> topNChoices = new PriorityQueue<>(nChoices);

            int trainSize = trainItemMap.size();
            int skipCount = 0;
            for (Integer itemId : itemScores.keySet()) {
                if (trainItemMap.containsKey(itemId)) {
                    skipCount++;
                    continue;
                }
                Double score = itemScores.get(itemId);
                ScoredItem scoredItem = new ScoredItem(itemId, score);
                if (topNChoices.size() < nChoices)
                    topNChoices.add(scoredItem);
                else {
                    double minScore = topNChoices.peek().getScore();
                    if (scoredItem.getScore() > minScore) {
                        // Remove min and add
                        topNChoices.remove();
                        topNChoices.add(scoredItem);
                    }// else ignore.
                }
            }

            System.err.printf("TrainCount: %d, SkipCount: %d for user: %s\n", trainSize, skipCount, userId);

            List<ScoredItem> choices = new LinkedList<>();
            while (!topNChoices.isEmpty()) {
                choices.add(0, topNChoices.remove());
            }

            return new Tuple2<>(userId, choices);
        });

        return userChoices;
    }

    public JavaPairRDD<String, List<ScoredItem>> generateChoicesWithoutCollect(
            JavaPairRDD<Integer, List<ScoredItem>> topNTGPairs,
            JavaPairRDD<String, Tuple2<List<Integer>, List<Integer>>> trainAndTest, int nChoices) {
        JavaPairRDD<String, List<Integer>> train = trainAndTest.mapValues(Tuple2::_1);
        JavaPairRDD<Integer, String> itemUserMap = train.flatMapValues(x -> x).mapToPair(Tuple2::swap);

        JavaPairRDD<Integer, Tuple2<String, List<ScoredItem>>> itemUserScoredItems = itemUserMap
                .join(topNTGPairs);
        JavaPairRDD<String, List<ScoredItem>> userToScoredItems = itemUserScoredItems.mapToPair(x -> x._2);

        JavaPairRDD<String, Iterable<List<ScoredItem>>> userScoredItemsGrouped = userToScoredItems
                .groupByKey();

        JavaPairRDD<String, Map<Integer, Boolean>> trainItemMapRdd = train
                .mapValues(x -> x.stream().collect(Collectors.toMap(y -> y, y -> true)));

        JavaPairRDD<String, Tuple2<Iterable<List<ScoredItem>>, Map<Integer, Boolean>>> userScoredItemsTrain = userScoredItemsGrouped
                .join(trainItemMapRdd);

        JavaPairRDD<String, List<ScoredItem>> userChoices = userScoredItemsTrain.mapToPair(x -> {
            String userId = String.valueOf(x._1);
            Iterable<List<ScoredItem>> scoredItemLists = x._2._1;
            Map<Integer, Boolean> trainItemMap = x._2._2;
            List<ScoredItem> allScoredItems = new ArrayList<>();
            for (List<ScoredItem> similarItems : scoredItemLists) {
                allScoredItems.addAll(similarItems);
            }

            Map<Integer, Double> itemScores = allScoredItems.parallelStream().collect(Collectors
                    .groupingBy(ScoredItem::getItemId, Collectors.summingDouble(ScoredItem::getScore)));

            Map<Integer, Long> itemCounts = allScoredItems.parallelStream()
                    .collect(Collectors.groupingBy(ScoredItem::getItemId, Collectors.counting()));

            Map<Integer, Optional<ScoredItem>> itemMaxScores = allScoredItems.parallelStream().collect(
                    Collectors.groupingBy(ScoredItem::getItemId,
                            Collectors.maxBy(new SerializableScoredItemComparator())));

            PriorityQueue<ScoredItem> topNChoices = new PriorityQueue<>(nChoices);

            int trainSize = trainItemMap.size();
            int skipCount = 0;
            for (Integer itemId : itemScores.keySet()) {
                if (trainItemMap.containsKey(itemId)) {
                    skipCount++;
                    continue;
                }
                Double score = itemScores.get(itemId);
                ScoredItem scoredItem = new ScoredItem(itemId, score);
                scoredItem.setCount(itemCounts.get(itemId).intValue());
                Optional<ScoredItem> maxScoreItem = itemMaxScores.get(itemId);
                maxScoreItem.ifPresent(scoredItem1 -> scoredItem.setMaxScore(scoredItem1.getScore()));
                if (topNChoices.size() < nChoices)
                    topNChoices.add(scoredItem);
                else {
                    double minScore = topNChoices.peek().getScore();
                    if (scoredItem.getScore() > minScore) {
                        // Remove min and add
                        topNChoices.remove();
                        topNChoices.add(scoredItem);
                    }// else ignore.
                }
            }

            System.err.printf(".. TrainCount:%d, SkipCount:%d for user:%s \n", trainSize, skipCount, userId);

            List<ScoredItem> choices = new LinkedList<>();
            while (!topNChoices.isEmpty()) {
                choices.add(0, topNChoices.remove());
            }

            return new Tuple2<>(userId, choices);
        });

        return userChoices;
    }*/
    
    public <T> JavaPairRDD<String, List<ScoredItem<Integer>>> generateChoicesForTrainWithoutCollect(
            JavaPairRDD<Integer, List<ScoredItem<Integer>>> topNTGPairs,
            JavaPairRDD<T, List<Integer>> train,
            int nChoices){
    	JavaPairRDD<Integer, T> itemUserMap = train.flatMapValues(x -> x).mapToPair(Tuple2::swap);

        JavaPairRDD<T, List<ScoredItem<Integer>>> userToScoredItems = itemUserMap.join(topNTGPairs).mapToPair(Tuple2::_2);
        JavaPairRDD<T, Iterable<List<ScoredItem<Integer>>>> userScoredItemsGrouped = userToScoredItems.groupByKey();

        JavaPairRDD<T, Map<Integer, Boolean>> trainItemMapRdd = train
                .mapValues(x -> x.stream().collect(Collectors.toMap(y -> y, y -> true)));

        JavaPairRDD<T, Tuple2<Iterable<List<ScoredItem<Integer>>>, Map<Integer, Boolean>>> userScoredItemsTrain = userScoredItemsGrouped
                .join(trainItemMapRdd);

        return userScoredItemsTrain.mapToPair(x -> {
            String userId = String.valueOf(x._1);
            Iterable<List<ScoredItem<Integer>>> scoredItemLists = x._2._1;
            Map<Integer, Boolean> trainItemMap = x._2._2;
            List<ScoredItem<Integer>> allScoredItems = new ArrayList<>();
            for (List<ScoredItem<Integer>> similarItems : scoredItemLists) {
                allScoredItems.addAll(similarItems);
            }

            Map<Integer, Double> itemScores = allScoredItems.parallelStream().collect(Collectors
                    .groupingBy(ScoredItem::getItemId, Collectors.summingDouble(ScoredItem::getScore)));

            Map<Integer, Long> itemCounts = allScoredItems.parallelStream()
                    .collect(Collectors.groupingBy(ScoredItem::getItemId, Collectors.counting()));

            Map<Integer, Optional<ScoredItem<Integer>>> itemMaxScores = allScoredItems.parallelStream().collect(
                    Collectors.groupingBy(ScoredItem::getItemId,
                            Collectors.maxBy(new SerializableScoredItemComparator())));

            PriorityQueue<ScoredItem<Integer>> topNChoices = new PriorityQueue<>(nChoices);

            int trainSize = trainItemMap.size();
            int skipCount = 0;
            for (Integer itemId : itemScores.keySet()) {
                if (trainItemMap.containsKey(itemId)) {
                    skipCount++;
                    continue;
                }
                Double score = itemScores.get(itemId);
                ScoredItem<Integer> scoredItem = new ScoredItem<Integer>(itemId, score);
                scoredItem.setCount(itemCounts.get(itemId).intValue());
                Optional<ScoredItem<Integer>> maxScoreItem = itemMaxScores.get(itemId);
                maxScoreItem.ifPresent(scoredItem1 -> scoredItem.setMaxScore(scoredItem1.getScore()));
                if (topNChoices.size() < nChoices)
                    topNChoices.add(scoredItem);
                else {
                    double minScore = topNChoices.peek().getScore();
                    if (scoredItem.getScore() > minScore) {
                        // Remove min and add
                        topNChoices.remove();
                        topNChoices.add(scoredItem);
                    }// else ignore.
                }
            }

            System.err.printf("TrainCount: %d, SkipCount: %d for user: %s \n", trainSize, skipCount, userId);

            List<ScoredItem<Integer>> choices = new LinkedList<>();
            while (!topNChoices.isEmpty()) {
                choices.add(0, topNChoices.remove());
            }

            return new Tuple2<>(userId, choices);
        });

    }

    /**
     * Generates nChoices for every user, without collecting the tg data locally.
     *
     * @param topNTGPairs Taste Graph data
     * @param trainAndTest Train and Test data
     * @param nChoices Number of Choices
     * @return User Choices
     */
    public <T> JavaPairRDD<String, List<ScoredItem<Integer>>> generateChoicesWithoutCollect(
            JavaPairRDD<Integer, List<ScoredItem<Integer>>> topNTGPairs,
            JavaPairRDD<T, Tuple2<List<Integer>, List<Integer>>> trainAndTest,
            int nChoices) {
        JavaPairRDD<T, List<Integer>> train = trainAndTest.mapValues(Tuple2::_1);
        return generateChoicesForTrainWithoutCollect(topNTGPairs, train, nChoices);
    }

    /**
     * Generates nChoices for every user, without collecting the tg data locally.
     *
     * @param topNTGPairs Taste Graph data
     * @param trainAndTest Train and Test data
     * @param nChoices Number of Choices
     * @return User Choices
     */
    public JavaPairRDD<String, List<Integer>> generateChoicesIntUserId(
            JavaPairRDD<Integer, List<ScoredItem<Integer>>> topNTGPairs,
            JavaPairRDD<Integer, Tuple2<List<Integer>, List<Integer>>> trainAndTest, int nChoices) {

        Map<Integer, List<ScoredItem<Integer>>> tgScoresMap = topNTGPairs.collectAsMap();

        JavaPairRDD<Integer, List<Integer>> train = trainAndTest.mapToPair(x -> new Tuple2<>(x._1, x._2._1));
        JavaPairRDD<String, List<Integer>> userChoices = train.mapToPair(x -> {
            String userId = String.valueOf(x._1);
            List<Integer> interactions = x._2;
            Map<Integer, Double> itemScores = Maps.newHashMap();
            int index = 0;
            for (Integer itemId : interactions) {
                if (index >= INTERACTION_HISTORY_CAP) {
                    System.err.println("Skipping additional interactions with size:" + interactions.size());
                    break;
                }
                Iterable<ScoredItem<Integer>> similarItems = tgScoresMap.get(itemId);
                for (ScoredItem<Integer> itemScore : similarItems) {
                    Integer simItemId = itemScore.getItemId();
                    Double score = itemScore.getScore();
                    Double existingScore = 0.0;
                    if (itemScores.containsKey(simItemId)) {
                        existingScore = itemScores.get(simItemId);
                    }
                    itemScores.put(simItemId, existingScore + score);
                }
                index++;
            }
            PriorityQueue<ScoredItem<Integer>> topNChoices = new PriorityQueue<>(nChoices);

            for (Integer itemId : itemScores.keySet()) {
                Double score = itemScores.get(itemId);
                ScoredItem<Integer> scoredItem = new ScoredItem<>(itemId, score);
                if (topNChoices.size() < nChoices)
                    topNChoices.add(scoredItem);
                else {
                    double minScore = topNChoices.peek().getScore();
                    if (scoredItem.getScore() > minScore) {
                        // Remove min and add
                        topNChoices.remove();
                        topNChoices.add(scoredItem);
                    }// else ignore.
                }
            }

            List<Integer> choiceItemIds = new LinkedList<>();
            while (!topNChoices.isEmpty()) {
                choiceItemIds.add(0, topNChoices.remove().getItemId());
            }

            return new Tuple2<>(userId, choiceItemIds);
        });

        return userChoices;
    }

    public static JavaPairRDD<Integer, List<ScoredItem<Integer>>> getTopNTGPairs(
            JavaPairRDD<Integer, Tuple2<Integer, Double>> tg, int n) {
        JavaPairRDD<Integer, Iterable<Tuple2<Integer, Double>>> tgGrouped = tg.groupByKey();

        return tgGrouped.mapToPair(x -> {
            PriorityQueue<ScoredItem<Integer>> topNChoicesQ = new PriorityQueue<>(n);
            List<ScoredItem<Integer>> topNChoices = new LinkedList<>();

            for (Tuple2<Integer, Double> tuple : x._2) {
                ScoredItem<Integer> scoredItem = new ScoredItem<>(tuple._1, tuple._2);
                if (topNChoicesQ.size() < n)
                    topNChoicesQ.add(scoredItem);
                else {
                    double minScore = topNChoicesQ.peek().getScore();
                    if (scoredItem.getScore() > minScore) {
                        // Remove min and add
                        topNChoicesQ.remove();
                        topNChoicesQ.add(scoredItem);
                    }// else ignore.
                }
            }

            while (!topNChoicesQ.isEmpty()) {
                topNChoices.add(0, topNChoicesQ.remove());
            }

            return new Tuple2<>(x._1, topNChoices);
        });
    }

    static class SerializableScoredItemComparator implements Serializable, Comparator<ScoredItem<Integer>> {
        private static final long serialVersionUID = 7449795817403753966L;

        @Override
        public int compare(ScoredItem<Integer> o1, ScoredItem<Integer> o2) {
            return o1.getScore().compareTo(o2.getScore());
        }
    }

}
