/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.utils;

import org.apache.commons.cli.Option;

/**
 * @author sundar
 */
public class CLIOptions {

    public static final Option OPT_TRXN_DIR = CommandLineOption
            .getOption(false, "trxn", "transaction-dataset", "dataset-path", "Path of transaction dataset");
    public static final Option OPT_TRXN_MERC_COL = CommandLineOption
            .getOption(false, "tm", "trxn-merchant-id-field", "field-name",
                    "Merchant Id field name in transaction dataset");
    public static final Option OPT_TRXN_CUST_COL = CommandLineOption
            .getOption(false, "tc", "trxn-customer-id-field", "field-name",
                    "Customer Id field name in transaction dataset");

    public static final Option OPT_MERC_DIR = CommandLineOption
            .getOption(false, "merc", "merchant-dataset", "dataset-path", "Path of merchant dataset");
    public static final Option OPT_MERC_MERC_COL = CommandLineOption
            .getOption(false, "mm", "item-merchant-id-field", "field-name",
                    "Merchant Id field name in merchant dataset");
    public static final Option OPT_MERC_TAG_COL = CommandLineOption
            .getOption(false, "mt", "item-tag-field", "field-name", "Tag field name in merchant dataset");

    public static final Option OPT_OP_DIR = CommandLineOption
            .getOption(true, "output", "output-dataset", "dataset-path", "Path of output dataset");

    public static final Option OPT_MODELS = CommandLineOption
            .getOption(true, "models", "models", "models", "Recommender Models to run");
    public static final Option OPT_CHOICES = CommandLineOption
            .getOption(true, "choices", "choices", "num-choices", "Number of choices to generate");

    public static final Option OPT_CHOICE_DIR = CommandLineOption
            .getOption(true, "choice", "choice-dataset", "dataset-path", "Path of choices dataset");
    public static final Option OPT_CHOICE_START = CommandLineOption
            .getOption(true, "start", "start-count", "eval-from-n", "Start num of choices");
    public static final Option OPT_CHOICE_END = CommandLineOption
            .getOption(true, "end", "end-count", "eval-to-n", "End num of choices");
    public static final Option OPT_CHOICE_INCR = CommandLineOption
            .getOption(false, "incr", "incr-count", "eval-incr-n", "Increment");

    public static final Option OPT_PARTITIONS = CommandLineOption
            .getOption(false, "p", "partitions", "num-partitions", "Partitions count");
}
