/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.choice.generator;

import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.function.Function2;
import org.apache.spark.storage.StorageLevel;

import com.crayondata.recommender.pca.ScoredItem;
import com.crayondata.utils.MaxHeap;

import scala.Tuple2;

/**
 * @author sundar
 */
public abstract class TGChoiceGenerator<U, I> extends BaseChoiceGenerator<U, I> {

    private static final long serialVersionUID = 5226643655403659913L;
    public static final int DEFAULT_TOP_TG_PAIRS = 100;

    // Following are initialized from constructor
    private int topTGPairsToTake;

    // Following are variables used while processing
    protected JavaPairRDD<U, I> userItemRDD;
    private JavaPairRDD<I, List<ScoredItem<I>>> tgPairs;

    public TGChoiceGenerator(JavaSparkContext sparkContext, String interactionDir, String outputDir,
            int numOfChoices, int topTGPairsToTake) {
        super(sparkContext, interactionDir, outputDir, numOfChoices);
        this.topTGPairsToTake = topTGPairsToTake;
    }

    @Override
    public void runModel() {
        JavaPairRDD<I, Tuple2<I, Double>> tgScores = generateTG();
        tgPairs = getTopNTGPairs(tgScores, topTGPairsToTake).persist(StorageLevel.DISK_ONLY());
    }

    @Override
    public void saveModelData() {
        String outputPath = Paths.get(outputDir, "tg-pairs").toString();
        tgPairs.flatMapValues(x -> x)
                .map(x -> x._1 + "\t" + x._2.getItemId() + "\t" + x._2.getScore())
                .saveAsTextFile(outputPath);
    }

    @Override
    public void generateChoices() {
        userChoices = generateChoices(userItemRDD, tgPairs, numOfChoices);
    }

    public static <U, I> JavaPairRDD<U, List<ScoredItem<I>>> generateChoices(JavaPairRDD<U, I> userItemRDD,
            JavaPairRDD<I, List<ScoredItem<I>>> tgPairs, int numOfChoices) {
        JavaPairRDD<I, U> itemUserRDD = userItemRDD.mapToPair(Tuple2::swap);
        JavaPairRDD<U, List<ScoredItem<I>>> joinedRDD = itemUserRDD.join(tgPairs).mapToPair(Tuple2::_2);
        JavaPairRDD<Tuple2<U, I>, Double> modifiedJoin = joinedRDD.flatMapToPair(x -> {
            U user = x._1;
            List<Tuple2<Tuple2<U, I>, Double>> out = new ArrayList<>();
            for (ScoredItem<I> s : x._2) {
                out.add(new Tuple2<>(new Tuple2<>(user, s.getItemId()), s.getScore()));
            }
            return out;
        }).reduceByKey((x, y) -> (x + y));
        JavaPairRDD<U, ScoredItem<I>> choicesAll = modifiedJoin
                .mapToPair(x -> new Tuple2<>(x._1._1, new ScoredItem<>(x._1._2, x._2)));
        List<ScoredItem<I>> zeroVal = new ArrayList<>();

        Function2<List<ScoredItem<I>>, ScoredItem<I>, List<ScoredItem<I>>> addEntryFn = (v1, v2) -> {
            v1.add(v2);
            return v1;
        };
        Function2<List<ScoredItem<I>>, List<ScoredItem<I>>, List<ScoredItem<I>>> combineFn = (v1, v2) -> {
            List<ScoredItem<I>> r = new ArrayList<>(v1.size() + v2.size());
            r.addAll(v1);
            r.addAll(v2);
            return r;
        };

        JavaPairRDD<U, List<ScoredItem<I>>> choices = choicesAll.aggregateByKey(zeroVal, addEntryFn, combineFn);
        return choices.mapValues(x -> {
            MaxHeap<ScoredItem<I>> topChoices = new MaxHeap<>(numOfChoices);
            x.forEach(topChoices::include);
            return topChoices.getAll();
        });
    }

    // From the user-item dataset, generate the taste graph data
    private JavaPairRDD<I, Tuple2<I, Double>> generateTG() {
        // swap user-item dataset to item-user dataset to get count of transactions of each item
        Map<I, Long> itemCountMap = userItemRDD.mapToPair(Tuple2::swap).countByKey()
                .entrySet().stream().collect(Collectors.toMap(Map.Entry::getKey, v -> (long) v.getValue()));
        // join user-item dataset with user-item dataset and get the item pairs.
        // exclude the item-item pairs where left & right are the same
        // take the count of occurrence of item-item pair
        JavaPairRDD<U, Tuple2<I, I>> joined = userItemRDD.join(userItemRDD);
        JavaPairRDD<Tuple2<I, I>, Integer> pairCountRdd = joined.map(x -> x._2)
                .filter(x -> (!x._1.equals(x._2))).mapToPair(x -> new Tuple2<>(x, 1))
                .reduceByKey((x, y) -> x + y);

        // final tg score is {n12 / (n1 + n2)} where
        // n12 is the item-item pair count
        // n1 is transaction count of item1 (left)
        // n2 is transaction count of item2 (right)
        return pairCountRdd.mapToPair(x -> {
            I item1Id = x._1._1;
            I item2Id = x._1._2;
            Integer pairCount = x._2;
            Long item1Count = itemCountMap.get(item1Id);
            Long item2Count = itemCountMap.get(item2Id);
            double score = (pairCount * 1.0) / (item1Count + item2Count);
            return new Tuple2<>(item1Id, new Tuple2<>(item2Id, score));
        });
    }

    // From taste graph data, get the top taste graph pairs
    // Note that this method also converts from Tuple2 to ScoredItem
    static <T> JavaPairRDD<T, List<ScoredItem<T>>> getTopNTGPairs(
            JavaPairRDD<T, Tuple2<T, Double>> tg, int n) {
        return tg.groupByKey().mapValues(x -> {
            MaxHeap<ScoredItem<T>> topNChoices = new MaxHeap<>(n);
            x.forEach(t -> topNChoices.include(new ScoredItem<>(t._1, t._2)));
            return topNChoices.getAll();
        });
    }


}
