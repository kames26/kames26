/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.data.sbi;

import java.nio.file.Paths;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.api.java.function.PairFunction;

import com.crayondata.choice.generator.ItemTagGraphChoiceGenerator;
import com.crayondata.choice.generator.TGChoiceGenerator;
import com.crayondata.choice.generator.UserAttrTagChoiceGenerator;
import com.crayondata.data.citi.CitiChoiceGenerator;
import com.crayondata.utils.SparkConfUtils;

import scala.Tuple2;

/**
 * @author sundar
 */
public class SbiChoiceGenerator {
    public static void main(String[] args) {
        if (args.length < 4) {
            System.err.println("Usage: " + CitiChoiceGenerator.class + " <interaction-dir> "
                    + " <output-dir> <numOfChoices> <models>");
            System.exit(1);
        }

        String interactionDir = args[0];
        String outputDir = args[1];
        int numOfChoices = Integer.valueOf(args[2]);
        List<String> models = Arrays.asList(args[3].split(","));

        SparkConf conf = new SparkConf().setAppName("SBI Choice Generator - " + args[3]);
        SparkConfUtils.printSparkConf(conf);
        SparkConfUtils.logSparkConf(conf);

        JavaSparkContext sc = new JavaSparkContext(conf);

        if (models.contains("tag")) {
            String userPrefOutDir = Paths.get(outputDir, "user_tag_pref_model").toString();
            String itemsDir = conf.get("spark.crayon.model.tag.items");
            if (itemsDir == null) {
                System.err.println(
                        "Items file/dir (spark.crayon.model.tag.items) is not set. Skipping Tag Model");
            } else {
                UserAttrTagChoiceGenerator<String, String> attrChoiceGenerator = new SbiUserAttrTagChoiceGenerator(
                        sc, interactionDir, userPrefOutDir, numOfChoices, itemsDir);
                attrChoiceGenerator.run();
            }
        }

        if (models.contains("taggraph")) {
            String tgOutDir = Paths.get(outputDir, "tag_graph_model").toString();
            String itemsDir = conf.get("spark.crayon.model.tag.items");
            int numTopTGPairs = conf
                    .getInt("spark.crayon.model.tg.top.tg.pairs", TGChoiceGenerator.DEFAULT_TOP_TG_PAIRS);
            if (itemsDir == null) {
                System.err.println(
                        "Items file/dir (spark.crayon.model.tag.items) is not set. Skipping Item Tag Model");
            } else {
                ItemTagGraphChoiceGenerator<String, String> itemTagGraphChoiceGenerator = new SbiItemTagGraphChoiceGenerator(
                        sc, interactionDir, itemsDir, tgOutDir, numOfChoices, numTopTGPairs);
                itemTagGraphChoiceGenerator.run();
            }
        }
    }

    // @formatter:off
    static final Function<String, Boolean> ATTR_DATA_FILTER_FN = (String line) -> line.split("\t").length >= 2;
    static final Function<String, Boolean> ATTR_DATA_TAG_FILTER_FN = (String line) -> line.split("\t")[1].length() > 0;
    static final Function<String, Boolean> INTR_DATA_FILTER_FN = (String line) -> line.split("\t").length >= 2;

    static final PairFunction<String, String, List<String>> ATTR_DATA_READ_FN = (String line) -> {
        String[] tokens = line.split("\t");
        List<String> tags = Arrays.stream(tokens[1].split(","))
                .map(String::trim)
                .filter(t -> t.length() > 0)
                .collect(Collectors.toList());
        return new Tuple2<>(tokens[0], tags);
    };

    static final PairFunction<String, String, String> INTR_DATA_READ_FN = (String line) -> {
        String[] tokens = line.split("\t");
        return new Tuple2<>(tokens[0], tokens[1]);
    };
    // @formatter:on
}
