/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.recommender.mlens;

import java.util.List;
import java.util.Map;

import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.mllib.linalg.Vector;
import org.apache.spark.storage.StorageLevel;

import com.crayondata.recommender.pca.PCAChoiceGenerator;
import com.crayondata.recommender.pca.PCAChoicesEvaluator;
import com.crayondata.recommender.pca.PCAGenerator;
import com.crayondata.recommender.pca.ScoredItem;
import com.crayondata.recommender.tg.TGChoiceGenerator;
import com.crayondata.utils.DataSplitter;

import scala.Tuple2;

/**
 * @author vivek
 */
public class MLensChoicesEvaluator extends PCAChoicesEvaluator {

    private static final long serialVersionUID = 1L;

    // private final static String USER_ACCURACY_FILE = "PerUserAccuracy";
    // private int tillN = 20; // Evaluated from 6 till atN value.
    // private String outputDir = "output_tg/accuracy";
    // private int partitions = 1024;
    // private int nComponents = 20;

    private String tgDir = null;

    private void setTgDir(String tgDir) {
        this.tgDir = tgDir;
    }

    public MLensChoicesEvaluator() {
    }

    public MLensChoicesEvaluator(String interactionFileUri, int tillN, String outputDir, int nComponents,
            int partitionCount) {
        super.interactionFileUri = interactionFileUri;
        super.tillN = tillN;
        super.outputDir = outputDir;
        super.nComponents = nComponents;
        super.partitions = partitionCount;
    }

    public static void main(String[] args) {
        SparkConf conf = new SparkConf().setAppName("Movie Lens Choice Evaluation application");
        conf.setIfMissing("spark.executor.memory", "64g");
        conf.setIfMissing("spark.num.executors", "1");
        // conf.setIfMissing("spark.executor.cores", "7");
        conf.setIfMissing("spark.executor.cores", "15");
        conf.setIfMissing("spark.storage.memoryFraction", "0.1");

        JavaSparkContext sc = new JavaSparkContext(conf);
        MLensChoicesEvaluator evaluator;

        if (args.length < 5) {
            System.out.println(
                    "Usage: MLensChoicesEvaluator <interaction-file> <tillN> <output-dir> <nComponents> "
                            + "<partition-count> <tg|pca> [start-n] [tg-dir]");
            System.out.println("Using default values...");
            evaluator = new MLensChoicesEvaluator();
        } else {
            evaluator = new MLensChoicesEvaluator(args[0], Integer.parseInt(args[1]), args[2],
                    Integer.parseInt(args[3]), Integer.parseInt(args[4]));
        }

        String modelType = args[5].trim();
        
        System.out.println("ModelType:" + modelType);

        if (args.length >= 7) {
            evaluator.setStartN(Integer.parseInt(args[6]));
            System.out.println("Setting start n as: " + args[6]);
        }

        if (args.length >= 8)
            evaluator.setTgDir(args[7]);

        if ("tg".equalsIgnoreCase(modelType)) {
            System.out.println("Generating and evaluating TG choices...");
            evaluator.evalTGChoices(sc);
        } else if ("pca".equalsIgnoreCase(modelType)) {
            System.out.println("Generating and evaluating PCA choices...");
            evaluator.evalChoices(sc);
        } else if ("user_sim".equalsIgnoreCase(modelType)) {
            System.out.println("Generating and evaluating SVD based user similarity choices...");
            evaluator.evalUserSimChoices(sc);
        } else if ("item_sim".equalsIgnoreCase(modelType)) {
            System.out.println("Generating and evaluating SVD based item similarity choices...");
            evaluator.evalItemSimChoices(sc);
        } else if ("tg_csv".equalsIgnoreCase(modelType)) {
            System.out.println("Generating and evaluating TG based choices from csv interaction file...");
            evaluator.evalTGChoicesFromCsv(sc);
        }else {
            System.out.println("Option: " + modelType + " not recognized");
            System.err.println("Option: " + modelType + " not recognized");
        }
    }
    
    private void evalItemSimChoices(JavaSparkContext sc) {
    	System.out.println("Generating and evaluating item sim choices..");
        JavaRDD<String> fileText = sc.textFile(interactionFileUri, partitions).cache();

        // Filtering invalid lines
        JavaRDD<String> filteredRdd = fileText.filter(x -> x.split("::").length == 4);

        JavaPairRDD<Integer, Integer> itemUserRdd = filteredRdd.mapToPair(x -> {
            String[] tokens = x.split("::");
            return new Tuple2<>(Integer.parseInt(tokens[1]), Integer.parseInt(tokens[0]));
        });
        JavaPairRDD<Integer, Tuple2<List<Integer>, List<Integer>>> trainAndTest = DataSplitter.createTrainTestSplit(
                itemUserRdd.mapToPair(Tuple2::swap), MIN_INTERACTION_COUNT).persist(StorageLevel.MEMORY_AND_DISK());
        JavaPairRDD<String, Tuple2<List<Integer>, List<Integer>>> trainAndTestModified = trainAndTest
                .mapToPair(x -> new Tuple2<>(String.valueOf(x._1), x._2));

        //int nComponents = 20;

        for (int nComponents = 3; nComponents <= 30; nComponents++) {
            System.err.println("Generating for nComponents:" + nComponents + ", tillN:" + tillN);
            PCAGenerator pcaGen = new PCAGenerator();
            JavaPairRDD<Integer, Vector> itemPCA = pcaGen.generatePCA(sc, trainAndTestModified, nComponents);
            Map<Integer, Vector> pcaMap = itemPCA.collectAsMap();
            PCAChoiceGenerator choiceGen = new PCAChoiceGenerator();
            JavaPairRDD<String, List<ScoredItem<Integer>>> userChoices = choiceGen
                    .generateItemSimChoices(sc, trainAndTestModified, nComponents, tillN, pcaMap, pcaGen);
            evaluateTillN(trainAndTestModified, userChoices, getChoiceItemIds(userChoices), sc, nComponents,
                    tillN);
            System.err
                    .println("Generating for nComponents:" + nComponents + ", tillN:" + tillN + "  done.!!");
        }

    }

    private void evalUserSimChoices(JavaSparkContext sc) {
        JavaRDD<String> fileText = sc.textFile(interactionFileUri, partitions).cache();

        // Filtering invalid lines
        JavaRDD<String> filteredRdd = fileText.filter(x -> x.split("::").length == 4);

        JavaPairRDD<Integer, Integer> itemUserRdd = filteredRdd.mapToPair(x -> {
            String[] tokens = x.split("::");
            return new Tuple2<>(Integer.parseInt(tokens[1]), Integer.parseInt(tokens[0]));
        });
        JavaPairRDD<Integer, Tuple2<List<Integer>, List<Integer>>> trainAndTest = DataSplitter.createTrainTestSplit(
                itemUserRdd.mapToPair(Tuple2::swap), MIN_INTERACTION_COUNT).persist(StorageLevel.MEMORY_AND_DISK());
        JavaPairRDD<String, Tuple2<List<Integer>, List<Integer>>> trainAndTestModified = trainAndTest
                .mapToPair(x -> new Tuple2<>(String.valueOf(x._1), x._2));

        //int nComponents = 20;

        for (int nComponents = 3; nComponents <= 30; nComponents++) {
            System.err.println("Generating for nComponents:" + nComponents + ", tillN:" + tillN);
            PCAGenerator pcaGen = new PCAGenerator();
            JavaPairRDD<Integer, Vector> itemPCA = pcaGen.generatePCA(sc, trainAndTestModified, nComponents);
            Map<Integer, Vector> pcaMap = itemPCA.collectAsMap();
            PCAChoiceGenerator choiceGen = new PCAChoiceGenerator();
            JavaPairRDD<String, List<ScoredItem<Integer>>> userChoices = choiceGen
                    .generateUserSimChoices(sc, trainAndTestModified, nComponents, tillN, pcaMap, pcaGen);
            evaluateTillN(trainAndTestModified, userChoices, getChoiceItemIds(userChoices), sc, nComponents,
                    tillN);
            System.err
                    .println("Generating for nComponents:" + nComponents + ", tillN:" + tillN + "  done.!!");
        }

    }

    public void evalChoices(JavaSparkContext sc) {
        JavaRDD<String> fileText = sc.textFile(interactionFileUri, partitions).cache();

        // Filtering invalid lines..
        //TODO: to revisit this step.. this may not be optimal
        JavaRDD<String> filteredRdd = fileText.filter(x -> x.split("::").length == 4);
        JavaPairRDD<Integer, Integer> itemUserRdd = filteredRdd.mapToPair(x -> {
            String[] tokens = x.split("::");
            return new Tuple2<>(Integer.parseInt(tokens[1]), Integer.parseInt(tokens[0]));
        });
        JavaPairRDD<Integer, Tuple2<List<Integer>, List<Integer>>> trainAndTest = DataSplitter.createTrainTestSplit(
                itemUserRdd.mapToPair(Tuple2::swap), MIN_INTERACTION_COUNT).persist(StorageLevel.MEMORY_AND_DISK());
        JavaPairRDD<String, Tuple2<List<Integer>, List<Integer>>> trainAndTestModified = trainAndTest
                .mapToPair(x -> new Tuple2<>(String.valueOf(x._1), x._2));
        persistTestAndTrain(trainAndTestModified);

        //int nComponents = 20;
        for (int nComponents = 1; nComponents <= 8; nComponents++) {
            System.err.println("Generating for nComponents:" + nComponents + ", tillN:" + tillN);
            PCAGenerator pcaGen = new PCAGenerator();
            JavaPairRDD<Integer, Vector> itemPCA = pcaGen.generatePCA(sc, trainAndTestModified, nComponents);
            Map<Integer, Vector> pcaMap = itemPCA.collectAsMap();
            PCAChoiceGenerator choiceGen = new PCAChoiceGenerator();
            JavaPairRDD<String, List<ScoredItem<Integer>>> userChoices = choiceGen
                    .generateChoices(sc, trainAndTestModified, nComponents, tillN, pcaMap, pcaGen);
            evaluateTillN(trainAndTestModified, userChoices, getChoiceItemIds(userChoices), sc, nComponents,
                    tillN);
            System.err.println("Generating for nComponents:" + nComponents + ", tillN:" + tillN + "  done!!");
        }

    }
    
    public void evalTGChoicesFromCsv(JavaSparkContext sc) {
        JavaRDD<String> fileText = sc.textFile(interactionFileUri, partitions).cache();

        // Filtering invalid lines..
        //TODO: to revisit this step.. this may not be optimal
        JavaRDD<String> filteredRdd = fileText.filter(x -> x.split(",").length == 2);
        JavaPairRDD<Integer, Integer> itemUserRdd = filteredRdd.mapToPair(x -> {
            String[] tokens = x.split(",");
            String[] userStr = tokens[0].split("-");
            return new Tuple2<>(Integer.parseInt(tokens[1]), Integer.parseInt(userStr[1]));
        });
        JavaPairRDD<Integer, Tuple2<List<Integer>, List<Integer>>> trainAndTest = DataSplitter
                .createTrainTestSplit(itemUserRdd.mapToPair(Tuple2::swap), MIN_INTERACTION_COUNT)
                .persist(StorageLevel.MEMORY_AND_DISK());

        TGChoiceGenerator tgGenerator = new TGChoiceGenerator();
        JavaPairRDD<Integer, List<ScoredItem<Integer>>> tgScoresRdd;
        if (tgDir != null)
            tgScoresRdd = tgGenerator.loadTGFromFile(tgDir, sc);
        else
            // tgScoresRdd = tgGenerator.generateTGIntUserId(trainAndTest, outputDir);
            tgScoresRdd = tgGenerator.generateTGScoredItems(trainAndTest, outputDir);
        System.err.println("Generating and evaluating choices for till n:" + tillN);
        JavaPairRDD<String, List<ScoredItem<Integer>>> userChoices = tgGenerator
                .generateChoicesWithoutCollect(tgScoresRdd, trainAndTest, tillN)
                .persist(StorageLevel.MEMORY_AND_DISK());

        JavaPairRDD<String, Tuple2<List<Integer>, List<Integer>>> trainTestModified = trainAndTest
                .mapToPair(x -> new Tuple2<>(String.valueOf(x._1), x._2))
                .persist(StorageLevel.MEMORY_AND_DISK());

        persistTestAndTrain(trainTestModified);

        evaluateTillN(trainTestModified, userChoices, getChoiceItemIds(userChoices), sc, 0, tillN);
        System.err.println(
                "Generating and evaluating choices for till n: " + tillN + " completed successfully..!!");
    }

    public void evalTGChoices(JavaSparkContext sc) {
        JavaRDD<String> fileText = sc.textFile(interactionFileUri, partitions).cache();

        // Filtering invalid lines..
        //TODO: to revisit this step.. this may not be optimal
        JavaRDD<String> filteredRdd = fileText.filter(x -> x.split("::").length == 4);
        JavaPairRDD<Integer, Integer> itemUserRdd = filteredRdd.mapToPair(x -> {
            String[] tokens = x.split("::");
            return new Tuple2<>(Integer.parseInt(tokens[1]), Integer.parseInt(tokens[0]));
        });
        JavaPairRDD<Integer, Tuple2<List<Integer>, List<Integer>>> trainAndTest = DataSplitter
                .createTrainTestSplit(itemUserRdd.mapToPair(Tuple2::swap), MIN_INTERACTION_COUNT)
                .persist(StorageLevel.MEMORY_AND_DISK());

        TGChoiceGenerator tgGenerator = new TGChoiceGenerator();
        JavaPairRDD<Integer, List<ScoredItem<Integer>>> tgScoresRdd;
        if (tgDir != null)
            tgScoresRdd = tgGenerator.loadTGFromFile(tgDir, sc);
        else
            // tgScoresRdd = tgGenerator.generateTGIntUserId(trainAndTest, outputDir);
            tgScoresRdd = tgGenerator.generateTGScoredItems(trainAndTest, outputDir);
        System.err.println("Generating and evaluating choices for till n:" + tillN);
        JavaPairRDD<String, List<ScoredItem<Integer>>> userChoices = tgGenerator
                .generateChoicesWithoutCollect(tgScoresRdd, trainAndTest, tillN)
                .persist(StorageLevel.MEMORY_AND_DISK());

        JavaPairRDD<String, Tuple2<List<Integer>, List<Integer>>> trainTestModified = trainAndTest
                .mapToPair(x -> new Tuple2<>(String.valueOf(x._1), x._2))
                .persist(StorageLevel.MEMORY_AND_DISK());

        persistTestAndTrain(trainTestModified);

        evaluateTillN(trainTestModified, userChoices, getChoiceItemIds(userChoices), sc, 0, tillN);
        System.err.println(
                "Generating and evaluating choices for till n: " + tillN + " completed successfully..!!");
    }
}
