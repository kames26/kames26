/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.cp.solr.ext;

import org.apache.lucene.analysis.payloads.PayloadHelper;
import org.apache.lucene.index.FieldInvertState;
import org.apache.lucene.search.similarities.DefaultSimilarity;
import org.apache.lucene.search.similarities.Similarity;
import org.apache.lucene.util.BytesRef;
import org.apache.lucene.util.SmallFloat;
import org.apache.solr.common.params.SolrParams;
import org.apache.solr.schema.SimilarityFactory;

public class PayloadSimilarityFactory extends SimilarityFactory {
    @Override
    public void init(SolrParams params) {
      super.init(params);
    }

    @Override
    public Similarity getSimilarity() {
      return new PayloadSimilarity();
    }
  }
/**
 * https://lucene.apache.org/core/4_0_0/core/org/apache/lucene/search/similarities/TFIDFSimilarity.html
 * @author thien
 *
 */
  class PayloadSimilarity extends DefaultSimilarity {

    //Here's where we actually decode the payload and return it.
    @Override
    public float scorePayload(int doc, int start, int end, BytesRef payload) {
      if (payload == null) return 1.0F;
      return PayloadHelper.decodeFloat(payload.bytes, payload.offset);
    }
    @Override
    public float coord(int overlap, int maxOverlap) {
      return 1.0f;
    }

    /** Implemented as <code>1/sqrt(sumOfSquaredWeights)</code>. */
    @Override
    public float queryNorm(float sumOfSquaredWeights) {
      return 1.0f;
    }
    
    /**
     * Encodes a normalization factor for storage in an index.
     * <p>
     * The encoding uses a three-bit mantissa, a five-bit exponent, and the
     * zero-exponent point at 15, thus representing values from around 7x10^9 to
     * 2x10^-9 with about one significant decimal digit of accuracy. Zero is also
     * represented. Negative numbers are rounded up to zero. Values too large to
     * represent are rounded down to the largest representable value. Positive
     * values too small to represent are rounded up to the smallest positive
     * representable value.
     * 
     * @see org.apache.lucene.document.Field#setBoost(float)
     * @see org.apache.lucene.util.SmallFloat
     */
  

    /** Implemented as
     *  <code>state.getBoost()*lengthNorm(numTerms)</code>, where
     *  <code>numTerms</code> is {@link FieldInvertState#getLength()} if {@link
     *  #setDiscountOverlaps} is false, else it's {@link
     *  FieldInvertState#getLength()} - {@link
     *  FieldInvertState#getNumOverlap()}.
     *
     *  @lucene.experimental */
    @Override
    public float lengthNorm(FieldInvertState state) {
      return 1.0f;
    }

    /** Implemented as <code>sqrt(freq)</code>. */
    @Override
    public float tf(float freq) {
      return 1.0f;
    }
      
    /** Implemented as <code>1 / (distance + 1)</code>. */
    @Override
    public float sloppyFreq(int distance) {
      return 1.0f;
    }
    
    /** The default implementation returns <code>1</code> */

    /** Implemented as <code>log(numDocs/(docFreq+1)) + 1</code>. */
    @Override
    public float idf(long docFreq, long numDocs) {
      return 1.0f;
    }
    
  }