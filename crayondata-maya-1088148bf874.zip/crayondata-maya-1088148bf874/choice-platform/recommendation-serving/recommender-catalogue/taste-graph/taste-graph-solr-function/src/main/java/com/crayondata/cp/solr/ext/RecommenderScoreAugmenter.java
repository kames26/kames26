/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.cp.solr.ext;

import java.util.Map;
import java.util.Map.Entry;

import org.apache.solr.common.SolrDocument;
import org.apache.solr.response.transform.DocTransformer;

import com.crayondata.recommender.Recommender;
import com.google.common.collect.Table;

public class RecommenderScoreAugmenter extends DocTransformer {

    private static final String RECOMMENDER_SCORES = "RECOMMENDER_SCORES";

    private final Map<Object, Object> requestContext;

    public RecommenderScoreAugmenter(Map<Object, Object> requestContext) {
        this.requestContext = requestContext;
    }

    @Override
    public void transform(SolrDocument doc, int docid) {
        if (!requestContext.containsKey(RECOMMENDER_SCORES)) {
            return;
        }

        final Table<Recommender, Integer, RecommenderResult> recommenderResultsByDocId = (Table<Recommender, Integer, RecommenderResult>) requestContext
                .get(RECOMMENDER_SCORES);
        final Map<Recommender, RecommenderResult> documentScores = recommenderResultsByDocId.column(docid);
        for (Entry<Recommender, RecommenderResult> recommenderResult : documentScores.entrySet()) {
            final Recommender currentRecommenderName = recommenderResult.getKey();
            final RecommenderResult currentRecommenderValue = recommenderResult.getValue();

            doc.setField(currentRecommenderName.getRawScoreAlias(),
                    Double.valueOf(currentRecommenderValue.getRecommenderScore()).floatValue());
            doc.setField(currentRecommenderName.getScoreAlias(),
                    Double.valueOf(currentRecommenderValue.getScaledScore()).floatValue());
        }
    }

    @Override
    public String getName() {
        return "Recommender Score Augmenter";
    }
}
