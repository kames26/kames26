/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.cp.solr.ext;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.stream.Stream;

import org.apache.commons.math3.stat.descriptive.SummaryStatistics;
import org.apache.solr.common.SolrException;
import org.apache.solr.common.params.CommonParams;
import org.apache.solr.common.params.GroupParams;
import org.apache.solr.common.params.MultiMapSolrParams;
import org.apache.solr.common.params.SolrParams;
import org.apache.solr.common.util.NamedList;
import org.apache.solr.handler.component.QueryComponent;
import org.apache.solr.handler.component.ResponseBuilder;
import org.apache.solr.request.SolrQueryRequest;
import org.apache.solr.response.ResultContext;
import org.apache.solr.search.DocIterator;
import org.apache.solr.search.DocList;
import org.apache.solr.search.DocSlice;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.crayondata.cp.solr.ext.RecommenderStats.RecommenderStatsEntry;
import com.crayondata.recommender.Recommender;
import com.google.common.base.Stopwatch;
import com.google.common.base.Strings;
import com.google.common.collect.HashBasedTable;
import com.google.common.collect.Maps;
import com.google.common.collect.MinMaxPriorityQueue;
import com.google.common.collect.Ordering;
import com.google.common.collect.Table;

/**
 * 
 * {@see <a href=
 * "http://blog.nbostech.com/2015/09/solr-search-conponent-multiple-queries/">
 * MultipleQueryComponent</a> } }
 *
 */
public class MultipleQueryComponent extends QueryComponent {

    private static final String[] RAWSCORE_PARAMS = new String[] { "[rawscores]", "*_rawscore", "*_score" };

    protected static Logger log = LoggerFactory.getLogger(MultipleQueryComponent.class);

    public static final String NUMBER_OF_QUERIES_PARAM = "qn";
    public static final String MULTI_QUERY_PREFIX = "mQry";
    public static final String MULTI_QUERY_BOOST_PREFIX = "mQryBoost";
    public static final String MULTI_QUERY_SCALE_MIN = "mQryScaleMin";
    public static final String MULTI_QUERY_SCALE_MAX = "mQryScaleMax";

    public static final String MULTI_QUERY_RECOMMENDER_NAME = "mQryRecommenderName";

    public static final String COMPONENT_NAME = "multiQuery";

    protected RecommenderStats recommenderStats;

    @Override
    public void init(NamedList args) {
        super.init(args);
        this.recommenderStats = new RecommenderStats();
    }

    @Override
    public void prepare(ResponseBuilder rb) throws IOException {
        SolrQueryRequest req = rb.req;
        SolrParams params = req.getParams();

        if (!params.getBool(COMPONENT_NAME, false)) {
            return;
        }

        // does not support grouping
        boolean grouping = params.getBool(GroupParams.GROUP, false);
        if (grouping) {
            throw new SolrException(SolrException.ErrorCode.BAD_REQUEST,
                    "Grouping is not supported by MultipleQueryComponent ");
        }

        Integer numberOfQueries = params.getInt(NUMBER_OF_QUERIES_PARAM);
        if (numberOfQueries == null || numberOfQueries <= 0) {
            throw new SolrException(SolrException.ErrorCode.BAD_REQUEST,
                    "Number of queries param is not set or invalid. Params value: " + numberOfQueries);
        }
        Integer rows = params.getInt(CommonParams.ROWS);
        if (rows == null || rows <= 0) {
            throw new SolrException(SolrException.ErrorCode.BAD_REQUEST,
                    "Number of rows param passed is invalid. rows value: " + rows);

        }
        List<RecommenderQuery> queries = buildRawQueries(params);
        if (queries == null || queries.size() == 0) {
            throw new SolrException(SolrException.ErrorCode.BAD_REQUEST,
                    "Require at least one query." + rows);

        }
        log.debug("Number of Queries: {}", queries.size());
    }

    @Override
    public void process(ResponseBuilder rb) throws IOException {
        final Stopwatch overallProcessingTime = new Stopwatch().start();
        log.debug("Process started: ");
        SolrQueryRequest req = rb.req;
        // original params
        SolrParams originalParams = req.getParams();
        if (!originalParams.getBool(COMPONENT_NAME, false)) {
            return;
        }

        final List<RecommenderQuery> rawQueries = buildRawQueries(originalParams);
        final Map<String, String[]> otherQueryParams = buildOtherParams(originalParams);

        final Table<Recommender, Integer, RecommenderResult> recommenderResultsByDocId = HashBasedTable
                .create();

        for (RecommenderQuery currentQuery : rawQueries) {

            final Map<String, String[]> rawParams = Maps.newHashMap();
            rawParams.putAll(otherQueryParams);
            if (currentQuery.getQueryBoost() == 0.0f) {
                log.debug("Not processing query #{} as boost is zero.", currentQuery);
                continue;
            }

            rawParams.put(CommonParams.Q, new String[] { currentQuery.getQueryString() });

            if (rawQueries.size() > 1) {
                // TODO review and parameterise. We will get better results if
                // we bring back more candidates per recommender. Performance
                // tradeoff.
                final int searchDepthFactor = 30;
                final Integer maxRows = originalParams.getInt(CommonParams.ROWS);
                rawParams.put(CommonParams.ROWS,
                        new String[] { Integer.toString(maxRows * searchDepthFactor) });
            }

            final MultiMapSolrParams solrParams = new MultiMapSolrParams(rawParams);
            req.setParams(solrParams);
            final RecommenderStatsEntry currentRecommenderStats = recommenderStats
                    .get(currentQuery.getRecommender());

            final Stopwatch stopwatch = new Stopwatch().start();
            final boolean success = processQuery(rb);
            if (!success) {
                currentRecommenderStats.logFailure();
                continue;
            }

            final long elapsedTimeMs = stopwatch.elapsed(TimeUnit.MILLISECONDS);
            log.debug("Processing query #{}, Query: {} took {}ms.", currentQuery.getRecommender(),
                    currentQuery.getQueryString(), elapsedTimeMs);

            if (rb.getResults() != null && rb.getResults().docList.size() > 0) {
                // if last query returned any results
                final DocList resultDocs = rb.getResults().docList;
                if (resultDocs.hasScores()) {
                    final boolean applyScoreScaling = rawQueries.size() > 1;
                    processQueryResults(resultDocs, currentQuery, applyScoreScaling,
                            recommenderResultsByDocId, currentRecommenderStats);
                    currentRecommenderStats.logStats(elapsedTimeMs, resultDocs.size());
                } else {
                    log.warn("Query returned {} results but no scores", resultDocs.size());
                }
            } else {
                log.debug("Query({}) returned no results", currentQuery.getRecommender());
                currentRecommenderStats.logStats(elapsedTimeMs, 0);
            }
        }

        final Integer maxRows = originalParams.getInt(CommonParams.ROWS);

        final String minScoreParam = rb.req.getParams().get("minScore", DEFAULT_MIN_ITEM_SCORE);
        final float minScore = Float.valueOf(minScoreParam).floatValue();

        final Map<Object, Object> requestContext = req.getContext();
        requestContext.put(RECOMMENDER_SCORES, recommenderResultsByDocId);

        final NamedList<ResultContext> response = rb.rsp.getValues();
        // remove all old responses
        while (response.get("response") != null) {
            response.remove("response");
        }
        final ResultContext aggregateResults = buildResponse(recommenderResultsByDocId, maxRows, minScore);
        response.add("response", aggregateResults);

        // rb.rsp.add("recommender-stats", recommenderStats.toString());
        final long elapsedTimeMs = overallProcessingTime.elapsed(TimeUnit.MILLISECONDS);
        recommenderStats.logOverallProcessingTime(elapsedTimeMs);
        log.debug("Processing query: {} took {}ms.", rb.getQueryString(), elapsedTimeMs);
    }

    private static final String RECOMMENDER_SCORES = "RECOMMENDER_SCORES";

    private static void processQueryResults(final DocList resultDocs, RecommenderQuery currentQuery,
            boolean applyScoreScaling,
            Table<Recommender, Integer, RecommenderResult> recommenderResultsByDocId,
            RecommenderStatsEntry currentRecommenderStats) {

        final SummaryStatistics recommenderQueryRawScoreStats = currentRecommenderStats.recommenderRawScoreStats
                .createContributingStatistics();
        final SummaryStatistics recommenderQueryScaledScoreStats = currentRecommenderStats.recommenderScaledScoreStats
                .createContributingStatistics();

        
        // TODO, rewrite using functions, e.g: null function versus scale
        // function. 
        final double scaleFactor;
        final double minRawScore;
        if (applyScoreScaling) {
            // Optimize, result is sorted by score, so min and max might
            // be available in O(1) time. Do we need the secondary sort on rating, esp given that it is 0 so often?
            final DocIterator itr = resultDocs.iterator();
            while (itr.hasNext()) {
                int nextDocId = itr.nextDoc();
                recommenderQueryRawScoreStats.addValue(itr.score());
            }
            log.debug("Query response statistics: {}", recommenderQueryRawScoreStats.toString());
            minRawScore = recommenderQueryRawScoreStats.getMin();
            final double maxMinusMin = recommenderQueryRawScoreStats.getMax() - minRawScore;
            scaleFactor = calcScaleFactor(maxMinusMin, currentQuery.getScaleRangeMin(),
                    currentQuery.getScaleRangeMax());
        } else {
            scaleFactor = 1.0;
            minRawScore = currentQuery.getScaleRangeMin();
        }

        final DocIterator itr2 = resultDocs.iterator();
        while (itr2.hasNext()) {
            final int nextDocId = itr2.nextDoc();
            final double recommenderScore = itr2.score();

            final double scaledScore;
            if (applyScoreScaling) {
                scaledScore = scaleScoreWithinRange(minRawScore, currentQuery.getScaleRangeMin(), scaleFactor,
                        recommenderScore);
            } else {
                scaledScore = recommenderScore;
            }
            recommenderQueryScaledScoreStats.addValue(scaledScore);

            final double boostedScaledScore = scaledScore * currentQuery.getQueryBoost();
            log.debug("Normalised score for doc {} from {} to: {}. After boost({}) applied: {}", nextDocId,
                    recommenderScore, scaledScore, currentQuery.getQueryBoost(), boostedScaledScore);
            final RecommenderResult recommenderResult = new RecommenderResult(currentQuery.getRecommender(),
                    nextDocId, recommenderScore, boostedScaledScore);
            recommenderResultsByDocId.put(currentQuery.getRecommender(), recommenderResult.getDocId(),
                    recommenderResult);
        }
    }

    private static double scaleScoreWithinRange(final double minScore, final float minRange,
            final double scaleFactor, final double recommenderScore) {
        return (recommenderScore - minScore) * scaleFactor + minRange;
    }

    private static double calcScaleFactor(final double maxMinusMin, final float minRange,
            final float maxRange) {
        final double scaledScore = (maxMinusMin == 0) ? 1 : (maxRange - minRange) / (maxMinusMin);
        return scaledScore;
    }

    private static Map<String, String[]> buildOtherParams(SolrParams originalParams) {
        final Map<String, String[]> otherParams = Maps.newHashMap();

        final Iterator<String> itr = originalParams.getParameterNamesIterator();
        while (itr.hasNext()) {
            String paramName = itr.next();
            if (!paramName.startsWith(MULTI_QUERY_PREFIX)) {
                otherParams.put(paramName, originalParams.getParams(paramName));
            }
        }
        if (originalParams.getBool("recscores", false)) {
            final String[] fieldListIncludingRawScores = Stream
                    .concat(Arrays.stream(originalParams.getParams(CommonParams.FL)),
                            Arrays.stream(RAWSCORE_PARAMS))
                    .toArray(String[]::new);

            otherParams.put(CommonParams.FL, fieldListIncludingRawScores);
        }
        return otherParams;
    }

    private static final float DEFAULT_MIN_SCALE_SCORE = 0.1f;
    private static String DEFAULT_MIN_ITEM_SCORE = Float.valueOf(DEFAULT_MIN_SCALE_SCORE + 0.001F).toString();

    public static ResultContext buildResponse(
            Table<Recommender, Integer, RecommenderResult> recommenderResultsByDocId, Integer maxRows,
            double minScore) {
        log.debug(
                "Consolidating %d recommender results for %d items from %d recommenders to generate final response.",
                recommenderResultsByDocId.size(), recommenderResultsByDocId.columnKeySet().size(),
                recommenderResultsByDocId.rowKeySet().size());

        final Collection<ResultItem> topScoringItems = findTopScoringItems(recommenderResultsByDocId, maxRows,
                minScore);

        final ResultContext aggregateResults = buildResponse(maxRows, topScoringItems);

        return aggregateResults;
    }

    private static ResultContext buildResponse(Integer maxRows, Collection<ResultItem> topScoringItems) {
        final int[] docIds = new int[maxRows];
        final float[] scores = new float[maxRows];
        int i = 0;
        for (ResultItem recommenderResult : topScoringItems) {
            docIds[i] = recommenderResult.docId;
            scores[i] = recommenderResult.docScore;
            i++;
        }

        final float maxScore = scores.length == 0 ? 0.0f : scores[0];
        // all the final result to response which will be sent to client
        final ResultContext aggregateResults = new ResultContext();
        aggregateResults.docs = new DocSlice(0, topScoringItems.size(), docIds, scores,
                topScoringItems.size(), maxScore);
        return aggregateResults;
    }

    private static Collection<ResultItem> findTopScoringItems(
            Table<Recommender, Integer, RecommenderResult> recommenderResultsByDocId, Integer maxRows,
            double minScore) {
        final MinMaxPriorityQueue<ResultItem> topScoringItems = MinMaxPriorityQueue.orderedBy(sortOrder)
                .maximumSize(maxRows).create();

        for (Integer docId : recommenderResultsByDocId.columnKeySet()) {
            double scaledScore = 0;

            for (RecommenderResult documentResult : recommenderResultsByDocId.column(docId).values()) {
                scaledScore += documentResult.getScaledScore();
            }
            if (scaledScore < minScore) {
                continue;
            }
            topScoringItems.add(new ResultItem(docId, scaledScore));
        }
        return sortOrder.sortedCopy(topScoringItems);
    }

    private static final Ordering<ResultItem> sortOrder = new Ordering<ResultItem>() {
        @Override
        public int compare(ResultItem left, ResultItem right) {
            return Double.compare(right.docScore, left.docScore);
        }
    };

    protected boolean processQuery(ResponseBuilder rb) {
        rb.setQuery(null);
        rb.setQueryString(null);
        try {
            super.prepare(rb); // prepare query parsers
            super.process(rb); // delegate query processing to QueryComponent
        } catch (Exception e) {
            log.warn("Recommender query failed", e);
            return false;
        }
        return true;
    }

    protected static List<RecommenderQuery> buildRawQueries(SolrParams params) throws SolrException {
        // find queries
        List<RecommenderQuery> queries = new ArrayList<>();
        int numberOfQueries = params.getInt(NUMBER_OF_QUERIES_PARAM);
        for (int n = 1; n <= numberOfQueries; n++) {
            String nthQuery = params.get(MULTI_QUERY_PREFIX + n);
            if (Strings.isNullOrEmpty(nthQuery)) {
                throw new SolrException(SolrException.ErrorCode.BAD_REQUEST,
                        "Query param: " + MULTI_QUERY_PREFIX + n + " is missing in Multi-Search Query");
            }
            nthQuery = java.net.URLDecoder.decode(nthQuery);

            final String nthRecommenderName = params.get(MULTI_QUERY_RECOMMENDER_NAME + n);
            if (Strings.isNullOrEmpty(nthRecommenderName)) {
                throw new SolrException(SolrException.ErrorCode.BAD_REQUEST, "Query param: "
                        + MULTI_QUERY_RECOMMENDER_NAME + n + " is missing in Multi-Search Query");
            }
            final Recommender recommender = Recommender.valueOf(nthRecommenderName);

            final Float nthQueryBoost = params.getFloat(MULTI_QUERY_BOOST_PREFIX + n, 1.0f);
            final Float nthQueryScaleMin = params.getFloat(MULTI_QUERY_SCALE_MIN + n,
                    DEFAULT_MIN_SCALE_SCORE);
            final Float nthQueryScaleMax = params.getFloat(MULTI_QUERY_SCALE_MAX + n, 1.0f);

            queries.add(new RecommenderQuery(recommender, nthQuery, nthQueryBoost.floatValue(),
                    nthQueryScaleMin.floatValue(), nthQueryScaleMax.floatValue()));
        }
        return queries;
    }

    private static class ResultItem {
        final int docId;
        final float docScore;

        public ResultItem(int docId, double docScore) {
            this.docId = docId;
            this.docScore = Double.valueOf(docScore).floatValue();
        }

        @Override
        public String toString() {
            return "ResultItem [docId=" + docId + ", docScore=" + docScore + "]";
        }
    }
}
