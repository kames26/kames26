/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.cp.solr.ext;

import com.crayondata.recommender.Recommender;

public class RecommenderResult {

    private final int docId;
    private final double recommenderScore;
    private final double scaledScore;
    private final Recommender recommenderType;

    public RecommenderResult(Recommender recommenderType, int docId, double recommenderScore,
            double scaledScore) {
        this.recommenderType = recommenderType;
        this.docId = docId;
        this.recommenderScore = recommenderScore;
        this.scaledScore = scaledScore;
    }

    public double getRecommenderScore() {
        return recommenderScore;
    }

    public double getScaledScore() {
        return scaledScore;
    }

    public int getDocId() {
        return docId;
    }

    public Recommender getRecommenderType() {
        return recommenderType;
    }

    @Override
    public String toString() {
        return "RecommenderResult [docId=" + docId + ", recommenderScore=" + recommenderScore
                + ", scaledScore=" + scaledScore + ", recommenderType=" + recommenderType + "]";
    }
}