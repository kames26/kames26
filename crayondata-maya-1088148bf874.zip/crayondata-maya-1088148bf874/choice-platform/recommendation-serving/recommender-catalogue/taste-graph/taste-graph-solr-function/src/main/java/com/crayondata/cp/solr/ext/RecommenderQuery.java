/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.cp.solr.ext;

import com.crayondata.recommender.Recommender;

class RecommenderQuery {
    private final String queryString;
    private final float queryBoost;
    private float scaleRangeMin;
    private float scaleRangeMax;
    private Recommender recommender;

    public RecommenderQuery(Recommender recommender, String queryString, float queryBoost,
            float scaleRangeMin, float scaleRangeMax) {
        this.recommender = recommender;
        this.queryString = queryString;
        this.queryBoost = queryBoost;
        this.scaleRangeMin = scaleRangeMin;
        this.scaleRangeMax = scaleRangeMax;
    }

    public String getQueryString() {
        return queryString;
    }

    public float getQueryBoost() {
        return queryBoost;
    }

    public float getScaleRangeMin() {
        return scaleRangeMin;
    }

    public float getScaleRangeMax() {
        return scaleRangeMax;
    }

    public Recommender getRecommender() {
        return recommender;
    }

    @Override
    public String toString() {
        return "RecommenderQuery [queryString=" + queryString + ", queryBoost=" + queryBoost
                + ", scaleRangeMin=" + scaleRangeMin + ", scaleRangeMax=" + scaleRangeMax
                + ", recommender=" + recommender + "]";
    }
}