/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.cp.solr.ext;

import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.math3.stat.descriptive.AggregateSummaryStatistics;
import org.apache.commons.math3.stat.descriptive.SummaryStatistics;
import org.apache.commons.math3.stat.descriptive.SynchronizedSummaryStatistics;
import org.apache.solr.common.util.NamedList;
import org.apache.solr.common.util.SimpleOrderedMap;

import com.crayondata.recommender.Recommender;
import com.google.common.base.Objects;
import com.google.common.base.Objects.ToStringHelper;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.ImmutableMap.Builder;

class RecommenderStats {

    private final Map<Recommender, RecommenderStats.RecommenderStatsEntry> recommenderStats;
    private final SummaryStatistics overallAverageProcessingTime;

    public RecommenderStats() {
        final Builder<Recommender, RecommenderStats.RecommenderStatsEntry> recommenderStatsBuilder = ImmutableMap.<Recommender, RecommenderStats.RecommenderStatsEntry> builder();
        for (Recommender recommender : Recommender.values()) {
            recommenderStatsBuilder.put(recommender, new RecommenderStatsEntry());
        }
        this.recommenderStats = recommenderStatsBuilder.build();
        this.overallAverageProcessingTime = new SynchronizedSummaryStatistics();
    }

    @Override
    public String toString() {
        final ToStringHelper toStringHelper = Objects.toStringHelper(this);
        for (Entry<Recommender, RecommenderStats.RecommenderStatsEntry> entry : recommenderStats.entrySet()) {
            toStringHelper.add(entry.getKey().toString(), entry.getValue().toString() + "\n");
        }

        return recommenderStats.toString();
    }

    static class RecommenderStatsEntry {
        private final SummaryStatistics averageProcessingTime;
        private final SummaryStatistics averageNumberItemsReturned;
        final AggregateSummaryStatistics recommenderRawScoreStats;
        final AggregateSummaryStatistics recommenderScaledScoreStats;

        private int failureCounter = 0;

        public RecommenderStatsEntry() {
            this.averageProcessingTime = new SynchronizedSummaryStatistics();
            this.averageNumberItemsReturned = new SynchronizedSummaryStatistics();
            this.recommenderRawScoreStats = new AggregateSummaryStatistics();
            this.recommenderScaledScoreStats = new AggregateSummaryStatistics();
        }

        void logStats(double processingTimeMillis, int numberItemsReturned) {
            averageProcessingTime.addValue(processingTimeMillis);
            averageNumberItemsReturned.addValue(numberItemsReturned);
        }

        void logFailure() {
            failureCounter++;
        }

        @Override
        public String toString() {
            if (averageProcessingTime.getN() > 0) {
                return String.format(
                        "#Calls: %d ( with %d failures), Processing time => Average: %.2fms, Min: %.2fms, Max: %.2fms. Mean #Items Returned: %.2f. Mean raw score: %.2f. Mean scaled score: %.2f.",
                        averageProcessingTime.getN() + failureCounter, failureCounter,
                        averageProcessingTime.getMean(), averageProcessingTime.getMin(),
                        averageProcessingTime.getMax(), averageNumberItemsReturned.getMean(),
                        recommenderRawScoreStats.getMean(), recommenderScaledScoreStats.getMean());
            }
            return "#Calls: " + failureCounter;
        }
    }

    public RecommenderStatsEntry get(Recommender recommender) {
        final RecommenderStatsEntry recommenderStatsEntry = recommenderStats.get(recommender);
        return recommenderStatsEntry;
    }

    public NamedList<String> asNamedList() {
        final NamedList<String> stats = new SimpleOrderedMap<>();
        stats.add("Mean request processing time",
                String.format("%.2f ms", overallAverageProcessingTime.getMean()));
        stats.add("Total Number Requests", String.valueOf(overallAverageProcessingTime.getN()));

        for (Entry<Recommender, RecommenderStats.RecommenderStatsEntry> entry : recommenderStats.entrySet()) {
            stats.add(entry.getKey().toString(), entry.getValue().toString());
        }
        return stats;
    }

    public void logOverallProcessingTime(long elapsedTimeMs) {
        overallAverageProcessingTime.addValue(elapsedTimeMs);
    }
}
