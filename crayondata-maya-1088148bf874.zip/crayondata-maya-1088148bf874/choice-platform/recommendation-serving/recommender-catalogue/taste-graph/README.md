All Batch processing of Taste graph model generation goes here.

