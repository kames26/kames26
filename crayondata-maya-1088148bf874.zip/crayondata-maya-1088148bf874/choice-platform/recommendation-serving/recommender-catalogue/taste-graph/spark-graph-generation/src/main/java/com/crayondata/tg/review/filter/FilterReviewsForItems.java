/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.tg.review.filter;

import java.nio.file.Paths;
import java.util.List;

import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.DataFrame;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.RowFactory;
import org.apache.spark.sql.SQLContext;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;

import scala.Tuple2;

import com.clearspring.analytics.util.Lists;

import static com.crayondata.tg.data.adaptor.ItemDetailsToTGMapper.ITEM_ID_FIELD_NAME;

/**
 * 
 * @author vivek
 *
 */
public class FilterReviewsForItems {
	
	private final SQLContext sqlContext;
	private final String itemDetailsPath;
	private final String reviewDataPath;
	private final String outputPath;
	
	public FilterReviewsForItems(SQLContext sqlContext,
			String itemDetailsPath, String reviewDataPath,String outputPath) {
		this.sqlContext = sqlContext;
		this.itemDetailsPath = itemDetailsPath;
		this.reviewDataPath = reviewDataPath;
		this.outputPath = outputPath;
	}

	public static void main(String[] args) {
		if (args.length < 3) {
            System.err.println("Usage: " + FilterReviewsForItems.class.getCanonicalName()
                    + " <details> <review_data> <output>");
            System.exit(1);
        }
		
		SparkConf conf = new SparkConf().setAppName("TG - Item Details Mapper");
        JavaSparkContext sparkContext = new JavaSparkContext(conf);
        SQLContext sqlContext = new SQLContext(sparkContext);
        
        FilterReviewsForItems filter = new FilterReviewsForItems(sqlContext, args[0], args[1], args[2]);
        filter.filterReviewsForItems();
	}
	
	public void filterReviewsForItems(){
		JavaPairRDD<Integer, Integer> itemDetails = loadItemDetails().mapToPair(x -> new Tuple2<>(x._1,x._1));
		JavaPairRDD<Integer, String> reviewData = readReviewData();
		
		System.out.println("Number of items from details:" + itemDetails.count());
		System.out.println("Number of unique items from reviews:" + reviewData.keys().distinct().count());
		System.out.println(".. Review Data count:"+reviewData.count());
		
		reviewData = reviewData.join(itemDetails).mapToPair(x -> new Tuple2<>(x._1, x._2._1));
		
		System.out.println(".. Review Data count after filtering:"+reviewData.count());
		System.out.println("Number of unique items from reviews after filtering:" + reviewData.keys().distinct().count());
		
		this.saveReviewData(reviewData);
		
		this.valdiateFilter(reviewData, itemDetails);
	}
	
	private void valdiateFilter(JavaPairRDD<Integer, String> reviewData, 
			JavaPairRDD<Integer, Integer> itemDetails){
		List<Integer> ids = Lists.newArrayList();
		ids.addAll(reviewData.keys().distinct().collect());
		ids.removeAll(itemDetails.keys().collect());
		System.out.println("Mistmatch ids:" + ids);
		if(!ids.isEmpty())
			System.out.println("There may be potential errors please check the above details printed..");
		else
			System.out.println("Filter completed successfully..!!");
	}
	
	public JavaPairRDD<Integer, Row> loadItemDetails() {
        DataFrame df = sqlContext.read().format("com.databricks.spark.avro").load(itemDetailsPath);
        return df.javaRDD().mapToPair(
                row -> new Tuple2<>(Integer.valueOf(row.getAs(ITEM_ID_FIELD_NAME).toString()), row));
    }
	
	public JavaPairRDD<Integer, String> readReviewData() {
		DataFrame df = sqlContext.read().format("com.databricks.spark.avro").load(reviewDataPath);
		return df.javaRDD().mapToPair(x -> new Tuple2<>(x.getInt(0), x.getString(1).intern()));
	}
	
	protected void saveReviewData(JavaPairRDD<Integer, String> reviewData) {
		JavaRDD<Row> reviewRows = reviewData.map(x -> RowFactory.create(new Object[] { x._1, x._2 }));
        DataFrame affDF = sqlContext.createDataFrame(reviewRows, getReviewDataSchema());
        affDF.write().format("com.databricks.spark.avro").save(this.outputPath);
    }
	
	private StructType getReviewDataSchema() {
        List<StructField> fields = Lists.newArrayList();
        fields.add(DataTypes.createStructField("itemId", DataTypes.IntegerType, false));
        fields.add(DataTypes.createStructField("userId", DataTypes.StringType, false));
        return DataTypes.createStructType(fields);
    }

}
