/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata;

import com.clearspring.analytics.util.Lists;
import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.DataFrame;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.RowFactory;
import org.apache.spark.sql.SQLContext;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import scala.Tuple2;

import java.io.IOException;
import java.nio.file.Paths;
import java.util.List;

/**
 * @author sundar
 */
public class TasteGraphAvro extends TasteGraph {
    private static final Logger log = LoggerFactory.getLogger(TasteGraphAvro.class);

    private SQLContext sqlContext;

    public TasteGraphAvro(JavaSparkContext sparkContext, int partitions, String reviewsPath,
            String outputDir) {
        super(sparkContext, partitions, reviewsPath, outputDir);
        sqlContext = new SQLContext(sparkContext);
    }

    public static void main(String[] args) throws IOException {
        if (args.length < 2) {
            // @formatter:off
            System.err.println("Usage: " + TasteGraphAvro.class.getCanonicalName() + " <review-file> <output-dir> [partitions]");
            // @formatter:on
            System.exit(1);
        }

        String reviewsFile = args[0];
        String outDir = args[1];
        int partitions = args.length >= 3 ? Integer.valueOf(args[2]) : SPARK_PARTITIONS;

        SparkConf conf = new SparkConf().setAppName("Taste Graph Avro");
        log.info("Spark Configuration");
        Tuple2<String, String>[] sparkConf = conf.getAll();
        for (Tuple2<String, String> c : sparkConf) {
            log.info(c._1 + " : " + c._2);
        }
        log.info("Partitions: " + partitions);
        JavaSparkContext sparkContext = new JavaSparkContext(conf);

        TasteGraphAvro tg = new TasteGraphAvro(sparkContext, partitions, reviewsFile, outDir);
        long start = System.currentTimeMillis();
        tg.processTasteGraph();
        long end = System.currentTimeMillis();
        log.info("Took: " + (end - start) + " ms");

        sparkContext.stop();
    }

    protected JavaPairRDD<String, Integer> readReviewData() {
        DataFrame df = sqlContext.read().format("com.databricks.spark.avro").load(reviewsPath);
        return df.javaRDD().mapToPair(x -> new Tuple2<>(x.getString(1).intern(), x.getInt(0)));
    }

    protected void saveAffinityData(JavaPairRDD<Tuple2<Integer, Integer>, Integer> affinity,
            String subDirName) {
        String destination = Paths.get(outputDir, subDirName).toString();
        JavaRDD<Row> affRow = affinity.map(x -> RowFactory.create(new Object[] { x._1._1, x._1._2, x._2 }));
        DataFrame affDF = sqlContext.createDataFrame(affRow, getAffinitySchema());
        affDF.write().format("com.databricks.spark.avro").save(destination);
    }

    private StructType getAffinitySchema() {
        List<StructField> fields = Lists.newArrayList();
        fields.add(DataTypes.createStructField("node1", DataTypes.IntegerType, false));
        fields.add(DataTypes.createStructField("node2", DataTypes.IntegerType, false));
        fields.add(DataTypes.createStructField("strength", DataTypes.IntegerType, false));
        return DataTypes.createStructType(fields);
    }
}
