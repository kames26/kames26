/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.tg.data.adaptor;

import org.apache.spark.sql.Row;
import scala.Tuple2;

import java.io.Serializable;
import java.util.List;

/**
 * @author sundar
 */
public class ItemDetailsObject implements Serializable {
    private Integer itemId;
    private Row detailData;
    private List<Tuple2<Integer, Integer>> nicheData;
    private List<Tuple2<Integer, Integer>> popularData;
    private List<Tuple2<Integer, Integer>> discoveryData;

    public ItemDetailsObject(Integer itemId, Row detailData) {
        this.itemId = itemId;
        this.detailData = detailData;
    }

    public Integer getItemId() {
        return itemId;
    }

    public Row getDetailData() {
        return detailData;
    }

    public List<Tuple2<Integer, Integer>> getNicheData() {
        return nicheData;
    }

    public void setNicheData(List<Tuple2<Integer, Integer>> nicheData) {
        this.nicheData = nicheData;
    }

    public List<Tuple2<Integer, Integer>> getPopularData() {
        return popularData;
    }

    public void setPopularData(List<Tuple2<Integer, Integer>> popularData) {
        this.popularData = popularData;
    }

    public List<Tuple2<Integer, Integer>> getDiscoveryData() {
        return discoveryData;
    }

    public void setDiscoveryData(List<Tuple2<Integer, Integer>> discoveryData) {
        this.discoveryData = discoveryData;
    }

    @Override
    public String toString() {
        return "{" +
                "itemId:" + itemId +
                ", nicheData:" + nicheData +
                ", popularData:" + popularData +
                ", discoveryData:" + discoveryData +
                '}';
    }
}
