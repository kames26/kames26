/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata;

import org.apache.commons.collections.CollectionUtils;
import org.apache.spark.HashPartitioner;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.function.PairFunction;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import scala.Tuple2;

import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Map;

public class DiscoveryAffinity {
    private static final Logger log = LoggerFactory.getLogger(DiscoveryAffinity.class);

    public static JavaPairRDD<Tuple2<Integer, Integer>, Integer> discoveryAffinity(
            JavaPairRDD<Tuple2<Integer, Integer>, Integer> affinity, Map<Integer, Integer> counts,
            JavaPairRDD<Tuple2<Integer, Integer>, Integer> popularAff,
            JavaPairRDD<Tuple2<Integer, Integer>, Integer> nicheAffinity, String outDir, int partitions) {
        // 1. Find base-discovery affinity
        JavaPairRDD<Tuple2<Integer, Integer>, Integer> baseDiscAff = calculateDiscoveryBaseAffinity(affinity,
                counts).persist(StorageLevel.DISK_ONLY())
                .partitionBy(new HashPartitioner(partitions));
        log.info("Discovery Base Affinity completed");
        baseDiscAff.map(aff -> aff._1._1 + "\t" + aff._1._2 + "\t" + aff._2)
                .saveAsTextFile(Paths.get(outDir, "discovery-base").toString());

        // 2. Find top affinity
        JavaPairRDD<Integer, Tuple2<Integer, Integer>> topAff = findTopAffinities(baseDiscAff);
        log.info("Discovery Top Affinity completed");
        topAff.map(aff -> aff._1 + "\t" + aff._2._1 + "\t" + aff._2._2)
                .saveAsTextFile(Paths.get(outDir, "discovery-top").toString());

        // 3. Series affinity
        JavaPairRDD<Tuple2<Integer, Integer>, Float> series = seriesFunction(baseDiscAff, topAff)
                .persist(StorageLevel.DISK_ONLY())
                .partitionBy(new HashPartitioner(partitions));
        log.info("Discovery Series Calculation completed");
        series.map(aff -> aff._1._1 + "\t" + aff._1._2 + "\t" + aff._2)
                .saveAsTextFile(Paths.get(outDir, "discovery-series").toString());

        // 4. Parallel affinity (a.k.a) Second-Hop affinity
        JavaPairRDD<Tuple2<Integer, Integer>, Integer> shAff = parallelFunction(baseDiscAff, series)
                .persist(StorageLevel.DISK_ONLY())
                .partitionBy(new HashPartitioner(partitions));
        log.info("Discovery Parallel Calculation completed");
        shAff.map(aff -> aff._1._1 + "\t" + aff._1._2 + "\t" + aff._2)
                .saveAsTextFile(Paths.get(outDir, "discovery-parallel").toString());

        // 5. Discover affinity
        return discovery(shAff, popularAff, nicheAffinity);
        // return discoveryAff;
    }

    public static JavaPairRDD<Tuple2<Integer, Integer>, Integer> calculateDiscoveryBaseAffinity(
            JavaPairRDD<Tuple2<Integer, Integer>, Integer> affinity, Map<Integer, Integer> counts) {
        JavaPairRDD<Tuple2<Integer, Integer>, Integer> filteredAffinity = affinity.filter(aff -> {
            int n1 = counts.get(aff._1._1);
            int n2 = counts.get(aff._1._2);
            return n2 >= Math.sqrt(n1) && n1 >= Math.sqrt(n2);
        });
        return filteredAffinity.mapToPair(aff -> {
            int n1 = counts.get(aff._1._1);
            int n2 = counts.get(aff._1._2);
            int e = Math.round((aff._2 * 1000) / Math.min(n1, n2));
            return new Tuple2<>(aff._1, e);
        }).filter(aff -> aff._2 > 100);
    }

    public static JavaPairRDD<Integer, Tuple2<Integer, Integer>> findTopAffinities(
            JavaPairRDD<Tuple2<Integer, Integer>, Integer> affinity) {
        final int topN = 100;
        /*JavaPairRDD<Integer, Tuple2<Integer, Integer>> values = affinity
                .mapToPair(aff -> new Tuple2<>(aff._1._1, new Tuple2<>(aff._1._2, aff._2)));
        MLPairRDDFunctions<Integer, Tuple2<Integer, Integer>> mlPairValues = MLPairRDDFunctions
                .fromPairRDD(values.rdd(), values.kClassTag(), values.vClassTag());
        RDD<Tuple2<Integer, Tuple2<Integer, Integer>[]>> topItems = mlPairValues.topByKey(100, (x, y) -> {
            int cmp = y._2 - x._2;
            if (cmp == 0) cmp = y._1 - x._1;
            return cmp;
        });
        // mlPairValues.topByKey(100, new scala.math.Ordering?);
        JavaPairRDD<Integer, Tuple2<Integer, Integer>[]> topPairsArr = topItems.toJavaRDD()
                .mapToPair(x -> new Tuple2<>(x._1, x._2));
        return topPairsArr.flatMapValues(Arrays::asList);*/

        JavaPairRDD<Integer, Tuple2<Integer, Integer>> itemPair = affinity
                .mapToPair(aff -> new Tuple2<>(aff._1._1, new Tuple2<>(aff._1._2, aff._2)));

        JavaPairRDD<Integer, Iterable<Tuple2<Integer, Integer>>> itemGrouped = itemPair.groupByKey();

        JavaPairRDD<Integer, Iterable<Tuple2<Integer, Integer>>> item1To2List = itemGrouped.mapToPair(
                new PairFunction<Tuple2<Integer, Iterable<Tuple2<Integer, Integer>>>, Integer, Iterable<Tuple2<Integer, Integer>>>() {
                    @Override
                    public Tuple2<Integer, Iterable<Tuple2<Integer, Integer>>> call(
                            Tuple2<Integer, Iterable<Tuple2<Integer, Integer>>> input) throws Exception {
                        ArrayList<Tuple2<Integer, Integer>> item2List = new ArrayList<>();
                        CollectionUtils.addAll(item2List, input._2().iterator());
                        Collections.sort(item2List, (v1, v2) -> {
                            int cmp = v2._2.compareTo(v1._2);
                            if (cmp == 0)
                                cmp = v2._1.compareTo(v1._1);
                            return cmp;
                        });
                        if (item2List.size() > topN)
                            item2List.subList(topN, item2List.size()).clear();
                        item2List.trimToSize();
                        return new Tuple2<>(input._1, item2List);
                    }
                });
        return item1To2List.flatMapToPair(grp -> {
            Collection<Tuple2<Integer, Tuple2<Integer, Integer>>> result = new ArrayList<>();
            grp._2.forEach(x -> result.add(new Tuple2<>(grp._1, x)));
            return result;
        });
    }

    public static JavaPairRDD<Tuple2<Integer, Integer>, Float> seriesFunction(
            JavaPairRDD<Tuple2<Integer, Integer>, Integer> baseAffinity,
            JavaPairRDD<Integer, Tuple2<Integer, Integer>> topAffinity) {
        JavaPairRDD<Integer, Tuple2<Integer, Integer>> morphedBase = baseAffinity
                .mapToPair(aff -> new Tuple2<>(aff._1._2, new Tuple2<>(aff._1._1, aff._2)));
        JavaPairRDD<Integer, Tuple2<Tuple2<Integer, Integer>, Tuple2<Integer, Integer>>> joinResult = morphedBase
                .join(topAffinity).filter(x -> x._2._1._1.intValue() != x._2._2._1.intValue());
        return joinResult.mapToPair(x -> {
            float v1 = x._2._1._2;
            float v2 = x._2._2._2;
            float series = (v1 * v2) / (v1 + v2);
            return new Tuple2<>(new Tuple2<>(x._2._1._1, x._2._2._1), series);
        }).reduceByKey((v1, v2) -> (v1 + v2));
    }

    public static JavaPairRDD<Tuple2<Integer, Integer>, Integer> parallelFunction(
            JavaPairRDD<Tuple2<Integer, Integer>, Integer> baseAffinity,
            JavaPairRDD<Tuple2<Integer, Integer>, Float> series) {
        return baseAffinity.mapValues(Integer::floatValue).union(series).reduceByKey((v1, v2) -> (v1 + v2))
                .mapValues(Math::round);
    }

    public static JavaPairRDD<Tuple2<Integer, Integer>, Integer> discovery(
            JavaPairRDD<Tuple2<Integer, Integer>, Integer> secondHopAff,
            JavaPairRDD<Tuple2<Integer, Integer>, Integer> nicheAff,
            JavaPairRDD<Tuple2<Integer, Integer>, Integer> popularAff) {
        return secondHopAff.subtractByKey(nicheAff).subtractByKey(popularAff);
    }
}
