/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata;

import org.apache.spark.HashPartitioner;
import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import scala.Tuple2;

import java.io.IOException;
import java.nio.file.Paths;
import java.util.Map;

/**
 * @author sundar
 */
public class TasteGraph {
    public static final String DISCOVERY = "discovery";

    public static final String NICHE = "niche";

    public static final String POPULAR = "popular";

    public static final String REVIEW_COUNT = "counts";

    public static final String BASE_AFFINITY = "base-affinity";

	private static final Logger log = LoggerFactory.getLogger(TasteGraph.class);

    public static final int SPARK_PARTITIONS = 500;

    protected JavaSparkContext sparkContext;
    protected int partitions;
    protected String reviewsPath;
    protected String outputDir;

    public TasteGraph(JavaSparkContext sparkContext, int partitions, String reviewsPath, String outputDir) {
        this.sparkContext = sparkContext;
        this.partitions = partitions;
        this.reviewsPath = reviewsPath;
        this.outputDir = outputDir;
    }

    public static void main(String[] args) throws IOException {
        if (args.length < 2) {
            // @formatter:off
            System.err.println("Usage: " + TasteGraph.class.getCanonicalName() + " <review-file> <output-dir> [partitions]");
            // @formatter:on
            System.exit(1);
        }

        String reviewsFile = args[0];
        String outDir = args[1];
        int partitions = args.length >= 3 ? Integer.valueOf(args[2]) : SPARK_PARTITIONS;

        SparkConf conf = new SparkConf().setAppName("Taste Graph");
        log.info("Spark Configuration");
        Tuple2<String, String>[] sparkConf = conf.getAll();
        for (Tuple2<String, String> c : sparkConf) {
            log.info(c._1 + " : " + c._2);
        }
        log.info("Partitions: " + partitions);
        JavaSparkContext sparkContext = new JavaSparkContext(conf);

        TasteGraph tg = new TasteGraph(sparkContext, partitions, reviewsFile, outDir);
        long start = System.currentTimeMillis();
        tg.processTasteGraph();
        long end = System.currentTimeMillis();
        log.info("Took: " + (end - start) + " ms");

        sparkContext.stop();
    }

    public void processTasteGraph() {
        JavaPairRDD<String, Integer> reviews = readReviewData().distinct();
        // Base Affinity
        log.info("Finding Base Affinity");
        JavaPairRDD<Tuple2<Integer, Integer>, Integer> affinity = findAffinity(reviews)
                .persist(StorageLevel.DISK_ONLY()).partitionBy(new HashPartitioner(partitions));
        saveAffinityData(affinity, BASE_AFFINITY);

        // Counts
        log.info("Finding Review Counts");
        JavaPairRDD<Integer, Integer> reviewCounts = findReviewCounts(reviews);
        saveCountsData(reviewCounts, REVIEW_COUNT);

        Map<Integer, Integer> counts = reviewCounts.collectAsMap();

        // Popular Affinity
        log.info("Finding Popular affinities");
        JavaPairRDD<Tuple2<Integer, Integer>, Integer> popularAffinity = popularAffinity(affinity, counts)
                .persist(StorageLevel.DISK_ONLY()).partitionBy(new HashPartitioner(partitions));
        saveAffinityData(popularAffinity, POPULAR);

        // Niche Affinity
        log.info("Finding Niche affinities");
        JavaPairRDD<Tuple2<Integer, Integer>, Integer> nicheAffinity = nicheAffinity(affinity, counts)
                .persist(StorageLevel.DISK_ONLY()).partitionBy(new HashPartitioner(partitions));
        saveAffinityData(nicheAffinity, NICHE);

        // Discovery Affinity
        log.info("Finding Discovery affinities");
        JavaPairRDD<Tuple2<Integer, Integer>, Integer> discoveryAffinity = DiscoveryAffinity
                .discoveryAffinity(affinity, counts, popularAffinity, nicheAffinity, outputDir, partitions);
        saveAffinityData(discoveryAffinity, DISCOVERY);

    }

    protected JavaPairRDD<String, Integer> readReviewData() {
        JavaRDD<String> reviews = sparkContext.textFile(reviewsPath);
        return convertRawReviews(reviews);
    }

    protected void saveCountsData(JavaPairRDD<Integer, Integer> counts, String dirName) {
        String destination = Paths.get(outputDir, dirName).toString();
        counts.map(c -> c._1 + "\t" + c._2).saveAsTextFile(destination);
    }

    protected void saveAffinityData(JavaPairRDD<Tuple2<Integer, Integer>, Integer> affinity,
            String subDirName) {
        String destination = Paths.get(outputDir, subDirName).toString();
        affinity.map(aff -> aff._1._1 + "\t" + aff._1._2 + "\t" + aff._2).saveAsTextFile(destination);
    }

    private static JavaPairRDD<Tuple2<Integer, Integer>, Integer> nicheAffinity(
            JavaPairRDD<Tuple2<Integer, Integer>, Integer> affinity, Map<Integer, Integer> counts) {
        return affinity.filter(aff -> counts.get(aff._1._2) >= Math.sqrt(counts.get(aff._1._1))).mapToPair(
                aff -> new Tuple2<>(aff._1,
                        Math.round(aff._2 * 1000 / Math.min(counts.get(aff._1._1), counts.get(aff._1._2)))))
                .filter(niche -> niche._2 > 100);
    }

    private static JavaPairRDD<Tuple2<Integer, Integer>, Integer> popularAffinity(
            JavaPairRDD<Tuple2<Integer, Integer>, Integer> affinity, Map<Integer, Integer> counts) {
        return affinity
                .mapToPair(aff -> new Tuple2<>(aff._1, Math.round(aff._2 * 1000 / (counts.get(aff._1._1)))))
                .filter(popAff -> popAff._2 > 150);
    }

    private static JavaPairRDD<Integer, Integer> findReviewCounts(JavaPairRDD<String, Integer> reviews) {
        return reviews.mapToPair(rev -> new Tuple2<>(rev._2, 1)).reduceByKey((v1, v2) -> (v1 + v2));
    }

    private static JavaPairRDD<Tuple2<Integer, Integer>, Integer> findAffinity(
            JavaPairRDD<String, Integer> reviews) {
        // Join
        log.info("Joining...");
        JavaPairRDD<String, Tuple2<Integer, Integer>> joinResult = reviews.join(reviews);
        // Filter
        log.info("Filtering...");
        JavaRDD<Tuple2<Integer, Integer>> affPair = joinResult.map(element -> element._2)
                .filter(p -> (p._1.intValue() != p._2.intValue()));
        // Group & Sum
        log.info("Group & Count...");
        JavaPairRDD<Tuple2<Integer, Integer>, Integer> affPairWithCount = affPair
                .mapToPair(p -> new Tuple2<>(p, 1)).reduceByKey((v1, v2) -> (v1 + v2));
        log.info("Affinity Pairs: " + affPairWithCount.count());
        return affPairWithCount;
    }

    protected JavaPairRDD<String, Integer> convertRawReviews(JavaRDD<String> reviews) {
        log.info("Converting raw data...");
        return reviews.mapToPair(review -> {
            String[] tokens = review.split("\t");
            return new Tuple2<>(tokens[1], Integer.valueOf(tokens[0]));
        });
    }
}
