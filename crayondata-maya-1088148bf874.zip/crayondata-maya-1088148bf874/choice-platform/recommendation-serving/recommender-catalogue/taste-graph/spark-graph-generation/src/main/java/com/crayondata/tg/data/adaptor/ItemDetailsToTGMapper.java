/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.tg.data.adaptor;

import com.crayondata.TasteGraph;
import com.google.common.base.Joiner;
import com.google.common.base.Optional;
import com.google.common.collect.Lists;
import org.apache.commons.collections.CollectionUtils;
import org.apache.spark.HashPartitioner;
import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.DataFrame;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.RowFactory;
import org.apache.spark.sql.SQLContext;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import scala.Tuple2;

import java.nio.file.Paths;
import java.util.Collections;
import java.util.List;

/**
 * @author sundar
 */
public class ItemDetailsToTGMapper {
    private static final Logger log = LoggerFactory.getLogger(ItemDetailsToTGMapper.class);

    public static final String ITEM_ID_FIELD_NAME = "id";

    public enum TGType {
        NICHE, POPULAR, DISCOVERY
    }

    private SQLContext sqlContext;
    private String detailsPath;
    private String nichePath;
    private String popularPath;
    private String discoveryPath;
    private String outputPath;
    private int partitions;
    private final boolean forEnterprise;

    public ItemDetailsToTGMapper(SQLContext sqlContext, String detailsPath, String nichePath,
            String popularPath, String discoveryPath, String outputPath, int partitions,
            boolean forEnterprise) {
        this.sqlContext = sqlContext;
        this.detailsPath = detailsPath;
        this.nichePath = nichePath;
        this.popularPath = popularPath;
        this.discoveryPath = discoveryPath;
        this.outputPath = outputPath;
        this.partitions = partitions;
        this.forEnterprise = forEnterprise;
    }

    public static void main(String[] args) {
        if (args.length < 5) {
            System.err.println("Usage: " + ItemDetailsToTGMapper.class.getCanonicalName()
                    + " <details> <niche> <popular> <discovery> <output> [partitions] [for_enterprise:true|false]");
            System.exit(1);
        }

        String detailsPath = args[0];
        String nichePath = args[1];
        String popularPath = args[2];
        String discoveryPath = args[3];
        String outputPath = args[4];
        int partitions = args.length >= 6 ? Integer.valueOf(args[5]) : TasteGraph.SPARK_PARTITIONS;
        boolean forEnterprise = args.length >= 7 ? Boolean.parseBoolean(args[6]) : false;

        SparkConf conf = new SparkConf().setAppName("TG - Item Details Mapper");
        JavaSparkContext sparkContext = new JavaSparkContext(conf);
        SQLContext sqlContext = new SQLContext(sparkContext);
        ItemDetailsToTGMapper itemDetailsToTGMapper = new ItemDetailsToTGMapper(sqlContext, detailsPath,
                nichePath, popularPath, discoveryPath, outputPath, partitions, forEnterprise);

        long start = System.currentTimeMillis();
        itemDetailsToTGMapper.mapDetailsAndTGData();
        long end = System.currentTimeMillis();
        log.info("Took: {} ms", (end - start));
    }

    public long mapDetailsAndTGData() {
        // @formatter:off
        JavaPairRDD<Integer, List<Tuple2<Integer, Integer>>> niche = loadAffinityData(nichePath)
                .persist(StorageLevel.DISK_ONLY()).partitionBy(new HashPartitioner(partitions));
        JavaPairRDD<Integer, List<Tuple2<Integer, Integer>>> popular = loadAffinityData(popularPath)
                .persist(StorageLevel.DISK_ONLY()).partitionBy(new HashPartitioner(partitions));
        JavaPairRDD<Integer, List<Tuple2<Integer, Integer>>> discovery = loadAffinityData(discoveryPath)
                .persist(StorageLevel.DISK_ONLY()).partitionBy(new HashPartitioner(partitions));
        // @formatter:on
        JavaPairRDD<Integer, Row> details = loadItemDetails(sqlContext, detailsPath);

        JavaPairRDD<Integer, ItemDetailsObject> itemDetailsRDD = details
                .mapToPair(p -> new Tuple2<>(p._1, new ItemDetailsObject(p._1, p._2)));

        JavaPairRDD<Integer, ItemDetailsObject> tgItemDetailsRDD = joinTGData(itemDetailsRDD, niche, popular,
                discovery);

        JavaPairRDD<Integer, Row> df = updateJsonWithTGData(tgItemDetailsRDD);

        List<StructField> fields = getExistingFieldsList(sqlContext, detailsPath);
        fields.addAll(getNewFieldsList());
        StructType schema = DataTypes.createStructType(fields);

        long recordCount = df.count();
        saveData(df.values(), schema);
        
        return recordCount;
    }

    public void saveAffinityData(JavaPairRDD<Integer, List<Tuple2<Integer, Integer>>> data, String dirName) {
        String destination = Paths.get(outputPath, dirName).toString();
        data.flatMapValues(x -> x).map(aff -> aff._1 + "\t" + aff._2._1 + "\t" + aff._2._2)
                .saveAsTextFile(destination);

    }

    public void saveItemDetailsObject(JavaRDD<ItemDetailsObject> data, String dirName) {
        String destination = Paths.get(outputPath, dirName).toString();
        data.saveAsTextFile(destination);
    }

    public void saveData(JavaRDD<Row> data, StructType schema) {
        DataFrame outputFrame = sqlContext.createDataFrame(data, schema);
        outputFrame.write().format("com.databricks.spark.avro").save(outputPath);
    }

    public List<StructField> getNewFieldsList() {
        List<StructField> newFields = Lists.newArrayList();
        if(this.forEnterprise){
            newFields.add(DataTypes.createStructField("ent_niche_items", DataTypes.StringType, true));
            newFields.add(DataTypes.createStructField("ent_popular_items", DataTypes.StringType, true));
            newFields.add(DataTypes.createStructField("ent_discovery_items", DataTypes.StringType, true));
        }else{
            newFields.add(DataTypes.createStructField("niche_items", DataTypes.StringType, true));
            newFields.add(DataTypes.createStructField("popular_items", DataTypes.StringType, true));
            newFields.add(DataTypes.createStructField("discovery_items", DataTypes.StringType, true));
        }
        	
        return newFields;
    }

    public List<StructField> getExistingFieldsList(SQLContext sqlContext, String path) {
        DataFrame df = sqlContext.read().format("com.databricks.spark.avro").load(path);
        StructType schema = df.schema();
        List<StructField> fields = Lists.newArrayList();
        for (StructField field : schema.fields()) {
            if (CUISINE_FIELD_NAMES.contains(field.name().toLowerCase())) {
                continue;
            }
            fields.add(DataTypes.createStructField(field.name(), field.dataType(), field.nullable()));
        }
        return fields;
    }

    public static final List<String> CUISINE_FIELD_NAMES = Lists
            .newArrayList("servescuisine_low", "servescuisine_high", "servescuisine_vhigh");

    protected JavaPairRDD<Integer, Row> updateJsonWithTGData(
            JavaPairRDD<Integer, ItemDetailsObject> itemDetailsRDD) {
        return itemDetailsRDD.mapToPair(x -> {
            ItemDetailsObject itemDetails = x._2;
            Row row = itemDetails.getDetailData();
            List<Object> lstObject = Lists.newArrayList();
            for (int i = 0; i < row.schema().fields().length; i++) {
                lstObject.add(row.get(i));
            }

            updateJsonObject(lstObject, itemDetails.getNicheData());
            updateJsonObject(lstObject, itemDetails.getPopularData());
            updateJsonObject(lstObject, itemDetails.getDiscoveryData());

            Row unionRow = RowFactory.create(lstObject.toArray(new Object[lstObject.size()]));
            return new Tuple2<>(x._1, unionRow);
        });
    }

    protected static void updateJsonObject(List<Object> lstObject, List<Tuple2<Integer, Integer>> item2List) {
        String itemAndScore = null;
        if (item2List != null && !item2List.isEmpty()) {
            List<String> itemList = Lists.newArrayList();
            List<String> scoreList = Lists.newArrayList();
            item2List.forEach(x -> {
                itemList.add(x._1.toString());
                scoreList.add(x._2.toString());
            });

            // Item and Scores
            List<String> itemAndScoreList = Lists.newArrayList();
            item2List.forEach(x -> itemAndScoreList.add(x._1 + "|" + x._2));
            if (!itemAndScoreList.isEmpty()) {
                itemAndScore = Joiner.on(" ").join(itemAndScoreList);
            }

        }
        lstObject.add(itemAndScore);
    }

    private static JavaPairRDD<Integer, ItemDetailsObject> joinTGData(
            JavaPairRDD<Integer, ItemDetailsObject> itemDetailsObjRDD,
            JavaPairRDD<Integer, List<Tuple2<Integer, Integer>>> niche,
            JavaPairRDD<Integer, List<Tuple2<Integer, Integer>>> popular,
            JavaPairRDD<Integer, List<Tuple2<Integer, Integer>>> discovery) {
        // @formatter:off
        JavaPairRDD<Integer, ItemDetailsObject> nicheMerged = mergeTGDataToItemDetails(itemDetailsObjRDD, niche, TGType.NICHE);
        JavaPairRDD<Integer, ItemDetailsObject> popularMerged = mergeTGDataToItemDetails(nicheMerged, popular, TGType.POPULAR);
        // @formatter:on
        return mergeTGDataToItemDetails(popularMerged, discovery, TGType.DISCOVERY);
    }

    private static JavaPairRDD<Integer, ItemDetailsObject> mergeTGDataToItemDetails(
            JavaPairRDD<Integer, ItemDetailsObject> itemDetailsRDD,
            JavaPairRDD<Integer, List<Tuple2<Integer, Integer>>> tgData, final TGType tgType) {
        JavaPairRDD<Integer, Tuple2<ItemDetailsObject, Optional<List<Tuple2<Integer, Integer>>>>> joinedWithTgData = itemDetailsRDD
                .leftOuterJoin(tgData);
        return joinedWithTgData.mapToPair(x -> {
            ItemDetailsObject itemDetailsObject = x._2._1;
            List<Tuple2<Integer, Integer>> affData = x._2._2.isPresent() ? x._2._2.get() : null;
            switch (tgType) {
            case NICHE:
                itemDetailsObject.setNicheData(affData);
                break;
            case POPULAR:
                itemDetailsObject.setPopularData(affData);
                break;
            case DISCOVERY:
                itemDetailsObject.setDiscoveryData(affData);
                break;
            }
            return new Tuple2<>(x._1, itemDetailsObject);
        });
    }

    public JavaPairRDD<Integer, Row> loadItemDetails(SQLContext sqlContext, String path) {
        DataFrame df = sqlContext.read().format("com.databricks.spark.avro").load(path);
        return df.javaRDD().mapToPair(
                row -> new Tuple2<>(Integer.valueOf(row.getAs(ITEM_ID_FIELD_NAME).toString()), row));

    }

    public JavaPairRDD<Integer, List<Tuple2<Integer, Integer>>> loadAffinityData(String path) {
        DataFrame df = sqlContext.read().format("com.databricks.spark.avro").load(path);
        // @formatter:off
        return df.javaRDD()
                .mapToPair(row -> new Tuple2<>(row.getInt(1), new Tuple2<>(row.getInt(0), row.getInt(2))))		/** Changed here to make node2 as the key*/
                .groupByKey()
                .mapToPair(x -> {
                    List<Tuple2<Integer, Integer>> affinities = Lists.newArrayList();
                    CollectionUtils.addAll(affinities, x._2().iterator());
                    Collections.sort(affinities, (o1, o2) -> o2._2.compareTo(o1._2));
                    return new Tuple2<>(x._1, affinities);
                });
        // @formatter:on
    }
}
