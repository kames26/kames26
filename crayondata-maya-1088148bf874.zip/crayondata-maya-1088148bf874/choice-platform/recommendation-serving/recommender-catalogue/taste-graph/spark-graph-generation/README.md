Sample review data is provided in the folder sample_data.

## Taste Graph
To run the program
spark-submit --class com.crayondata.TasteGraph target/spark-graph-generation-0.1-SNAPSHOT.jar \<input-reviews\> \<output-folder\> \[partitions\]
spark-submit --class com.crayondata.TasteGraphAvro target/spark-graph-generation-0.1-SNAPSHOT.jar \<input-reviews-dataset\> \<output-folder\> \[partitions\]

###  Sample
spark-submit --class com.crayondata.TasteGraph target/spark-graph-generation-0.1-SNAPSHOT.jar sample_data/reviews sample_data/output

###  Avro Sample
To run the TasteGraphAvro program, create the reviews using kite-dataset

kite-dataset create dataset:file:sample\_data/avro\_input --schema sample\_data/reviews.avsc
kite-dataset csv-import sample_data/reviews dataset:file:sample\_data/avro\_input --delimiter '\t' --no-header

spark-submit --class com.crayondata.TasteGraphAvro target/spark-graph-generation-0.1-SNAPSHOT.jar dataset:file:sample_data/avro_input sample_data/avro\_output

## Item Details - TG Mapper
To run the program
spark-submit --class com.crayondata.tg.data.adaptor.ItemDetailsToTGMapper target/spark-graph-generation-0.1-SNAPSHOT.jar \<details\> \<niche\> \<popular\> \<discovery\> \<output\> \[partitions\]

All the inputs specified should be Avro files. Input can be created using kite-dataset
