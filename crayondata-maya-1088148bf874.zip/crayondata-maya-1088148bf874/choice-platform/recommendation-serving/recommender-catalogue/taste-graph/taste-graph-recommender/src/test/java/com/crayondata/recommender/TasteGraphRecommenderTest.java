/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.recommender;

import static org.junit.Assert.assertNotNull;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

import com.crayondata.choice.rateableitem.Category;
import com.crayondata.choice.userprofile.UserInteraction;
import com.crayondata.choice.userprofile.UserInteraction.InteractionType;
import com.crayondata.choice.userprofile.UserProfile;
import com.crayondata.choice.userprofile.UserProfile.UserModels;
import com.crayondata.choice.userprofile.model.AttributeWeightModel;
import com.crayondata.recommender.context.UserContext;
import com.crayondata.recommender.search.IRecommendBySearch.RecommenderSearchParameters;
import com.google.common.base.Optional;
import com.google.common.collect.Table;

@Ignore
public class TasteGraphRecommenderTest {
    private static TasteGraphRecommender tgRecommenderTest = null;
    private static Recommender name = null;
    private static String itemsFieldName = null;
    private static String itemScoresFieldName = null;
    private static UserContext userContext = null;
    private static UserProfile userProfile = null;
    private static int userId = -1;
    private static UserInteraction userInteraction = null;
    private static Collection<UserInteraction> interaction = null;
    private static Table<Category, InteractionType, Iterable<UserInteraction>> userLikes = null;
    private static List<Integer> likedEntities = null;

    @Before
    public void setup() {
        name = Recommender.TGFIRSTHOPNICHE;
        itemsFieldName = "niche_items";
        itemScoresFieldName = "niche_item_scores";
        userId = 123456;
        userContext = new UserContext(userId, new Date(), Optional.absent());

        userInteraction = new UserInteraction();
        userInteraction.setId(1);
        userInteraction.setCategory(Category.CROSS);
        userInteraction.setLocation("47.39041121158791,10.9145932196729");
        interaction = new ArrayList<UserInteraction>();
        interaction.add(userInteraction);
        userLikes.put(Category.CROSS, InteractionType.Like, interaction);
        userProfile = new UserProfile(userId, userLikes,
                Collections.<UserModels, AttributeWeightModel> emptyMap());
        tgRecommenderTest = new TasteGraphRecommender(name, itemsFieldName);
        userContext.setCategory(Category.CROSS);
        likedEntities = new ArrayList<Integer>();
        likedEntities.add(10000000);
        likedEntities.add(10000001);
        likedEntities.add(10000002);
        likedEntities.add(10000003);
        likedEntities.add(10000004);
        // userContext.setLikedEntities(likedEntities);
    }

    @Test
    @Ignore
    public void testGenerateSearchSubQuery() {
        Optional<RecommenderSearchParameters> criteria = tgRecommenderTest.generateSearchSubQuery(userContext,
                userProfile);
        assertNotNull(criteria);
        Assert.assertTrue(criteria.isPresent());
    }
}
