/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.recommender;

import org.springframework.data.solr.core.query.SimpleQuery;
import org.springframework.data.solr.core.query.SimpleStringCriteria;

import com.crayondata.choice.userprofile.UserProfile;
import com.crayondata.recommender.context.UserContext;
import com.crayondata.recommender.search.IRecommendBySearch;
import com.google.common.base.Optional;
import com.google.common.collect.Iterables;

public class TasteGraphRecommender implements IRecommendBySearch {

    private final static String qFormat = "{!tg df=%s v=$USER_HISTORY}";
    // private static final Joiner queryTermJoiner = Joiner.on(" ");

    private final Recommender name;
    private final Optional<RecommenderSearchParameters> recommenderQuery;

    public TasteGraphRecommender(Recommender name, String fieldName) {
        this.name = name;

        final String queryStr = String.format(qFormat, fieldName);
        final SimpleQuery query = new SimpleQuery(new SimpleStringCriteria(queryStr));
        this.recommenderQuery = Optional.of(RecommenderSearchParameters.create(query));
    }

    @Override
    public Optional<RecommenderSearchParameters> generateSearchSubQuery(UserContext userContext,
            UserProfile userProfile) {
        final Iterable<Integer> likedItemsUserFromHistory = userProfile
                .getUserLikes(userContext.getCategory());
        if (likedItemsUserFromHistory == null || Iterables.isEmpty(likedItemsUserFromHistory)) {
            return Optional.absent();
        }

        return recommenderQuery;
    }

    @Override
    public Recommender getName() {
        return this.name;
    }

    @Override
    public String toString() {
        return getName().toString();
    }
}
