/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.recommender;

import static org.junit.Assert.*;

import java.util.Collection;

import org.junit.Test;

import com.google.common.base.Optional;
import com.google.common.collect.Lists;

/**
 * 
 * @author vivek
 *
 */
public class CategoricalCriteriaBuilderTest {

	@Test
	public void testBuildWithTwoAttrs() {
		//For cuisine
		final Optional<String> cuisineQStr = WeightedFeatureCriteriaBuilder.forFeature("cuisine", 0.78)
                .addFeatureValue("french", 0.643).addFeatureValue("chinese", 0.34).build();
        assertTrue(cuisineQStr.isPresent());
        System.out.println(cuisineQStr.get());
        //For Options
        final Optional<String> optionsQStr = WeightedFeatureCriteriaBuilder.forFeature("options", 0.78)
                .addFeatureValue("Lunch", 0.25).addFeatureValue("Breakfast", 0.25)
                .addFeatureValue("Internet", 0.5).build();
        assertTrue(optionsQStr.isPresent());
        System.out.println(optionsQStr.get());
        //Building CategoricalCriteria
        Collection<String> attrQueryStrList = Lists.newArrayList();
        attrQueryStrList.add(cuisineQStr.get());attrQueryStrList.add(optionsQStr.get());
        CategoricalCriteriaBuilder builder = new CategoricalCriteriaBuilder(attrQueryStrList);
        Optional<String> result = builder.build();
        assertTrue(result.isPresent());
        System.out.println(result.get());
	}

	@Test
	public void testBuildWithSingleAttr() {
		//For Amenities
		final Optional<String> amenitiesQStr = WeightedFeatureCriteriaBuilder.forFeature("amenities", 0.78)
                .addFeatureValue("Swimming Pool", 0.25).addFeatureValue("Parking", 0.25)
                .addFeatureValue("Restaurant", 0.5).build();
        assertTrue(amenitiesQStr.isPresent());
        System.out.println(amenitiesQStr.get());
        //Building for categorical attributes
        Collection<String> attrQueryStrList = Lists.newArrayList();
        attrQueryStrList.add(amenitiesQStr.get());
        CategoricalCriteriaBuilder builder = new CategoricalCriteriaBuilder(attrQueryStrList);
        Optional<String> result = builder.build();
        assertTrue(result.isPresent());
        System.out.println(result.get());
	}
	
	@Test
	public void testBuildWithEmptyAttr() {
		//For Amenities
		final Optional<String> amenitiesQStr = WeightedFeatureCriteriaBuilder.forFeature("amenities", 0.78).build();
        assertFalse(amenitiesQStr.isPresent());
        
        //Building for categorical attributes
        Collection<String> attrQueryStrList = Lists.newArrayList();
        CategoricalCriteriaBuilder builder = new CategoricalCriteriaBuilder(attrQueryStrList);
        Optional<String> result = builder.build();
        assertFalse(result.isPresent());
	}
}
