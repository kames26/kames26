/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.recommender;

import static com.crayondata.choice.userprofile.UserProfile.UserModels.CrayonNumAttributeRecommender;
import static com.crayondata.recommender.search.IRecommendBySearch.RecommenderSearchParameters.create;

import java.util.Collections;
import java.util.List;
import java.util.Map;

import org.apache.commons.math3.stat.descriptive.StatisticalSummary;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.solr.core.query.Query;
import org.springframework.data.solr.core.query.SimpleQuery;
import org.springframework.stereotype.Component;

import com.crayondata.choice.userprofile.UserProfile;
import com.crayondata.choice.userprofile.UserProfile.UserModels;
import com.crayondata.choice.userprofile.model.AttributeWeightModel;
import com.crayondata.choice.userprofile.model.CategoryAttributeStatsTracker;
import com.crayondata.choice.userprofile.model.CategoryAttributeStatsTracker.NumericalAttribute;
import com.crayondata.recommender.context.UserContext;
import com.crayondata.recommender.search.IRecommendBySearch;
import com.google.common.base.Joiner;
import com.google.common.base.Optional;
import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;

@Component
public class CrayonNumericalAttributeRecommender implements IRecommendBySearch {

    private static final Logger LOG = LoggerFactory.getLogger(CrayonNumericalAttributeRecommender.class);

    private static final Joiner csvJoiner = Joiner.on(",");

    /**
     * Need an inverse on top of dist to compute the similarity. Need
     * recip(x,m,a,b) ---> a/(m*x+b) to handle inverse with taking care of div
     * by zero.
     */
    private static final String NumericalAttributeTemplate = "{!func}recip(dist(1,%s),1,1,1)";
    // private final QueryParsers queryParsers = new QueryParsers();

    @Override
    public Optional<RecommenderSearchParameters> generateSearchSubQuery(UserContext userContext,
            UserProfile userProfile) {
        if (!CrayonNumAttributeRecommender.SUPPORTED_CATEGORY_TYPES.contains(userContext.getCategory())) {
            return Optional.absent();
        }

        final Optional<AttributeWeightModel> userModel = userProfile.getModel(CrayonNumAttributeRecommender);
        if (!userModel.isPresent()) {
            LOG.debug("User {} doesn't have a model of type {}.", userProfile.getUserId(),
                    CrayonNumAttributeRecommender);
            return Optional.absent();
        }

        final Iterable<Integer> categoryInteractions = userProfile.getUserLikes(userContext.getCategory());
        if (Iterables.isEmpty(categoryInteractions)) {
            LOG.debug("User {} doesn't have any interaction data for category {}.", userProfile.getUserId(),
                    userContext.getCategory());
            return Optional.absent();
        }

        final CategoryAttributeStatsTracker categoryAttributeWeights = userModel.get()
                .getAttributeWeights(userContext.getCategory());

        final Query numericalQuery = buildNumbericalSubQuery(
                categoryAttributeWeights.getNumericalAttributeStats());

        final Map<String, String> modelParameters = Collections.emptyMap();
        // TODO, this is done in categorical recommender, will refactor to
        // completely split this model later. Liam
        // userModel.get().getModelParameters(userContext.getCategory());

        return Optional.of(create(numericalQuery, modelParameters));
    }

    // TODO review, this is actually the same for all users, Liam
    private static Query buildNumbericalSubQuery(
            final Map<NumericalAttribute, StatisticalSummary> numericalAttributeStats) {

        final List<String> parts = Lists.newArrayList();
        for (NumericalAttribute numericalAttribute : numericalAttributeStats.keySet()) {
            final List<String> nameValPair = Lists.newArrayList();
            final String attributeName = numericalAttribute.getAttributeFieldName();
            nameValPair.add(attributeName);
            nameValPair.add("$" + numericalAttribute.toString());
            parts.add(csvJoiner.join(nameValPair));
        }
        final String queryString = String.format(NumericalAttributeTemplate, csvJoiner.join(parts));
        return new SimpleQuery(queryString);
    }

    @Override
    public Recommender getName() {
        return Recommender.ATTRIBUTE_NUMERICAL;
    }

    @Override
    public String toString() {
        return getName().toString();
    }
}
