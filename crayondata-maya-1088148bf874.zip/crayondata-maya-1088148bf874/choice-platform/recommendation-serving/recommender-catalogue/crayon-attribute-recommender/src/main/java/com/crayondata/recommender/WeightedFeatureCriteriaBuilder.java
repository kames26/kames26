/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.recommender;

import java.util.List;
import java.util.Map;

import org.springframework.data.solr.core.query.Criteria;
import org.springframework.data.solr.core.query.SimpleStringCriteria;

import com.google.common.base.Joiner;
import com.google.common.base.Joiner.MapJoiner;
import com.google.common.base.Optional;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

public class WeightedFeatureCriteriaBuilder {

    private static final String CriteriaTemplate = "%s:(%s)^%f";
    private static final MapJoiner spaceJoiner = Joiner.on(' ').withKeyValueSeparator("^");
    
    private static final Joiner csvJoiner = Joiner.on(',');
    
    // Sample -- product(tf(cuisine,"European"),0.25)
    private static final String featureValueTemplate = "product(tf(%s,%s),%.3f)";
    private static final String featureTemplate = "product(sum(%s),%.2f)";
    

    private final String featureName;
    private final double featureWeight;

    private final Map<String, Double> featureValueWeights;

    private WeightedFeatureCriteriaBuilder(String featureName, double featureWeight) {
        this.featureName = featureName;
        this.featureWeight = featureWeight;
        this.featureValueWeights = Maps.newHashMap();
    }

    public static WeightedFeatureCriteriaBuilder forFeature(String featureName, double featureWeight) {
        return new WeightedFeatureCriteriaBuilder(featureName, featureWeight);
    }

    private static final String QUOTE_MATCH = "\\'";
    private static final String REPLACEMENT = "?";// Lucene single character wildcard

    public WeightedFeatureCriteriaBuilder addFeatureValue(String featureValue, double featureValueWeight) {
        final String processedFeatureValue = String.format("\"%s\"",
                featureValue.replaceAll(QUOTE_MATCH, REPLACEMENT));
        featureValueWeights.put(processedFeatureValue, featureValueWeight);
        return this;
    }

    public Optional<String> build() {
    	
    	if(featureValueWeights.isEmpty())
    		return Optional.absent();
    	
    	List<String> featureValueCritList = Lists.newArrayList();
    	featureValueWeights.entrySet().forEach(x -> {
    				if(x.getValue()>0)
    					featureValueCritList.add(String.format(featureValueTemplate, featureName, x.getKey(),x.getValue()));
    			});
    	
    	String queryString = String.format(featureTemplate, csvJoiner.join(featureValueCritList), featureWeight);
    	
        /*final String queryString = String.format(CriteriaTemplate, featureName,
                spaceJoiner.join(featureValueWeights), featureWeight);
        if (featureValueWeights.isEmpty()) {
            return Optional.absent();
        }
        return Optional.of(new SimpleStringCriteria(queryString));*/
    	
    	return Optional.of(queryString);
    }

    @Override
    public String toString() {
        return "WeightedFeatureCriteriaBuilder [featureName=" + featureName + ", featureWeight="
                + featureWeight + ", featureValueWeights=" + featureValueWeights + "]";
    }
}
