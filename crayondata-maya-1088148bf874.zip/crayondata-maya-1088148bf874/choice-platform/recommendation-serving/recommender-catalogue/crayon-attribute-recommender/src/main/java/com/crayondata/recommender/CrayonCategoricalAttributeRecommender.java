/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.recommender;

import static com.crayondata.choice.userprofile.UserProfile.UserModels.CrayonCatAttributeRecommender;
import static com.crayondata.recommender.search.IRecommendBySearch.RecommenderSearchParameters.create;

import java.util.Collection;
import java.util.Map;
import java.util.function.Consumer;

import org.apache.commons.math3.stat.Frequency;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.solr.core.query.SimpleQuery;
import org.springframework.stereotype.Component;

import com.crayondata.choice.userprofile.UserProfile;
import com.crayondata.choice.userprofile.model.AttributeWeightModel;
import com.crayondata.choice.userprofile.model.CategoryAttributeStatsTracker;
import com.crayondata.choice.userprofile.model.CategoryAttributeStatsTracker.CategoricalAttribute;
import com.crayondata.recommender.context.UserContext;
import com.crayondata.recommender.search.IRecommendBySearch;
import com.google.common.base.Optional;
import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;

@Component
public class CrayonCategoricalAttributeRecommender implements IRecommendBySearch {

    private static final Logger LOG = LoggerFactory.getLogger(CrayonCategoricalAttributeRecommender.class);

    @Override
    public Optional<RecommenderSearchParameters> generateSearchSubQuery(UserContext userContext,
            UserProfile userProfile) {
        if (!CrayonCatAttributeRecommender.SUPPORTED_CATEGORY_TYPES.contains(userContext.getCategory())) {
            return Optional.absent();
        }

        final Optional<AttributeWeightModel> userModel = userProfile.getModel(CrayonCatAttributeRecommender);
        if (!userModel.isPresent()) {
            LOG.debug("User {} doesn't have a model of type {}.", userProfile.getUserId(),
                    CrayonCatAttributeRecommender);
            return Optional.absent();
        }

        final Iterable<Integer> categoryInteractions = userProfile.getUserLikes(userContext.getCategory());
        if (Iterables.isEmpty(categoryInteractions)) {
            LOG.debug("User {} doesn't have any interaction data for category {}.", userProfile.getUserId(),
                    userContext.getCategory());
            return Optional.absent();
        }

        final CategoryAttributeStatsTracker categoryAttributeWeights = userModel.get()
                .getAttributeWeights(userContext.getCategory());

        final Optional<String> optCategoricalQuery = buildCategoricalSubQuery(categoryAttributeWeights,
                userProfile.getUserId());

        if (optCategoricalQuery.isPresent()) {
            final Map<String, String> modelParameters = userModel.get()
                    .getModelParameters(userContext.getCategory());
            final SimpleQuery recommenderQuery = new SimpleQuery(optCategoricalQuery.get());
            return Optional.of(create(recommenderQuery, modelParameters));
        }
        return Optional.absent();
    }

    private static Optional<String> buildCategoricalSubQuery(
            final CategoryAttributeStatsTracker categoryAttributeWeights, int userId) {

        if (Iterables.isEmpty(categoryAttributeWeights.getAttributeNames())) {
            LOG.debug("User({}) model has no attribute weights for this category {}.", userId,
                    categoryAttributeWeights);
            return Optional.absent();
        }

        final Collection<String> perAttrCritStrList = Lists.newArrayList();

        for (CategoricalAttribute modelAttribute : categoryAttributeWeights.getDistinctAttrCount().keySet()) {
            final String attributeName = modelAttribute.toString();
            final float attributeWeight = categoryAttributeWeights.getAttributeWeight(attributeName);

            final Frequency attributeValueWeights = categoryAttributeWeights
                    .getAttributeValueWeights(attributeName);
            final Optional<String> currentAttributeCriteria = buildCriteriaForCurrentAttribute(
                    attributeValueWeights, modelAttribute, attributeWeight);
            if (currentAttributeCriteria.isPresent()) {
                perAttrCritStrList.add(currentAttributeCriteria.get());
            }
        }

        CategoricalCriteriaBuilder attrCritBuilder = new CategoricalCriteriaBuilder(perAttrCritStrList);
        final Optional<String> categoricalQuery = attrCritBuilder.build();
        if (!categoricalQuery.isPresent())
            LOG.debug("Could not generate categorical subquery for user id: {} input: {}", userId,categoryAttributeWeights);

        return categoricalQuery;
    }

    private static Optional<String> buildCriteriaForCurrentAttribute(final Frequency attributeValueWeights,
            CategoricalAttribute modelAttribute, final float featureWeight) {

        final WeightedFeatureCriteriaBuilder weightedFeatureCriteriaBuilder = WeightedFeatureCriteriaBuilder
                .forFeature(modelAttribute.getAttributeFieldName(), featureWeight);

        attributeValueWeights.valuesIterator().forEachRemaining(new Consumer<Comparable<?>>() {
            @Override
            public void accept(Comparable<?> featureValue) {
                final float featureValueWeight = Double.valueOf(attributeValueWeights.getPct(featureValue))
                        .floatValue();
                weightedFeatureCriteriaBuilder.addFeatureValue(featureValue.toString(), featureValueWeight);
            }
        });

        final Optional<String> result = weightedFeatureCriteriaBuilder.build();
        return result;
    }

    @Override
    public Recommender getName() {
        return Recommender.ATTRIBUTE_CATEGORICAL;
    }

    @Override
    public String toString() {
        return getName().toString();
    }
}
