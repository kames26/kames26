/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.recommender;

import java.util.Collection;

import org.springframework.data.solr.core.query.Criteria;
import org.springframework.data.solr.core.query.SimpleStringCriteria;

import com.google.common.base.Joiner;
import com.google.common.base.Optional;

/**
 * 
 * @author vivek
 *
 */
public class CategoricalCriteriaBuilder {

	private static final String categoricalTemplate = "{!func}sum(%s)";
	private static final Joiner csvJoiner = Joiner.on(',');
	
	private Collection<String> perAttributeCriteriaList;
	
	public CategoricalCriteriaBuilder(Collection<String> perAttributeCriteriaList){
		this.perAttributeCriteriaList = perAttributeCriteriaList;
	}
	
	public Optional<String> build() {
		if(perAttributeCriteriaList == null || perAttributeCriteriaList.isEmpty())
			return Optional.absent();
		
		String queryString = String.format(categoricalTemplate, csvJoiner.join(perAttributeCriteriaList));
		
		return Optional.of(queryString);
	}
}
