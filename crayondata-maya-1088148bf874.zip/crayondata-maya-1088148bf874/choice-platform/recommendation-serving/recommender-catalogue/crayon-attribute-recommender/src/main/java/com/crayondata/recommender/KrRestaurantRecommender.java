/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.recommender;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.StringJoiner;

import org.apache.solr.client.solrj.SolrQuery;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.solr.core.query.Query;
import org.springframework.data.solr.core.query.SimpleQuery;
import org.springframework.stereotype.Component;

import com.crayondata.choice.rateableitem.Category;
import com.crayondata.choice.rateableitem.LocalBusiness;
import com.crayondata.choice.rateableitem.RateableItemDao;
import com.crayondata.choice.userprofile.UserProfile;
import com.crayondata.recommender.context.UserContext;
import com.crayondata.recommender.search.IRecommendBySearch;
import com.google.common.base.Optional;
import com.google.common.collect.Lists;

@Component
public class KrRestaurantRecommender implements IRecommendBySearch {

    // private final static StructType localBusinessSchema = new StructType(new
    // StructField[] {
    // new StructField("text", new ArrayType(DataTypes.StringType, true), false,
    // Metadata.empty())});

    //
    // Engineered features:
    // Mean of aggregated rating
    // Variance of aggregated rating
    // Distribution score of each feature value for Cuisine

    // constants about restaurants field names
    public static final String RESTAURANT_DESCRIPTION_FIELD = "description";
    public static final String RESTAURANT_SENTIMENT_FIELD = "sentiment";

    // constants about the method name of combining restaurants and tags
    public static final String RESTAURANT_TAG_COMBINE_RERANK = "rerank";
    public static final String RESTAURANT_TAG_COMBINE_WEIGHT = "weighted";

    // constants about the method name of combining relevance and sentiment
    public static final String RELEVANCE_SENTIMENT_METHOD_SORT = "sort";
    public static final String RELEVANCE_SENTIMENT_METHOD_BOOST = "boost";

    // number of recommended results to return
    int noOfRowsToReturn = 5;

    // configure the weights if using weighted method for restaurnats and tags,
    float restaurantWeightOverTags = 0.01f;
    float tagWeightOverRestaurant = 0.99f;

    // configure the rerank documents no. and weights if using rerank method for
    // restaurant and tags
    int reRankDocs = 1000;
    float reRankWeight = 2f;

    // default methods
    String restaurantTagCombineMethod = RESTAURANT_TAG_COMBINE_RERANK;
    String relevanceSentimentCombineMethod = RELEVANCE_SENTIMENT_METHOD_BOOST;

    // whether enable sentiment boost for restaurant when getting restaurant
    // profile for query
    boolean enableFavoriteRestaurantBoostBySentiment = false;

    public static final String tagWeightsFile = "tags/tagsWithWeights.txt";

    RateableItemDao<LocalBusiness> krDao;

    @Autowired
    KrRestaurantRecommender(RateableItemDao<LocalBusiness> dao) {
        this.krDao = dao;
    }

    @Override
    public Optional<RecommenderSearchParameters> generateSearchSubQuery(UserContext userContext,
            UserProfile userProfile) {

        Collection<List<String>> tagsCollection = userContext.getKeywords().values(); // tags

        List<String> tags = new ArrayList<>();
        for (List<String> tagsList : tagsCollection) {
            tags.addAll(tagsList);
        }

        Iterable<Integer> restaurantIds = userProfile.getUserLikes(Category.RESTAURANT);

        final Iterable<LocalBusiness> mayaRestaurants = krDao.findAll(restaurantIds);
        List<LocalBusiness> mayaRestaurantList = Lists.newArrayList(mayaRestaurants);

        Map<String, String> tagWeights = loadTagWeights();

        Query query = generateSolrQuery(tags, mayaRestaurantList, tagWeights);

        return Optional.of(RecommenderSearchParameters.create(query));

    }

    @Override
    public Recommender getName() {
        return Recommender.ATTRIBUTE_CATEGORICAL;// TODO
    }

    /*
     * Generate solr query based on user profile (restaurants or tags)
     */
    public Query generateSolrQuery(List<String> tags, List<LocalBusiness> mayaFavoriteRestaurantList,
            Map<String, String> tagWeigths) {
        // skip if user has given nothing

        if ((0 == mayaFavoriteRestaurantList.size()) && (0 == tags.size())) {
            return null;// TODO maybe it is worth to return empty collection
                        // instead of null
        }
        // create initials
        SolrQuery targetQuery = null;

        // generate solr query based on different cases
        if (0 == tags.size()) {
            // case 1: restaurants list only
            targetQuery = getQueryFromRestaurants(mayaFavoriteRestaurantList);

        } else if (0 == mayaFavoriteRestaurantList.size()) {
            // case 2: tags list only
            targetQuery = getQueryFromTags(tags, tagWeigths);

        } else {
            // case 3: both restaurant list and tag list are there
            targetQuery = getQueryFromBoth(mayaFavoriteRestaurantList, tags, tagWeigths);
        }

        // set other common query fields if any
        if (targetQuery != null) {
            targetQuery.setFields("*", "score");
            targetQuery.setRows(noOfRowsToReturn);
        }

        // // rerank query
        // targetQuery.set("rq","{!rerank reRankQuery=$rqq reRankDocs=" +
        // String.valueOf(reRankDocs) + " reRankWeight=" +
        // String.valueOf(reRankWeight) + "}");
        // targetQuery.set("rqq", "sentiment");

        return new SimpleQuery(targetQuery.toString());
    }

    public SolrQuery getQueryFromRestaurants(List<LocalBusiness> restaurantArrayList) {
        String qstr = constructQueryStringFromRestaurants(restaurantArrayList);
        if (qstr == null || 0 == qstr.length()) {
            return null;
        }
        SolrQuery squery = wrapRelevanceAndSentiment(qstr);
        return squery;

    }

    public SolrQuery getQueryFromTags(List<String> tags, Map<String, String> tagWeights) {
        String qstr = constructQueryStringFromTags(tags, tagWeights);
        if (qstr == null || 0 == qstr.length()) {
            return null;
        }
        SolrQuery squery = wrapRelevanceAndSentiment(qstr);
        return squery;
    }

    public SolrQuery wrapRelevanceAndSentiment(String qstr) {
        if (qstr == "" || qstr == null) {
            return null;
        }
        SolrQuery squery = new SolrQuery();
        if (relevanceSentimentCombineMethod == RELEVANCE_SENTIMENT_METHOD_SORT) {
            // sort by mulitple values: score, sentiment. the second comes to
            // effect only when the first field results in tie
            squery.setQuery(qstr);
            squery.addSort("score", SolrQuery.ORDER.desc);
            squery.addSort("sentiment", SolrQuery.ORDER.desc);
        } else if (relevanceSentimentCombineMethod == RELEVANCE_SENTIMENT_METHOD_BOOST) {
            qstr = "{!boost b=" + RESTAURANT_SENTIMENT_FIELD + "}" + qstr;
            System.out.print("Final tag query string:" + qstr);
            squery.setQuery(qstr);
        }
        return squery;
    }

    public SolrQuery getQueryFromBoth(List<LocalBusiness> restaurantArrayList, List<String> tags,
            Map<String, String> tagWeights) {
        String queryStrRest = constructQueryStringFromRestaurants(restaurantArrayList);
        String queryStrTag = constructQueryStringFromTags(tags, tagWeights);

        if ((null == queryStrRest || 0 == queryStrRest.length())
                && (null == queryStrTag || 0 == queryStrTag.length())) {
            return null;
        }

        SolrQuery squery = null;
        String queryString = "";
        if (null == queryStrRest || 0 == queryStrRest.length()) {
            queryString = queryStrTag;
            squery = wrapRelevanceAndSentiment(queryString);
        } else if (null == queryStrTag || 0 == queryStrTag.length()) {
            queryString = queryStrRest;
            squery = wrapRelevanceAndSentiment(queryString);
        } else {
            if (this.restaurantTagCombineMethod == RESTAURANT_TAG_COMBINE_WEIGHT) {
                // weight restaurans and tags differently

                queryString = "(" + queryStrRest + ")^" + String.valueOf(restaurantWeightOverTags) + "("
                        + queryStrTag + ")^" + String.valueOf(tagWeightOverRestaurant);

                squery = wrapRelevanceAndSentiment(queryString);

            } else if (this.restaurantTagCombineMethod == RESTAURANT_TAG_COMBINE_RERANK) {
                squery = new SolrQuery();
                if (relevanceSentimentCombineMethod == RELEVANCE_SENTIMENT_METHOD_SORT) {
                    squery.set("q", queryStrTag);
                    squery.set("rq", "{!rerank reRankQuery=$rqq reRankDocs=" + String.valueOf(reRankDocs)
                            + " reRankWeight=" + String.valueOf(reRankWeight) + "}");
                    squery.set("rqq", queryStrRest);

                    // sort by mulitple values: score, sentiment. the second
                    // comes to effect only when the first field results in tie
                    squery.addSort("score", SolrQuery.ORDER.desc);
                    squery.addSort("sentiment", SolrQuery.ORDER.desc);

                } else if (relevanceSentimentCombineMethod == RELEVANCE_SENTIMENT_METHOD_BOOST) {
                    queryString = "{!boost b=" + RESTAURANT_SENTIMENT_FIELD + "}" + queryStrTag;
                    squery.set("q", queryString);
                    squery.set("rq", "{!rerank reRankQuery=$rqq reRankDocs=" + String.valueOf(reRankDocs)
                            + " reRankWeight=" + String.valueOf(reRankWeight) + "}");
                    squery.set("rqq", queryStrRest);
                }
            }
        }

        return squery;
    }

    public String constructQueryStringFromRestaurants(List<LocalBusiness> restaurantArrayList) {
        String queryString = "";
        int count = 0;
        for (LocalBusiness mayaRestaurant : restaurantArrayList) {
            count++;
            // get the description of each given restaurant
            // SolrQuery squery = new SolrQuery();
            // squery.setQuery("id:\"" + sid+"\"");
            // SolrDocumentList restaurants = solrDao.searchDoc(squery);

            // skip empty restaurants
            // if (restaurants == null || 0 == restaurants.size()) {
            // continue;
            // }

            // get the first restaurant's descriptions
            String restDesc = mayaRestaurant.getDescription();// TODO have to
                                                              // check is it
                                                              // required to
                                                              // change
                                                              // description to
                                                              // entity (
                                                              // description
                                                              // could be
                                                              // already in use
                                                              // )
            Float restSenti = mayaRestaurant.getSentiment();

            // create a entity-count map from the entities in the restaurant
            // description
            Map<String, Integer> entityMap = new HashMap<>();
            String[] tmp = restDesc.split(",");
            for (String s : tmp) {
                String key = s.trim();
                if (entityMap.containsKey(key)) {
                    entityMap.put(key, entityMap.get(key) + 1);
                } else {
                    entityMap.put(key, 1);
                }
            }

            // construct a query string for each restaurant independently
            StringJoiner sj = new StringJoiner(" OR ", RESTAURANT_DESCRIPTION_FIELD + ":(", ")");
            int entityCount = 0;
            entityMap = sortByComparator(entityMap);
            for (Map.Entry<String, Integer> entry : entityMap.entrySet()) {
                entityCount++;
                if (entityCount > 50) {
                    break;
                }
                String oneSample = "\"".concat(entry.getKey()).concat("\"^")
                        .concat(String.valueOf(entry.getValue()));
                sj.add(oneSample);
            }

            // append the query string to the result query string
            if (enableFavoriteRestaurantBoostBySentiment) {
                String boostedStr = "(".concat(sj.toString()).concat(")^").concat(String.valueOf(restSenti));
                queryString = queryString.concat(boostedStr);
            } else {
                queryString = queryString.concat(" ").concat(sj.toString());
            }
        }
        // print and return the final query string
        System.out.println("The restaurant query string is:" + queryString);
        return queryString;
    }

    public static String constructQueryStringFromTags(List<String> tags, Map<String, String> tagWeights) {
        String queryString = "";
        for (String tag : tags) {
            // check wheter the tag contains tag keys or not, if yes, ignore it.
            if (-1 != tag.lastIndexOf(":")) {
                System.out.println("Original pair:" + tag);
                tag = tag.substring(tag.lastIndexOf(":") + 1, tag.length());
                System.out.println("refined tag:" + tag);
            }

            // try to get the expanded tags words
            if (tagWeights.containsKey(tag)) {
                String expendedTags = tagWeights.get(tag);
                queryString = queryString.concat(RESTAURANT_DESCRIPTION_FIELD + ":" + expendedTags + "");
            } else { // no expanded words are found
                queryString = queryString.concat(RESTAURANT_DESCRIPTION_FIELD + ":\"" + tag + "\"");
            }
        }
        System.out.println("The tag query string is:" + queryString);
        return queryString;
    }

    private static Map<String, Integer> sortByComparator(Map<String, Integer> unsortMap) {

        // Convert Map to List
        List<Map.Entry<String, Integer>> list = new LinkedList<>(unsortMap.entrySet());

        // Sort list with comparator, to compare the Map values
        Collections.sort(list, new Comparator<Map.Entry<String, Integer>>() {
            @Override
            public int compare(Map.Entry<String, Integer> o1, Map.Entry<String, Integer> o2) {
                return (o1.getValue()).compareTo(o2.getValue());
            }
        });

        // Convert sorted map back to a Map
        Map<String, Integer> sortedMap = new LinkedHashMap<>();
        for (Iterator<Map.Entry<String, Integer>> it = list.iterator(); it.hasNext();) {
            Map.Entry<String, Integer> entry = it.next();
            sortedMap.put(entry.getKey(), entry.getValue());
        }
        return sortedMap;
    }

    private Map<String, String> loadTagWeights() {

        // load the tag weights from the resource folder
        Map<String, String> tagWeigths = new HashMap<>();
        ClassLoader classLoader = getClass().getClassLoader();
        File file = new File(classLoader.getResource(tagWeightsFile).getFile());

        // load tags and weights and save into the tagweights map
        try {
            InputStream in = new FileInputStream(file);
            BufferedReader reader = new BufferedReader(new InputStreamReader(in));
            String line;
            while ((line = reader.readLine()) != null) {
                String[] tmp = line.split("\t");
                tagWeigths.put(tmp[0], tmp[1]);
            }
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return tagWeigths;
    }
}
