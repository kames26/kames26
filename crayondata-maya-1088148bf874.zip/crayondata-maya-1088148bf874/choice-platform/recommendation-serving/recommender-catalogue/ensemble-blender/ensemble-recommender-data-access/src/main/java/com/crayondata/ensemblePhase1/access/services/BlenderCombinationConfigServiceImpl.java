/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.ensemblePhase1.access.services;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import com.crayondata.access.ensemblePhase1.IBlenderCombinationConfigDAO;
import com.crayondata.ensemblePhase1.access.repositories.BlenderCombinationConfigRepo;

@Service
public class BlenderCombinationConfigServiceImpl implements IBlenderCombinationConfigDAO {
    @Autowired
    public BlenderCombinationConfigRepo blenderCombinationConfigRepo;

    @Override
    public BlenderCombinationConfig update(BlenderCombinationConfig update) {
        BlenderCombinationConfig status = blenderCombinationConfigRepo.save(update);
        return status;
    }

    @Override
    public BlenderCombinationConfig updateSuccess(Integer cid, int success) {
        BlenderCombinationConfig blenderCombinationConfig = getCombinationByCid(cid);
        int updateSuccess = blenderCombinationConfig.getSuccess() + success;
        int failure = blenderCombinationConfig.getFailure();
        double sucessPercentage = (double) updateSuccess / (double) (updateSuccess + failure);
        double failurePercentage = ((double) failure / (double) (updateSuccess + failure));
        blenderCombinationConfig.setSuccessPercentage(sucessPercentage);
        blenderCombinationConfig.setFailurePercentage(failurePercentage);
        blenderCombinationConfig.setSuccess(updateSuccess);
        blenderCombinationConfig.setFailure(failure);
        update(blenderCombinationConfig);
        return blenderCombinationConfig;
    }

    @Override
    public BlenderCombinationConfig updateFailure(Integer cid, int failure) {
        BlenderCombinationConfig blenderCombinationConfig = getCombinationByCid(cid);
        int updateFailure = blenderCombinationConfig.getFailure() + failure;
        int success = blenderCombinationConfig.getSuccess();
        double sucessPercentage = ((double) success / (double) (updateFailure + success));
        double failurePercentage = ((double) updateFailure / (double) (updateFailure + success));
        blenderCombinationConfig.setSuccessPercentage(sucessPercentage);
        blenderCombinationConfig.setFailurePercentage(failurePercentage);
        blenderCombinationConfig.setSuccess(blenderCombinationConfig.getSuccess());
        blenderCombinationConfig.setFailure(updateFailure);
        update(blenderCombinationConfig);
        return blenderCombinationConfig;
    }

    @Override
    public BlenderCombinationConfig updateTotalDelivered(Integer cid, int totalDelivered) {
        BlenderCombinationConfig blenderCombinationConfig = getCombinationByCid(cid);
        blenderCombinationConfig.setTotalDelivered(blenderCombinationConfig.getTotalDelivered()
                + totalDelivered);
        update(blenderCombinationConfig);
        return blenderCombinationConfig;
    }

    @Override
    @Cacheable("getCombinationByCid")
    public BlenderCombinationConfig getCombinationByCid(Integer cid) {
        Collection<BlenderCombinationConfig> result = blenderCombinationConfigRepo.findByCid(cid);
        return (result != null && result.size() > 0) ? result.iterator().next() : null;
    }

    @Override
    @Cacheable("getSortedCombinationsByPercentageOfSuccess")
    public Collection<BlenderCombinationConfig> getSortedCombinationsByPercentageOfSuccess(
            int recommenderCount) {
        Collection<BlenderCombinationConfig> listofrecommendation = blenderCombinationConfigRepo
                .findByRecommenderCountOrderBySuccessPercentageDescCidAsc(recommenderCount);
        return listofrecommendation;
    }

}
