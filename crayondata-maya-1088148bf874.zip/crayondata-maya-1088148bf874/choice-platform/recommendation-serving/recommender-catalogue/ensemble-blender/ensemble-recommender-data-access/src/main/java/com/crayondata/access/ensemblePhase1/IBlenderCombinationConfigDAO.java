/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.access.ensemblePhase1;

import java.util.Collection;

import com.crayondata.ensemblePhase1.access.services.BlenderCombinationConfig;

/**
 * The interface containing all APIs that the BlenderCombinationConfig DAO needs
 * to implement.
 *
 * @author Prashant Singh
 *
 */
public interface IBlenderCombinationConfigDAO {
    /**
     * Get the entity from data repository.
     *
     * @param cid
     * @return BlenderCombinationConfig
     */
    public BlenderCombinationConfig getCombinationByCid(Integer cid);

    /**
     * Lists down all the BlenderCombinationConfig objects available in sorted
     * manner on the basis of PercentageOfSuccess field.
     *
     * @param recommenderCount
     *            No. of recommenders used in the ensemble model
     * @return Collection
     */
    public Collection<BlenderCombinationConfig> getSortedCombinationsByPercentageOfSuccess(
            int recommenderCount);

    /**
     * Updates the given object identified by id with the given update object.
     *
     * @param update
     * @return boolean
     */
    public BlenderCombinationConfig update(BlenderCombinationConfig update);

    /**
     * Updates the given object identified by id with the given success value.
     *
     * @param cid
     * @param success
     * @return
     */
    public BlenderCombinationConfig updateSuccess(Integer cid, int success);

    /**
     * Updates the given object identified by id with the given failure value.
     *
     * @param cid
     * @param failure
     * @return
     */
    public BlenderCombinationConfig updateFailure(Integer cid, int failure);

    /**
     * Updates the given object identified by id with the given totalDelivered
     * value.
     *
     * @param cid
     * @param totalDelivered
     * @return
     */
    public BlenderCombinationConfig updateTotalDelivered(Integer cid, int totalDelivered);
}
