/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.ensemblePhase1.access.services;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * Data model object for storing first level of scoring for each recommender
 * system.
 *
 * @author Prashant Singh
 *
 */
@Entity
@Table(name = "blender_combination_config")
public class BlenderCombinationConfig {
    @Id
    @Column(name = "cid")
    protected Integer cid;

    @Column(name = "combinations")
    protected String combinations;

    @Column(name = "success")
    protected Integer success;

    @Column(name = "failure")
    protected Integer failure;

    @Column(name = "success_percentage")
    protected Double successPercentage;

    @Column(name = "failure_percentage")
    protected Double failurePercentage;

    @Column(name = "total_delivered")
    protected Integer totalDelivered;

    @Column(name = "recommender_count")
    protected Integer recommenderCount;

    public Integer getCid() {
        return cid;
    }

    public void setCid(Integer cid) {
        this.cid = cid;
    }

    public String getCombinations() {
        return combinations;
    }

    public void setCombinations(String combinations) {
        this.combinations = combinations;
    }

    public int getSuccess() {
        return success;
    }

    public void setSuccess(int success) {
        this.success = success;
    }

    public int getFailure() {
        return failure;
    }

    public void setFailure(int failure) {
        this.failure = failure;
    }

    public double getSuccessPercentage() {
        return successPercentage;
    }

    public void setSuccessPercentage(double successPercentage) {
        this.successPercentage = successPercentage;
    }

    public double getFailurePercentage() {
        return failurePercentage;
    }

    public void setFailurePercentage(double failurePercentage) {
        this.failurePercentage = failurePercentage;
    }

    public int getTotalDelivered() {
        return totalDelivered;
    }

    public void setTotalDelivered(int totalDelivered) {
        this.totalDelivered = totalDelivered;
    }

    public Integer getRecommenderCount() {
        return recommenderCount;
    }

    public void setRecommenderCount(Integer recommenderCount) {
        this.recommenderCount = recommenderCount;
    }

    @Override
    public String toString() {
        return "BlenderCombinationConfig [cid=" + cid + ", combinations=" + combinations + ", success="
                + success + ", failure=" + failure + ", successPercentage=" + successPercentage
                + ", failurePercentage=" + failurePercentage + ", totalDelivered=" + totalDelivered
                + ", recommenderCount=" + recommenderCount + "]";
    }

}
