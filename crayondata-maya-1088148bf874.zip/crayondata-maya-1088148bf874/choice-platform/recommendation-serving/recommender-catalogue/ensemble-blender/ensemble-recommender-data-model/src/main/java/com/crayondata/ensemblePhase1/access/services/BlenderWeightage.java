/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.ensemblePhase1.access.services;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "blender_weightage")
public class BlenderWeightage {

    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.AUTO)
    protected Integer id;

    @Column(name = "rank")
    protected Integer rank;

    @Column(name = "distributed_weightage")
    protected Double distributedWeightage;

    @Column(name = "recommender_count")
    protected Integer recommenderCount;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getRank() {
        return rank;
    }

    public void setRank(Integer rank) {
        this.rank = rank;
    }

    public Double getDistributedWeightage() {
        return distributedWeightage;
    }

    public void setDistributedWeightage(Double distributedWeightage) {
        this.distributedWeightage = distributedWeightage;
    }

    public Integer getRecommenderCount() {
        return recommenderCount;
    }

    public void setRecommenderCount(Integer recommenderCount) {
        this.recommenderCount = recommenderCount;
    }

    @Override
    public String toString() {
        return "BlenderWeightage [id=" + id + ", rank=" + rank + ", distributedWeightage="
                + distributedWeightage + ", recommenderCount=" + recommenderCount + "]";
    }

}
