/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.recommender.search.impl;

import com.crayondata.access.ensemblePhase1.IBlenderCombinationConfigDAO;
import com.crayondata.access.ensemblePhase1.IBlenderWeightageDAO;
import com.crayondata.choice.rateableitem.Category;
import com.crayondata.ensemblePhase1.access.services.BlenderCombinationConfig;
import com.crayondata.ensemblePhase1.access.services.BlenderWeightage;
import com.crayondata.recommender.Recommender;
import com.crayondata.recommender.RecommenderScenario;
import com.crayondata.recommender.context.UserContext;
import com.crayondata.recommender.search.IRecommendBySearch;
import com.crayondata.recommender.search.IWeightsProvider;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;
import org.apache.mahout.math.DenseVector;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class RecommenderWeightsProvider implements IWeightsProvider {

    private static final float DEFAULT_WEIGHT = 1;
    private static final int RECOMMENDER_COUNT = 10;
    private static final Logger logger = LoggerFactory.getLogger(RecommenderWeightsProvider.class);

    private static final Random random = new Random();
    private static WeightedRandomizer weightedRandomizer;

    private final IBlenderCombinationConfigDAO blenderCombinationConfigService;
    private final IBlenderWeightageDAO blenderWeightageService;

    @Autowired
    public RecommenderWeightsProvider(IBlenderCombinationConfigDAO blenderCombinationConfigService,
            IBlenderWeightageDAO blenderWeightageService) {
        this.blenderCombinationConfigService = blenderCombinationConfigService;
        this.blenderWeightageService = blenderWeightageService;
    }

    private List<String> getCombinations(int recommenderCount) {
        // extract only combination labels from the config sorted by their % of
        // success
        Collection<BlenderCombinationConfig> combinationConfigs = blenderCombinationConfigService
                .getSortedCombinationsByPercentageOfSuccess(recommenderCount);
        List<String> combinations = combinationConfigs.stream().map(BlenderCombinationConfig::getCombinations)
                .collect(Collectors.toList());
        return combinations;
    }

    private double[] getDistributionWeightages(int recommenderCount) {
        // extract only weightage values
        Collection<BlenderWeightage> blenderWeightages = blenderWeightageService
                .getSortedDistributedWeightage(recommenderCount);
        double[] weightages = blenderWeightages.stream().map(BlenderWeightage::getDistributedWeightage)
                .mapToDouble(Double::doubleValue).toArray();
        return weightages;
    }

    /**
     * Creates random weights from the label combinations using the mapping H=>3|4 L=>1|2
     *
     * @param label Sequence of H/L label combination. For e.g. HHLHHH
     * @return Array of weights of same size as number of characters in input label
     */
    private static int[] getRandomWeightsFromLabel(String label) {
        final int randomLevels = 2;
        int[] weights = new int[label.length()];
        for (int i = 0; i < weights.length; i++) {
            int nextLevel = random.nextInt(randomLevels);
            char character = label.charAt(i);
            switch (character) {
            case 'H':
                weights[i] = nextLevel + 3;
                break;
            case 'L':
                weights[i] = nextLevel + 1;
                break;
            }
        }
        return weights;
    }

    private static String stringifyWeights(int[] weights) {
        String weightString = Arrays.stream(weights).boxed().map(i -> i.toString()).collect(Collectors.joining());
        return weightString;
    }

    private static int[] generateWeights(String combination) {
        int[] randomWeightsFromLabel = getRandomWeightsFromLabel(combination);
        logger.debug("Converted label to random weights: " + Arrays.toString(randomWeightsFromLabel));
        return randomWeightsFromLabel;
    }

    private String getRandomCombinationLabel() {
        if (weightedRandomizer == null) {
            // initialize distribution for randomizer
            double[] distributionWeightages = getDistributionWeightages(RECOMMENDER_COUNT);
            weightedRandomizer = new WeightedRandomizer(new DenseVector(distributionWeightages));
        }
        // get combinations sorted by % of success, pick random label and
        // convert into randomized weightages
        List<String> combinations = getCombinations(RECOMMENDER_COUNT);
        String combination = combinations.get(weightedRandomizer.next());
        logger.debug("Generated combination label {}", combination);
        return combination;
    }

    private static float[] normalizeWeights(float[] weights) {
        // normalize weights by sum of all weights
        float sum = 0;
        for (float weight : weights) {
            sum += weight;
        }
//        logger.info("Normalizing weights using sum: " + sum);
        if (sum != 0) {
            for (int i = 0; i < weights.length; i++) {
                weights[i] /= sum;
            }
        }
        logger.debug("Normalized weights: " + Arrays.toString(weights));
        return weights;
    }

    /**
     * Update weights resetting weight for any unused recommender to 0
     *
     * @param weights Original set of weights which has to be updated
     * @param recommenderList List of all supported recommenders
     * @param preferredRecommenders List of recommenders which are used for the current recommendation
     * @return Updated weights in which weightage for any recommender not in preferred list is set to 0
     */
    private static float[] resetWeights(float[] weights, List<Recommender> recommenderList,
            Iterable<IRecommendBySearch> preferredRecommenders) {
        float[] updatedWeights = new float[weights.length];
        preferredRecommenders.forEach((preferredRecommender) -> {
            int recommenderIndex = recommenderList.indexOf(preferredRecommender.getName());
            if (0 <= recommenderIndex && recommenderIndex < weights.length) {
                updatedWeights[recommenderIndex] = weights[recommenderIndex];
            }
        });
        return updatedWeights;
    }

    private static float[] calculateWeights(List<Recommender> recommenderList,
            Iterable<IRecommendBySearch> recommenders, float[] weights) {
        float[] normalizedWeights = normalizeWeights(
                resetWeights(weights, recommenderList, recommenders)
        );
        return normalizedWeights;
    }

    private static float[] intToFloatArray(int[] intArray) {
        float[] floatArray = new float[intArray.length];
        for (int i = 0; i < intArray.length; i++) {
            floatArray[i] = intArray[i];
        }
        return floatArray;
    }

    @Override
    public RecommenderWeights provideWeights(UserContext userContext, Object userProfile,
            Iterable<IRecommendBySearch> recommenders) {
        return new RecommenderWeights() {
            /*
             * This code works on the assumption that only the first RECOMMENDER_COUNT recommenders from
             * Recommender enum is used for the recommendation and is highly dependent on the order of the
             * recommenders defined in the Recommender enum.
             * If a preferred recommender i.e. a recommender which is used as part of the ensemble recommender
             * is defined at an index greater than RECOMMENDER_COUNT in the Recommender enum declaration,
             * then that recommender wont be considered as part of the weightage calculation
             * but a default weightage of DEFAULT_WEIGHT is returned instead.
             * This works perfect for the current definition of Recommender enum where
             * TG recommenders, Attribute, Attribute review, Geospatial and Enterprise recommenders are defined
             * as the first 9 recommenders and other recommenders which are not part of ensemble are defined
             * at indices above 9.
             */

            List<Recommender> recommenderList = Arrays.asList(Recommender.values());
            String combinationLabel = getRandomCombinationLabel();

            int[] randomizedWeights = generateWeights(combinationLabel);
            String weightageString = stringifyWeights(randomizedWeights);
            float[] weights = resetWeights(intToFloatArray(randomizedWeights), recommenderList, recommenders);

            @Override
            public float get(Recommender recommender) {
                int recommenderIndex = recommenderList.indexOf(recommender);
                if (recommenderIndex == -1) {
                    logger.warn("Unrecognized recommender {}: something went wrong", recommender);
                    return 0;
                } else if (recommenderIndex < weights.length) {
                    return weights[recommenderIndex];
                } else {
                    logger.info("Recommender {} lies out of combination label range: {}>{}", recommender,
                            recommenderIndex, weights.length);
                    logger.info("Using default weightage of {}", DEFAULT_WEIGHT);
                    return DEFAULT_WEIGHT;
                }
            }

            @Override
            public void normalizeWeights(Iterable<IRecommendBySearch> usedRecommenders) {
                weights = calculateWeights(recommenderList, usedRecommenders, weights);
                logger.debug("Weights after normalizing only used recommenders={}", Arrays.toString(weights));
            }

            @Override
            public String getCombinationLabel() {
                return combinationLabel;
            }

            @Override
            public String getLabelWeightageString() {
                return weightageString;
            }

        };
    }

    @Override
    public RecommenderWeights provideWeights(UserContext userContext, Object userProfile, Iterable<IRecommendBySearch> recommenders, Category category, RecommenderScenario recommenderScenario) {
        return provideWeights(userContext, userProfile, recommenders);
    }

}
