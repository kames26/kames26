/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.recommender.search.impl;

import java.util.Random;

import org.apache.mahout.math.Vector;
import org.apache.mahout.math.stats.Sampler;

/**
 * A random number generator with weighted distribution
 *
 */
class WeightedRandomizer {

    private final Vector weightage;
    private final Sampler sampler;

    public WeightedRandomizer(Vector weightage) {
        this.weightage = weightage;
        sampler = new Sampler(new Random(), weightage);
    }

    public int next() {
        int sample = sampler.sample();
        return sample;
    }

    public Vector getWeightage() {
        return weightage;
    }

}
