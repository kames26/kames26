/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.item.processor.spark.user;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.spark.HashPartitioner;
import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.mllib.linalg.Matrices;
import org.apache.spark.mllib.linalg.Vector;
import org.apache.spark.mllib.linalg.SparseVector;
import org.apache.spark.mllib.linalg.distributed.BlockMatrix;
import org.apache.spark.mllib.linalg.distributed.CoordinateMatrix;
import org.apache.spark.mllib.linalg.distributed.IndexedRow;
import org.apache.spark.mllib.linalg.distributed.IndexedRowMatrix;
import org.apache.spark.mllib.linalg.distributed.RowMatrix;
import org.apache.spark.sql.DataFrame;
import org.apache.spark.sql.SQLContext;
import org.apache.spark.storage.StorageLevel;

import com.clearspring.analytics.util.Lists;
import com.crayondata.choice.rateableitem.Category;
import com.crayondata.choice.rateableitem.CreativeWork;
import com.crayondata.choice.rateableitem.LocalBusiness;
import com.crayondata.choice.rateableitem.MayaRestaurant;
import com.crayondata.item.processor.LBRestaurantProcessor;
import com.crayondata.item.processor.RestaurantProcessor;
import com.crayondata.item.provider.impl.CachedItemProviderImpl;
import com.google.common.base.Optional;
import com.google.common.collect.ImmutableBiMap;
import com.google.common.collect.Iterables;

import scala.Tuple2;
import scala.Tuple3;
import scala.Tuple6;

/**
 * 
 * @author vivek
 *
 */
public class ContentBasedUserSimilarity<T> implements Serializable {
	
	private String itemIdsFile;
	private String userInteractionFile;
	private String solrHost;
	private Category category;
	
	private Map<Integer, Integer> itemIndices;
	private Map<String, Integer> userIndices;
	
	private ImmutableBiMap<Integer, Integer> itemIdToIndices;
	private ImmutableBiMap<Integer, Integer> indicesToItemIds;
	
	private ImmutableBiMap<String, Integer> userIdToIndices;
	private ImmutableBiMap<Integer, String> indicesToUserIds;
	
	private Map<String, Integer> cuisineDocFreq;
	private Map<String, Integer> optionsDocFreq;
	
	private Map<String, UserProfile> userProfileMap;
	
	private final String output_prefix = "target/output";
	
	private List<Integer> interactedItemIds;
	
	private static final int PARTITION_COUNT = 32;
	
	private static final int MIN_INTERACTIONS = 10;
	
	private static final double SIM_THRESHOLD = 0.5;
	
	private static final String sep = "|";
	
	private static final int topN = 10;
	
	
	public static void main(String[] args) {
		if(args.length < 4){
			System.err.println(" Usage: ContentBasedUserSimilarity <category> <item-id_file> <interaction-file> <solr-host> ");
			System.exit(1);
		}
		
		Category cat = Category.parseCategory(args[0]);
		ContentBasedUserSimilarity userSimilarity;
		if(cat.isLocalBusiness())
			userSimilarity = new ContentBasedUserSimilarity<LocalBusiness>(cat, args[1], args[2], args[3]);
		else 
			userSimilarity = new ContentBasedUserSimilarity<CreativeWork>(cat, args[1], args[2], args[3]);

		SparkConf conf = new SparkConf().setAppName("Item Similarity Application").set("spark.executor.memory", "32g")
                .set("spark.num.executors", "1")/*.set("spark.executor.cores", "7").*/.set("spark.total.executor.cores", "15")
                .set("spark.storage.memoryFraction", "0.1");
        JavaSparkContext sc = new JavaSparkContext(conf);
                
        long startTime = System.currentTimeMillis();
        
        userSimilarity.buildModel(sc);
        
        System.out.println(" Time taken:" + (System.currentTimeMillis() - startTime));
        
	}
	
	public ContentBasedUserSimilarity(Category cat, String itemIdsFile,
			String userInteractionFile, String solrHost) {
		super();
		this.category = cat;
		this.itemIdsFile = itemIdsFile;
		this.userInteractionFile = userInteractionFile;
		this.solrHost = solrHost;
	}
	
	public void buildModel(JavaSparkContext sc){
		JavaRDD<String> itemIdStr = sc.textFile(this.itemIdsFile).cache();
		List<Integer> itemIds = itemIdStr.map(x -> Integer.parseInt(x)).collect();
		
		JavaPairRDD<String, Integer> interactions = readReviewDataFromAvro(sc, this.userInteractionFile).partitionBy(new HashPartitioner(PARTITION_COUNT)).cache();
		JavaPairRDD<String, Vector> userItemVector = computeUserItemVector(itemIds, interactions, sc).partitionBy(new HashPartitioner(PARTITION_COUNT)).cache();
		
		JavaPairRDD<Integer, Vector> vectorRdd = computeVectorsForRestaurants(this.interactedItemIds, sc, userItemVector);
		
		
	}
	
	public JavaPairRDD<String, Vector> computeUserItemVector(List<Integer> itemIds2, JavaPairRDD<String, Integer> interactions, JavaSparkContext sc){
		/*final List<Integer> itemIds = interactions.values().distinct().collect();*/
		itemIndices = new HashMap<>();
		int index = 0;
		/*for(Integer id : itemIds){
			if(!itemIndices.containsKey(id)){
				itemIndices.put(id, index);
				index++;	
			}
		}*/
		
		for(Integer id : itemIds2){
			if(!itemIndices.containsKey(id)){
				itemIndices.put(id, index);
				index++;	
			}
		}
		
		System.out.println(".. Number of items::" + itemIds2.size());
		
		final List<String> userIds = interactions.keys().distinct().collect();
		userIndices = new HashMap<>();
		index = 0;
		for(String id : userIds){
			if(!userIndices.containsKey(id)){
				userIndices.put(id, index);
				index++;	
			}
		}
		
		System.out.println(".. Number of users::" + userIds.size());
		
		userIdToIndices = new ImmutableBiMap.Builder<String, Integer>().putAll(
				userIndices).build();
		indicesToUserIds = userIdToIndices.inverse();
		
		JavaPairRDD<String, Iterable<Integer>> grouped = 
				interactions.groupByKey();
		JavaPairRDD<String, Optional<List<Integer>>> filtered = grouped.mapToPair(x -> {
			String userId = x._1;
			Set<Integer> result = new HashSet<>();
			for(Integer itemId : x._2){
				if(itemIndices.containsKey(itemId))
					result.add(itemId);
			}
			if(result.isEmpty() || result.size() < MIN_INTERACTIONS)
				return new Tuple2<>(userId, Optional.absent());
			else{
				List<Integer> resultList = Lists.newArrayList();
				resultList.addAll(result);
				return new Tuple2<>(userId, Optional.of(resultList));
			}
		});
		
		JavaPairRDD<String, Integer> filteredInteractions = 
				filtered.filter(x -> x._2.isPresent()).flatMapToPair(  x -> {
			Collection<Tuple2<String, Integer>> result = Lists.newArrayList();
			x._2.get().forEach(y -> result.add(new Tuple2<>(x._1, y)));
			return result;
		}).cache();
		
		interactedItemIds = filteredInteractions.values().distinct().collect();
		itemIndices = new HashMap<>();
		
		index = 0;
		for(Integer id : interactedItemIds){
			if(!itemIndices.containsKey(id)){
				itemIndices.put(id, index);
				index++;	
			}
		}
		
		System.out.println(".. Number of interacted items::" + interactedItemIds.size());
		
		itemIdToIndices = new ImmutableBiMap.Builder<Integer, Integer>().putAll(
				itemIndices).build();
		indicesToItemIds = itemIdToIndices.inverse();
		
		JavaPairRDD<String, Iterable<Integer>> groupFiltered = filteredInteractions.groupByKey();
		System.out.println("... Number of users in groupFiltered.." + groupFiltered.count());
		
		construcUserProfiles(groupFiltered, sc);
		
		JavaPairRDD<String, Optional<Vector>> vectorOptRdd = groupFiltered.mapToPair(x -> {
			String userId = x._1;
			
			Set<Integer> indicesSet = new HashSet<>();
			for(Integer itemId : x._2){
				if(itemIndices.containsKey(itemId)){
					Integer itemIndex = itemIndices.get(itemId);
					indicesSet.add(itemIndex);
				}
			}
			int size = indicesSet.size();
			if(size < MIN_INTERACTIONS)
				return new Tuple2<>(userId, Optional.absent());
			double[] vals = new double[size];
			int[] indices = new int[size];
			indicesSet.iterator();
			int i=0; 
			for(Integer itemIndex : indicesSet){
				indices[i] = itemIndex;
				i++;
			}
			
			Arrays.fill(vals, 1);
			Vector result = new SparseVector(interactedItemIds.size(), indices, vals);
			return new Tuple2<>(userId,Optional.of(result));
		});
		
		JavaPairRDD<String, Vector> vectorRdd =   vectorOptRdd.filter( x -> x._2.isPresent()).mapToPair(x -> new Tuple2<>(x._1, x._2.get())).cache();
		
		System.out.println(".. Number of users:: after filtering::" + vectorRdd.count());
		
		this.userIndices = sc.broadcast(this.userIndices).getValue();
		this.itemIndices = sc.broadcast(this.itemIndices).getValue();
		
		this.userIdToIndices = sc.broadcast(this.userIdToIndices).getValue();
		this.indicesToUserIds = sc.broadcast(this.indicesToUserIds).getValue();
		
		this.itemIdToIndices = sc.broadcast(this.itemIdToIndices).getValue();
		this.indicesToItemIds = sc.broadcast(this.indicesToItemIds).getValue();
		this.interactedItemIds = sc.broadcast(this.interactedItemIds).getValue();
		
		return vectorRdd;
	}
	
	private void construcUserProfiles(JavaPairRDD<String, Iterable<Integer>> userItems, JavaSparkContext sc){
		/*JavaPairRDD<String, UserProfile> userProfilesRdd = userItems.mapToPair(x -> {
			String userId = x._1;
			Collection<Integer> itemIds = Lists.newArrayList();
			Iterables.addAll(itemIds, x._2);
			return new Tuple2<>(userId, new UserProfile(userId, itemIds));
		});*/
		/*this.userProfileMap = userProfilesRdd.collectAsMap();*/
		
		int totalItemCount = this.interactedItemIds.size();
		int likedItemCount = 0;
		
		this.userProfileMap = new HashMap<>();
		
		Map<String, Iterable<Integer>> userItemMap = userItems.collectAsMap();
		
		int index = 1;
		for(String userId : userItemMap.keySet()){
			Collection<Integer> itemIds = Lists.newArrayList();
			Iterables.addAll(itemIds, userItemMap.get(userId));
			likedItemCount = itemIds.size();
			this.userProfileMap.put(userId, new UserProfile(index,userId, itemIds));
			this.userProfileMap.get(userId).setLikedItemPerc(100.0f * likedItemCount/totalItemCount);
			index++;
		}
		
		/*this.userProfileMap = sc.broadcast(this.userProfileMap).getValue();*/
		System.out.println(".. Number of profiles created..:" + this.userProfileMap.size());
		System.out.println("Profile map:" + this.userProfileMap);
	}
	
	private CachedItemProviderImpl<T> initCache(List<Integer> itemIdList, Category cat){
    	CachedItemProviderImpl<T> itemProvider = new CachedItemProviderImpl<T>(cat, solrHost);
        itemProvider.constructCache(itemIdList);
        return itemProvider;
    }


	protected JavaPairRDD<String, Integer> readReviewDataFromAvro(JavaSparkContext sc, String fileUri) {
		/*System.out.println(" File name........::" + fileUri);*/
        SQLContext sqlContext = new SQLContext(sc);
        DataFrame df = sqlContext.read().format("com.databricks.spark.avro").load(fileUri);
        return df.javaRDD().mapToPair(x -> {
        	return new Tuple2<>(x.getString(1).intern(), x.getInt(0));	
        });
    }
	
	private JavaPairRDD<Integer, Vector> computeVectors(JavaPairRDD<Integer, LocalBusiness> objRDD,
            List<String> cuisinesList, List<String> optionsList, JavaPairRDD<String, Vector> userItemVector, JavaSparkContext sc){
        final LBRestaurantProcessor restProcessor = new LBRestaurantProcessor(cuisinesList, optionsList, cuisineDocFreq, optionsDocFreq);
        
       /* JavaPairRDD<Integer, Vector> vectorRDD = objRDD.mapToPair(input -> new Tuple2<Integer, Vector>(input._1, restProcessor.processRestaurant(input._2)));
        System.out.println(cuisinesList+"::OPTIONS::"+ optionsList+",PriceRange, AmbienceRating, FoodRating, ServiceRating, ValueRating, AggregateRating");
        
        saveVectors(vectorRDD, cuisinesList, optionsList);*/
        
        JavaPairRDD<Integer, Vector> ratingVector = objRDD.mapToPair(x -> new Tuple2<>(x._1, restProcessor.getRatingVector(x._2)));
        
        processRatingVectors(userItemVector, sc, ratingVector);
        
        /*JavaPairRDD<Integer, Vector> cuisineVector = objRDD.mapToPair(input -> new Tuple2<Integer, Vector>(input._1, restProcessor.computeCuisineVector(input._2)));*/
        JavaPairRDD<Integer, Vector> normalizedVector = objRDD.mapToPair(input -> new Tuple2<Integer, Vector>(input._1, restProcessor.getNormalizedVector(input._2)));
        JavaRDD<IndexedRow>  indexedRows = normalizedVector.map(x -> {
        	IndexedRow row = new IndexedRow(this.itemIndices.get(x._1), x._2);
        	return row;
        });
        
        saveUserItemVectors(userItemVector);
        /*saveCuisineVectors(cuisineVector, cuisinesList);*/
        saveNormalizedVectors(normalizedVector, cuisinesList, optionsList);
        
        broadcastRestMaps(restProcessor, sc);
        
        final IndexedRowMatrix optionCuisineMat = new IndexedRowMatrix(indexedRows.rdd());
        
        JavaRDD<IndexedRow> indexedUserRows = userItemVector.map(x ->{
        	IndexedRow row = new IndexedRow(this.userIndices.get(x._1), x._2);
        	return row;
        });
        final IndexedRowMatrix userMatrix = new IndexedRowMatrix(indexedUserRows.rdd());
        
       	BlockMatrix optionCuisineBlkMat = optionCuisineMat.toBlockMatrix();
       	BlockMatrix userBlkMat = userMatrix.toBlockMatrix();
        
     // User preference matrix ** ItemAttributeMatrix k users, n items, m attrs   k x n  ** n x m ---> k x m
       	BlockMatrix userOptionCuisineProfiles = userBlkMat.multiply(optionCuisineBlkMat).cache(); 
       	
       	System.out.println(".. Constructed user profiles..");
       	
       	saveUserProfileVectors(userOptionCuisineProfiles, cuisinesList, optionsList, restProcessor);
       	
       	System.out.println("User profile save completed..!");
       	
       	RowMatrix colMatrix = userOptionCuisineProfiles.toCoordinateMatrix().transpose().toRowMatrix();
       	System.out.println("Similarity computation started..");
       	CoordinateMatrix similarities = colMatrix.columnSimilarities(SIM_THRESHOLD);
       	
       	System.out.println("Similarity computation completed..");
        
       	JavaPairRDD<String, Collection<Tuple2<String, Double>>> lookupTable = constructLookup(similarities);
       	saveLookupTable(sc, lookupTable);
       	
       	return normalizedVector;
    }
	
	private void broadcastRestMaps(LBRestaurantProcessor restProcessor,
			JavaSparkContext sc) {
		restProcessor.setCuisineToIndexMap(sc.broadcast(restProcessor.getCuisineToIndexMap()).getValue());
		restProcessor.setOptionToIndexMap(sc.broadcast(restProcessor.getOptionToIndexMap()).getValue());
		
		restProcessor.setIndicesToCuisineMap(sc.broadcast(restProcessor.getIndicesToCuisineMap()).getValue());
		restProcessor.setIndicesToOptionMap(sc.broadcast(restProcessor.getIndicesToOptionMap()).getValue());
	}

	private void updateUserProfileWithRating(JavaPairRDD<String, Tuple6<Double, Double, Double, Double, Double, Double>> userRatingMap
		, JavaSparkContext sc){
		userRatingMap.collectAsMap().forEach((key,x) -> {
			UserProfile userProfile = this.userProfileMap.get(key);
			userProfile.setPriceRange(x._1().floatValue());
			userProfile.setAmbienceRating(x._2().floatValue());
			userProfile.setFoodRating(x._3().floatValue());
			userProfile.setServiceRating(x._4().floatValue());
			userProfile.setValueRating(x._5().floatValue());
			userProfile.setAggregatedRating(x._6().floatValue());
		});
		System.out.println(".. profile map:" + this.userProfileMap);
	}
	
	private void processRatingVectors(JavaPairRDD<String, Vector> userItemVector, JavaSparkContext sc, JavaPairRDD<Integer, Vector> itemRatingVector){
		final Map<String, Integer> userToItemCount = userItemVector.mapToPair(x -> new Tuple2<>(x._1, x._2.numNonzeros())).collectAsMap();
		JavaRDD<IndexedRow> indexedUserRows = userItemVector.map(x ->{
        	IndexedRow row = new IndexedRow(this.userIndices.get(x._1), x._2);
        	return row;
        });
        final IndexedRowMatrix userMatrix = new IndexedRowMatrix(indexedUserRows.rdd());
        
        JavaRDD<IndexedRow>  indexedRows = itemRatingVector.map(x -> {
        	IndexedRow row = new IndexedRow(this.itemIndices.get(x._1), x._2);
        	return row;
        });
        
        final IndexedRowMatrix ratingMatrix = new IndexedRowMatrix(indexedRows.rdd());
        
        BlockMatrix ratingBlkMatrix = ratingMatrix.toBlockMatrix();
       	BlockMatrix userBlkMat = userMatrix.toBlockMatrix();
       	
       	BlockMatrix userRatingProfile = userBlkMat.multiply(ratingBlkMatrix);
       	
       	JavaRDD<IndexedRow> rowsRdd = userRatingProfile.toIndexedRowMatrix().rows().toJavaRDD();
		JavaPairRDD<String, Vector> userRatingProfileVec = rowsRdd.mapToPair(x -> {
			String userId = indicesToUserIds.get(Integer.valueOf((int)x.index()));
			Vector vec = x.vector();
			return new Tuple2<>(userId, vec);
		});
		
		JavaPairRDD<String, Tuple6<Double, Double, Double, Double, Double, Double>> userRatingProfileVals = 
			userRatingProfileVec.mapToPair(x -> {
			String userId = x._1;
			double[] vals = x._2.toArray();
			int userItmCount = userToItemCount.get(userId);
			Tuple6<Double, Double, Double, Double, Double, Double> result = new Tuple6<>(vals[0]/userItmCount, vals[1]/userItmCount, vals[2]/userItmCount,  
					vals[3]/userItmCount, vals[4]/userItmCount, vals[5]/userItmCount);
			return new Tuple2<>(userId, result);
		});
		
		updateUserProfileWithRating(userRatingProfileVals, sc);
		
		userRatingProfileVals.map(x -> 
				 x._1+"," + x._2._1()+"," + x._2._2()+"," + x._2._3()+"," + x._2._4()+"," + x._2._5()+"," + x._2._6()).saveAsTextFile(output_prefix+"/UserRatingProfile");
	}
	
	private void saveLookupTable(JavaSparkContext sc, 
			JavaPairRDD<String, Collection<Tuple2<String, Double>>> lookupTable){
		JavaRDD<Tuple3<String, String, Double>> tuples = 
				lookupTable.flatMap(x -> {
			Collection<Tuple3<String, String, Double>> result = Lists.newArrayList();
			x._2.forEach(y -> result.add(new Tuple3<>(x._1,y._1,y._2)));
			return result;
		});
		
		UserSimilarityDAO similarityDAO = new UserSimilarityDAO();
		
		System.out.println(".. writing similarity into solr..");
		tuples.collect().forEach(x -> {
			String userFromId = String.valueOf(this.userProfileMap.get(x._1()).getId());
			String userToId = String.valueOf(this.userProfileMap.get(x._2()).getId());
			UserSimilarity similarity = new UserSimilarity(userFromId, userToId, 
					x._3().floatValue(), 0.0f);
			similarity.setId(userFromId+"||" +userToId);
			similarityDAO.addRecord(similarity);
		});
		
		System.out.println(".. writing similarity into solr.. completed..!!");
		
		JavaRDD<String> toPrint = tuples.map(x -> x._1()+","+x._2() + "," + x._3());
		toPrint.saveAsTextFile(output_prefix+"/UserSimilarities");
	}
	
	private JavaPairRDD<String, Collection<Tuple2<String, Double>>> constructLookup(CoordinateMatrix similarities){
		JavaPairRDD<String, Tuple2<String, Double>> user1To2Map = 
		    	similarities.entries().toJavaRDD().mapToPair(x -> {
		    	String user1Id = this.indicesToUserIds.get((int)x.i());
		    	String user2Id = this.indicesToUserIds.get((int)x.j());
		    	Double value = x.value();
		    	return new Tuple2<>(user1Id, new Tuple2<>(user2Id, value));
		    });
		
		return constructScoreLookupFrom(user1To2Map);
	}
	
	private JavaPairRDD<String, Collection<Tuple2<String, Double>>> constructScoreLookupFrom(
			JavaPairRDD<String, Tuple2<String, Double>> user1To2Map) {
	
		System.out.printf("Number of similarities:%d\n", user1To2Map.count());
	
		JavaPairRDD<String, Tuple2<String, Double>> filtered =  
				user1To2Map.filter(x -> {
					boolean retVal = true;
					if(x._1 == null || x._2 == null || x._2._1 == null || x._2._2 == null)
						retVal = false;
					return retVal;
				});
		System.out.printf("Number of similarities filtered:%d\n", filtered.count());
	
		JavaPairRDD<String, Iterable<Tuple2<String, Double>>> item1ScoresMap =  
				filtered.groupByKey();
		System.out.printf("Count after group by:%d\n", item1ScoresMap.count());
	
		JavaPairRDD<String, Collection<Tuple2<String,Double>>> lookupTable =
				item1ScoresMap.mapToPair(x -> {
					List<Tuple2<String, Double>> scoreCollection = new ArrayList<>();
					/*Iterables.addAll(scoreCollection, x._2);*/
					x._2.forEach(y -> scoreCollection.add(y));
					Collections.sort(scoreCollection, new SerializableTupleComaparator());
					Collection<Tuple2<String, Double>> retVal = 
							(scoreCollection.size() > topN)?new ArrayList<>(scoreCollection.subList(0, topN)): scoreCollection;
							return new Tuple2<>(x._1, retVal);
				});
	
		System.out.printf("Count of entries in lookup table :%d\n", lookupTable.count());
	
		return lookupTable.cache();
	}
	
	public class SerializableTupleComaparator implements Comparator<Tuple2<String, Double>>, Serializable {
    	private static final long serialVersionUID = 1L;

		@Override
    	public int compare(Tuple2<String, Double> o1, Tuple2<String, Double> o2) {
    		return o2._2.compareTo(o1._2);
    	}
    }
	
	private void saveUserItemVectors(JavaPairRDD<String, Vector> userItemVector){
		StringBuilder headerBuf = new StringBuilder();
		headerBuf.append("userId");
		for(int i=0;i<this.indicesToItemIds.size();i++){
			headerBuf.append(","+this.indicesToItemIds.get(i));
		}
		
		PrintStream ps;
		try {
			ps = new PrintStream(new FileOutputStream(output_prefix+ "/user_item_header.txt"));
			ps.println(headerBuf.toString());
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		
		JavaRDD<String> toPrint = userItemVector.map(x -> {
			String userId = x._1;
			Vector vec = x._2.toDense();
			StringBuilder buf = new StringBuilder();
			buf.append(userId);
			double[] vals = vec.toArray();
			for(double val: vals){
				buf.append(","+val);
			}
			/*list.stream().forEachOrdered(y -> buf.append(y+","));*/
			
			return buf.toString();
		});
		
		toPrint.saveAsTextFile(output_prefix + "/UserItemVectors");
	}
	
	private void updateUserProfileWithAttrs(JavaPairRDD<String, Vector> userProfileVec
			, List<String> cuisinesList, List<String> optionsList, LBRestaurantProcessor restProcessor){
		userProfileVec.collectAsMap().forEach((x,y) -> {
			String userId = x;
			UserProfile userProfile = this.userProfileMap.get(userId);
			Vector vec = y.toDense();
			double[] vals = vec.toArray();
			int cuisineSize = cuisinesList.size();
			int optionSize = optionsList.size();
			Collection<String> cuisineAndScore = Lists.newArrayList();
			Collection<String> optionAndScore = Lists.newArrayList();
			
			int cuisineCount = 0;
			int optionCount = 0;
			
			for(int i=0; i<vals.length;i++){
				double score =vals[i];
				String attr;
				if(score > 0){
					if(i<cuisineSize){
						attr = restProcessor.cuisineValFromIndex(i);
						cuisineAndScore.add(attr+sep+score);
						cuisineCount++;
					}else{
						attr = restProcessor.optionValFromIndex(i-cuisineSize);
						optionAndScore.add(attr+sep+score);
						optionCount++;
					}
					
				}
			}
			userProfile.setCuisineAndScore(cuisineAndScore);
			userProfile.setOptionAndScore(optionAndScore);
			userProfile.setCuisinePerc(100.0f * cuisineCount/cuisineSize);
			userProfile.setOptionPerc(100.0f * optionCount/optionSize);
			
			System.out.println("userId:"+ userId);
			System.out.println(cuisineAndScore);
		});
		
		System.out.println(" Updated.. user profiles after attr update..");
		System.out.println(this.userProfileMap);
		
		System.out.println(".. Writing user profiles into solr..");
		
		UserProfileDAO profileDAO = new UserProfileDAO();
		profileDAO.addRecords(this.userProfileMap.values());
		
		System.out.println(".. Writing user profiles into solr.. completed...");
	}
	
	private void saveUserProfileVectors(BlockMatrix userCuisineProfiles, List<String> cuisinesList, List<String> optionsList, LBRestaurantProcessor restProcessor){
		StringBuilder headerBuf = new StringBuilder();
		headerBuf.append("userId");
		cuisinesList.stream().forEachOrdered(x -> headerBuf.append(",cuisine_"+x));
		
		PrintStream ps;
		try {
			ps = new PrintStream(new FileOutputStream(output_prefix + "/user_profile_header.txt"));
			ps.println(headerBuf.toString());
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		
		JavaRDD<IndexedRow> rowsRdd = userCuisineProfiles.toIndexedRowMatrix().rows().toJavaRDD();
		JavaPairRDD<String, Vector> userProfileVec = rowsRdd.mapToPair(x -> {
			String userId = indicesToUserIds.get(Integer.valueOf((int)x.index()));
			Vector vec = x.vector();
			return new Tuple2<>(userId, vec);
		});
		
		updateUserProfileWithAttrs(userProfileVec, cuisinesList, optionsList, restProcessor);
		
		JavaRDD<String> toPrint = userProfileVec.map(x -> {
			String userId = x._1;
			Vector vec = x._2.toDense();
			StringBuilder buf = new StringBuilder();
			buf.append(userId);
			double[] vals = vec.toArray();
			for(double val: vals){
				buf.append(","+val);
			}
			/*list.stream().forEachOrdered(y -> buf.append(y+","));*/
			
			return buf.toString();
		});
		
		toPrint.saveAsTextFile(output_prefix + "/UserProfileVectors");
		
		
	}
	
	private void saveNormalizedVectors(JavaPairRDD<Integer, Vector> vectorRDD, 
			List<String> cuisinesList, List<String> optionsList){
		StringBuilder headerBuf = new StringBuilder();
		headerBuf.append("itemId");
		cuisinesList.stream().forEachOrdered(x -> headerBuf.append(",cuisine_"+x));
		optionsList.stream().forEachOrdered(x -> headerBuf.append(",option_"+x));
		System.out.println(".....Header Start....");
		PrintStream ps;
		try {
			ps = new PrintStream(new FileOutputStream(output_prefix + "/normalized_vector_header.txt"));
			ps.println(headerBuf.toString());
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		System.out.println(headerBuf.toString());
		System.out.println(".....Header End....");
		
		JavaRDD<String> toPrint = vectorRDD.map(x -> {
			int itemId = x._1;
			Vector vec = x._2.toDense();
			StringBuilder buf = new StringBuilder();
			buf.append(itemId);
			double[] vals = vec.toArray();
			for(double val: vals){
				buf.append(","+val);
			}
			/*list.stream().forEachOrdered(y -> buf.append(y+","));*/
			
			return buf.toString();
		});
		
		toPrint.saveAsTextFile(output_prefix + "/RestaurantNormalizedVectors");
	}
	
	private void saveCuisineVectors(JavaPairRDD<Integer, Vector> vectorRDD, List<String> cuisinesList){
		StringBuilder headerBuf = new StringBuilder();
		headerBuf.append("itemId");
		cuisinesList.stream().forEachOrdered(x -> headerBuf.append(",cuisine_"+x));
		System.out.println(".....Header Start....");
		PrintStream ps;
		try {
			ps = new PrintStream(new FileOutputStream(output_prefix + "/cuisine_vector_header.txt"));
			ps.println(headerBuf.toString());
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		System.out.println(headerBuf.toString());
		System.out.println(".....Header End....");
		
		JavaRDD<String> toPrint = vectorRDD.map(x -> {
			int itemId = x._1;
			Vector vec = x._2.toDense();
			StringBuilder buf = new StringBuilder();
			buf.append(itemId);
			double[] vals = vec.toArray();
			for(double val: vals){
				buf.append(","+val);
			}
			/*list.stream().forEachOrdered(y -> buf.append(y+","));*/
			
			return buf.toString();
		});
		
		toPrint.saveAsTextFile(output_prefix + "/RestaurantCuisineVectors");
	}
	
	private void saveVectors(JavaPairRDD<Integer, Vector> vectorRDD, List<String> cuisinesList, List<String> optionsList){
		StringBuilder headerBuf = new StringBuilder();
		headerBuf.append("itemId,");
		cuisinesList.stream().forEachOrdered(x -> headerBuf.append("cuisine_"+x+","));
		optionsList.stream().forEachOrdered(x -> headerBuf.append("option_"+x+","));
		headerBuf.append("PriceRange,").append("AmbienceRating,").append("FoodRating,").append("ServiceRating,").append("ValueRating,").append("AggregateRating");
		System.out.println(".....Header Start....");
		PrintStream ps;
		try {
			ps = new PrintStream(new FileOutputStream(output_prefix + "/vector_header.txt"));
			ps.println(headerBuf.toString());
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		System.out.println(headerBuf.toString());
		System.out.println(".....Header End....");
		
		JavaRDD<String> toPrint = vectorRDD.map(x -> {
			int itemId = x._1;
			Vector vec = x._2.toDense();
			StringBuilder buf = new StringBuilder();
			buf.append(itemId);
			double[] vals = vec.toArray();
			for(double val: vals){
				buf.append(","+val);
			}
			/*list.stream().forEachOrdered(y -> buf.append(y+","));*/
			
			return buf.toString();
		});
		
		toPrint.saveAsTextFile(output_prefix + "/RestaurantVectors");
	}
	
	protected JavaPairRDD<Integer, Vector> computeVectorsForRestaurants(List<Integer> itemIdList,
    		JavaSparkContext sc, JavaPairRDD<String, Vector> userItemVector){
		
		System.out.println(" Computing vectors for:" + itemIdList.size());
		
    	CachedItemProviderImpl<T> itemProvider = initCache(itemIdList, this.category);

    	JavaRDD<Integer> itemIdsRdd = 
    			sc.parallelize(itemIdList);
    	JavaPairRDD<Integer, T> itemsMapRdd = 
    			itemIdsRdd.mapToPair(x -> new Tuple2<>(x, itemProvider.getItem(x)));

    	JavaPairRDD<Integer, LocalBusiness> restRdd = (JavaPairRDD<Integer, LocalBusiness>) itemsMapRdd;


    	JavaRDD<Collection<String>> cuisineRdd = restRdd.map(input -> /*LBRestaurantProcessor.getList(*/input._2.getCuisines());//);	
    	JavaRDD<Collection<String>> optionsRdd = restRdd.map(input -> /*LBRestaurantProcessor.getList(*/input._2.getOptions());//);
    	
    	List<String> cuisineList = getUniqueStrings(cuisineRdd, true, sc);
    	List<String> optionsList = getUniqueStrings(optionsRdd, false, sc);
    	
    	JavaPairRDD<Integer, Vector> vectorRDD = computeVectors(restRdd, cuisineList, optionsList, userItemVector, sc).persist(StorageLevel.DISK_ONLY());
    	
    	 System.out.println(".. Vector computation completed..");
    	return vectorRDD;
    }
    
    private List<String> getUniqueStrings(JavaRDD<Collection<String>> strListRDD, boolean forCuisine, JavaSparkContext sc){
        
        JavaRDD<Collection<String>> lowerCuisineListRDD = strListRDD.map(new Function<Collection<String>, Collection<String>>(){
            @Override
            public Collection<String> call(Collection<String> input) throws Exception {
                Collection<String> result = new ArrayList<String>();
                for(String cuisine : input){
                    result.add(cuisine.toLowerCase());
                }
                return result;
            }
        });
        Collection<String> zeroVal = new ArrayList<>();
        Collection<String> uniqStrList = lowerCuisineListRDD.fold(zeroVal, 
        		(x, y) -> {
        			Collection<String> result = new ArrayList<>();
        			x.stream().forEach(z -> 
        			{
        				if(!result.contains(z))
        					result.add(z);
        			});
        			y.stream().forEach(z -> 
        			{
        				if(!result.contains(z))
        					result.add(z);
        			});
        			
        			return result;
        		});
        /*JavaRDD<String> allStrRDD = lowerCuisineListRDD.flatMap(input -> input);
        System.out.println(allStrRDD.take(10));
        JavaRDD<String> distinctStrRDD = allStrRDD.distinct();*/
        
        JavaPairRDD<String, Integer> mapRdd =  lowerCuisineListRDD.flatMapToPair(x -> {
        	Collection<Tuple2<String, Integer>> result = Lists.newArrayList();
        	x.forEach(y -> result.add(new Tuple2<>(y,1)));
        	return result;
        });
        
        if(forCuisine){
        	this.cuisineDocFreq = 
        			mapRdd.reduceByKey((x,y) -> x+y).collectAsMap();
        	this.cuisineDocFreq = sc.broadcast(this.cuisineDocFreq).getValue();
        }else{
        	this.optionsDocFreq = 
        			mapRdd.reduceByKey((x,y) -> x+y).collectAsMap();
        	this.optionsDocFreq = sc.broadcast(this.optionsDocFreq).getValue();
        }
        
        List<String> uniqList = new ArrayList<>();
        uniqList.addAll(uniqStrList);
        System.out.println("uniqSize:" + uniqList.size());
        return uniqList;
    }

}
