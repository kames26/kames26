/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.item.processor;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.spark.mllib.linalg.SparseVector;
import org.apache.spark.mllib.linalg.Vector;

import com.crayondata.choice.rateableitem.LocalBusiness;
import com.google.common.base.Optional;
import com.google.common.collect.ImmutableBiMap;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Maps;

/**
 * 
 * @author vivek
 *
 */
public class LBRestaurantProcessor implements Serializable {
    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    
    private Map<String, Integer> cuisineIndexMap;
    private Map<String, Integer> optionIndexMap;
    
    private final Collection<String> uniqCusinesList;
    private final Collection<String> uniqOptionsList;
    
    private Map<String,Double> priceRangeValues; 
    private static final int BIN_SIZE = 10;
    private static final int RATING_COUNT = 5;
    
    private ImmutableBiMap<String, Integer> cuisineToIndexMap;
	private ImmutableBiMap<Integer, String> indicesToCuisineMap;
	
	private ImmutableBiMap<String, Integer> optionToIndexMap;
	private ImmutableBiMap<Integer, String> indicesToOptionMap;
	
	private Map<String, Integer> cuisineDocFreq;
	private Map<String, Integer> optionsDocFreq;
	
	
	public String cuisineValFromIndex(Integer index){
		return this.indicesToCuisineMap.get(index);
	}
	
	public String optionValFromIndex(Integer index){
		return this.indicesToOptionMap.get(index);
	}
	
	public ImmutableBiMap<String, Integer> getCuisineToIndexMap() {
		return cuisineToIndexMap;
	}

	public void setCuisineToIndexMap(
			ImmutableBiMap<String, Integer> cuisineToIndexMap) {
		this.cuisineToIndexMap = cuisineToIndexMap;
	}

	public ImmutableBiMap<Integer, String> getIndicesToCuisineMap() {
		return indicesToCuisineMap;
	}

	public void setIndicesToCuisineMap(
			ImmutableBiMap<Integer, String> indicesToCuisineMap) {
		this.indicesToCuisineMap = indicesToCuisineMap;
	}

	public ImmutableBiMap<String, Integer> getOptionToIndexMap() {
		return optionToIndexMap;
	}

	public void setOptionToIndexMap(ImmutableBiMap<String, Integer> optionToIndexMap) {
		this.optionToIndexMap = optionToIndexMap;
	}

	public ImmutableBiMap<Integer, String> getIndicesToOptionMap() {
		return indicesToOptionMap;
	}

	public void setIndicesToOptionMap(
			ImmutableBiMap<Integer, String> indicesToOptionMap) {
		this.indicesToOptionMap = indicesToOptionMap;
	}

	public LBRestaurantProcessor(Collection<String> uniqCusinesList,
			Collection<String> uniqOptionsList,
			Map<String, Integer> cuisineDocFreq,
			Map<String, Integer> optionsDocFreq) {
		super();
		this.uniqCusinesList = uniqCusinesList;
		this.uniqOptionsList = uniqOptionsList;
		this.cuisineDocFreq = cuisineDocFreq;
		this.optionsDocFreq = optionsDocFreq;
		init();
	}

    private void init(){
        indexUniqCuisines();
        indexUniqOptions();
        priceRangeValues = ImmutableMap.of("Low", 1.0, "Medium", 2.0, "High", 3.0, "Very High", 4.0);
    }
    
    private void indexUniqCuisines(){
        cuisineIndexMap = Maps.newHashMap();
        int cuisineIndex = 0;
        for(String cuisine : this.uniqCusinesList){
            cuisineIndexMap.put(cuisine, cuisineIndex);
            cuisineIndex++;
        }
        
        cuisineToIndexMap = new ImmutableBiMap.Builder<String, Integer>().putAll(
        		cuisineIndexMap).build();
        indicesToCuisineMap = cuisineToIndexMap.inverse();
    }
    
    private void indexUniqOptions(){
        optionIndexMap = Maps.newHashMap();
        int optionIndex = 0;
        for(String option : this.uniqOptionsList){
            optionIndexMap.put(option, optionIndex);
            optionIndex++;
        }
        
        optionToIndexMap = new ImmutableBiMap.Builder<String, Integer>().putAll(
        		optionIndexMap).build();
        indicesToOptionMap = optionToIndexMap.inverse();
    }
    
    public Vector computeCuisineVector(LocalBusiness restaurant){
    	Vector result;
    	Optional<int[]> cuisinesIndices = getCuisinesIndices(restaurant);
    	Optional<int[]> cuisineDFs = getCuisinesDF(restaurant);
    	if(cuisinesIndices.isPresent()){
    		int[] indices = cuisinesIndices.get();
    		int[] dfs = cuisineDFs.get();
    		double[] vals = new double[indices.length];
    		
    		double sqrtLen = Math.sqrt(indices.length);
    		
    		/*Arrays.fill(vals, 1.0/indices.length);*/
    		for(int i=0;i<indices.length;i++){
    			vals[i] = 1.0/(sqrtLen*dfs[i]);
    		}
    		
    		result = new SparseVector(this.uniqCusinesList.size(), indices, vals);
    	}else
    		result = new SparseVector(this.uniqCusinesList.size(), new int[0], new double[0]);
    	
    	return result;
    }
    
    public Vector computeOptionsVector(LocalBusiness restaurant){
    	Vector result;
    	Optional<int[]> optionsIndices = getOptionsIndices(restaurant,0);
    	Optional<int[]> optionsDFs = getOptionsDF(restaurant);
    	if(optionsIndices.isPresent()){
    		int[] indices = optionsIndices.get();
    		double[] vals = new double[indices.length];
    		int[] dfs = optionsDFs.get();
    		
    		/*Arrays.fill(vals,1);*/
    		for(int i=0;i<indices.length;i++){
    			vals[i] = 1.0/(indices.length*dfs[i]);
    		}
    		result = new SparseVector(this.uniqOptionsList.size(), indices, vals);
    	}else
    		result = new SparseVector(this.uniqOptionsList.size(), new int[0], new double[0]);
    	
    	return result;
    }
    
    public Vector computePrieRangeAndRatingVector(LocalBusiness restaurant){
    	int[] indices = getPriceAndRatingIndices(0);
    	double[] vals = getPriceAndRatingVals(restaurant);
    	Vector result = new SparseVector(RATING_COUNT+1, indices, vals);
    	
    	return result;
    }
    
    public Vector getNormalizedVector(LocalBusiness restaurant){
    	Vector result;
    	int size = this.uniqCusinesList.size() + this.uniqOptionsList.size();
    	int optionsOffset = this.uniqCusinesList.size();
        Optional<int[]> cuisinesIndices = getCuisinesIndices(restaurant);
        Optional<int[]> optionsIndices = getOptionsIndices(restaurant, optionsOffset);
        Optional<int[]> mergedIndices = getMergedIndices(cuisinesIndices, optionsIndices);
        Optional<int[]> cuisineDFs = getCuisinesDF(restaurant);
        Optional<int[]> optionDFs = getOptionsDF(restaurant);
        if(mergedIndices.isPresent()){
        	int[] indices = mergedIndices.get();
        	double[] vals = new double[indices.length];
        	int i=0;
        	if(cuisinesIndices.isPresent()){
        		int[] dfs = cuisineDFs.get();
        		int cusineLen = cuisinesIndices.get().length;
        		for(;i<cusineLen;i++){
        			vals[i] = 1.0/(cusineLen*dfs[i]);
        		}
        	}
        	if(optionsIndices.isPresent()){
        		int[] dfs = optionDFs.get();
        		int optionLen = optionsIndices.get().length;
        		for(;i<optionLen;i++){
        			vals[i] = 1.0/(optionLen*dfs[i]);
        		}
        	}
        	result = new SparseVector(size, indices, vals);
        }else
        	result = new SparseVector(size, new int[0], new double[0]);
        
        return result;
    }

    
    public Vector processRestaurant(LocalBusiness restaurant){
        int size = this.uniqCusinesList.size() + this.uniqOptionsList.size()+RATING_COUNT+1;
        int optionsOffset = this.uniqCusinesList.size();
        Optional<int[]> cuisinesIndices = getCuisinesIndices(restaurant);
        Optional<int[]> optionsIndices = getOptionsIndices(restaurant, optionsOffset);
        Optional<int[]> mergedIndices = getMergedIndices(cuisinesIndices, optionsIndices);
        
        int[] priceAndRatingIndices = getPriceAndRatingIndices(optionsOffset+uniqOptionsList.size());
        double[] priceAndRatingVals = getPriceAndRatingVals(restaurant);
        
        int[] indices;
        double[] values;
        
        if(mergedIndices.isPresent()){
            int[] cuisineAndOptionIndices = mergedIndices.get();
            double[] cuisineAndOptionVals = new double[cuisineAndOptionIndices.length];
            Arrays.fill(cuisineAndOptionVals, 1);
            indices = new int[cuisineAndOptionIndices.length + priceAndRatingIndices.length];
            values = new double[cuisineAndOptionIndices.length + priceAndRatingIndices.length];
            
            System.arraycopy(cuisineAndOptionIndices, 0, indices, 0, cuisineAndOptionIndices.length);
            System.arraycopy(priceAndRatingIndices, 0, indices, cuisineAndOptionIndices.length, priceAndRatingIndices.length);
            
            System.arraycopy(cuisineAndOptionVals, 0, values, 0, cuisineAndOptionVals.length);
            System.arraycopy(priceAndRatingVals, 0, values, cuisineAndOptionVals.length, priceAndRatingVals.length);
        }else{
            indices = priceAndRatingIndices;
            values = priceAndRatingVals;
        }
            
        Vector result = new SparseVector(size, indices, values);
        
        return result;
    }
    
    public Vector getRatingVector(LocalBusiness restaurant){
    	int[] priceAndRatingIndices = getPriceAndRatingIndices(0);
        double[] priceAndRatingVals = getPriceAndRatingVals(restaurant);
        Vector result = new SparseVector(priceAndRatingIndices.length, priceAndRatingIndices, priceAndRatingVals);
        
        return result;
    }
    
    private int[] getPriceAndRatingIndices(int offset){
        int[] result = new int[RATING_COUNT+1];
        for(int i=0;i < result.length;i++)
            result[i] = offset+i;
        return result;
    }
    
    private double[] getPriceAndRatingVals(LocalBusiness restaurant){
        double[] result = new double[RATING_COUNT+1];
        result[0] = 0;
        if(priceRangeValues.containsKey(restaurant.getPriceRange()))
            result[0] = priceRangeValues.get(restaurant.getPriceRange());
        result[1] = restaurant.getAmbienceRating()/BIN_SIZE;
        result[2] = restaurant.getFoodRating()/BIN_SIZE;
        result[3] = restaurant.getServiceRating()/BIN_SIZE;
        result[4] = restaurant.getValueRating()/BIN_SIZE;
        result[5] = restaurant.getAggregateRating()/BIN_SIZE;
        
        return result;
    }
    
    private Optional<int[]> getMergedIndices(Optional<int[]> cuisinesIndices,
            Optional<int[]> optionsIndices){
        if(cuisinesIndices.isPresent() && optionsIndices.isPresent()){
            int[] cuisineIdexArr = cuisinesIndices.get();
            int[] optionIndexArr = optionsIndices.get();
            int[] result = new int[cuisineIdexArr.length + optionIndexArr.length];
            System.arraycopy(cuisineIdexArr, 0, result, 0, cuisineIdexArr.length);
            System.arraycopy(optionIndexArr, 0, result, cuisineIdexArr.length, optionIndexArr.length);
            return Optional.of(result);
        }
        else if(cuisinesIndices.isPresent())
            return Optional.of(cuisinesIndices.get());
        else if(optionsIndices.isPresent())
            return Optional.of(optionsIndices.get());
        else
            return Optional.absent();
    }
    
    private Optional<int[]> getCuisinesIndices(LocalBusiness restaurant){
        Collection<String> cuisines = /*getList(*/restaurant.getCuisines();//);
        if(cuisines.isEmpty())
            return Optional.absent();
        int[] result = new int[cuisines.size()];
        int index = 0;
        for(String cuisine : cuisines){
            result[index] = cuisineIndexMap.get(cuisine.toLowerCase());
            index++;
        }
        return Optional.of(result);
    }
    
    private Optional<int[]> getCuisinesDF(LocalBusiness restaurant){
        Collection<String> cuisines = /*getList(*/restaurant.getCuisines();//);
        if(cuisines.isEmpty())
            return Optional.absent();
        int[] result = new int[cuisines.size()];
        int index = 0;
        for(String cuisine : cuisines){
            result[index] = this.cuisineDocFreq.get(cuisine.toLowerCase());
            index++;
        }
        return Optional.of(result);
    }
    
    private Optional<int[]> getOptionsIndices(LocalBusiness restaurant, int offset){
        Collection<String> options = /*getList(*/restaurant.getOptions();//);
        if(options.isEmpty())
            return Optional.absent();
        int[] result = new int[options.size()];
        int index = 0;
        for(String option : options){
            result[index] = optionIndexMap.get(option.toLowerCase())+offset;
            index++;
        }
        return Optional.of(result);
    }
    
    private Optional<int[]> getOptionsDF(LocalBusiness restaurant){
        Collection<String> options = /*getList(*/restaurant.getOptions();//);
        if(options.isEmpty())
            return Optional.absent();
        int[] result = new int[options.size()];
        int index = 0;
        for(String option : options){
            result[index] = this.optionsDocFreq.get(option.toLowerCase());
            index++;
        }
        return Optional.of(result);
    }
    
    /*public static Collection<String> getList(Collection<String> list){
    	Collection<String> result =  new ArrayList<>();
    	if(!list.isEmpty()){
    		String[] tokens = list.iterator().next().split(",");
    		for(String token : tokens){
    			result.add(token);
    		}
    	}
    	
    	return result;
    }*/

}
