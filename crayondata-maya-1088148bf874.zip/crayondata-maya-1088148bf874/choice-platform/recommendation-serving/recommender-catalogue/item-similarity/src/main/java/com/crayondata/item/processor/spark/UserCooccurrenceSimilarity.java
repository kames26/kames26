/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.item.processor.spark;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.collections.CollectionUtils;
import org.apache.spark.HashPartitioner;
import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.mllib.linalg.SparseVector;
import org.apache.spark.mllib.linalg.Vector;
import org.apache.spark.mllib.linalg.distributed.CoordinateMatrix;
import org.apache.spark.mllib.linalg.distributed.RowMatrix;
import org.apache.spark.sql.DataFrame;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SQLContext;
import org.apache.spark.sql.functions;
import org.apache.spark.storage.StorageLevel;

import scala.Tuple2;

import com.clearspring.analytics.util.Lists;
import com.google.common.base.Optional;
import com.google.common.collect.Iterables;
import com.google.common.collect.Sets;

/**
 * 
 * @author vivek
 *
 */
public class UserCooccurrenceSimilarity extends ItemSimilarityProcessor implements Serializable {
	
	private static String TRAIN_FILE =  "data/train.avro";
    private static int NUM_PARTITIONS = 1024;
    private static int TOP_N = 200;
    private static String OUTPUT = "output";
    private static double SIM_THRESHOLD = 0.3;
    private static Optional<String> MODEL_FILE_URI=Optional.absent();
    
    private String trainFileUri;
    private int topN;
    private String ouputDir;
    private int numPartitions; 
    private double simThreshold;
    private Optional<String> modelFileUri;
    
    /*private Map<Integer, Collection<Tuple2<Integer, Double>>> lookupMap;*/
    
    private final ISimilarityScoreLookupUtil lookupUtil;
	private JavaPairRDD<Integer, Collection<Tuple2<Integer, Double>>> lookupTable;

    public UserCooccurrenceSimilarity(String trainFileUri, int topN, String outputDir, 
    		double simThreshold, int numPartitions, Optional<String> modelFileUri){
    	this.trainFileUri = trainFileUri;
    	this.topN = topN;
    	this.ouputDir = outputDir;
    	this.simThreshold = simThreshold;
    	this.numPartitions = numPartitions;
    	this.modelFileUri = modelFileUri;
    	this.lookupUtil = new SimilarityScoreLookupUtil(topN, numPartitions);
    }
    
	public static void main(String[] args) {
		if(args.length < 5){
			System.err.println("Usage:: UserCooccurrenceSimilarity <train-file-uri> <top-n-similarities> <output> "
					+ "<sim-threshold> <num-partitions> [model-fileuril]");
			System.exit(1);
		}
		TRAIN_FILE = args[0];
		TOP_N = Integer.parseInt(args[1]);
		OUTPUT = args[2];
		SIM_THRESHOLD = Double.parseDouble(args[3]);
		NUM_PARTITIONS = Integer.parseInt(args[4]);
		
		if(args.length >= 6){
			MODEL_FILE_URI = Optional.of(args[5]);
		}
		UserCooccurrenceSimilarity similarityProcessor = 
				new UserCooccurrenceSimilarity(TRAIN_FILE, TOP_N, OUTPUT, SIM_THRESHOLD, NUM_PARTITIONS, MODEL_FILE_URI);
		
        SparkConf conf = new SparkConf().setAppName("User Cooccurrence Similarity applition").set("spark.executor.memory", "64g")
                .set("spark.num.executors", "1")/*.set("spark.executor.cores", "7").*/.set("spark.total.executor.cores", "15")
                .set("spark.storage.memoryFraction", "0.1");
        JavaSparkContext sc = new JavaSparkContext(conf);

		similarityProcessor.loadModel(sc);
	}
	
	public void loadModel(JavaSparkContext sc) {
		if(modelFileUri.isPresent()){
			System.out.println(" Loading model from location:" + modelFileUri.get());
			this.lookupTable = this.lookupUtil.loadScoreLookupFrom(modelFileUri.get(), sc).cache()/*.persist(StorageLevel.DISK_ONLY())*/;
			System.out.printf(".. Number of lookup table entries loaded from file:%d::%s\n", 
					this.lookupTable.count(), modelFileUri.get());
			/*this.lookupMap  =
					this.lookupTable.collectAsMap();*/
		}else
			buildModel(sc);
	}

	public void buildModel(JavaSparkContext sc){
		this.lookupTable = this.constructLookupTable(sc);
		System.out.printf(".. Lookup table consutructed with:%d entries\n",this.lookupTable.count());
		/*this.lookupMap = this.lookupTable.collectAsMap();*/
	}
	
	protected JavaPairRDD<Integer, String> readReviewDataFromAvro(JavaSparkContext sc, String fileUri) {
        SQLContext sqlContext = new SQLContext(sc);
        DataFrame df = sqlContext.read().format("com.databricks.spark.avro").load(fileUri);
        return df.javaRDD().mapToPair(x -> new Tuple2<>(x.getInt(0), x.getString(1).intern()));
    }
	
	public JavaPairRDD<Integer, Collection<Tuple2<Integer, Double>>> constructLookupTable(JavaSparkContext sc){
		JavaPairRDD<Integer, String> interactionRdd = readReviewDataFromAvro(sc, this.trainFileUri).
				partitionBy(new HashPartitioner(numPartitions)).persist(StorageLevel.DISK_ONLY());
		JavaPairRDD<Integer, Integer> itemIdToIndexMap  = createIdToIndexMap(sc,
				interactionRdd.keys().distinct()).cache();
		Map<String, Integer> userIdToIndexMap = createUserToIndexMap(sc, 
				interactionRdd.values().distinct())/*.cache()*/;
		
		System.out.println("Number of unique users:" + userIdToIndexMap.size());
		System.out.println("Number of unique items:" + itemIdToIndexMap.count());
		
		JavaPairRDD<Integer, Vector> itemToUserVectors = constructVectors(interactionRdd, userIdToIndexMap);
		itemToUserVectors.saveAsTextFile(this.ouputDir+"/Vectors");
		
		RowMatrix transposedMatrix = this.lookupUtil.constructTransposedRowMatrix(itemToUserVectors, itemIdToIndexMap);
		
		System.out.println(".. Matrix construction completed..");
        
        CoordinateMatrix similarities = transposedMatrix.columnSimilarities(this.simThreshold);
        
        this.lookupUtil.saveSimilarities(similarities, itemIdToIndexMap, this.ouputDir);
        
        return this.lookupUtil.constructScoreLookup(similarities, itemIdToIndexMap);
	}
	
	/**
	 * Constructing vector with item id/index as key and user id index values as vectors 
	 * @param interactionRdd
	 * @param userToIndexRdd
	 * @return
	 */
	private JavaPairRDD<Integer, Vector> constructVectors(JavaPairRDD<Integer, String> interactionRdd,
			Map<String, Integer> userToIndexMap){
		/*Map<String, Integer>  userToIndexMap = userToIndexRdd.collectAsMap();*/
		System.out.println(" Constructing vectors..");
		System.out.println(" User to index map size"+ userToIndexMap.size());
		JavaPairRDD<Integer, Integer> itemToUserIndexMap = 
				interactionRdd.mapToPair(x -> new Tuple2<>(x._1, userToIndexMap.get(x._2)));
		itemToUserIndexMap.saveAsTextFile(this.ouputDir+"/ItemToUserIndex");
		JavaPairRDD<Integer, Iterable<Integer>> groupedItemRdd = itemToUserIndexMap.groupByKey();
		JavaPairRDD<Integer, Vector> itemToUserVector = groupedItemRdd.mapToPair(x -> {
			
			Set<Integer> indicesSet = Sets.newHashSet();
			Iterables.addAll(indicesSet, x._2);// Adding to Set to remove duplicates..
			int[] indices = new int[indicesSet.size()];
			Iterator<Integer> iter = indicesSet.iterator();
			for(int i=0;i<indices.length;i++){
				indices[i]=iter.next().intValue();
			}
			double[] values = new double[indices.length];
			Arrays.fill(values, 1.0);
			int size = userToIndexMap.size();
			Vector rowVec = new SparseVector(size, indices, values);
			
			return new Tuple2<>(x._1,rowVec);
		});
		
		return itemToUserVector;
	}
	
	private Map<String, Integer> createUserToIndexMap(JavaSparkContext jc, 
    		JavaRDD<String> userdsRdd){
    	List<String> userIds = userdsRdd.collect();
        /*itemIdToIndexMap = Maps.newHashMap();*/
        List<Tuple2<String, Integer>> tuples = new ArrayList<>();
        int index = 0;
        System.err.println("Creating user to index map:");
        for(String userId : userIds){
            tuples.add(new Tuple2<>(userId, index));
            System.err.printf("userid:%s\tindex:%d\n", userId, index);
            index++;
        }
        
        System.out.println(" Max index created.." + index);
        /*System.err.println(".. User id to index map created.."+tuples);*/
        JavaPairRDD<String, Integer> userIdToIndices = jc.parallelizePairs(tuples);
        userIdToIndices.saveAsTextFile(this.ouputDir+"/UserToIndex");
        
        return userIdToIndices.collectAsMap();
    }
	
	private JavaPairRDD<Integer, Integer> createIdToIndexMap(JavaSparkContext jc, 
    		JavaRDD<Integer> itemIdsRdd){
    	List<Integer> itemIds = itemIdsRdd.collect();
        /*itemIdToIndexMap = Maps.newHashMap();*/
        List<Tuple2<Integer, Integer>> tuples = new ArrayList<>();
        int index = 0;
        System.err.println("Creating item to index map:");
        for(Integer itemId : itemIds){
            tuples.add(new Tuple2<>(itemId, index));
            index++;
        }
        
        System.out.println(" Max item index created.." + index);
        /*System.err.println(".. Id to index map created.."+tuples);*/
        
        return jc.parallelizePairs(tuples);
    }
	
	class SerializableTupleComaparator implements Comparator<Tuple2<Integer, Double>>, Serializable {
    	private static final long serialVersionUID = 1L;

		@Override
    	public int compare(Tuple2<Integer, Double> o1, Tuple2<Integer, Double> o2) {
    		return o1._2.compareTo(o2._2);
    	}
    }
	
	/*public List<Integer> getOrderedChoices(List<Integer> itemIds) {
		return this.lookupUtil.getOrderedChoices(itemIds, lookupMap);
	}*/
	
	public JavaPairRDD<Integer, Collection<Tuple2<Integer, Double>>> getLookupTable(){
		return this.lookupTable;
	}
	
	public DataFrame getLookupDataFrame(JavaSparkContext sc){
		JavaPairRDD<Integer, Tuple2<Integer, Double>> pairedLookup = 
				lookupTable.flatMapToPair(x -> {
			List<Tuple2<Integer, Tuple2<Integer, Double>>> tuples = new ArrayList<>();
			x._2.forEach(y -> tuples.add(new Tuple2<>(x._1, y)));
    		return tuples;
		}).partitionBy(new HashPartitioner(numPartitions)).persist(StorageLevel.DISK_ONLY());
		
		JavaRDD<ScoredPair> scoredPairs = pairedLookup.map(x -> new ScoredPair(x._1.intValue(), 
				x._2._1.intValue(), x._2._2.doubleValue()));
		
		SQLContext sqlContext = new SQLContext(sc);
		DataFrame scoredPairDF = sqlContext.createDataFrame(scoredPairs, ScoredPair.class);
		
		return scoredPairDF;
	}
	
	
	public class ScoredPair{
		private int itemFromId;
		private int itemToId;
		private double similarityScore;
		
		public ScoredPair(){}
		public ScoredPair(int itemFromId, int itemToId,
				double similarityScore) {
			super();
			this.itemFromId = itemFromId;
			this.itemToId = itemToId;
			this.similarityScore = similarityScore;
		}
		public int getItemFromId() {
			return itemFromId;
		}
		public void setItemFromId(int itemFromId) {
			this.itemFromId = itemFromId;
		}
		public int getItemToId() {
			return itemToId;
		}
		public void setItemToId(int itemToId) {
			this.itemToId = itemToId;
		}
		public double getSimilarityScore() {
			return similarityScore;
		}
		public void setSimilarityScore(double similarityScore) {
			this.similarityScore = similarityScore;
		}
		
		
	}

}
