/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.item.processor.spark.user;

import java.io.Serializable;
import java.util.Collection;

import org.apache.solr.client.solrj.beans.Field;

public class UserProfile implements Serializable {
	
	@Field("id")
	private int id;
	
	@Field("UserId")
	String userId;
	@Field("Items")
	Collection<Integer> items; // IDs of the restaurants user rated
	@Field("CuisineAndScore")
	Collection<String> cuisineAndScore; // cuisines and scores
	
	@Field("OptionAndScore")
	Collection<String> optionAndScore;
	
	@Field("PriceRange")
	private float priceRange;
	
	@Field("AmbienceRating")
	private float ambienceRating;
	
	@Field("FoodRating")
	private float foodRating;
	
	@Field("ServiceRating")
	private float serviceRating;
	
	@Field("ValueRating")
	private float valueRating;
	
	@Field("AggregatedRating")
	private float aggregatedRating;
	
	@Field("CuisinePerc")
	private float cuisinePerc;
	
	@Field("OptionPerc")
	private float optionPerc;
	
	@Field("LikedItemPerc")
	private float likedItemPerc;
	
	public UserProfile(){
		
	}
	
	public UserProfile(int id,String userId, Collection<Integer> items) {
		super();
		this.id = id;
		this.userId = userId;
		this.items = items;
	}

	public UserProfile(String userId, Collection<Integer> items,
			Collection<String> attributeAndScoreMap) {
		super();
		this.userId = userId;
		this.items = items;
		this.cuisineAndScore = attributeAndScoreMap;
	}

	public float getLikedItemPerc() {
		return likedItemPerc;
	}

	public void setLikedItemPerc(float likedItemPerc) {
		this.likedItemPerc = likedItemPerc;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public Collection<Integer> getItems() {
		return items;
	}
	public void setItems(Collection<Integer> items) {
		this.items = items;
	}

	public Collection<String> getCuisineAndScore() {
		return cuisineAndScore;
	}

	public void setCuisineAndScore(Collection<String> cuisineAndScore) {
		this.cuisineAndScore = cuisineAndScore;
	}

	public Collection<String> getOptionAndScore() {
		return optionAndScore;
	}

	public void setOptionAndScore(Collection<String> optionAndScore) {
		this.optionAndScore = optionAndScore;
	}

	public double getPriceRange() {
		return priceRange;
	}

	public void setPriceRange(float priceRange) {
		this.priceRange = priceRange;
	}

	public float getAmbienceRating() {
		return ambienceRating;
	}

	public void setAmbienceRating(float ambienceRating) {
		this.ambienceRating = ambienceRating;
	}

	public float getFoodRating() {
		return foodRating;
	}

	public void setFoodRating(float foodRating) {
		this.foodRating = foodRating;
	}

	public float getServiceRating() {
		return serviceRating;
	}

	public void setServiceRating(float serviceRating) {
		this.serviceRating = serviceRating;
	}

	public float getValueRating() {
		return valueRating;
	}

	public void setValueRating(float valueRating) {
		this.valueRating = valueRating;
	}

	public float getAggregatedRating() {
		return aggregatedRating;
	}

	public void setAggregatedRating(float aggregatedRating) {
		this.aggregatedRating = aggregatedRating;
	}
	
	public float getCuisinePerc() {
		return cuisinePerc;
	}

	public void setCuisinePerc(float cuisinePerc) {
		this.cuisinePerc = cuisinePerc;
	}

	public float getOptionPerc() {
		return optionPerc;
	}

	public void setOptionPerc(float optionPerc) {
		this.optionPerc = optionPerc;
	}

	public String toString(){
		StringBuilder buf = new StringBuilder();
		buf.append("[userId:"+this.userId).append(", items:" + this.items).append(", priceRange:" + this.priceRange)
			.append(", ambienceRating:"+this.ambienceRating).append(", foodRating:" + this.foodRating)
			.append(", serviceRating:"+this.serviceRating).append(", valueRating:" + this.valueRating)
			.append(", aggregatedRating:"+this.aggregatedRating).append(", attrScores:" + this.cuisineAndScore+"]");
		return buf.toString();
	}
	
}