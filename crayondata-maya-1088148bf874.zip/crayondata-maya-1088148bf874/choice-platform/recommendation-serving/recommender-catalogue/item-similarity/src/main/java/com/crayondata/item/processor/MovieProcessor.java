/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.item.processor;

import java.io.Serializable;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Map;

import org.apache.spark.mllib.linalg.SparseVector;
import org.apache.spark.mllib.linalg.Vector;

import com.crayondata.choice.rateableitem.CreativeWork;
import com.crayondata.choice.rateableitem.MayaMovie;
import com.google.common.base.Optional;
import com.google.common.collect.Maps;

/**
 * 
 * @author vivek
 *
 */
public class MovieProcessor implements Serializable {
    
    private static final int BIN_SIZE = 10;
    private static final int RATING_COUNT = 1;
    
    private Map<String, Integer> genreIndexMap;
    private Map<String, Integer> castIndexMap;
    private Map<String, Integer> directorIndexMap;
    
    private Collection<String> uniqGenresList;
    private Collection<String> uniqCastsList;
    private Collection<String> uniqDirectorsList;

    public MovieProcessor(List<String> uniqGenresList, 
            List<String> uniqCastsList, List<String> uniqDirectorsList) {
        this.uniqGenresList = uniqGenresList;
        this.uniqCastsList = uniqCastsList;
        this.uniqDirectorsList = uniqDirectorsList;
        init();
    }
    
    private void init(){
        indexUniqGenres();
        indexUniqCasts();
        indexUniqDirectors();
    }
    
    private void indexUniqGenres(){
        this.genreIndexMap = Maps.newHashMap();
        int genreIndex = 0;
        for(String genre : this.uniqGenresList){
            genreIndexMap.put(genre, genreIndex);
            genreIndex++;
        }
    }
    
    private void indexUniqCasts(){
        this.castIndexMap = Maps.newHashMap();
        int castIndex = 0;
        for(String cast : this.uniqCastsList){
            castIndexMap.put(cast, castIndex);
            castIndex++;
        }
    }
    
    private void indexUniqDirectors(){
        this.directorIndexMap = Maps.newHashMap();
        int dirIndex = 0;
        for(String director : this.uniqDirectorsList){
            directorIndexMap.put(director, dirIndex);
            dirIndex++;
        }
    }
    
    public Vector processMovie(CreativeWork movie){
        int size = this.uniqGenresList.size() + this.uniqCastsList.size()+  this.uniqDirectorsList.size()+RATING_COUNT;
        int castOffset = this.uniqGenresList.size();
        int directorOffset = this.uniqGenresList.size() + this.uniqCastsList.size();
        Optional<int[]> genresIndices = getGenresIndices(movie);
        Optional<int[]> castsIndices = getCastsIndices(movie, castOffset);
        Optional<int[]> directorsIndices = getDirectorIndices(movie, directorOffset);
        
        Optional<int[]> mergedIndices = getMergedIndices(genresIndices, castsIndices, directorsIndices);
        
        int ratingIndex = directorOffset + this.uniqDirectorsList.size();
        double ratingVal = movie.getAggregateRating()/BIN_SIZE;
        
        int[] indices;
        double[] values;
        
        if(mergedIndices.isPresent()){
            int[] attributeIndices = mergedIndices.get();
            double[] attributeVals = new double[attributeIndices.length];
            Arrays.fill(attributeVals, 1);
            indices = new int[attributeIndices.length + 1];
            values = new double[attributeIndices.length + 1];
            
            System.arraycopy(attributeIndices, 0, indices, 0, attributeIndices.length);
            indices[indices.length-1] = ratingIndex;
            
            
            System.arraycopy(attributeVals, 0, values, 0, attributeVals.length);
            values[indices.length-1]=ratingVal;
        }else{
            indices = new int[1];indices[0]=ratingIndex;
            values = new double[1];values[0]=ratingVal;
        }
            
        Vector result = new SparseVector(size, indices, values);
        
        return result;
    }
    
    private Optional<int[]> getMergedIndices(Optional<int[]> genreIndices,
            Optional<int[]> castsIndices, Optional<int[]> directorIndices){
        int resultLength = 0;
        if(genreIndices.isPresent())
            resultLength += genreIndices.get().length;
        if(castsIndices.isPresent())
            resultLength += castsIndices.get().length;
        if(directorIndices.isPresent())
            resultLength += directorIndices.get().length;
        
        if(resultLength <= 0)
            return Optional.absent();
        
        int[] result = new int[resultLength];
        int offset = 0;
        if(genreIndices.isPresent()){
            System.arraycopy(genreIndices.get(), 0, result, offset, genreIndices.get().length);
            offset += genreIndices.get().length;
        }
        if(castsIndices.isPresent()){
            System.arraycopy(castsIndices.get(), 0, result, offset, castsIndices.get().length);
            offset += castsIndices.get().length;
        }
        if(directorIndices.isPresent()){
            System.arraycopy(directorIndices.get(), 0, result, offset, directorIndices.get().length);
            offset += directorIndices.get().length;
        }
        
        return Optional.of(result);
    }
    
    private Optional<int[]> getGenresIndices(CreativeWork movie){
        Collection<String> generes = movie.getGenre();
        if(generes.isEmpty())
            return Optional.absent();
        int[] result = new int[generes.size()];
        int index = 0;
        for(String genre : generes){
            result[index] = this.genreIndexMap.get(genre.toLowerCase());
            index++;
        }
        return Optional.of(result);
    }
    
    private Optional<int[]> getCastsIndices(CreativeWork movie, int offset){
        Collection<String> casts = movie.getCast();
        if(casts.isEmpty())
            return Optional.absent();
        int[] result = new int[casts.size()];
        int index = 0;
        for(String cast : casts){
            result[index] = this.castIndexMap.get(cast.toLowerCase())+offset;
            index++;
        }
        return Optional.of(result);
    }
    
    private Optional<int[]> getDirectorIndices(CreativeWork movie, int offset){
        Collection<String> directors = movie.getDirector();
        if(directors.isEmpty())
            return Optional.absent();
        int[] result = new int[directors.size()];
        int index = 0;
        for(String director : directors){
            result[index] = this.directorIndexMap.get(director.toLowerCase())+offset;
            index++;
        }
        return Optional.of(result);
    }

}
