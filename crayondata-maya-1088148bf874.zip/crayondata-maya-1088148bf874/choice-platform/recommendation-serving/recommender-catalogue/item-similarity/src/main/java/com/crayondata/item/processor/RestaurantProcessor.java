/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.item.processor;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.spark.mllib.linalg.SparseVector;
import org.apache.spark.mllib.linalg.Vector;

import com.crayondata.choice.rateableitem.MayaRestaurant;
import com.google.common.base.Optional;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Maps;

/**
 * 
 * @author vivek
 *
 */
public class RestaurantProcessor implements Serializable {
    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    
    private Map<String, Integer> cuisineIndexMap;
    private Map<String, Integer> optionIndexMap;
    
    private final Collection<String> uniqCusinesList;
    private final Collection<String> uniqOptionsList;
    
    private Map<String,Double> priceRangeValues; 
    private static final int BIN_SIZE = 10;
    private static final int RATING_COUNT = 5;

    public RestaurantProcessor(List<String> uniqCusinesList, 
            List<String> uniqOptionsList) {
        this.uniqCusinesList = uniqCusinesList;
        this.uniqOptionsList = uniqOptionsList;
        init();
    }
    
    private void init(){
        indexUniqCuisines();
        indexUniqOptions();
        priceRangeValues = ImmutableMap.of("Low", 1.0, "Medium", 2.0, "High", 3.0, "Very High", 4.0);
    }
    
    private void indexUniqCuisines(){
        cuisineIndexMap = Maps.newHashMap();
        int cuisineIndex = 0;
        for(String cuisine : this.uniqCusinesList){
            cuisineIndexMap.put(cuisine, cuisineIndex);
            cuisineIndex++;
        }
    }
    
    private void indexUniqOptions(){
        optionIndexMap = Maps.newHashMap();
        int optionIndex = 0;
        for(String option : this.uniqOptionsList){
            optionIndexMap.put(option, optionIndex);
            optionIndex++;
        }
    }
    
    public Vector processRestaurant(MayaRestaurant restaurant){
        int size = this.uniqCusinesList.size() + this.uniqOptionsList.size()+RATING_COUNT+1;
        int optionsOffset = this.uniqCusinesList.size();
        Optional<int[]> cuisinesIndices = getCuisinesIndices(restaurant);
        Optional<int[]> optionsIndices = getOptionsIndices(restaurant, optionsOffset);
        Optional<int[]> mergedIndices = getMergedIndices(cuisinesIndices, optionsIndices);
        
        int[] priceAndRatingIndices = getPriceAndRatingIndices(optionsOffset+uniqOptionsList.size());
        double[] priceAndRatingVals = getPriceAndRatingVals(restaurant);
        
        int[] indices;
        double[] values;
        
        if(mergedIndices.isPresent()){
            int[] cuisineAndOptionIndices = mergedIndices.get();
            double[] cuisineAndOptionVals = new double[cuisineAndOptionIndices.length];
            Arrays.fill(cuisineAndOptionVals, 1);
            indices = new int[cuisineAndOptionIndices.length + priceAndRatingIndices.length];
            values = new double[cuisineAndOptionIndices.length + priceAndRatingIndices.length];
            
            System.arraycopy(cuisineAndOptionIndices, 0, indices, 0, cuisineAndOptionIndices.length);
            System.arraycopy(priceAndRatingIndices, 0, indices, cuisineAndOptionIndices.length, priceAndRatingIndices.length);
            
            System.arraycopy(cuisineAndOptionVals, 0, values, 0, cuisineAndOptionVals.length);
            System.arraycopy(priceAndRatingVals, 0, values, cuisineAndOptionVals.length, priceAndRatingVals.length);
        }else{
            indices = priceAndRatingIndices;
            values = priceAndRatingVals;
        }
            
        Vector result = new SparseVector(size, indices, values);
        
        return result;
    }
    
    private int[] getPriceAndRatingIndices(int offset){
        int[] result = new int[RATING_COUNT+1];
        for(int i=0;i < result.length;i++)
            result[i] = offset+i;
        return result;
    }
    
    private double[] getPriceAndRatingVals(MayaRestaurant restaurant){
        double[] result = new double[RATING_COUNT+1];
        result[0] = 0;
        if(priceRangeValues.containsKey(restaurant.getPriceRange()))
            result[0] = priceRangeValues.get(restaurant.getPriceRange());
        result[1] = restaurant.getAmbienceRating()/BIN_SIZE;
        result[2] = restaurant.getFoodRating()/BIN_SIZE;
        result[3] = restaurant.getServiceRating()/BIN_SIZE;
        result[4] = restaurant.getValueRating()/BIN_SIZE;
        result[5] = restaurant.getAggregateRating()/BIN_SIZE;
        
        return result;
    }
    
    private Optional<int[]> getMergedIndices(Optional<int[]> cuisinesIndices,
            Optional<int[]> optionsIndices){
        if(cuisinesIndices.isPresent() && optionsIndices.isPresent()){
            int[] cuisineIdexArr = cuisinesIndices.get();
            int[] optionIndexArr = optionsIndices.get();
            int[] result = new int[cuisineIdexArr.length + optionIndexArr.length];
            System.arraycopy(cuisineIdexArr, 0, result, 0, cuisineIdexArr.length);
            System.arraycopy(optionIndexArr, 0, result, cuisineIdexArr.length, optionIndexArr.length);
            return Optional.of(result);
        }
        else if(cuisinesIndices.isPresent())
            return Optional.of(cuisinesIndices.get());
        else if(optionsIndices.isPresent())
            return Optional.of(optionsIndices.get());
        else
            return Optional.absent();
    }
    
    private Optional<int[]> getCuisinesIndices(MayaRestaurant restaurant){
        Collection<String> cuisines = restaurant.getCuisines();
        if(cuisines.isEmpty())
            return Optional.absent();
        int[] result = new int[cuisines.size()];
        int index = 0;
        for(String cuisine : cuisines){
            result[index] = cuisineIndexMap.get(cuisine.toLowerCase());
            index++;
        }
        return Optional.of(result);
    }
    
    private Optional<int[]> getOptionsIndices(MayaRestaurant restaurant, int offset){
        Collection<String> options = restaurant.getOptions();
        if(options.isEmpty())
            return Optional.absent();
        int[] result = new int[options.size()];
        int index = 0;
        for(String option : options){
            result[index] = optionIndexMap.get(option.toLowerCase())+offset;
            index++;
        }
        return Optional.of(result);
    }
    
    

}
