/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.item.processor.spark.user;

import java.io.Serializable;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.collections.CollectionUtils;
import org.apache.spark.HashPartitioner;
import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.function.PairFunction;
import org.apache.spark.partial.BoundedDouble;
import org.apache.spark.partial.PartialResult;
import org.apache.spark.sql.DataFrame;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.RowFactory;
import org.apache.spark.sql.SQLContext;
import org.apache.spark.sql.functions;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;
import org.apache.spark.storage.StorageLevel;

import scala.Tuple2;

import com.clearspring.analytics.util.Lists;
import com.crayondata.item.processor.spark.UserCooccurrenceSimilarity;
import com.google.common.base.Optional;
import com.google.common.collect.Iterables;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;

/**
 * 
 * @author vivek
 *
 */
public class JaccardUserSimilarity implements Serializable {
	
	private static String TRAIN_FILE =  "data/train.avro";
    private static int NUM_PARTITIONS = 1024;
    private static int TOP_N = 200;
    private static String OUTPUT = "output";
    private static int INTERACTION_COUNT = 150;
        
    private final String trainFileUri;
    private final int topN;
    private final String ouputDir;
    private final int numPartitions; 
    private final int interactionCount;

    public JaccardUserSimilarity(String trainFileUri, int topN,
			String ouputDir, int interactionCount, int numPartitions) {
		super();
		this.trainFileUri = trainFileUri;
		this.topN = topN;
		this.ouputDir = ouputDir;
		this.interactionCount = interactionCount;
		this.numPartitions = numPartitions;
	}

    /*private JavaPairRDD<String, Tuple2<String, Double>> lookupTable = */

	public static void main(String[] args) {
		if(args.length < 4){
			System.err.println("Usage:: JaccardUserSimilarity <train-file-uri> <top-n-similarities> <output> <interaction-count> [num-partitions]");
			System.exit(1);
		}
		TRAIN_FILE = args[0];
		TOP_N = Integer.parseInt(args[1]);
		OUTPUT = args[2];
		INTERACTION_COUNT = Integer.parseInt(args[3]);
		
		if(args.length >= 4){
			NUM_PARTITIONS = Integer.parseInt(args[4]);
		}
		JaccardUserSimilarity similarityProcessor = 
				new JaccardUserSimilarity(TRAIN_FILE, TOP_N, OUTPUT, INTERACTION_COUNT, NUM_PARTITIONS);
		
        SparkConf conf = new SparkConf().setAppName("Jaccard User Similarity applition").set("spark.executor.memory", "64g")
                .set("spark.num.executors", "1")/*.set("spark.executor.cores", "7").*/.set("spark.total.executor.cores", "15")
                /*.set("spark.storage.memoryFraction", "0.1")*/;
        JavaSparkContext sc = new JavaSparkContext(conf);
        similarityProcessor.buildModel(sc);
	}
	
	public void buildModel(JavaSparkContext sc){
		// User id to item id
		JavaPairRDD<Integer, Integer> interactionData = readReviewDataFromAvro(sc, this.trainFileUri)
				.partitionBy(new HashPartitioner(numPartitions)).cache();
		System.out.println("Number of interactions read:" + interactionData.count());
		JavaPairRDD<Tuple2<Integer, Integer>, Double> jaccardScoresRdd = /*computeJaccardForPairsUsingSqlDf(interactionData, sc); */
				computeJaccardForPairs(interactionData);
		System.out.println(".. Number of jaccard similarity computed:" + jaccardScoresRdd.count());
		
		JavaPairRDD<Integer, Iterable<Tuple2<Integer, Double>>> topRatedPairs = findTopRatedPairs(jaccardScoresRdd, this.topN);
		System.out.println(" Top rated paris count:" + topRatedPairs.count());
		topRatedPairs.saveAsTextFile(ouputDir+"/TopRatedPairs");
		
		enhanceUserInteractionsSqlDF(interactionData, topRatedPairs, sc);
		
		/*enhanceUserInteractions(interactionData, transformTopRatedPairs(topRatedPairs), sc);*/
	}
	
	private JavaPairRDD<String, Collection<String>> transformTopRatedPairs(
			JavaPairRDD<String, Iterable<Tuple2<String, Double>>> topRatedPairs){
		return topRatedPairs.mapToPair(x -> {
			Collection<String> orderedSimUsers = Lists.newArrayList();
			for(Tuple2<String, Double> item : x._2){
				orderedSimUsers.add(item._1);
			}
			return new Tuple2<>(x._1, orderedSimUsers);
		});
	}
	
	public class ItemCoOcurrence implements Serializable {
		private String user1Id, user2Id;
		private int itemId;
		public ItemCoOcurrence() {
			super();
		}
		public ItemCoOcurrence(String user1Id, String user2Id, int itemId) {
			super();
			this.user1Id = user1Id;
			this.user2Id = user2Id;
			this.itemId = itemId;
		}
		public String getUser1Id() {
			return user1Id;
		}
		public void setUser1Id(String user1Id) {
			this.user1Id = user1Id;
		}
		public String getUser2Id() {
			return user2Id;
		}
		public void setUser2Id(String user2Id) {
			this.user2Id = user2Id;
		}
		public int getItemId() {
			return itemId;
		}
		public void setItemId(int itemId) {
			this.itemId = itemId;
		}
		
	}
	
	public class CoOccurrenceSummary implements Serializable{
		private String user1Id, user2Id;
		private int count;
		public CoOccurrenceSummary() {
			super();
		}
		public CoOccurrenceSummary(String user1Id, String user2Id, int count) {
			super();
			this.user1Id = user1Id;
			this.user2Id = user2Id;
			this.count = count;
		}
		public String getUser1Id() {
			return user1Id;
		}
		public void setUser1Id(String user1Id) {
			this.user1Id = user1Id;
		}
		public String getUser2Id() {
			return user2Id;
		}
		public void setUser2Id(String user2Id) {
			this.user2Id = user2Id;
		}
		public int getCount() {
			return count;
		}
		public void setCount(int count) {
			this.count = count;
		}
		
	}
	
	public class Interaction implements Serializable{
		private int userId;
		private int itemId;
		
		public Interaction(){}

		public Interaction(int userId, int itemId) {
			this.userId = userId;
			this.itemId = itemId;
		}

		public int getUserId() {
			return userId;
		}

		public void setUserId(int userId) {
			this.userId = userId;
		}

		public int getItemId() {
			return itemId;
		}

		public void setItemId(int itemId) {
			this.itemId = itemId;
		}
	}
	
	public class UserSimilarityPair implements Serializable{
		private Integer userFromId;
		private Integer userToId;
		private double score;
		
		public UserSimilarityPair(){}

		public UserSimilarityPair(Integer userFromId, Integer userToId,
				double score) {
			super();
			this.userFromId = userFromId;
			this.userToId = userToId;
			this.score = score;
		}

		public Integer getUserFromId() {
			return userFromId;
		}

		public void setUserFromId(Integer userFromId) {
			this.userFromId = userFromId;
		}

		public Integer getUserToId() {
			return userToId;
		}

		public void setUserToId(Integer userToId) {
			this.userToId = userToId;
		}

		public double getScore() {
			return score;
		}

		public void setScore(double score) {
			this.score = score;
		}
		
	}
	
	public class UserTransactions implements Serializable{
		private String userId;
		private List<Integer> personalItems;
		private List<Integer> collabItems;
		public String getUserId() {
			return userId;
		}
		public void setUserId(String userId) {
			this.userId = userId;
		}
		public List<Integer> getPersonalItems() {
			return personalItems;
		}
		public void setPersonalItems(List<Integer> personalItems) {
			this.personalItems = personalItems;
		}
		public List<Integer> getCollabItems() {
			return collabItems;
		}
		public void setCollabItems(List<Integer> collabItems) {
			this.collabItems = collabItems;
		}
		public UserTransactions(String userId, List<Integer> personalItems,
				List<Integer> collabItems) {
			super();
			this.userId = userId;
			this.personalItems = personalItems;
			this.collabItems = collabItems;
		}
		public UserTransactions() {
		}
	}
	
	private void enhanceUserInteractionsSqlDF(JavaPairRDD<Integer, Integer> interactionData,
			JavaPairRDD<Integer, Iterable<Tuple2<Integer, Double>>> topRatedPairs, JavaSparkContext sc){
		SQLContext sqlContext = new SQLContext(sc);
		
		JavaPairRDD<Integer, Tuple2<Integer, Double>> flatRatedPairs =
				topRatedPairs.flatMapToPair(x -> {
			Collection<Tuple2<Integer, Tuple2<Integer, Double>>> scoredPairs = Lists.newArrayList();
			x._2.forEach(y -> scoredPairs.add(new Tuple2<>(x._1,y)));
			return scoredPairs;
		});
		
		JavaRDD<UserSimilarityPair> similarityPairs = flatRatedPairs.map(x -> new UserSimilarityPair(x._1, x._2._1, x._2._2)).repartition(numPartitions);
		DataFrame similarityDF = sqlContext.createDataFrame(similarityPairs, UserSimilarityPair.class).repartition(numPartitions);
		
		JavaRDD<Interaction> interactionRdd = interactionData.map(x -> new Interaction(x._1, x._2)).repartition(numPartitions);
		DataFrame interactionDF = sqlContext.createDataFrame(interactionRdd, Interaction.class).repartition(numPartitions);
		
		DataFrame collobTransactions = similarityDF
				.join(interactionDF, similarityDF.col("userToId").equalTo(interactionDF.col("userId")))
				.select(similarityDF.col("userFromId").as("userId"), /*similarityDF.col("userToId"),*/ 
						similarityDF.col("score").as("score"),interactionDF.col("itemId").as("itemId")).repartition(numPartitions);
		DataFrame aggregTransaction = 
				collobTransactions.groupBy(collobTransactions.col("userId"),collobTransactions.col("itemId"))
				.agg(functions.avg(collobTransactions.col("score")).as("avgSimilarityScore")).repartition(numPartitions);
		
		System.out.println(".. Enhancing the interaction data..");
		JavaPairRDD<Integer, Integer> result = addCollabTransToTransData(interactionData, aggregTransaction);
		System.out.println(".. Enhancing the interaction data completed successfully..");
		System.out.println("Saving the interactions to text file..");
		saveUpdatedInteractions(result, sc);
	}
	
	private JavaPairRDD<Integer, Integer> addCollabTransToTransData(JavaPairRDD<Integer, Integer> interactionData,
			DataFrame aggregTransaction){
		JavaRDD<Row> rowsRdd = aggregTransaction.toJavaRDD();
    	JavaPairRDD<Integer, Tuple2<Integer, Double>> collabItems = rowsRdd.mapToPair(
    			row -> new Tuple2<>(row.getInt(0), new Tuple2<>(row.getInt(1), row.getDouble(2))));
    	
    	JavaPairRDD<Integer, Iterable<Tuple2<Integer, Double>>> itemsGroupedRdd = 
    			collabItems.groupByKey();
        	System.out.println("Rdd Group by with key completed..");
        	JavaPairRDD<Integer, List<Tuple2<Integer, Double>>> topNItemsRdd =
        	itemsGroupedRdd.mapToPair(input ->{
        		ArrayList<Tuple2<Integer, Double>> item2List = new ArrayList<>();
            	CollectionUtils.addAll(item2List, input._2.iterator());
            	Collections.sort(item2List, (v1, v2) -> {
            		int cmp = v2._2.compareTo(v1._2);
            		if (cmp == 0)
            			cmp = v2._1.compareTo(v1._1);
            		return cmp;
            	});
            	if (item2List.size() > topN)
            		item2List.subList(topN, item2List.size()).clear();
            	item2List.trimToSize();
            	return new Tuple2<>(input._1, item2List);
        	});
        	System.out.println("Rdd filter by topN.." + topN + ".. completed..");
        	
        	topNItemsRdd.mapToPair(x -> {
        		List<String> toPrint = Lists.newArrayList();
        		x._2.stream().forEachOrdered(y -> toPrint.add(y._1+"|"+y._2));
        		return new Tuple2<>(x._1, toPrint);
        	}).saveAsTextFile(this.ouputDir + "/CollabItems");
        	
        	JavaPairRDD<Integer, List<Integer>> collabItemIds =
        			topNItemsRdd.mapToPair(x -> {
        		List<Integer> itemIds = Lists.newArrayList();
        		x._2.stream().forEachOrdered(y -> itemIds.add(y._1));
        		return new Tuple2<>(x._1, itemIds);
        	});
        	JavaPairRDD<Integer, Integer> collabTransData = 
        			collabItemIds.flatMapToPair(x -> {
        		List<Tuple2<Integer, Integer>> tuples = Lists.newArrayList();
        		x._2.forEach(y -> tuples.add(new Tuple2<>(x._1, y)));
        		return tuples;
        	});
        	
        	JavaPairRDD<Integer, Integer> result = interactionData.union(collabTransData);
        	
        	return result;
	}
	
	private void enhanceUserInteractions(JavaPairRDD<Integer, Integer> interactionData,
			JavaPairRDD<Integer, Collection<Integer>> topRatedPairs, JavaSparkContext sc){
		
		JavaPairRDD<Integer, List<Integer>> userToInteractions = 
			interactionData.groupByKey().mapToPair(x -> {
				List<Integer> interactions = Lists.newArrayList();
				Iterables.addAll(interactions, x._2);
				return new Tuple2<>(x._1, interactions);
			}).cache();
		Map<Integer, List<Integer>> userInteractionsMap = userToInteractions.collectAsMap();
		System.out.println(".. Interaction map size:" + userInteractionsMap.size());
		
		JavaPairRDD<Integer, List<Integer>> userInteractionsUpdated = 
				topRatedPairs.mapToPair(x -> {
			Integer userId = x._1;
			List<Integer> interactions = userInteractionsMap.get(userId);
			Collection<Integer> simUsers = x._2();
			for(Integer simUserId : simUsers){
				if(interactions.size() >= interactionCount){
					break;
				}
				int toTake = interactionCount - interactions.size();
				List<Integer> thisUserInteractions = userInteractionsMap.get(simUserId);
				if(toTake >= thisUserInteractions.size())
					interactions.addAll(thisUserInteractions);
				else
					interactions.addAll(thisUserInteractions.subList(0, toTake));
			}
			return new Tuple2<>(userId, interactions);
		});
		
		JavaPairRDD<Integer, Integer> flatInteractions =
				userInteractionsUpdated.flatMapToPair(x -> {
			Collection<Tuple2<Integer, Integer>> tuples = Lists.newArrayList();
			Integer userId = x._1;
			Collection<Integer> itemIds = x._2;
			itemIds.forEach(y -> tuples.add(new Tuple2<>(userId, y)));
			return tuples;
		});
		
		System.out.println(" Number of updated updated interactions:" +
				flatInteractions.count());
		
		saveUpdatedInteractions(flatInteractions, sc);
	}
	
	/**
	 * JaccardSimilarity = M11 / (M10 + M01 + M11)
	 * Where,
	 * 	M11 is common likes
	 * 	M10 and M01 are respective likes by users.
	 * 
	 * https://en.wikipedia.org/wiki/Jaccard_index#Tanimoto_coefficient_.28extended_Jaccard_coefficient.29
	 * @param interactionData
	 * @return
	 */
	protected JavaPairRDD<Tuple2<Integer, Integer>, Double> computeJaccardForPairs(JavaPairRDD<Integer, Integer> interactionData){
		System.out.println("Number of unique users:" + interactionData.keys().distinct().count());
		
		// Item id to user id.
		JavaPairRDD<Integer, Integer> reversed = interactionData.mapToPair(x -> new Tuple2<>(x._2, x._1)).cache();
		System.out.println("Number of reversed pairs created.." + reversed.count());
		
		JavaPairRDD<Integer, Iterable<Integer>> groupBy = 
			reversed.groupByKey();
		System.out.println(".. Group by count."+ groupBy.count());
		/*groupBy.mapToPair(x -> new Tuple2<>(x._1, Iterables.size(x._2))).foreach(x -> System.out.printf("ItemId: %d, count of users%d\n",x._1,x._2));*/
		
		// Filtering out all products with only user transacted with it.
		JavaPairRDD<Integer, Optional<List<Integer>>> groupByUniqUsers =
			groupBy.mapToPair(x -> {
			Set<Integer> set1 = Sets.newHashSet();
			Iterables.addAll(set1, x._2);
			
			List<Integer> list1 = Lists.newArrayList();
			list1.addAll(set1);
			
			int size = list1.size();
			
			Optional<List<Integer>> result = Optional.absent();
			if(size > 1)
				result = Optional.of(list1);
			
			return new Tuple2<>(x._1, result);
		});
		JavaPairRDD<Integer, Optional<List<Integer>>> filtered =
				groupByUniqUsers.filter(x -> x._2.isPresent());
		// Item id to uniq users.
		JavaPairRDD<Integer, List<Integer>> filteredUniqUsers =  
			filtered.mapToPair(x -> new Tuple2<>(x._1, x._2.get()));
		System.out.println(".. filteredUniq Product count "+ filteredUniqUsers.count());
		/*filteredUniqUsers.foreach(x -> System.out.printf("Post filter:: ItemId:%d\tCount of users:%d\n",x._1,x._2.size()));*/
		
		// Item to uniq user map.
		JavaPairRDD<Integer, Integer> filteredTrans =   
			filteredUniqUsers.flatMapToPair(x -> {
			List<Tuple2<Integer, Integer>> result = Lists.newArrayList();
			x._2.forEach(y -> result.add(new Tuple2<>(x._1, y)));
			return result;
		}).cache();
		System.out.println(".. filteredTrans count " + filteredTrans.count());
		System.out.println("Uniq item ids: " + filteredTrans.keys().distinct().count());
		System.out.println("Uniq user ids: " + filteredTrans.values().distinct().count());
		
		/*JavaPairRDD<Integer, Optional<List<Tuple2<String, 
		 String>>>> enumerated = groupBy.mapToPair(x -> {
			Set<String> set1 = Sets.newHashSet();
			Iterables.addAll(set1, x._2);
			
			List<String> list1 = Lists.newArrayList();
			list1.addAll(set1);
			
			int size = list1.size();
			System.out.println("... List size:" + size);
			Optional<List<Tuple2<String, String>>> result = Optional.absent();
			if(size <= 1)
				return new Tuple2<>(x._1,result);
			
			List<Tuple2<String, String>> resultList = Lists.newArrayList();
			for(int i=0;i<size-1;i++){
				for(int j=i+1;j<size;j++){
					resultList.add(new Tuple2<>(list1.get(i), list1.get(j)));
				}
			}
			return new Tuple2<>(x._1,Optional.of(resultList));
		});
		
		System.out.println(".. enumeration done:" + enumerated.count());
		
		JavaPairRDD<Integer, Optional<List<Tuple2<String, String>>>> filtered = 
			enumerated.filter(x -> x._2.isPresent());
		System.out.println(".. Filtered :" + filtered.count());
		
		JavaPairRDD<Integer, List<Tuple2<String, String>>> filtered1 = 
			filtered.mapToPair(x -> new Tuple2<>(x._1, x._2.get()));
		
		JavaPairRDD<Integer, Tuple2<String, String>> flattened =  
			filtered1.flatMapToPair(x -> {
			List<Tuple2<String, String>> values = x._2;
			List<Tuple2<Integer, Tuple2<String, String>>> tuples = Lists.newArrayList();
			values.forEach(y -> tuples.add(new Tuple2<>(x._1, y)));
			
			return tuples;
		});*/
		
		/*System.out.println(".. Flattened..count:" + flattened.count());*/
		
		/*JavaPairRDD<Integer, Tuple2<String, String>> joined = reversed.join(reversed);
		System.out.println(".. Number of joined pairs:" + joined.count());
		
		JavaRDD<Tuple2<String, String>> filtered = joined.map(x -> x._2);
		System.out.println(".. Number of pairs created.."+ filtered.count());
		
		filtered = filtered.filter(x -> !x._1.equals(x._2));
		
		System.out.println("Number of filtered pairs:" + filtered.count());*/
		
		/*JavaRDD<Tuple2<String, String>>  pairsRdd = flattened.map(x -> x._2);
		System.out.println(".. pairs rdd:" + pairsRdd.count());*/
		
		JavaPairRDD<Integer, Tuple2<Integer, Integer>> joined = filteredTrans.join(filteredTrans);
		/*JavaRDD<Tuple2<String, String>> pairsRdd = joined.map(x -> x._2);*//*.cache()*//*.persist(StorageLevel.MEMORY_AND_DISK())*/
		System.out.println(".. Joined pairs...."+ joined.count());
						
		JavaRDD<Tuple2<Integer, Integer>> pairsFiltered = joined.filter(x -> (!x._2._1.equals(x._2._2))).map(x -> x._2);
		/*JavaPairRDD<Tuple2<Integer, Integer>, Integer> intersectCounts = joined.mapToPair(x -> new Tuple2<>(x._2,1)); */
		/*JavaPairRDD<Tuple2<Integer, Integer>, Integer> intersectCounts = joined.mapPartitionsToPair(x -> {
			Collection<Tuple2<Tuple2<Integer, Integer>, Integer>> result = Lists.newArrayList();
			x.forEachRemaining(y -> 
			result.add(new Tuple2<>(y._2, y._1)));
			return result;
		}, false);*/
				/*.partitionBy(new HashPartitioner(numPartitions));*/
		
		/*JavaPairRDD<Tuple2<Integer, Integer>, Iterable<Tuple2<Integer, 
		 Tuple2<Integer, Integer>>>> grouped = 
			joined.groupBy(x -> x._2);
		System.out.println(".. Grouped count:" + grouped.count());
		
		JavaPairRDD<Tuple2<Integer, Integer>, Integer> intersectCounts = grouped.mapToPair(x -> 
			new Tuple2<>(x._1, Iterables.size(x._2)));*/
		/*System.out.println("mapped pairs count::"+ pairs.count());*/
		/*System.out.println("mapped pairs distinct count::"+ pairs.countApproxDistinct(0.05));*/
		/*PartialResult<Map<Tuple2<Integer, Integer>, BoundedDouble>> countByVal = 
				pairs.countByValueApprox(0, 0.95);
		countByVal.getFinalValue().forEach((x,y) -> {
			System.out.printf("Count of :%s\t%s\n", x, y);
		});*/
		
		final Integer one = new Integer(1);
		
		/*JavaRDD<Tuple2<Integer, Integer>> pairsFiltered = pairs.filter(x -> (!x._1.equals(x._2)));*/ /*x._1.intValue() != x._2.intValue()*/
		System.out.println("Filtered pairs count::"+ pairsFiltered.count());
		JavaPairRDD<Tuple2<Integer, Integer>, Integer> intersectCounts = pairsFiltered.mapToPair(x -> new Tuple2<>(x, one)).reduceByKey((x,y) -> new Integer(x.intValue()+y.intValue()));
		
		/*intersectCounts = intersectCounts.reduceByKey((x,y) -> x+y, numPartitions);*/
		System.out.println("Number of unique pairs after intersection:" + intersectCounts.count());
		
		Map<Integer, Integer> itemCounts = filteredTrans.mapToPair(x -> new Tuple2<>(x._2,1)).reduceByKey((x,y) -> x+y).collectAsMap();
		System.out.println(".. Size of the item count map:" + itemCounts.size());
		
		 JavaPairRDD<Tuple2<Integer, Integer>, Double> result =
				 intersectCounts.mapToPair(x -> {
			double m11 = x._2.intValue();
			double m10 = itemCounts.get(x._1._1) - m11;
			double m01 = itemCounts.get(x._1._2) - m11;
			double score = m11 / (m10+m01+m11);
			return new Tuple2<>(x._1,score);
		});
		 
		return result;
	}
	
	private void savePairedResult(JavaPairRDD<Integer, Tuple2<String, String>> pairedResult, 
			JavaPairRDD<Integer, String> filteredTrans){
		pairedResult/*.map(x -> x._1+","+x._2._1 + "," + x._2._2)*/.saveAsTextFile("data/PairedResult");
		filteredTrans/*.map(x -> x._1+","+x._2)*/.saveAsTextFile("data/FilteredTrans");
	}
	
	/**
	 * JaccardSimilarity = M11 / (M10 + M01 + M11)
	 * Where,
	 * 	M11 is common likes
	 * 	M10 and M01 are respective likes by users.
	 * 
	 * https://en.wikipedia.org/wiki/Jaccard_index#Tanimoto_coefficient_.28extended_Jaccard_coefficient.29
	 * @param interactionData
	 * @return
	 */
	protected JavaPairRDD<Tuple2<Integer, Integer>, Double> computeJaccardForPairsUsingSqlDf(JavaPairRDD<Integer, Integer> interactionData,
			JavaSparkContext sc){
		
		SQLContext sqlContext = new SQLContext(sc);
		JavaRDD<Interaction> interactionRdd = interactionData.map(x -> new Interaction(x._1.intValue(), x._2.intValue())).repartition(this.numPartitions)
				.persist(StorageLevel.DISK_ONLY());
		
		DataFrame interactionDF = sqlContext.createDataFrame(interactionRdd, Interaction.class).repartition(numPartitions);
		DataFrame interactionDFCopy = sqlContext.createDataFrame(interactionRdd, Interaction.class).repartition(numPartitions);
		
		DataFrame joined = interactionDF.join(interactionDFCopy, interactionDF.col("itemId").equalTo(interactionDFCopy.col("itemId"))
				.and(interactionDF.col("userId").notEqual(interactionDFCopy.col("userId"))))
				.select(interactionDF.col("itemId").as("itemId"), interactionDF.col("userId").as("user1Id"),
						interactionDFCopy.col("userId").as("user2Id")).repartition(numPartitions);
		DataFrame grouped = 
				joined.groupBy(joined.col("user1Id"), joined.col("user2Id")).agg(functions.count(joined.col("user1Id")).as("count"))
				.repartition(numPartitions);
		System.out.println(".. Grouped schema: " + Arrays.asList(grouped.columns()));
		System.out.println(grouped.schema().toString());
		JavaRDD<Row> rowsRdd = grouped.toJavaRDD().repartition(numPartitions).persist(StorageLevel.DISK_ONLY());
		System.out.println("Grouping completed..:" + rowsRdd.count());
		JavaPairRDD<Tuple2<Integer, Integer>, Long> intersectCounts = rowsRdd.mapToPair(
    			row -> new Tuple2<>(new Tuple2<>(row.getInt(0), row.getInt(1)),row.getLong(2)));
		
		/*JavaPairRDD<Integer, String> reversed = interactionData.mapToPair(x -> new Tuple2<>(x._2, x._1));
		JavaPairRDD<Integer, Tuple2<String, String>> joined = reversed.join(reversed).persist(StorageLevel.DISK_ONLY());
		JavaRDD<Tuple2<String, String>> filtered = joined.map(x -> x._2).filter(x -> !x._1.equals(x._2)).persist(StorageLevel.DISK_ONLY());
		
		JavaPairRDD<Tuple2<String, String>, Integer> intersectCounts = filtered.mapToPair(x -> new Tuple2<>(x,1)).reduceByKey((x,y) -> x+y).persist(StorageLevel.DISK_ONLY());*/
		
		Map<Integer, Integer> itemCounts = interactionData.mapToPair(x -> new Tuple2<>(x._1,1)).reduceByKey((x,y) -> x+y).collectAsMap();
		
		 JavaPairRDD<Tuple2<Integer, Integer>, Double> result =
				 intersectCounts.mapToPair(x -> {
			double m11 = x._2.longValue();
			double m10 = itemCounts.get(x._1._1) - m11;
			double m01 = itemCounts.get(x._1._2) - m11;
			double score = m11 / (m10+m01+m11);
			return new Tuple2<>(x._1,score);
		});
		 
		return result;
	}
	
	private JavaPairRDD<Integer, Iterable<Tuple2<Integer, Double>>> findTopRatedPairs(
            JavaPairRDD<Tuple2<Integer, Integer>, Double> scoresRdd, final int topN) {
        
        JavaPairRDD<Integer, Tuple2<Integer, Double>> itemPair =
        			scoresRdd.mapToPair(x -> new Tuple2<>(x._1._1, new Tuple2<>(x._1._2, x._2)));
        		

        JavaPairRDD<Integer, Iterable<Tuple2<Integer, Double>>> itemGrouped = itemPair.groupByKey().partitionBy(new HashPartitioner(numPartitions));

        JavaPairRDD<Integer, Iterable<Tuple2<Integer, Double>>> item1To2List = itemGrouped.mapToPair(input ->{
        	ArrayList<Tuple2<Integer, Double>> item2List = new ArrayList<>();
        	CollectionUtils.addAll(item2List, input._2().iterator());
        	Collections.sort(item2List, (v1, v2) -> {
        		int cmp = v2._2.compareTo(v1._2);
        		if (cmp == 0)
        			cmp = v2._1.compareTo(v1._1);
        		return cmp;
        	});
        	if (item2List.size() > topN)
        		item2List.subList(topN, item2List.size()).clear();
        	item2List.trimToSize();
        	return new Tuple2<>(input._1, item2List);
        });
        
        return item1To2List;
        /*return item1To2List.flatMapToPair(grp -> {
            Collection<Tuple2<String, Tuple2<String, Double>>> result = new ArrayList<>();
            grp._2.forEach(x -> result.add(new Tuple2<>(grp._1, x)));
            return result;
        });*/
    }

	
	protected JavaPairRDD<Integer, Integer> readReviewDataFromAvro(JavaSparkContext sc, String fileUri) {
        SQLContext sqlContext = new SQLContext(sc);
        DataFrame df = sqlContext.read().format("com.databricks.spark.avro").load(fileUri);
        return df.javaRDD().mapToPair(x -> new Tuple2<>(new Integer(Integer.parseInt(x.getString(1))), x.getInt(0)));
    }
	
	protected void saveUpdatedInteractions(JavaPairRDD<Integer, Integer> interactions,JavaSparkContext sc) {
        String destination = this.ouputDir + "/Interactions";
        JavaRDD<Row> affRow = interactions.map(x -> RowFactory.create(new Object[] { x._2, String.valueOf(x._1) }));
        SQLContext sqlContext = new SQLContext(sc);
        DataFrame affDF = sqlContext.createDataFrame(affRow, getInteractionSchema());
        affDF.write().format("com.databricks.spark.avro").save(destination);
    }

    private StructType getInteractionSchema() {
        List<StructField> fields = Lists.newArrayList();
        fields.add(DataTypes.createStructField("itemId", DataTypes.IntegerType, false));
        fields.add(DataTypes.createStructField("userId", DataTypes.StringType, false));
        return DataTypes.createStructType(fields);
    }


}
