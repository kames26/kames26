/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.item.processor.spark;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;

import org.apache.spark.HashPartitioner;
import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.api.java.function.Function2;
import org.apache.spark.api.java.function.PairFunction;
import org.apache.spark.mllib.linalg.Vector;
import org.apache.spark.mllib.linalg.distributed.CoordinateMatrix;
import org.apache.spark.mllib.linalg.distributed.MatrixEntry;
import org.apache.spark.mllib.linalg.distributed.RowMatrix;

import scala.Tuple2;
import scala.runtime.BoxedUnit;

import com.crayondata.choice.rateableitem.MayaRestaurant;
import com.crayondata.item.processor.RestaurantProcessor;
import com.crayondata.item.provider.impl.ItemProviderImpl;
import com.google.common.collect.Maps;

/**
 * 
 * @author vivek
 *
 */
public class ItemSimilarityProcessor {
    
    private static String fileUri =  "data/rest_details.json";
    private static final int NUM_PARTITIONS = 1024;

    public static void main(String[] args) {
        if(args.length >= 1){
            fileUri = args[0];
            System.out.printf("Using the file:%s passed for processing\n",fileUri);
        }else
            System.out.println("File URI not mentioned using the default value:"+ fileUri);
        SparkConf conf = new SparkConf().setAppName("Item Similarity Application").set("spark.executor.memory", "32g")
                .set("spark.num.executors", "1")/*.set("spark.executor.cores", "7").*/.set("spark.total.executor.cores", "15")
                .set("spark.storage.memoryFraction", "0.1");
        JavaSparkContext sc = new JavaSparkContext(conf);
                
        long startTime = System.currentTimeMillis();
        
        JavaRDD<String> rawData = sc.textFile(fileUri)/*.cache()*/;
        long totalLines = rawData.count();
        
        final ItemProviderImpl provider = new ItemProviderImpl();
        
        System.out.println("Total number of lines:"+totalLines);
        JavaPairRDD<Integer, MayaRestaurant> objRDD = rawData.mapToPair(new PairFunction<String, Integer, MayaRestaurant>(){

            @Override
            public Tuple2<Integer, MayaRestaurant> call(String json) throws Exception {
                MayaRestaurant obj = provider.provideRestaurant(json);
                return new Tuple2<Integer, MayaRestaurant>(obj.getId(), obj);
            }
            
        });
        
        JavaRDD<Collection<String>> cuisineListRDD = objRDD.map(input -> input._2.getCuisines());
        JavaRDD<Collection<String>> optionsListRDD = objRDD.map(input -> input._2.getOptions());
        
        List<String> cuisinesList = getUniqueStrings(cuisineListRDD);
        List<String> optionsList = getUniqueStrings(optionsListRDD);
        
        JavaPairRDD<Integer, Vector> vectorRDD = computeVectors(objRDD, cuisinesList, optionsList);
        /*vectorRDD = vectorRDD.partitionBy(new HashPartitioner(NUM_PARTITIONS));*/
        
        RowMatrix matrix = constructRowMatrix(vectorRDD);
        
        CoordinateMatrix similarities = matrix.columnSimilarities(0.5);
        similarities.entries().saveAsTextFile("target/Similarities");
        similarities.toIndexedRowMatrix();
        
        long endTime = System.currentTimeMillis();
        System.out.println(".. Time taken:" + (endTime-startTime));
    }
    
    private static RowMatrix constructRowMatrix(JavaPairRDD<Integer, Vector> vectorRDD){
        List<Integer> itemIds = vectorRDD.keys().collect();
        final Map<Integer, Integer> itemIdToIndexMap = Maps.newHashMap();
        int index = 0;
        for(Integer itemId : itemIds){
            itemIdToIndexMap.put(itemId, index);
            index++;
        }
        
        JavaRDD<Collection<MatrixEntry>> matrixEntriesRDD =  vectorRDD.map(new Function<Tuple2<Integer, Vector>, Collection<MatrixEntry>>(){

            @Override
            public Collection<MatrixEntry> call(Tuple2<Integer, Vector> input) throws Exception {
                int colIndex = itemIdToIndexMap.get(input._1);
                Vector vector = input._2;
                double[] values = vector.toDense().toArray();
                
                int rowIndex = 0;
                Collection<MatrixEntry> result = new ArrayList<>();
                for(double val : values){
                    result.add(new MatrixEntry(rowIndex, colIndex, val));
                    rowIndex++;
                }
                /*vector.foreachActive(new Function2<Object, Object, BoxedUnit>(){

                    @Override
                    public BoxedUnit call(Object arg0, Object arg1) throws Exception {
                        result.add(new MatrixEntry())
                    }
                    
                });*/
                return result;
            }
            
        });
        
        JavaRDD<MatrixEntry> flatMatEntriesRDD = matrixEntriesRDD.flatMap(input -> input);
        CoordinateMatrix coordMatrix = new CoordinateMatrix(flatMatEntriesRDD.rdd());
        return coordMatrix.toRowMatrix();
    }
    
    private static JavaPairRDD<Integer, Vector> computeVectors(JavaPairRDD<Integer, MayaRestaurant> objRDD,
            List<String> cuisinesList, List<String> optionsList){
        final RestaurantProcessor restProcessor = new RestaurantProcessor(cuisinesList, optionsList);
        
        JavaPairRDD<Integer, Vector> vectorRDD = objRDD.mapToPair(input -> new Tuple2<Integer, Vector>(input._1, restProcessor.processRestaurant(input._2)));
        System.out.println(cuisinesList+"::OPTIONS::"+ optionsList+",PriceRange, AmbienceRating, FoodRating, ServiceRating, ValueRating, AggregateRating");
        vectorRDD.saveAsTextFile("target/RestaurantVectors");
        return vectorRDD;
    }
    
    private static List<String> getUniqueStrings(JavaRDD<Collection<String>> strListRDD){
        
        JavaRDD<Collection<String>> lowerCuisineListRDD = strListRDD.map(new Function<Collection<String>, Collection<String>>(){
            @Override
            public Collection<String> call(Collection<String> input) throws Exception {
                Collection<String> result = new ArrayList<String>();
                for(String cuisine : input){
                    result.add(cuisine.toLowerCase());
                }
                return result;
            }
        });
        JavaRDD<String> allStrRDD = lowerCuisineListRDD.flatMap(input -> input);
        JavaRDD<String> distinctStrRDD = allStrRDD.distinct();
        return distinctStrRDD.collect();
    }

}
