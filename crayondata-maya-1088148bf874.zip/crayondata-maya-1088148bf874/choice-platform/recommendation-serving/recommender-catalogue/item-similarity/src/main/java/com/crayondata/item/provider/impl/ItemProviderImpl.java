/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.item.provider.impl;


import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.function.Consumer;

import com.crayondata.choice.rateableitem.MayaHotel;
import com.crayondata.choice.rateableitem.MayaMovie;
import com.crayondata.choice.rateableitem.MayaRestaurant;
import com.crayondata.item.provider.ItemProvider;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

/**
 * 
 * @author vivek
 *
 */
public class ItemProviderImpl implements ItemProvider,Serializable {
    
    private static final String CUISINE_LOW = "servescuisine_low";
    private static final String CUISINE_HIGH = "servescuisine_high";
    private static final String CUISINE_VHIGH = "servescuisine_vhigh";
    
    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    
    /*private final Gson gson;*/
    
    public ItemProviderImpl(){
        /*this.gson = new GsonBuilder().create();*/
    }

    @Override
    public MayaRestaurant provideRestaurant(String json) {
        Gson gson = new GsonBuilder().create();
        MayaRestaurant result = gson.fromJson(json, MayaRestaurant.class);
        result.setCuisines(getCuisines(json));
        
        return result;
    }
    
    private Collection<String> getCuisines(String json){
        JsonParser parser = new JsonParser();
        JsonElement element = 
                parser.parse(json);
        JsonObject obj = 
                element.getAsJsonObject();
        Collection<String> cuisines = new ArrayList<>();
        processCuisineElement(obj.get(CUISINE_LOW), cuisines);
        processCuisineElement(obj.get(CUISINE_HIGH), cuisines);
        processCuisineElement(obj.get(CUISINE_VHIGH), cuisines);
        
        return cuisines;
    }
    
    private void processCuisineElement(JsonElement cusineElement, Collection<String> cuisines){
        if(cusineElement != null && cusineElement.isJsonArray()){
            cusineElement.getAsJsonArray().forEach(new Consumer<JsonElement>(){
                @Override
                public void accept(JsonElement t) {
                    cuisines.add(t.getAsString());
                }
            });
        }
    }

    @Override
    public MayaHotel provideHotel(String json) {
        return new GsonBuilder().create().fromJson(json, MayaHotel.class);
    }

    @Override
    public MayaMovie provideMovie(String json) {
        return new GsonBuilder().create().fromJson(json, MayaMovie.class);
    }

}
