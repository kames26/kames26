/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.item.provider.impl;

import java.io.Serializable;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import com.crayondata.choice.rateableitem.Category;
import com.crayondata.choice.rateableitem.CreativeWork;
import com.crayondata.choice.rateableitem.LocalBusiness;
import com.crayondata.choice.rateableitem.RateableItemDao;
import com.crayondata.choice.rateableitem.solr.CreativeWorkDAOImpl;
import com.crayondata.choice.rateableitem.solr.LocalBusinessDAOImpl;
import com.crayondata.item.provider.ICachedItemProvider;

/**
 * 
 * @author vivek
 *
 * @param <T>
 */
public class CachedItemProviderImpl<T> implements ICachedItemProvider<T>,Serializable {
    
    private static final int PAGINATION_SIZE = 100;
    
    private String solrHost = "latest-solr.buildmaya.com"/*"dev.buildmaya.com"*/;
    private static final String solrPort = "8983";

    private Category cat;
    
    private Map<Integer,T> itemCache;
    
    @Override
    public T getItem(int id) {
        return this.itemCache.get(id);
    }
    
    public CachedItemProviderImpl(Category cat, 
            String solrHost){
        this.cat = cat;
        this.solrHost = solrHost;
        this.itemCache = new ConcurrentHashMap<Integer, T>();
    }
    
    public void constructCache(List<Integer> itemIds){
        if(cat.isLocalBusiness())
            loadLocalBusinesses(itemIds);
        else
            loadCreativeWorkss(itemIds);
    }
    
    private void loadLocalBusinesses(List<Integer> itemIds){
        RateableItemDao<LocalBusiness> localBusinessDAO = new LocalBusinessDAOImpl(solrHost, solrPort);
        int size = itemIds.size();
        for(int index=0;index<size;){
            Collection<Integer> itemIdChunk;
            if(index+PAGINATION_SIZE >=size)
                itemIdChunk = itemIds.subList(index, size);
            else{
                int toIndex = index+PAGINATION_SIZE;
                itemIdChunk = itemIds.subList(index, toIndex);
            }
            localBusinessDAO.findAll(itemIdChunk).forEach(x -> this.itemCache.put(x.getId(), (T)x));
            index += PAGINATION_SIZE;
        }
    }
    
    private void loadCreativeWorkss(List<Integer> itemIds){

        RateableItemDao<CreativeWork> creativeWorkDAO = new CreativeWorkDAOImpl(solrHost, solrPort);
        int size = itemIds.size();
        for(int index=0;index<size;){
            Collection<Integer> itemIdChunk;
            if(index+PAGINATION_SIZE >=size)
                itemIdChunk = itemIds.subList(index, size);
            else{
                int toIndex = index+PAGINATION_SIZE;
                itemIdChunk = itemIds.subList(index, toIndex);
            }
            creativeWorkDAO.findAll(itemIdChunk).forEach(x -> this.itemCache.put(x.getId(), (T)x));
            index += PAGINATION_SIZE;
        }
    }
}
