/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.item.processor.spark;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

import org.apache.spark.HashPartitioner;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.mllib.linalg.SparseVector;
import org.apache.spark.mllib.linalg.Vector;
import org.apache.spark.mllib.linalg.distributed.CoordinateMatrix;
import org.apache.spark.mllib.linalg.distributed.MatrixEntry;
import org.apache.spark.mllib.linalg.distributed.RowMatrix;
import org.apache.spark.storage.StorageLevel;

import scala.Tuple2;

import com.google.common.collect.ImmutableBiMap;

/**
 * 
 * @author vivek
 *
 */
public class SimilarityScoreLookupUtil implements ISimilarityScoreLookupUtil {
	
	private final int topN;
	private final int partitionCount;
	
	public SimilarityScoreLookupUtil(int topN, int partitionCount){
		this.topN = topN;
		this.partitionCount = partitionCount;		
	}
	
	public RowMatrix constructTransposedRowMatrix(JavaPairRDD<Integer, Vector> vectorRDD, JavaPairRDD<Integer, Integer> idToIndexRdd) {
	    
	    
	    final Map<Integer, Integer> finalItemIdToIndexMap = idToIndexRdd.collectAsMap();
	    
	    System.out.println(".. Number of entris in id to index as map..:" + finalItemIdToIndexMap.size());
	    
	    JavaRDD<Collection<MatrixEntry>> matrixEntriesRDD =  vectorRDD.map(input -> {
	            int colIndex = finalItemIdToIndexMap.get(input._1);
	            SparseVector vector = input._2.toSparse();
	            int[] indices = vector.indices();
	            double[] values = vector.values();
	            Collection<MatrixEntry> result = new ArrayList<>();
	            
	            for(int i=0;i<indices.length;i++){
	            	result.add(new MatrixEntry(indices[i], colIndex, values[i]));
	            }
	            
	            /*double[] values = vector.toDense().toArray();
	            int rowIndex = 0;
	            
	            for(double val : values){
	                result.add(new MatrixEntry(rowIndex, colIndex, val));
	                rowIndex++;
	            }*/
	            return result;
	    });
	    
	    JavaRDD<MatrixEntry> flatMatEntriesRDD = matrixEntriesRDD.flatMap(input -> input);
	    CoordinateMatrix coordMatrix = new CoordinateMatrix(flatMatEntriesRDD.rdd());
	    return coordMatrix.toRowMatrix();
	}

	protected JavaPairRDD<Integer, Integer> createIdToIndexMap(JavaSparkContext jc, 
    		JavaPairRDD<Integer, Vector> vectorRDD){
    	List<Integer> itemIds = vectorRDD.keys().collect();
        /*itemIdToIndexMap = Maps.newHashMap();*/
        List<Tuple2<Integer, Integer>> tuples = new ArrayList<>();
        int index = 0;
        for(Integer itemId : itemIds){
            tuples.add(new Tuple2<>(itemId, index));
            index++;
        }
        
        System.err.println(".. Id to index map created.."+tuples);
        
        return jc.parallelizePairs(tuples);
    }

	/* (non-Javadoc)
	 * @see com.crayondata.item.processor.spark.ISimilarityScoreLookupUtil#constructSimilarityModel(org.apache.spark.api.java.JavaPairRDD, org.apache.spark.api.java.JavaSparkContext)
	 */
	@Override
	public JavaPairRDD<Integer, Collection<Tuple2<Integer, Double>>> constructSimilarityModel(JavaPairRDD<Integer, Vector> vectorRDD, JavaSparkContext jc) {
		
	    vectorRDD = vectorRDD.partitionBy(new HashPartitioner(partitionCount)).persist(StorageLevel.DISK_ONLY());
	    JavaPairRDD<Integer, Integer> idToIndexRdd = createIdToIndexMap(jc, vectorRDD).cache();
	    
	    RowMatrix matrix = constructTransposedRowMatrix(vectorRDD, idToIndexRdd);
	    
	    System.out.println(".. Matrix construction completed..");
	    
	    CoordinateMatrix similarities = matrix.columnSimilarities(0.5);
	    
	    saveSimilarities(similarities, idToIndexRdd, "target");
	    
	    /*return constructScoreLookup(similarities.toIndexedRowMatrix());*/
	    return constructScoreLookup(similarities, idToIndexRdd);
	}

	public void saveSimilarities(CoordinateMatrix similarities, JavaPairRDD<Integer, Integer> idToIndexRdd,
			String outputDir) {
		ImmutableBiMap<Integer, Integer> biMap = new ImmutableBiMap.Builder<Integer, Integer>().putAll(
				idToIndexRdd.collectAsMap()).build();
		System.out.println(".. saveSimilarities.. :: biMap size:" + biMap.size());
	    ImmutableBiMap<Integer, Integer> indexToItemIdMap = biMap.inverse();
	    System.out.println(".. saveSimilarities.. :: indexToItemIdMap size::" + 
	    		indexToItemIdMap.size());
	    System.err.println(".. saveSimilarities.. :: inverse map::" + indexToItemIdMap);
	    
	    JavaPairRDD<Integer, Tuple2<Integer, Double>> item1to2Map = 
	        	similarities.entries().toJavaRDD().mapToPair(x -> {
	        	Integer item1Id = indexToItemIdMap.get((int)x.i());
	        	Integer item2Id = indexToItemIdMap.get((int)x.j());
	        	Double value = x.value();
	        	return new Tuple2<>(item1Id, new Tuple2<>(item2Id, value));
	        });
	    
	    JavaRDD<String> toPrintRdd = 
	    		item1to2Map.map(x -> x._1 + "," + x._2._1 + "," + x._2._2);
	    toPrintRdd.saveAsTextFile(outputDir+"/Similarities");
	}

	/* (non-Javadoc)
	 * @see com.crayondata.item.processor.spark.ISimilarityScoreLookupUtil#loadScoreLookupFrom(java.lang.String, org.apache.spark.api.java.JavaSparkContext)
	 */
	@Override
	public JavaPairRDD<Integer, Collection<Tuple2<Integer, Double>>> loadScoreLookupFrom(String fileUri, JavaSparkContext jc) {
		// FIXME To check if cache() will work for 5 to 10 M entries.
		JavaPairRDD<Integer, Tuple2<Integer, Double>> item1to2Map =
				jc.textFile(fileUri).mapToPair(x -> {
			String[] tokens = x.split(",");
			Integer item1Id = Integer.valueOf(tokens[0]);
	    	Integer item2Id = Integer.valueOf(tokens[1]);
	    	Double value = Double.valueOf(tokens[2]);
	    	/*System.out.printf("Loading:%d,%d,%f\n", item1Id, item2Id, value);*/
	    	return new Tuple2<>(item1Id, new Tuple2<>(item2Id, value));
		}).cache();
		
		return constructScoreLookupFrom(item1to2Map).cache();
	}

	private JavaPairRDD<Integer, Collection<Tuple2<Integer, Double>>> constructScoreLookupFrom(
			JavaPairRDD<Integer, Tuple2<Integer, Double>> item1to2Map) {
	
		System.out.printf("Number of similarities:%d\n", item1to2Map.count());
	
		JavaPairRDD<Integer, Tuple2<Integer, Double>> filtered =  
				item1to2Map.filter(x -> {
					boolean retVal = true;
					if(x._1 == null || x._2 == null || x._2._1 == null || x._2._2 == null)
						retVal = false;
					return retVal;
				});
		System.out.printf("Number of similarities filtered:%d\n", filtered.count());
	
		JavaPairRDD<Integer, Iterable<Tuple2<Integer, Double>>> item1ScoresMap =  
				filtered.groupByKey();
		System.out.printf("Count after group by:%d\n", item1ScoresMap.count());
	
		JavaPairRDD<Integer, Collection<Tuple2<Integer,Double>>> lookupTable =
				item1ScoresMap.mapToPair(x -> {
					List<Tuple2<Integer, Double>> scoreCollection = new ArrayList<>();
					/*Iterables.addAll(scoreCollection, x._2);*/
					x._2.forEach(y -> scoreCollection.add(y));
					Collections.sort(scoreCollection, new SerializableTupleComaparator());
					Collection<Tuple2<Integer, Double>> retVal = 
							(scoreCollection.size() > topN)?new ArrayList<>(scoreCollection.subList(0, topN)): scoreCollection;
							return new Tuple2<>(x._1, retVal);
				});
	
		System.out.printf("Count of entries in lookup table :%d\n", lookupTable.count());
	
		return lookupTable.cache();
	}

	public JavaPairRDD<Integer, Collection<Tuple2<Integer, Double>>> constructScoreLookup(CoordinateMatrix similarities, JavaPairRDD<Integer, Integer> idToIndexMap) {
		ImmutableBiMap<Integer, Integer> biMap = new ImmutableBiMap.Builder<Integer, Integer>().putAll(
				idToIndexMap.collectAsMap()).build();
	    ImmutableBiMap<Integer, Integer> indexToItemIdMap = biMap.inverse();
	    
	    JavaPairRDD<Integer, Tuple2<Integer, Double>> item1to2Map = 
	    	similarities.entries().toJavaRDD().mapToPair(x -> {
	    	Integer item1Id = indexToItemIdMap.get((int)x.i());
	    	Integer item2Id = indexToItemIdMap.get((int)x.j());
	    	Double value = x.value();
	    	return new Tuple2<>(item1Id, new Tuple2<>(item2Id, value));
	    });
	    
	    return constructScoreLookupFrom(item1to2Map);
	}
	

    
    public class SerializableTupleComaparator implements Comparator<Tuple2<Integer, Double>>, Serializable {
    	private static final long serialVersionUID = 1L;

		@Override
    	public int compare(Tuple2<Integer, Double> o1, Tuple2<Integer, Double> o2) {
    		return o2._2.compareTo(o1._2);
    	}
    }

	/* (non-Javadoc)
	 * @see com.crayondata.item.processor.spark.ISimilarityScoreLookupUtil#getOrderedChoices(java.util.List, java.util.Map)
	 */
	@Override
	public List<Integer> getOrderedChoices(List<Integer> itemIds, 
			Map<Integer, Collection<Tuple2<Integer, Double>>> lookupMap) {
		List<Collection<Tuple2<Integer, Double>>> choicesAndScores = new ArrayList<>();
		itemIds.forEach(x -> choicesAndScores.add(getChoices(x, lookupMap)));
		List<Tuple2<Integer, Double>> flatList = 
			choicesAndScores.stream().flatMap(x -> x.stream()).collect(Collectors.toList());
		Map<Integer, Double> itemSumScoreMap = new ConcurrentHashMap<>();
		Map<Integer, Integer> itemScoreCountMap = new ConcurrentHashMap<>();
		
		flatList.forEach(x -> {
			Integer itemId = x._1;
			Double score = x._2;
			if(itemSumScoreMap.containsKey(itemId)){
				double existingScore = itemSumScoreMap.get(itemId);
				itemSumScoreMap.put(itemId, 
						/*(score>existingScore)?score:existingScore*/ existingScore+score);  // Score aggregate function ---> Max function
				int existingCount = itemScoreCountMap.get(itemId);
				itemScoreCountMap.put(itemId, existingCount+1);
			}else{
				itemSumScoreMap.put(itemId, score);
				itemScoreCountMap.put(itemId, 1);
			}
		});
		Map<Integer, Double> itemMeanScoreMap = new ConcurrentHashMap<>();
		itemSumScoreMap.entrySet().forEach(x -> {
			double mean = x.getValue()/itemScoreCountMap.get(x.getKey());
			itemMeanScoreMap.put(x.getKey(), mean);
		});
		List<Integer> result = itemMeanScoreMap.entrySet().stream().sorted(Map.Entry.<Integer,Double>comparingByValue().reversed())
			.map(x -> x.getKey()).collect(Collectors.toList());
		
		/*JavaRDD<Collection<Tuple2<Integer, Double>>> choicesRdd = 
				jc.parallelize(choicesAndScores).cache();
		JavaPairRDD<Integer, Double> choicesMapRdd = 
				choicesRdd.flatMap(x -> x).mapToPair(x -> x);
		JavaPairRDD<Integer, Double> combinedScoreMap =  
			choicesMapRdd.foldByKey(0.0, (x,y)->x+y); // Change here for other functions..
		JavaPairRDD<Double, Integer> flippedMap = combinedScoreMap.mapToPair(x -> new Tuple2<>(x._2,x._1));*/
		
		int maxChoices = (itemIds.size() <= 100)?itemIds.size() : 100;
		/*List<Integer> result = flippedMap.sortByKey().values().collect();*/
		if(result.size() > maxChoices)
			result = new ArrayList<>(result.subList(0, maxChoices));
		return result;
	}

	public Collection<Tuple2<Integer, Double>> getChoices(Integer itemId,
			Map<Integer, Collection<Tuple2<Integer, Double>>> lookupMap) {
		System.err.printf("Looking up for key:%d\n", itemId);
		/*List<Collection<Tuple2<Integer, Double>>> filtered =
				this.lookupTable.lookup(itemId);
		Collection<Tuple2<Integer, Double>> result = (filtered != null)?filtered.get(0):Collections.emptyList();*/
		// Need to find out an alternate to this.. FIXME
		Collection<Tuple2<Integer, Double>> result = 
				lookupMap.get(itemId);
		if(result == null)
			result = Collections.emptyList();
		
		System.err.printf(".. Size of the list:%d\n", result.size());
		return result;
	}

	
}
