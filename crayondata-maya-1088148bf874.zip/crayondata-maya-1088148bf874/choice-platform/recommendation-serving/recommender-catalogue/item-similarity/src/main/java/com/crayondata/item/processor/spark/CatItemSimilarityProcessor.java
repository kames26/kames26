/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.item.processor.spark;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.List;
import java.util.Map;

import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.mllib.linalg.Vector;
import org.apache.spark.storage.StorageLevel;

import scala.Tuple2;

import com.crayondata.choice.rateableitem.Category;
import com.crayondata.choice.rateableitem.CreativeWork;
import com.crayondata.choice.rateableitem.LocalBusiness;
import com.crayondata.item.processor.MovieProcessor;
import com.crayondata.item.provider.impl.CachedItemProviderImpl;

/**
 * 
 * @author vivek
 *
 * @param <T>
 */
public class CatItemSimilarityProcessor<T> implements Serializable {
    
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	protected JavaPairRDD<Integer, Collection<Tuple2<Integer, Double>>> lookupTable;
    
	protected Category cat;
    protected List<Integer> itemIdList;

    protected int partitionCount = 256;

	protected Map<Integer, Collection<Tuple2<Integer, Double>>> lookupMap;
	
	protected static final int TOP_N = 20;

	     
    private static String SOLR_HOST;
    
    private static final int MAX_CHOICES = 18;
    
    private String solrHost;
    
    /*private Map<Integer, Integer> itemIdToIndexMap;*/
    
    
    /*private static final int NUM_PARTITIONS = 512;*/
    private static int NUM_PARTITIONS = 256;
    
    private final ISimilarityScoreLookupUtil lookupUtil;
    
    public CatItemSimilarityProcessor(Category cat, String solrHost, int partitionCount, int topN){
        this.cat = cat;
        this.solrHost = solrHost;
        this.partitionCount = partitionCount;
        this.lookupUtil = new SimilarityScoreLookupUtil(topN, partitionCount);
    }
    
    public void loadModel(String fileUri, JavaSparkContext sc) {
		this.lookupTable = this.lookupUtil.loadScoreLookupFrom(fileUri, sc).cache()/*.persist(StorageLevel.DISK_ONLY())*/;
		System.out.printf(".. Number of lookup table entries loaded from file:%d::%s\n", 
				this.lookupTable.count(), fileUri);
		this.lookupMap  =
				this.lookupTable.collectAsMap();
	}

	public void buildModel(List<Integer> itemIdList, JavaSparkContext sc) {
	    this.itemIdList = itemIdList;
	    
	    JavaPairRDD<Integer, Vector> itemVectorRdd=null;
	    if(cat.isCreativeWork())
	    	itemVectorRdd = computeVectorsForMovies(itemIdList, sc);
	    
		this.lookupTable = this.lookupUtil.constructSimilarityModel(itemVectorRdd,
				sc).cache()/*.persist(StorageLevel.DISK_ONLY())*/;
		System.out.printf(".. Lookup table consutructed with:%d entries\n",this.lookupTable.count());
		this.lookupMap  =
				this.lookupTable.collectAsMap();
	}

	protected JavaPairRDD<Integer, Vector> computeVectorsForMovies(List<Integer> itemIdList,
    		JavaSparkContext sc){
    	CachedItemProviderImpl<T> itemProvider = initCache();

    	JavaRDD<Integer> itemIdsRdd = 
    			sc.parallelize(itemIdList);
    	JavaPairRDD<Integer, T> itemsMapRdd = 
    			itemIdsRdd.mapToPair(x -> new Tuple2<>(x, itemProvider.getItem(x)));

    	JavaPairRDD<Integer, CreativeWork> movieMapRdd = (JavaPairRDD<Integer, CreativeWork>) itemsMapRdd;


    	JavaRDD<Collection<String>> genreListRdd = movieMapRdd.map(input -> input._2.getGenre());
    	JavaRDD<Collection<String>> castListRdd = movieMapRdd.map(input -> input._2.getCast());
    	JavaRDD<Collection<String>> directorListRdd = movieMapRdd.map(input -> input._2.getDirector());

    	List<String> genreList = getUniqueStrings(genreListRdd);
    	List<String> castList = getUniqueStrings(castListRdd);
    	List<String> directorList = getUniqueStrings(directorListRdd);

    	JavaPairRDD<Integer, Vector> vectorRDD = computeVectorsFrom(movieMapRdd, genreList, castList,
    			directorList).persist(StorageLevel.DISK_ONLY());
    	System.out.println(".. Vector computation completed..");
    	return vectorRDD;
    }

	
    private CachedItemProviderImpl<T> initCache(){
    	CachedItemProviderImpl<T> itemProvider = new CachedItemProviderImpl<T>(cat, solrHost);
        itemProvider.constructCache(itemIdList);
        return itemProvider;
    }
    
    private static JavaPairRDD<Integer, Vector> computeVectorsFrom(JavaPairRDD<Integer, CreativeWork> objRDD,
            List<String> genreList, List<String> castList, List<String> directorList){
        final MovieProcessor movieProcessor = new MovieProcessor(genreList, castList, directorList);
        
        JavaPairRDD<Integer, Vector> vectorRDD = objRDD.mapToPair(input -> new Tuple2<Integer, Vector>(input._1, movieProcessor.processMovie(input._2)));
        /*System.out.println(genreList+"::CAST::"+ castList+"::DIRECTOR::"+ directorList+", AggregateRating");*/
        vectorRDD.saveAsTextFile("target/MovieVectors");
        return vectorRDD;
    }
    
    public static List<String> getUniqueStrings(JavaRDD<Collection<String>> strListRDD){
        
        JavaRDD<Collection<String>> lowerCuisineListRDD = strListRDD.map(input -> {
                Collection<String> result = new ArrayList<String>();
                for(String cuisine : input){
                    result.add(cuisine.toLowerCase());
                }
                return result;
            });
        JavaRDD<String> allStrRDD = lowerCuisineListRDD.flatMap(input -> input);
        JavaRDD<String> distinctStrRDD = allStrRDD.distinct();
        return distinctStrRDD.collect();
    }

    
        
    public static void main(String[] args) {
        if(args.length < 3)
            System.err.println("Usage:: CatItemSimilarityProcessor <category> <solr-host> <partition-count> <topN>");
        else{
            Category cat = Category.parseCategory(args[0]);
            SOLR_HOST = args[1];
            CatItemSimilarityProcessor similarityProcessor; 
            NUM_PARTITIONS = Integer.parseInt(args[2]);
            int topN = Integer.parseInt(args[3]);
            if(cat.isLocalBusiness())
                similarityProcessor = new CatItemSimilarityProcessor<LocalBusiness>(cat, SOLR_HOST, NUM_PARTITIONS, topN);
            else
                similarityProcessor = new CatItemSimilarityProcessor<CreativeWork>(cat, SOLR_HOST, NUM_PARTITIONS, topN);
        }
            
    }

	public List<Integer> getOrderedChoices(List<Integer> itemIds) {
		return this.lookupUtil.getOrderedChoices(itemIds, lookupMap);
	}
    

}
