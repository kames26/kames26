All runtime scoring modules for the models goes here.
Anything related to batch mode model generation of Taste Graph gets into ./taste-graph directory.
