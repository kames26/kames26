/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.evaluation.metrics.output;

import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;

import scala.Tuple2;
import scala.Tuple3;

public class ResultJoiner {
    
    private static final String file1Uri = "/home/vivek/evaluator/results/attr_results.csv";
    private static final String file2Uri = "/home/vivek/evaluator/results/tg_results.csv";

    public static void main(String[] args) {
        SparkConf conf = new SparkConf().setAppName("Uid pid Application").set("spark.executor.memory", "32g")
                .set("spark.num.executors", "1")/*.set("spark.executor.cores", "7").*/.set("spark.total.executor.cores", "15")
                .set("spark.storage.memoryFraction", "0.1");
        JavaSparkContext sc = new JavaSparkContext(conf);
        
        JavaRDD<String> file1Rdd = sc.textFile(file1Uri).cache();
        JavaRDD<String> file2Rdd = sc.textFile(file2Uri).cache();
        
        JavaPairRDD<String, Tuple2<Integer, Double>>
            file1Data = file1Rdd.mapToPair(input -> {
               String[] tokens = input.split(",");
               Tuple2<Integer, Double> val = new Tuple2<>(Integer.parseInt(tokens[1]),
                       Double.parseDouble(tokens[2]));
               return new Tuple2<>(tokens[0], val);
            });
        
        JavaPairRDD<String, Tuple2<Integer, Double>>
        file2Data = file2Rdd.mapToPair(input -> {
           String[] tokens = input.split(",");
           Tuple2<Integer, Double> val = new Tuple2<>(Integer.parseInt(tokens[1]),
                   Double.parseDouble(tokens[2]));
           return new Tuple2<>(tokens[0], val);
        });
        
        JavaPairRDD<String, Tuple3<Integer, Double, Double>> 
            joinedData = file1Data.join(file2Data).mapToPair(
                    input -> {
                        String key = input._1;
                        Tuple2<Integer, Double> val1 = input._2._1;
                        Tuple2<Integer, Double> val2 = input._2._2;
                        return new Tuple2<>(key, new Tuple3<>(val1._1,val1._2, val2._2));
                    });
        
        JavaRDD<String> toPrint = joinedData.map(
                    input -> {
                        String userId = input._1;
                        Integer interactions = input._2._1();
                        Double model1Accr = input._2._2();
                        Double model2Accr = input._2._3();
                        
                        return userId + "," + interactions + "," + model1Accr+ "," + model2Accr;
                    });

        toPrint.saveAsTextFile("/home/vivek/evaluator/results/joined");
    }

}
