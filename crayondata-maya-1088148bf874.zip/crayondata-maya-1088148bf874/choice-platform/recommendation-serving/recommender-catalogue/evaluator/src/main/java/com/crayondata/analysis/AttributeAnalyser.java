/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.analysis;

import com.crayondata.evaluation.metrics.enterprise.PropertiesLoader;
import com.google.common.base.Joiner;
import com.google.common.base.Optional;
import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.DataFrame;
import org.apache.spark.sql.SQLContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.geo.Point;
import scala.Tuple2;
import scala.collection.JavaConversions;
import scala.collection.mutable.WrappedArray;

/**
 *
 * @author somin
 */
public class AttributeAnalyser implements Serializable {

    private String propFileUri;
    private String detailsFileUri;
    private String interactionsFileUri;

    private static final Logger LOG = LoggerFactory.getLogger(AttributeAnalyser.class);

    private static final Joiner csvJoiner = Joiner.on(",");

    private static final double CUISINE_FILTER_THRESHOLD = 0.75;
    private static final boolean ENABLE_FILTER = true;

    public AttributeAnalyser(String propFileUri) {
        this.propFileUri = propFileUri;
    }

    private DataFrame readDataFromAvroFile(JavaSparkContext sc, String fileUri) {
        SQLContext sqlContext = new SQLContext(sc);
        DataFrame df = sqlContext.read().format("com.databricks.spark.avro").load(fileUri);
        return df;
    }

    protected JavaPairRDD<Integer, List<String>> extractCuisineFromDataFrame(DataFrame df) {
        return df.javaRDD().mapToPair(x -> {
            List<String> asList;
            //for 3 cuisine columns
            WrappedArray c1 = x.getAs("c1");
            WrappedArray c2 = x.getAs("c2");
            WrappedArray c3 = x.getAs("c3");
            if ((c1 == null && c2 == null && c3 == null)) {
                asList = Collections.emptyList();
            } else {
                asList = new ArrayList<>();
                asList.addAll(c1 == null ? Collections.emptyList() : scalaListToJavaList(c1));
                asList.addAll(c2 == null ? Collections.emptyList() : scalaListToJavaList(c2));
                asList.addAll(c3 == null ? Collections.emptyList() : scalaListToJavaList(c3));
            }
            return new Tuple2<>(x.getInt(0), asList);
        });
    }

    private static List scalaListToJavaList(WrappedArray c1) {
        return JavaConversions.asJavaList(c1.toList());
    }

    protected JavaPairRDD<Integer, List<String>> extractCuisineFromAvroFile(JavaSparkContext sc, String fileUri) {
        DataFrame dataFromAvro = readDataFromAvroFile(sc, fileUri);
        JavaPairRDD<Integer, List<String>> item_cuisines = extractCuisineFromDataFrame(dataFromAvro);
//        List<Tuple2<Integer, List<String>>> first = item_cuisines.take(5);
//        first.forEach(x -> {
//            System.out.println("1111111111111" + x._1);
//            System.out.println("2222222222222" + x._2);
//        });
        return item_cuisines;
    }

    protected JavaPairRDD<Integer, String> extractGeoFromAvroFile(JavaSparkContext sc, String fileUri) {
        DataFrame dataFromAvro = readDataFromAvroFile(sc, fileUri);
        return dataFromAvro.javaRDD().mapToPair(x -> {
            String geo = x.getAs("geo");
            return new Tuple2<>(x.getInt(0), geo);
        });
    }

    protected JavaPairRDD<Integer, String> extractInteractionsFromAvroFile(JavaSparkContext sc, String fileUri) {
        DataFrame dataFrame = readDataFromAvroFile(sc, fileUri);
        return dataFrame.javaRDD().mapToPair(x -> new Tuple2<>(x.getInt(0), x.getString(1).intern()));
    }

    protected JavaPairRDD<Integer, Tuple2<String, List<String>>> joinInteractionsAndCuisines(JavaPairRDD<Integer, String> interactions, JavaPairRDD<Integer, List<String>> cuisines) {
        JavaPairRDD<Integer, Tuple2<String, List<String>>> interactions_cuisines = interactions.join(cuisines);
        return interactions_cuisines;
    }

    protected JavaPairRDD<Integer, Tuple2<String, String>> joinInteractionsAndGeo(JavaPairRDD<Integer, String> interactions, JavaPairRDD<Integer, String> geo) {
        JavaPairRDD<Integer, Tuple2<String, String>> interactions_geo = interactions.join(geo);
        return interactions_geo;
    }

    protected void processCuisineCountsPerUser(
            JavaPairRDD<Integer, Tuple2<String, List<String>>> joinInteractionsAndCuisines) {
        JavaRDD<Tuple2<String, List<String>>> map = joinInteractionsAndCuisines.map(x -> x._2);
        JavaPairRDD<String, String> flatMapToPair = map.flatMapToPair(
                x -> {
                    List<Tuple2<String, String>> result = Lists.newArrayList();
                    x._2.forEach(
                            y -> result.add(new Tuple2<>(x._1, y))
                    );
                    return result;
                }
        );
        JavaPairRDD<String, Integer> mapToPair = flatMapToPair.distinct().groupByKey().mapToPair(
                x -> new Tuple2<>(x._1, Iterables.size(x._2))
        );
        mapToPair.map(x -> x._1 + "," + x._2).saveAsTextFile("output/cuisines_per_user");
    }

    protected void processCuisineDistributionPerUser(
            JavaPairRDD<Integer, Tuple2<String, List<String>>> joinInteractionsAndCuisines) {
        JavaPairRDD<String, Integer> userTransCount
                = joinInteractionsAndCuisines.mapToPair(x -> new Tuple2<>(x._2._1, x._1)).mapToPair(x -> new Tuple2<>(x._1, 1)).reduceByKey((x, y) -> x + y);
        JavaPairRDD<String, Long> uniqRestCount
                = computeUniqRestaurantCounts(joinInteractionsAndCuisines);

        JavaRDD<Tuple2<String, List<String>>> map = joinInteractionsAndCuisines.map(x -> x._2);
        JavaPairRDD<String, String> flatMapToPair = map.flatMapToPair(
                x -> {
                    List<Tuple2<String, String>> result = Lists.newArrayList();
                    x._2.forEach(
                            y -> result.add(new Tuple2<>(x._1, y))
                    );
                    return result;
                }
        );
        JavaPairRDD<String, Iterable<String>> groupByKey = flatMapToPair.groupByKey();

        JavaPairRDD<String, Long> userUniqCuisineCount
                = groupByKey.mapToPair(x -> {
                    String userId = x._1;
                    List<String> cuisines = Lists.newArrayList();
                    Iterables.addAll(cuisines, x._2);
                    long uniqCuisineCount = cuisines.stream().distinct().count();
                    return new Tuple2<>(userId, uniqCuisineCount);
                });

        JavaPairRDD<String, Map<String, Double>> perUserCuisineDistr = groupByKey.mapToPair(x -> {
            String userId = x._1;
            List<String> cuisines = Lists.newArrayList();
            Iterables.addAll(cuisines, x._2);
            double cuisineCount = cuisines.stream().count() * 1.0;
            Map<String, Long> cuisineCountMap
                    = cuisines.stream().collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));
            Map<String, Double> cuisineDistrMap = Maps.newConcurrentMap();
            cuisineCountMap.forEach((cuisine, count) -> cuisineDistrMap.put(cuisine, count / cuisineCount));
            return new Tuple2<>(userId, cuisineDistrMap);
        });

        JavaPairRDD<String, String> userToCuisineDistrStr = perUserCuisineDistr.mapToPair(x -> {
            List<String> values = Lists.newArrayList();
            x._2.forEach((a, b) -> values.add(a + "," + b));
            return new Tuple2<>(x._1, csvJoiner.join(values));
        });

        JavaPairRDD<String, String> userTransRest
                = userTransCount.join(uniqRestCount).mapToPair(x -> new Tuple2<>(x._1, x._2._1 + "," + x._2._2));
        JavaPairRDD<String, String> userTransRestCuisines
                = userTransRest.join(userUniqCuisineCount).mapToPair(x -> new Tuple2<>(x._1, x._2._1 + "," + x._2._2));
        JavaPairRDD<String, String> userStats
                = userTransRestCuisines.join(userToCuisineDistrStr).mapToPair(x -> new Tuple2<>(x._1, x._2._1 + "," + x._2._2));

        userStats.map(x -> x._1 + "," + x._2).saveAsTextFile("output/PerUserStats");
    }

    protected JavaPairRDD<String, Long> computeUniqRestaurantCounts(JavaPairRDD<Integer, Tuple2<String, List<String>>> joinInteractionsAndCuisines) {
        JavaPairRDD<String, Integer> usersAndItems
                = joinInteractionsAndCuisines.mapToPair(x -> new Tuple2<>(x._2._1, x._1));
        JavaPairRDD<String, Long> usersItemCount
                = usersAndItems.groupByKey().mapToPair(x -> {
                    List<Integer> itemIds = Lists.newArrayList();
                    Iterables.addAll(itemIds, x._2);
                    long uniqRestCount = itemIds.stream().distinct().count();
                    return new Tuple2<>(x._1, uniqRestCount);
                });

        return usersItemCount;
    }

    protected Map<String, Integer> processCuisineCounts(
            JavaPairRDD<Integer, Tuple2<String, List<String>>> joinInteractionsAndCuisines) {
        JavaRDD<List<String>> cuisines = joinInteractionsAndCuisines.map(x -> x._2._2);
        JavaRDD<String> flatMap = cuisines.flatMap(x -> x);
        JavaPairRDD<String, Integer> mapToPair = flatMap.mapToPair(x -> new Tuple2<>(x, 1));
        JavaPairRDD<String, Integer> reduceByKey = mapToPair.reduceByKey((x, y) -> x + y);
        reduceByKey.map(x -> x._1 + "," + x._2).saveAsTextFile("output/cuisineCounts");
        reduceByKey.foreach(x -> {
            System.out.println(x);
        });
        Map<String, Integer> collectAsMap = reduceByKey.collectAsMap();
        return collectAsMap;
    }

    protected void processCuisines(JavaSparkContext sc) {
        JavaPairRDD<Integer, List<String>> extractCuisineFromAvroFile = extractCuisineFromAvroFile(sc, detailsFileUri);
        JavaPairRDD<Integer, String> extractInteractionsFromAvroFile = extractInteractionsFromAvroFile(sc, interactionsFileUri);
        JavaPairRDD<Integer, Tuple2<String, List<String>>> joinInteractionsAndCuisines = joinInteractionsAndCuisines(extractInteractionsFromAvroFile, extractCuisineFromAvroFile);

        if (ENABLE_FILTER) {
            JavaPairRDD<Integer, String> retainedTransactions
                    = filterTransactions(joinInteractionsAndCuisines, extractInteractionsFromAvroFile);
            joinInteractionsAndCuisines = joinInteractionsAndCuisines(retainedTransactions, extractCuisineFromAvroFile);
        }

        processCuisineCounts(joinInteractionsAndCuisines);
        processCuisineCountsPerUser(joinInteractionsAndCuisines);

        processCuisineDistributionPerUser(joinInteractionsAndCuisines);

        JavaPairRDD<String, List<String>> user_cuisines = joinInteractionsAndCuisines.map(x -> x._2).mapToPair(x -> x);
        JavaPairRDD<String, Integer> reversed = extractInteractionsFromAvroFile.mapToPair(x -> new Tuple2<>(x._2, x._1));
        JavaPairRDD<String, Integer> user_trans_counts = reversed.groupByKey().mapToPair(
                x -> new Tuple2<>(x._1, Iterables.size(x._2))
        );
        Integer trans_sum = user_trans_counts.values().fold(0, (x, y) -> x + y);
        long trans_count = user_trans_counts.values().count();
        float trans_avg = 1.0f * trans_sum / trans_count;
        JavaPairRDD<String, Integer> high_trans = user_trans_counts.filter(x -> x._2 >= trans_avg);
        JavaPairRDD<String, Integer> low_trans = user_trans_counts.filter(x -> x._2 < trans_avg);
        JavaRDD<List<String>> highTrans_cuisines = user_cuisines.join(high_trans).map(x -> x._2._1);
        JavaRDD<List<String>> lowTrans_cuisines = user_cuisines.join(low_trans).map(x -> x._2._1);
        JavaPairRDD<String, Integer> highTrans_cuisineCounts = getCuisineCounts(highTrans_cuisines);
        JavaPairRDD<String, Integer> lowTrans_cuisineCounts = getCuisineCounts(lowTrans_cuisines);
        highTrans_cuisineCounts.map(x -> x._1 + "," + x._2).saveAsTextFile("output/cuisines_highTrans");
        lowTrans_cuisineCounts.map(x -> x._1 + "," + x._2).saveAsTextFile("output/cuisines_lowTrans");
    }

    protected JavaPairRDD<Integer, String> filterTransactions(JavaPairRDD<Integer, Tuple2<String, List<String>>> joinInteractionsAndCuisines,
            JavaPairRDD<Integer, String> transactionsRdd) {
        JavaPairRDD<String, List<String>> userToCuisines
                = joinInteractionsAndCuisines.mapToPair(x -> new Tuple2<>(x._2._1, x._2._2));
        JavaPairRDD<String, Iterable<List<String>>> groupedByUsers = userToCuisines.groupByKey();
        JavaPairRDD<String, Double> fillRateRatio
                = groupedByUsers.mapToPair(x -> {
                    Iterable<List<String>> cuisineList = x._2;
                    int count = Iterables.size(cuisineList);
                    final List<List<String>> nonEmpty = Lists.newArrayList();
                    cuisineList.forEach(y -> {
                        if (y != null && !y.isEmpty()) {
                            nonEmpty.add(y);
                        }
                    });
                    int nonEmptyCount = nonEmpty.size();
                    double ratio = nonEmptyCount / count * 1.0;
                    return new Tuple2<>(x._1, ratio);
                });
        System.out.println("User count:" + fillRateRatio.count());
        JavaPairRDD<String, Double> retainedUsers
                = fillRateRatio.filter(x -> x._2.doubleValue() >= CUISINE_FILTER_THRESHOLD);
        System.out.println("retained users post filter:" + retainedUsers.count());

        System.out.println("Transactions count:" + transactionsRdd.count());
        JavaPairRDD<String, Tuple2<Integer, Double>> joinedTransactions
                = transactionsRdd.mapToPair(x -> new Tuple2<>(x._2, x._1)).join(retainedUsers);
        JavaPairRDD<Integer, String> retainedTransactionsRdd
                = joinedTransactions.mapToPair(x -> new Tuple2<>(x._2._1, x._1));
        System.out.println("Retained transactions count:" + retainedTransactionsRdd.count());
        return retainedTransactionsRdd;
    }

    private JavaPairRDD<String, Integer> getCuisineCounts(JavaRDD<List<String>> cuisines) {
        JavaRDD<String> flatMap = cuisines.flatMap(x -> x);
        JavaPairRDD<String, Integer> mapToPair = flatMap.mapToPair(x -> new Tuple2<>(x, 1));
        JavaPairRDD<String, Integer> reduceByKey = mapToPair.reduceByKey((x, y) -> x + y);
        return reduceByKey;
    }

    protected void processGeo(JavaSparkContext sc) {
        JavaPairRDD<Integer, String> extractCuisineFromAvroFile = extractGeoFromAvroFile(sc, detailsFileUri);
        JavaPairRDD<Integer, String> extractInteractionsFromAvroFile = extractInteractionsFromAvroFile(sc, interactionsFileUri);
        JavaPairRDD<Integer, Tuple2<String, String>> joinInteractionsAndGeo = joinInteractionsAndGeo(extractInteractionsFromAvroFile, extractCuisineFromAvroFile);

        JavaPairRDD<String, Iterable<String>> user_geo = joinInteractionsAndGeo.map(x -> x._2).mapToPair(x -> x).groupByKey();
        JavaPairRDD<String, Point> user_centroid = computeAndUpdateCentroid(user_geo);

        JavaPairRDD<String, Tuple2<Iterable<String>, Point>> user_geo_centroid = user_geo.join(user_centroid);
        JavaPairRDD<String, List<Double>> user_distances = user_geo_centroid.mapToPair(x -> {
            Iterable<String> locations = x._2._1;
            Point centroid = x._2._2;
            List<Double> distances = Lists.newArrayList();
            locations.forEach(z -> {
                double distance = GeoDistanceCalculator.distance(z, centroid);
                if (distance != -1) {
                    distances.add(distance);
                }
            });
            return new Tuple2<>(x._1, distances);
        }).filter(x -> !x._2.isEmpty());
        JavaPairRDD<String, Double> user_minDistance = user_distances.mapToPair(x
                -> new Tuple2<>(x._1, x._2.stream().min((a, b) -> a.compareTo(b)))
        ).filter(x -> x._2.isPresent()).mapToPair(x -> new Tuple2<>(x._1, x._2.get()));

        JavaPairRDD<String, Double> user_maxDistance = user_distances.mapToPair(x
                -> new Tuple2<>(x._1, x._2.stream().max((a, b) -> a.compareTo(b)))
        ).filter(x -> x._2.isPresent()).mapToPair(x -> new Tuple2<>(x._1, x._2.get()));

        JavaPairRDD<String, Double> user_avgDistance = user_distances.mapToPair(x -> {
            double sum = x._2.stream().map(y -> y).reduce((a, b) -> a + b).get();
            long count = x._2.stream().count();
            return new Tuple2<>(x._1, sum / count);
        }
        );

        user_centroid
                .join(user_minDistance).mapToPair(x -> new Tuple2<>(x._1, "\"" + x._2._1.getX() + "," + x._2._1.getY() + "\"," + x._2._2))
                .join(user_maxDistance).mapToPair(x -> new Tuple2<>(x._1, x._2._1 + "," + x._2._2))
                .join(user_avgDistance).mapToPair(x -> new Tuple2<>(x._1, x._2._1 + "," + x._2._2))
                .map(x -> x._1 + "," + x._2).saveAsTextFile("output/userCentroid");

    }

    private JavaPairRDD<String, Point> computeAndUpdateCentroid(JavaPairRDD<String, Iterable<String>> user_geo) {
        final double GEO_CENTROID_THRESHOLD = 0.5;

        JavaPairRDD<String, Optional<Point>> user_centroid = user_geo.mapToPair(x -> {
            int missingCount = 0;
            double totalCount = 0;
            List<Double> latList = new ArrayList<>();
            List<Double> lonList = new ArrayList<>();
            for (String latLon : x._2) {
                totalCount++;
                // geo processing
                if (latLon == null || latLon.isEmpty()) {
                    missingCount++;
                } else {
                    String[] tokens = latLon.split(",");
                    if (tokens.length < 2) {
                        missingCount++; // Invalid geo
                    } else {
                        latList.add(Double.parseDouble(tokens[0]));
                        lonList.add(Double.parseDouble(tokens[1]));
                    }
                }
            }
            Optional<Point> centroid = Optional.absent();
            double geoMissingRatio = missingCount / totalCount;
            if (geoMissingRatio < GEO_CENTROID_THRESHOLD
                    && !latList.isEmpty()
                    && !lonList.isEmpty()) {
                Map<String, List<Double>> filteredLatLon = getCentroidWithDistanceFilter(latList, lonList);
                centroid = calculateCentroid(filteredLatLon.get("lat"), filteredLatLon.get("lon"));
            } else if (latList.isEmpty() || lonList.isEmpty()) {
                LOG.debug("Skipping geo centroid for:{} as there are no geo locations.",
                        x._1);
            } else if (geoMissingRatio > GEO_CENTROID_THRESHOLD) {
                LOG.error("Skipping geo centroid for:{} based on migging geo ratio:{}",
                        x._1, geoMissingRatio);
            }
            return new Tuple2<>(x._1, centroid);
        }
        );
        return user_centroid.filter(x -> x._2.isPresent()).mapToPair(x -> new Tuple2<>(x._1, x._2.get()));
    }

    private Optional<Point> calculateCentroid(List<Double> latList, List<Double> lonList) {
        Optional<Point> centroid = Optional.absent();
        double meanLat = latList.stream().reduce((x, y) -> x + y).get() / latList.stream().count();
        double meanLon = lonList.stream().reduce((x, y) -> x + y).get() / lonList.stream().count();
        centroid = Optional.of(new Point(meanLat, meanLon));

        return centroid;
    }

    private Map<String, List<Double>> getCentroidWithDistanceFilter(List<Double> latList, List<Double> lonList) {
        final double thresholdLat = 1;
        final double thresholdLon = 1;
        Double minLat = null;
        Double maxLat = null;
        Double minLon = null;
        Double maxLon = null;

        List<Double> filteredLatList = new ArrayList<>(latList.size());
        List<Double> filteredLonList = new ArrayList<>(lonList.size());

        for (int i = 0; i < latList.size(); i++) {
            Double lat = latList.get(i);
            Double lon = lonList.get(i);

            // compare with min latitude
            if (minLat == null) {
                minLat = lat;
            } else if (lat < minLat - thresholdLat) {
//                System.out.println("Ignoring " + lat + "," + lon);
                continue;
            } else if (lat < minLat) {
                minLat = lat;
            }
            // compare with max latitude
            if (maxLat == null) {
                maxLat = lat;
            } else if (lat > maxLat + thresholdLat) {
//                System.out.println("Ignoring " + lat + "," + lon);
                continue;
            } else if (lat > maxLat) {
                maxLat = lat;
            }

            // compare with min longitude
            if (minLon == null) {
                minLon = lon;
            } else if (lon < minLon - thresholdLon) {
//                System.out.println("Ignoring " + lat + "," + lon);
                continue;
            } else if (lon < minLon) {
                minLon = lon;
            }
            // compare with max longitude
            if (maxLon == null) {
                maxLon = lon;
            } else if (lon > maxLon + thresholdLon) {
//                System.out.println("Ignoring " + lat + "," + lon);
                continue;
            } else if (lon > maxLon) {
                maxLon = lon;
            }

            filteredLatList.add(lat);
            filteredLonList.add(lon);
        }
        /*
        System.out.println("MinLat " + minLat);
        System.out.println("MinLon " + minLon);
        System.out.println("MaxLat " + maxLat);
        System.out.println("MaxLon " + maxLon);
         */
        Map<String, List<Double>> latLonMap = new HashMap<>();
        latLonMap.put("lat", filteredLatList);
        latLonMap.put("lon", filteredLonList);
        return latLonMap;
    }

    private void initProps() throws IOException {
        PropertiesLoader propLoader = new PropertiesLoader(this.propFileUri);
        propLoader.loadProperties();

        this.detailsFileUri = System.getProperty("detailsFile");
        this.interactionsFileUri = System.getProperty("InteractionsFile");
    }

    public static void main(String[] args) throws IOException {
        if (args.length < 1) {
            System.out.println("Usage::java AttributeAnalyser <prop-filename>");
            System.exit(1);
        }

        SparkConf conf = new SparkConf().setAppName("Attribute Analysis Application").set("spark.executor.memory", "64g")
                .set("spark.num.executors", "1")/*.set("spark.executor.cores", "7").*/.set("spark.total.executor.cores", "15")
                .set("spark.storage.memoryFraction", "0.1");
        JavaSparkContext sc = new JavaSparkContext(conf);

        long startTime = System.currentTimeMillis();
        AttributeAnalyser analyser = new AttributeAnalyser(args[0]);
        analyser.initProps();
        analyser.processCuisines(sc);
        analyser.processGeo(sc);

        long endTime = System.currentTimeMillis();
        System.out.println(".. Total Time taken :" + (endTime - startTime) / 1000);
    }
}
