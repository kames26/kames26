/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.evaluation.choices;

import java.io.Serializable;
import java.util.List;

import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;

import com.crayondata.choice.rateableitem.Category;
import com.crayondata.choice.rateableitem.CreativeWork;
import com.crayondata.choice.rateableitem.LocalBusiness;
import com.crayondata.item.processor.spark.CatItemSimilarityProcessor;
import com.crayondata.recommender.Recommender;
import com.google.common.base.Optional;

/**
 * 
 * @author vivek
 *
 */
public class ItemSimilarityAdapter implements ChoiceGenerator, Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private CatItemSimilarityProcessor similarityProcessor;
	
	private Category cat;
	private String solrHost;
	
	private String ITEM_ID_FILE = "data/item-ids.csv";
	
	private int partitionCount;
	private static final int topN=20;
	
	public ItemSimilarityAdapter(Category cat, String solrHost, int partitionCount){
		this.cat = cat;
		this.solrHost = solrHost;
		this.partitionCount = partitionCount;
	}
	
	public void initModel(JavaSparkContext jc, Optional<String> modelFileUri){
		switch(cat){
		case MOVIE:
			this.similarityProcessor = new CatItemSimilarityProcessor<CreativeWork>(cat, solrHost, partitionCount, topN);
			break;
		case RESTAURANT:
			this.similarityProcessor = new CatItemSimilarityProcessor<LocalBusiness>(cat, solrHost, partitionCount, topN);
			break;
		case HOTEL:
			this.similarityProcessor = new CatItemSimilarityProcessor<LocalBusiness>(cat, solrHost, partitionCount, topN);
			break;
		default:
			throw new IllegalArgumentException("Unsupported category:"+cat);
		}
		
		JavaRDD<String> itemIdStr = jc.textFile(ITEM_ID_FILE).cache();
		List<Integer> itemIds = itemIdStr.map(x -> Integer.parseInt(x)).collect();
		if(modelFileUri.isPresent())
			similarityProcessor.loadModel(modelFileUri.get(), jc);
		else
			similarityProcessor.buildModel(itemIds, jc);
	}

	@Override
	public List<Integer> getOrderedChoices(List<Integer> itemIds, String userId, 
            boolean setCentroidLocation, boolean useAttrFilterFromProfile, int topN) {
		return similarityProcessor.getOrderedChoices(itemIds);
	}

	@Override
	public List<List<Integer>> getOrderedChoicesForModels(
			List<Integer> itemIds, String userId, List<Recommender[]> models,
            boolean setCentroidLocation, boolean useAttrFilterFromProfile, int topN) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public long getFailureCount() {
		// TODO Auto-generated method stub
		return 0;
	}
	
}
