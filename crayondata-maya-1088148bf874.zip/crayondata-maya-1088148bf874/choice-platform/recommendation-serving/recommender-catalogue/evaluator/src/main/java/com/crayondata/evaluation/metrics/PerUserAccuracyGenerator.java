/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.evaluation.metrics;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.DataFrame;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.RowFactory;
import org.apache.spark.sql.SQLContext;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;

import com.crayondata.recommender.Recommender;
import com.google.common.base.Optional;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

import static com.crayondata.evaluation.metrics.EvaluationMetricsGenerator.USER_ACCURACY_FILE;
import static com.crayondata.evaluation.metrics.EvaluationMetricsGenerator.USER_RAW_METRIC_FILE;
import static com.crayondata.evaluation.metrics.EvaluationMetricsGenerator.USER_TOPN_CHOICES_FILE;

import com.google.common.collect.Sets;

import java.util.Set;

import scala.Tuple2;
import scala.Tuple3;

public class PerUserAccuracyGenerator implements Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    
    private final int atN;
    private final String dirPrefix;
    private final int recoCount;
    
    public PerUserAccuracyGenerator(int atN, String dirPrefix, int recoCount){
        this.atN = atN;
        this.dirPrefix = dirPrefix;
        this.recoCount = recoCount;
    }
    
    public void generateCoverageAcrossUsers(JavaPairRDD<String, List<Integer>> usersToItems,
            JavaPairRDD<String, List<List<Integer>>> userToChoices,
            List<Recommender[]> recommenderLists){
    	JavaPairRDD<String, Integer> testItems = usersToItems.flatMapToPair(x -> {
    		List<Tuple2<String, Integer>> result = Lists.newArrayList();
    		x._2.forEach(y -> result.add(new Tuple2<>(x._1,y)));
    		return result;
    	});
    	final long testItemsCount = testItems.values().distinct().count();
    	JavaPairRDD<Integer, String> testItemsReversed = testItems.mapToPair(x -> new Tuple2<>(x._2, x._1));
    	
    	int index=0;
    	final List<Double> modelCoverageList = Lists.newArrayList();
    	final List<String> modelDescriptionList = Lists.newArrayList();
    	final Map<String, Double> modelCoverageMap = Maps.newHashMap();
    	for(Recommender[] models : recommenderLists){
    		modelDescriptionList.add(Arrays.asList(models).toString());
    		final int finalIndex = index; 
    		JavaPairRDD<Integer, String> userModelChoices = userToChoices.flatMapToPair(x -> {
    			List<Tuple2<Integer, String>> result = Lists.newArrayList();
    			List<Integer> modelChoices = x._2.get(finalIndex);
    			modelChoices.forEach(y -> result.add(new Tuple2<>(y, x._1)));
    			return result;
    		});
    		final long matchedCount = testItemsReversed.join(userModelChoices).keys().distinct().count();
    		double modelCoverage = matchedCount/testItemsCount * 1.0;
    		modelCoverageList.add(modelCoverage);
    		modelCoverageMap.put(Arrays.asList(models).toString(), modelCoverage);
    		index++;
    	}
    	System.out.println("Model coverage values:");
    	System.out.println("--------------------------------");
    	
    	System.out.println(modelDescriptionList);
    	System.out.println(modelCoverageList);
    	System.out.println(modelCoverageMap);
    	
    	System.out.println("--------------------------------");
    	System.out.println("Model coverage values ends..");
    }

    public void generateAccuracyForUsers(JavaPairRDD<String, List<Integer>> trainUsersToItems,
    		JavaPairRDD<String, List<Integer>> usersToItems,
            JavaPairRDD<String, List<List<Integer>>> userToChoices, JavaSparkContext sc, boolean persistChoices){
        JavaPairRDD<String, Tuple2<List<Integer>, Optional<List<List<Integer>>>>> userItemsAndChoices = 
                usersToItems.leftOuterJoin(userToChoices)/*.filter(input -> (input._2._2 != null))*/;
        
        JavaPairRDD<String, Tuple2<List<Integer>, List<List<Integer>>>> userItemsAndTopNChoices = 
                userItemsAndChoices.mapToPair(input -> {
                	List<List<Integer>> filteredList = new ArrayList<>();
                	if(input._2._2.isPresent()){
                		List<List<Integer>> choicesList = input._2._2.get();
                		choicesList.forEach(x -> {
                			filteredList.add((x.size() > atN)?x.subList(0, atN):x);
                		});
                	}else{
                		for(int i=0;i<this.recoCount;i++){
                			filteredList.add(new ArrayList<>());
                		}
                	}
                    return new Tuple2<>(input._1,
                            new Tuple2<>(input._2._1,
                                    filteredList));
                }).cache();
        
        if(persistChoices)
        	saveTopNChoices(userItemsAndTopNChoices, trainUsersToItems , sc);
        
        JavaPairRDD<String, Tuple2<List<Double>, List<Double>> > userMetrics = 
                userItemsAndTopNChoices.mapToPair(input -> {
                        List<Double> accuracies = new ArrayList<>();
                        List<Double> coverages = new ArrayList<>();
                        List<Integer> items = input._2._1;
                        List<List<Integer>> choicesList = input._2._2;
                        choicesList.forEach(choices -> {
                            final Map<Integer, Boolean> itemMap = new HashMap<Integer, Boolean>();
                            items.forEach(x -> itemMap.put(x, true));
                            final double matchCount = 
                                    choices.stream().filter(x -> itemMap.containsKey(x)).count();
                            final long choiceCount = choices.stream().count();
                            final long itemCount = items.size();
                            double accuracy = 0.0;
                            double coverage = matchCount/itemCount;
                            if(choiceCount > 0)
                                accuracy = matchCount/choiceCount;
                            accuracies.add(accuracy);
                            coverages.add(coverage);
                        });
                        return new Tuple2<>(input._1,new Tuple2<>(accuracies,coverages));
                    });
        
        JavaPairRDD<String, Tuple2<List<Integer>, List<Integer>> > userRawMetrics = 
                userItemsAndTopNChoices.mapToPair(input -> {
                        List<Integer> matchCounts = new ArrayList<>();
                        List<Integer> choiceCounts = new ArrayList<>();
                        List<Integer> items = input._2._1;
                        List<List<Integer>> choicesList = input._2._2;
                        choicesList.forEach(choices -> {
                            final Map<Integer, Boolean> itemMap = new HashMap<Integer, Boolean>();
                            items.forEach(x -> itemMap.put(x, true));
                            final int matchCount = 
                                    (int) choices.stream().filter(x -> itemMap.containsKey(x)).count();
                            final int choiceCount = (int) choices.stream().count();
                            matchCounts.add(matchCount);
                            choiceCounts.add(choiceCount);
                            
                        });
                        return new Tuple2<>(input._1,new Tuple2<>(choiceCounts, matchCounts));
                    });
        
        persistRawMetrics(userRawMetrics, usersToItems, trainUsersToItems);
        
        persistComputedMetrics(userMetrics, usersToItems, trainUsersToItems);
        
                
        /*Tuple2<Integer, Double> zeroValue = new Tuple2<>(0,0.0);
        userAccuracies.values().aggregate(zeroValue, new Function2<Tuple2<Integer, Double>, Tuple2<String, Integer>, Tuple2<Integer, Double>>(){

            @Override
            public Tuple2<Integer, Double> apply(Tuple2<Integer, Double> aggr, Tuple2<String, Integer> input)
                    throws Exception {
                return new Tuple2<>(aggr._1+1,aggr._2+input._2);
            }

            }, new Function2<Tuple2<Integer, Double>,Tuple2<Integer, Double>, Tuple2<Integer, Double>>(){

                @Override
                public Tuple2<Integer, Double> apply(Tuple2<Integer, Double> arg0,
                        Tuple2<Integer, Double> arg1) throws Exception {
                    return new Tuple2<>(arg0._1+arg1._1, arg0._2+arg1._2);
                }
            
        });*/
        
        JavaPairRDD<String, Integer> usersToItemCount =
                usersToItems.mapToPair(x -> new Tuple2<>(x._1,x._2.size()));
        long count = userRawMetrics.count();
       /* double sumAccuracies = userAccuracies.values().fold( 0.0, 
                ((x,y) -> x+y));*/
        Tuple2<Tuple2<List<Integer>, List<Integer>>, Integer> zeroValue = new Tuple2<>(new Tuple2<>(new ArrayList<>(), new ArrayList<>()),0);
        for(int i=0;i<recoCount;i++){
        	zeroValue._1._1.add(0);
        	zeroValue._1._2.add(0);
        }
        Tuple2<Tuple2<List<Integer>, List<Integer>>, Integer> sums = userRawMetrics.join(usersToItemCount).values().fold(zeroValue, (x,y) ->{
        	List<Integer> choiceCount = new ArrayList<>();
        	List<Integer> matchCount = new ArrayList<>();
        	for(int i=0;i<recoCount;i++){
        		choiceCount.add(x._1._1.get(i) + x._1._1.get(i));
        		matchCount.add(x._1._2.get(i) + x._1._2.get(i));
        	}
        	
        	System.err.println("Choice count::" + choiceCount);
        	System.err.println("Match count::" + matchCount);
        	
            int itemCount = x._2.intValue() + y._2.intValue();
            
            return new Tuple2<>(new Tuple2<>(choiceCount, matchCount), itemCount);
        });
        
        System.out.println(" Aggregated values:" + sums);
        
        List<Double> accuracyMeans = new ArrayList<>();
        List<Double> coverageMeans = new ArrayList<>();
        for(int i=0;i<recoCount;i++){
        	accuracyMeans.add((sums._1._1.get(i) != 0)?sums._1._2.get(i)/sums._1._1.get(i)*1.0 : 0.0);
        	coverageMeans.add(sums._1._2.get(i)/sums._2*1.0);
        }
        
        int itemCount = sums._2;
        
        System.out.printf("Average accuracy across users:%d, %s at %d\n", count, accuracyMeans.toString(), atN);
        System.out.printf("Average coverage across users:%d, items:%d  %s at %d\n", count, itemCount, coverageMeans.toString(), atN);

        /*JavaPairRDD<List<Integer>, List<List<Integer>>> mapToPair = userItemsAndTopNChoices.mapToPair(x -> x._2);
        int recommenderCount = mapToPair.first()._2.size();
        Set<Integer> testItems = Sets.newHashSet();
        List<Set<Integer>> choiceItems = Lists.newArrayList();
        for (int i = 0; i < recommenderCount; i++) {
            choiceItems.add(Sets.newHashSet());
        }
        mapToPair.foreach(x -> {
            testItems.addAll(x._1);
            for (int i = 0; i < x._2.size(); i++) {
                choiceItems.get(i).addAll(x._2.get(i));
            }
        });
        System.out.println("Test item count: " + testItems.size());
        for (Set<Integer> choiceItemSet : choiceItems) {
            System.out.println("Choice item counts: " + choiceItemSet.size());
        }
        for (Set<Integer> choiceItemSet : choiceItems) {
            choiceItemSet.retainAll(testItems);
            System.out.println("Matching choice item counts: " + choiceItemSet.size());
        }
        for (Set<Integer> choiceItemSet : choiceItems) {
            System.out.println("Coverage: " + (choiceItemSet.size() * 1.0 / testItems.size()));
        }*/
    }
    
    private void persistComputedMetrics(
			JavaPairRDD<String, Tuple2<List<Double>, List<Double>>> userMetrics,
			JavaPairRDD<String, List<Integer>> usersToItems,
			JavaPairRDD<String, List<Integer>> trainUsersToItems) {
    	JavaPairRDD<String, Integer> testUsersToItemCount =
                usersToItems.mapToPair(x -> new Tuple2<>(x._1,x._2.size()));
    	JavaPairRDD<String, Integer> trainUsersToItemCount =
    			trainUsersToItems.mapToPair(x -> new Tuple2<>(x._1, x._2.size()));
    	JavaPairRDD<String, Tuple2<Integer, Optional<Integer>>> usersToOptItemCount = 
    			testUsersToItemCount.leftOuterJoin(trainUsersToItemCount);
    	JavaPairRDD<String, String> usersToItemCount =
    			usersToOptItemCount.mapToPair(x -> {
    		Tuple2<Integer, Integer> result = new Tuple2<>(x._2._1, 0);
    		if(x._2._2.isPresent())
    			result = new Tuple2<>(x._2._1, x._2._2.get());
    		return new Tuple2<>(x._1, result._1+","+result._2);
    	});
    	
        JavaPairRDD<String, Tuple2<List<Double>, List<Double>>> usersItemCountMetrics =  
            usersToItemCount.join(userMetrics).mapToPair(x -> new Tuple2<>(x._1+","+x._2._1, x._2._2));

        //userAccuracies.saveAsTextFile("target/UsersAccuracies");
        JavaRDD<String> toPrint = usersItemCountMetrics.map(input ->{
        	String accuracies = input._2._1.stream().map(x -> String.valueOf(x)).reduce((x,y) -> x+","+y).get();
            String coverages = input._2._2.stream().map(x -> String.valueOf(x)).reduce((x,y) -> x+","+y).get();
            return input._1+"," + accuracies+","+coverages;
        });
        toPrint.saveAsTextFile(this.dirPrefix + USER_ACCURACY_FILE);

		
	}

	private void persistRawMetrics(
			JavaPairRDD<String, Tuple2<List<Integer>, List<Integer>>> userRawMetrics,
			JavaPairRDD<String, List<Integer>> usersToItems,
			JavaPairRDD<String, List<Integer>> trainUsersToItems) {
		
    	JavaPairRDD<String, Integer> testUsersToItemCount =
                usersToItems.mapToPair(x -> new Tuple2<>(x._1,x._2.size()));
    	JavaPairRDD<String, Integer> trainUsersToItemCount =
    			trainUsersToItems.mapToPair(x -> new Tuple2<>(x._1, x._2.size()));
    	JavaPairRDD<String, Tuple2<Integer, Optional<Integer>>> usersToOptItemCount = 
    			testUsersToItemCount.leftOuterJoin(trainUsersToItemCount);
    	JavaPairRDD<String, String> usersToItemCount =
    			usersToOptItemCount.mapToPair(x -> {
    		Tuple2<Integer, Integer> result = new Tuple2<>(x._2._1, 0);
    		if(x._2._2.isPresent())
    			result = new Tuple2<>(x._2._1, x._2._2.get());
    		return new Tuple2<>(x._1, result._1+","+result._2);
    	});
               
        JavaPairRDD<String, Tuple2<List<Integer>, List<Integer>>> usersItemCountMetrics =  
            usersToItemCount.join(userRawMetrics).mapToPair(x -> new Tuple2<>(x._1+","+x._2._1, x._2._2));
        
        //userAccuracies.saveAsTextFile("target/UsersAccuracies");
        JavaRDD<String> toPrint = usersItemCountMetrics.map(input ->{
        	String accuracies = input._2._1.stream().map(x -> String.valueOf(x)).reduce((x,y) -> x+","+y).get();
            String coverages = input._2._2.stream().map(x -> String.valueOf(x)).reduce((x,y) -> x+","+y).get();
            return input._1+"," + accuracies+","+coverages;
        });
        toPrint.saveAsTextFile(this.dirPrefix + USER_RAW_METRIC_FILE);
		
	}

	protected void saveTopNChoices(JavaPairRDD<String, Tuple2<List<Integer>, List<List<Integer>>>> userItemsAndTopNChoices, JavaPairRDD<String, List<Integer>> trainUsersToItems, JavaSparkContext sc) {
        String destination = this.dirPrefix + USER_TOPN_CHOICES_FILE;
        
        JavaPairRDD<String, Tuple3<List<Integer>, List<Integer>, List<List<Integer>>>>  userItemsChoicesAndTrainItems = 
        	userItemsAndTopNChoices.leftOuterJoin(trainUsersToItems).mapToPair(x -> {
        		List<Integer> trainItems = new ArrayList<>();
        		if(x._2._2.isPresent())
        			trainItems = x._2._2.get();
        		return new Tuple2<>(x._1, new Tuple3<>(x._2._1._1, trainItems, x._2._1._2));
        	});
        
        JavaRDD<Row> affRow = userItemsChoicesAndTrainItems.map(x -> RowFactory.create(new Object[] { x._1, x._2._3().size(), 
        			x._2._1(),x._2._2(), x._2._3()}));
        SQLContext sqlContext = new SQLContext(sc);
        DataFrame affDF = sqlContext.createDataFrame(affRow, getTopNChoicesSchema());
        affDF.write().format("com.databricks.spark.avro").save(destination);
    }
    
    private StructType getTopNChoicesSchema() {
        List<StructField> fields = Lists.newArrayList();
        fields.add(DataTypes.createStructField("userId", DataTypes.StringType, false));
        fields.add(DataTypes.createStructField("recommenderCount", DataTypes.IntegerType, false));
        fields.add(DataTypes.createStructField("testItemIds", DataTypes.createArrayType(DataTypes.IntegerType), false));
        fields.add(DataTypes.createStructField("trainItemIds", DataTypes.createArrayType(DataTypes.IntegerType), false));
        fields.add(DataTypes.createStructField("choices", DataTypes.createArrayType(DataTypes.createArrayType(DataTypes.IntegerType)), false));
        return DataTypes.createStructType(fields);
    }
}
