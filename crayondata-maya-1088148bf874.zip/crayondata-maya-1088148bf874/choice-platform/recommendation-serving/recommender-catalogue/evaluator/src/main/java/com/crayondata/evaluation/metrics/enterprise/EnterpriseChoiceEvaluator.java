/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.evaluation.metrics.enterprise;

import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.spark.HashPartitioner;
import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.DataFrame;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SQLContext;
import org.apache.spark.sql.functions;

import scala.Tuple2;
import scala.collection.JavaConversions;
import scala.collection.Seq;

import com.clearspring.analytics.util.Lists;
import com.crayondata.choice.rateableitem.Category;
import com.crayondata.evaluation.choices.CategoryChoiceGenerator;
import com.crayondata.evaluation.choices.ChoiceGenerator;
import com.crayondata.evaluation.choices.EnterpriseSimilarityAdapter;
import com.crayondata.evaluation.metrics.EvaluationMetricsGenerator;
import com.crayondata.evaluation.metrics.PerUserAccuracyGenerator;
import com.crayondata.recommender.Recommender;import com.google.common.base.Optional;
import com.google.common.collect.Iterables;


/**
 * 
 * @author vivek
 *
 */
public class EnterpriseChoiceEvaluator extends EvaluationMetricsGenerator{
	
	private static final String USER_TEST = "/UserInteractions/Test";
	private static final String USER_TRAIN = "/UserInteractions/Train";
	
	private static int NUM_PARTITIONS = 256;
	
	private static final int SIM_TOPN = 50;
	private static final double SIM_THRESHOLD = 0.4;
	
	private static final boolean USER_USER_INTERSECTION = false;
	
	public EnterpriseChoiceEvaluator(String propFileUri) {
		this.propFileUri = propFileUri;
	}
	
	private void initProps() throws IOException{
		PropertiesLoader propLoader = new PropertiesLoader(this.propFileUri);
		propLoader.loadProperties();
		
		this.solrHost = System.getProperty("solrHost");
		this.cat = Category.parseCategory(System.getProperty("category"));
		this.outputDir = System.getProperty("outputDir");
		this.trainFileUri = System.getProperty("trainInteractionFile");
		this.testFileUri = System.getProperty("testInteractionFile");
		String[] atNTokens = System.getProperty("atN").split(",");
		this.atNList = new int[atNTokens.length];
		int index=0;
		for(String atNStr : atNTokens){
			this.atNList[index++]=Integer.parseInt(atNStr);
		}
		String simFlagProp = System.getProperty("useOnlySimilarityModel","false");
		System.out.println("simFlagProp" + simFlagProp);
		this.useOnlySimilarityModel =  Boolean.parseBoolean(simFlagProp.trim());
		String simModelFileStr = System.getProperty("similarityModelFileUri", "");
		this.similarityModelFileUri = (simModelFileStr.isEmpty())?Optional.absent():Optional.of(simModelFileStr);
		
		this.partitionCount = Integer.parseInt(System.getProperty("partitionCount", "256"));
	}
	
	private String propFileUri;

	private String solrHost;
	private Category cat;
	private String outputDir;
	private String trainFileUri;
	private String testFileUri;
	private int[] atNList;
	private boolean useOnlySimilarityModel=false;
	private Optional<String> similarityModelFileUri;
	private int partitionCount;
	
	
public static final List<Recommender[]> recommenderLists;
    
    static {
        recommenderLists = new ArrayList<>();
        Recommender[] topRated = { Recommender.TOPRATEDITEM };
        Recommender[] attribute = {  Recommender.ATTRIBUTE_NUMERICAL, Recommender.ATTRIBUTE_CATEGORICAL };
        Recommender[] tg1 = { Recommender.TGFIRSTHOPNICHE};
        Recommender[] tg2 = { Recommender.TGFIRSTHOPPOPULAR};
        Recommender[] tg3 = { Recommender.TGSECONDHOPDISCOVERY };
        Recommender[] tgall = { Recommender.TGFIRSTHOPNICHE, Recommender.TGFIRSTHOPPOPULAR, Recommender.TGSECONDHOPDISCOVERY };
        Recommender[] tg_attr = { Recommender.ATTRIBUTE_NUMERICAL, Recommender.ATTRIBUTE_CATEGORICAL, Recommender.TGFIRSTHOPNICHE, 
                Recommender.TGFIRSTHOPPOPULAR, Recommender.TGSECONDHOPDISCOVERY };
        
        Recommender[] enttg1 = { Recommender.ENTERPRISETGFIRSTHOPNICHE};
        Recommender[] enttg2 = { Recommender.ENTERPRISETGFIRSTHOPPOPULAR};
        Recommender[] enttg3 = { Recommender.ENTERPRISETGSECONDHOPDISCOVERY };
        Recommender[] enttgall = { Recommender.ENTERPRISETGFIRSTHOPNICHE, 
        		Recommender.ENTERPRISETGFIRSTHOPPOPULAR, Recommender.ENTERPRISETGSECONDHOPDISCOVERY };
        Recommender[] ent_attr = { Recommender.ENTERPRISETGFIRSTHOPNICHE, 
        		Recommender.ENTERPRISETGFIRSTHOPPOPULAR, Recommender.ENTERPRISETGSECONDHOPDISCOVERY, Recommender.ATTRIBUTE_NUMERICAL, Recommender.ATTRIBUTE_CATEGORICAL };
        Recommender[] all = {Recommender.ATTRIBUTE_NUMERICAL, Recommender.ATTRIBUTE_CATEGORICAL,
            Recommender.ENTERPRISETGFIRSTHOPNICHE, Recommender.ENTERPRISETGFIRSTHOPPOPULAR, Recommender.ENTERPRISETGSECONDHOPDISCOVERY,
            Recommender.TGFIRSTHOPNICHE, Recommender.TGFIRSTHOPPOPULAR, Recommender.TGSECONDHOPDISCOVERY};
        
        
        
        /*recommenderLists.add(topRated);
        recommenderLists.add(attribute);*/
        recommenderLists.add(enttg1);
        recommenderLists.add(enttg2);
        recommenderLists.add(enttg3);
        recommenderLists.add(enttgall);
        recommenderLists.add(attribute);
        recommenderLists.add(ent_attr);

        recommenderLists.add(tg1);
        recommenderLists.add(tg2);
        recommenderLists.add(tg3);
        recommenderLists.add(tgall);
        recommenderLists.add(all);
        
        
        /*recommenderLists.add(all);*/
    }
    
    
    
    public static void main(String[] args) throws IOException {
    	if(args.length<1){
    		System.out.println("Usage::java EnterpriseChoiceEvaluator <prop-filename>");
    		System.exit(1);
    	}
    	
    	SparkConf conf = new SparkConf().setAppName("Choice Evaliation applition").set("spark.executor.memory", "64g")
                .set("spark.num.executors", "1")/*.set("spark.executor.cores", "7").*/.set("spark.total.executor.cores", "15")
                .set("spark.storage.memoryFraction", "0.1");
        JavaSparkContext sc = new JavaSparkContext(conf);
                
        long startTime = System.currentTimeMillis();
        EnterpriseChoiceEvaluator metricsGen = new EnterpriseChoiceEvaluator(args[0]);
        metricsGen.generateForAllN(sc);
        
        long endTime = System.currentTimeMillis();
        System.out.println(".. Total Time taken :" + (endTime-startTime)/1000);
	}
    
    public void generateForAllN(JavaSparkContext sc) throws IOException{
    	initProps();
    	for(int n : this.atNList){
    		long startTimeForN = System.currentTimeMillis(); 
            System.out.printf("Starting for atN:%d\n", n);
    		this.atN = n;
    		this.outputDir += "/"+this.atN;
    		this.generateEnterpriseMetrics(sc, n);
    		
    		System.out.printf("Completed for atN:%d\n", n);
            System.out.printf("Time taken for atN:%d, %d seconds\n", n, 
                    (System.currentTimeMillis()-startTimeForN)/1000);
    	}
    }
    
    public void generateEnterpriseMetrics(JavaSparkContext sc, final int topN) throws IOException{
    	
    	System.out.println(".. Getting train interactions..");
        JavaPairRDD<String, List<Integer>> train = 
                this.getInteractions(sc, this.trainFileUri).partitionBy(new HashPartitioner(this.partitionCount)).cache();
        System.out.println(".. Getting test interactions..");
        JavaPairRDD<String, List<Integer>> test = 
        		this.getInteractions(sc, this.testFileUri).partitionBy(new HashPartitioner(this.partitionCount)).cache();
        
        
        train.saveAsTextFile(this.outputDir+USER_TRAIN);
        test.saveAsTextFile(this.outputDir+USER_TEST);
        
        System.out.println(".. Number of train users:"+ train.count());
        System.out.println(".. Number of test users:"+ test.count());
        
        ChoiceGenerator  choiceGenerator = new CategoryChoiceGenerator(cat, solrHost);
        EnterpriseSimilarityAdapter similarityChoiceGenerator = new EnterpriseSimilarityAdapter(trainFileUri, SIM_TOPN, outputDir, 
        		this.partitionCount, SIM_THRESHOLD, this.similarityModelFileUri);
        
        
        /** Optional optimization step for restricting choice generation for 
         * users that can be validated. */
        if(USER_USER_INTERSECTION){
        	JavaPairRDD<String, Tuple2<List<Integer>, List<Integer>>> joined =
        			test.join(train);
        	train = joined.mapToPair(x -> new Tuple2<>(x._1,x._2._2));
        	test = joined.mapToPair(x -> new Tuple2<>(x._1, x._2._1));

        	System.out.println(".. Modified train user count:" + train.count());
        	System.out.println(".. Modified test user count:" + test.count());
        }else{
        	System.out.println("Chosen not take intersection of users from train and test");
        	JavaPairRDD<String, Tuple2<List<Integer>, List<Integer>>> joined =
        			test.join(train);
        	train = joined.mapToPair(x -> new Tuple2<>(x._1,x._2._2));
        	System.out.println(".. Modified train user count:" + train.count());
        }
        
        JavaPairRDD<String, List<List<Integer>>> userToChoices = null;
        PerUserAccuracyGenerator accuracyGen;
        System.out.println("Use only similarity flag:" + this.useOnlySimilarityModel);
        if(this.useOnlySimilarityModel){
        	Recommender[] user_cooccurrence = {Recommender.USERCOOCCURRENCE};
        	recommenderLists.clear();
        	recommenderLists.add(user_cooccurrence);
        	System.out.println("Configured to use only similarity model..");
        	System.out.println("Initializing simialarity model from file:" + this.similarityModelFileUri.get());
        	similarityChoiceGenerator.initModel(sc);
        	System.out.println("Similarity model initialization completed.. Successfully");
        	System.out.println("Generating choices from similairty model..");
        	
        	long simStartTime = System.currentTimeMillis();
        	/*userToChoices = train.mapToPair(input -> new Tuple2<>(input._1, 
        			similarityChoiceGenerator.getOrderedChoicesForModels(input._2, input._1, null, USE_USER_CENTROID)))
        			.partitionBy(new HashPartitioner(1024)).cache();*/
        	userToChoices = similarityChoiceGenerator.getChoicesFromSimilarityModel(train, sc, topN);
        	System.out.println("Choice generation from similarity model completed.. Successfully.. for:" 
        			+ userToChoices.count() + " users..");
        	System.out.println(".. Time taken:" + (System.currentTimeMillis()-simStartTime));
        	
        	accuracyGen = new PerUserAccuracyGenerator(atN, this.outputDir, 1);
        }else{
        	System.out.println("Not Configured to use only similarity model..");
        	long startTime = System.currentTimeMillis();
        	userToChoices = train.mapToPair(input -> new Tuple2<>(input._1, 
                    choiceGenerator.getOrderedChoicesForModels(input._2, input._1, recommenderLists, USE_USER_CENTROID, USE_USER_ATTRIBUTE_PREFERENCE, topN)))
                    .partitionBy(new HashPartitioner(1024)).cache();
        	System.out.println("Choice generation from all models.. Successfully.. for:" 
        			+ userToChoices.count() + " users..");
        	System.out.println(".. Time taken:" + (System.currentTimeMillis()-startTime));
        	accuracyGen = new PerUserAccuracyGenerator(atN, this.outputDir, recommenderLists.size());
        }
        
        /*JavaPairRDD<String, List<Integer>> simChoices = train.mapToPair(input -> new Tuple2<>(input._1, 
        		this.similarityAdapter.getOrderedChoices(input._2, input._1)));
        System.out.printf("Time taken for similarity choices:%d\n", (System.currentTimeMillis()-simStartTime));
        
        userToChoices = userToChoices.join(simChoices).mapToPair(x -> {
        	List<List<Integer>> result = x._2._1;
        	result.add(x._2._2);
        	return new Tuple2<>(x._1, result);
        }).cache();*/
        
        System.out.println("Writing choices generated into dir:"+this.outputDir+USER_CHOICES_FILE);
        userToChoices.saveAsTextFile(this.outputDir+USER_CHOICES_FILE);
        
        System.out.printf("Number of choice generation failed..%d", choiceGenerator.getFailureCount());
        System.out.println("Generating coverage..");
        accuracyGen.generateCoverageAcrossUsers(test, userToChoices, recommenderLists);
        System.out.println("Coverage generation completed..!!");
        System.out.println(".. Generating per user accuracy..");
        accuracyGen.generateAccuracyForUsers(train,test, userToChoices, sc, true);
        System.out.println("Accuracy generated completed successfully..!!");
        printMoreStats(test, userToChoices, recommenderLists);
    }
    
    private JavaPairRDD<String, List<Integer>> getInteractions(JavaSparkContext sc, String fileUri){
		JavaPairRDD<String, Integer> userItemMapRdd;
		userItemMapRdd = readReviewDataFromAvro(sc, fileUri);
		
		printStats(userItemMapRdd);
		
		JavaPairRDD<String, List<Integer>> userInteractions = 
				userItemMapRdd.groupByKey().mapToPair(x -> {
			List<Integer> itemIdList = Lists.newArrayList();
			Iterables.addAll(itemIdList, x._2);
			return new Tuple2<>(x._1, itemIdList);
		});
		return userInteractions;
	}
}
