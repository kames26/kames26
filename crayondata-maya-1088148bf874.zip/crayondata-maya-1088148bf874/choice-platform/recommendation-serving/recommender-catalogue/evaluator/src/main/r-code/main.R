###############################################
########   Author: Vivek   ####################
###############################################
## Invoke libraries.R while invoking first time

source("plot_functions.R")
create_plots("with_itmsim_accuracies.csv","plots/with_sim_movies18",18)

create_plots("Jun-6/Output/18/UserAccuracies/movies_18.csv","Jun-6/Output/plots/18",18)

create_plots("Jun-6/Output/6/UserAccuracies/movies_6.csv","Jun-6/Output/plots/6",6)
