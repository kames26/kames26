
paired_data <- read.csv("backup/paired-results.csv", 
                           header=FALSE, stringsAsFactors=FALSE, sep=",")

colnames(paired_data) <- c("user", "interactions", "attr", "tg");

sum(ifelse(is.na(paired_data$attr),1,0))
sum(ifelse(is.na(paired_data$tg),1,0))

paired_data$attr[is.na(paired_data$attr)] <- 0

plot(attr~tg, data=paired_data)

ggplot(paired_data, aes(tg,attr)) + 
  annotate("rect", xmin = 0, xmax = 0.259, ymin = 0, ymax = 0.119, fill= "yellow")  + 
  annotate("rect", xmin = 0.26, xmax = 0.51, ymin = 0.12, ymax = 0.23 , fill= "blue") + 
  annotate("rect", xmin = 0, xmax = 0.259, ymin = 0.12, ymax = 0.23, fill= "green") + 
  annotate("rect", xmin = 0.26, xmax = 0.51, ymin = 0, ymax = 0.119, fill= "red") + 
  geom_point() +theme(text = element_text(size=20))+ggtitle("Accuracies - TG vs Attribute Model") +  labs(x="TG",y="Attr") #+ xlim(-10,10)+ ylim(-10,10)


test <- t.test(paired_data$tg, paired_data$attr, paird=TRUE, alt="greater")
summary(test)
