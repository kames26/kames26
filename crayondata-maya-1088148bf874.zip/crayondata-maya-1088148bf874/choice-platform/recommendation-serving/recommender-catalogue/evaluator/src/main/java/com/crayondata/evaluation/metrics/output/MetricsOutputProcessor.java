/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.evaluation.metrics.output;

import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;

import scala.Tuple2;
import static com.crayondata.evaluation.metrics.EvaluationMetricsGenerator.USER_ACCURACY_FILE;
import static com.crayondata.evaluation.metrics.EvaluationMetricsGenerator.USER_ITEM_COUNT_FILE;

public class MetricsOutputProcessor {
    
    private static final String CONSOLIDATED = "/Consolidated";
    
    public static void main(String[] args) {
        SparkConf conf = new SparkConf().setAppName("Uid pid Application").set("spark.executor.memory", "32g")
                .set("spark.num.executors", "1")/*.set("spark.executor.cores", "7").*/.set("spark.total.executor.cores", "15")
                .set("spark.storage.memoryFraction", "0.1");
        JavaSparkContext sc = new JavaSparkContext(conf);

        for(String outputDir : args){
            System.out.println("Processing dir:"+ outputDir);
            processDir(outputDir, sc);
        }
    }
    
    private static void processDir(String dirName, JavaSparkContext sc){
        JavaRDD<String> userItemsStr = sc.textFile(dirName+USER_ITEM_COUNT_FILE).cache();
        JavaRDD<String> userAccuracyStr = sc.textFile(dirName+USER_ACCURACY_FILE).cache();
        
        JavaPairRDD<String, Integer> userItemCount = userItemsStr.mapToPair(
                input -> {
                    String[] tokens = input.split(",");
                    return new Tuple2<>(tokens[0], Integer.parseInt(tokens[1]));
                });
        
        JavaPairRDD<String, Double> userAccuracyCount = userAccuracyStr.mapToPair(
                input -> {
                   String[] tokens = input.split(",");
                   return new Tuple2<>(tokens[0], Double.parseDouble(tokens[1]));
                });
        
        JavaPairRDD<String, Tuple2<Integer, Double>> joined = 
                userItemCount.join(userAccuracyCount);
        joined.map(input -> input._1+"," +input._2._1 +"," + input._2._2).saveAsTextFile(dirName + USER_ACCURACY_FILE+CONSOLIDATED);
    }

}
