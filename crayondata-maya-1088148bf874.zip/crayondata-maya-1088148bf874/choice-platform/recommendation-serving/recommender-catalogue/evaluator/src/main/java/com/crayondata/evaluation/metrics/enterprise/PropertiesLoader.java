/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.evaluation.metrics.enterprise;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Arrays;
import java.util.Properties;

/**
 * 
 * @author vivek
 *
 */
public class PropertiesLoader {
	private String fileUri;
	
	public PropertiesLoader(String fileUri){
		this.fileUri = fileUri;
	}
	
	public void loadProperties() throws IOException{
		Properties props = new Properties();
		InputStream stream = new FileInputStream(new File(fileUri));
		props.load(stream);
		for(Object obj : props.keySet()){
			String key = obj.toString();
			String prop = System.getProperty((String) key);
			if(prop == null || prop.isEmpty()){
				System.setProperty(key, props.getProperty(key));
				System.out.printf("using the prop fro file for :%s\t%s\n", key, props.getProperty(key));
			}else
				System.out.printf("using the system prop for :%s\t%s\n", key, prop);
		}
	}
}
