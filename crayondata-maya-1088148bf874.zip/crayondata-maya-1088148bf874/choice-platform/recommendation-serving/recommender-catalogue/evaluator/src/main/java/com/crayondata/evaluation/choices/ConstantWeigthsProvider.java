/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.evaluation.choices;

import com.crayondata.choice.rateableitem.Category;
import com.crayondata.recommender.Recommender;
import com.crayondata.recommender.RecommenderScenario;
import com.crayondata.recommender.context.UserContext;
import com.crayondata.recommender.search.IRecommendBySearch;
import com.crayondata.recommender.search.IWeightsProvider;

public class ConstantWeigthsProvider implements IWeightsProvider {
    
    public ConstantWeigthsProvider() {
    }

    @Override
    public RecommenderWeights provideWeights(UserContext userContext, Object userProfile,
            Iterable<IRecommendBySearch> recommenders) {
        return new RecommenderWeights() {
            public float get(Recommender recommender) {
                return 1.0f;
            }

            /**
             * Get the combination label(HLHLHHLLH) used to randomize weights for this instance
             *
             * @return
             */
            public String getCombinationLabel() {
                /*throw new RuntimeException("Not implemented!");*/
                return "DUMMY_LABEL";
            }

            /**
             * Get the randomized weightages(323143124) as per the current combination label
             *
             * @return
             */
            public String getLabelWeightageString() {
                /*throw new RuntimeException("Not implemented!");*/
                return "DUMMY_WEIGHTAGE";
            }

            /**
             * Normalize weights resetting weight for any unused recommender to 0
             *
             * @param usedRecommenders
             */
            public void normalizeWeights(Iterable<IRecommendBySearch> usedRecommenders) {
            }
        };
    }

    @Override
    public RecommenderWeights provideWeights(UserContext userContext, Object userProfile, Iterable<IRecommendBySearch> recommenders, Category category, RecommenderScenario recommenderScenario) {
        return provideWeights(userContext, userProfile, recommenders);
    }

}
