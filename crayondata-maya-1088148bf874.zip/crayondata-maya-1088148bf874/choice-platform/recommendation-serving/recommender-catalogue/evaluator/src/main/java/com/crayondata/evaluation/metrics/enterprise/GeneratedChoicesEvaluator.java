/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.evaluation.metrics.enterprise;

import java.util.ArrayList;
import java.util.List;

import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.DataFrame;
import org.apache.spark.sql.SQLContext;

import com.crayondata.evaluation.metrics.PerUserAccuracyGenerator;
import com.crayondata.recommender.Recommender;
import com.google.common.collect.Lists;

import scala.Tuple2;

/**
 * 
 * @author vivek
 *
 */
public class GeneratedChoicesEvaluator {

    /** Format: (userid, [item1, item2]) */
    private String testItemsFileUri;
    /** Format: (userid,[[model1:c1, model1:c2],[model2:c1, model2:c2]]) */
    private String choiceFileUri;
    private int atN;
    private int recoCount;
    private String outputDir;

    public static final List<Recommender[]> recommenderLists;

    static {
        recommenderLists = new ArrayList<>();
        Recommender[] topRated = { Recommender.TOPRATEDITEM };
        Recommender[] attribute = { Recommender.ATTRIBUTE_NUMERICAL, Recommender.ATTRIBUTE_CATEGORICAL };
        Recommender[] tg1 = { Recommender.TGFIRSTHOPNICHE };
        Recommender[] tg2 = { Recommender.TGFIRSTHOPPOPULAR };
        Recommender[] tg3 = { Recommender.TGSECONDHOPDISCOVERY };
        Recommender[] tgall = { Recommender.TGFIRSTHOPNICHE, Recommender.TGFIRSTHOPPOPULAR,
                Recommender.TGSECONDHOPDISCOVERY };
        Recommender[] all = { Recommender.ATTRIBUTE_NUMERICAL, Recommender.ATTRIBUTE_CATEGORICAL,
                Recommender.TGFIRSTHOPNICHE, Recommender.TGFIRSTHOPPOPULAR,
                Recommender.TGSECONDHOPDISCOVERY };

        Recommender[] enttg1 = { Recommender.ENTERPRISETGFIRSTHOPNICHE };
        Recommender[] enttg2 = { Recommender.ENTERPRISETGFIRSTHOPPOPULAR };
        Recommender[] enttg3 = { Recommender.ENTERPRISETGSECONDHOPDISCOVERY };
        Recommender[] enttgall = { Recommender.ENTERPRISETGFIRSTHOPNICHE,
                Recommender.ENTERPRISETGFIRSTHOPPOPULAR, Recommender.ENTERPRISETGSECONDHOPDISCOVERY };
        Recommender[] ent_all = { Recommender.ENTERPRISETGFIRSTHOPNICHE,
                Recommender.ENTERPRISETGFIRSTHOPPOPULAR, Recommender.ENTERPRISETGSECONDHOPDISCOVERY,
                Recommender.ATTRIBUTE_NUMERICAL, Recommender.ATTRIBUTE_CATEGORICAL };

        /*
         * recommenderLists.add(topRated); recommenderLists.add(attribute);
         */
        recommenderLists.add(enttg1);
        recommenderLists.add(enttg2);
        recommenderLists.add(enttg3);
        recommenderLists.add(enttgall);
        recommenderLists.add(attribute);
        recommenderLists.add(ent_all);
        /* recommenderLists.add(all); */
    }

    public static void main(String[] args) {
        SparkConf conf = new SparkConf().setAppName("Choice Evaliation applition")
                .set("spark.executor.memory", "64g").set("spark.num.executors", "1")
                /* .set("spark.executor.cores", "7"). */.set("spark.total.executor.cores", "15")
                .set("spark.storage.memoryFraction", "0.1");
        JavaSparkContext sc = new JavaSparkContext(conf);

        if (args.length < 4) {
            System.out.println(
                    ".. Usage GeneratedChoicesEvaluator <choicesFileUri> <atN> <recoCount> <outputDir>");
            System.exit(1);
        }

        GeneratedChoicesEvaluator evaluator = new GeneratedChoicesEvaluator(args[0],
                Integer.parseInt(args[1]), Integer.parseInt(args[2]), args[3]);
        evaluator.generateMetrics(sc);
    }

    /*
     * private JavaPairRDD<String, List<Integer>> loadTestItems(JavaSparkContext
     * sc){ JavaPairRDD<String, List<Integer>> testItems; JavaRDD<String>
     * strings = sc.textFile(testItemsFileUri);
     * 
     * final Splitter splitterL1 =
     * Splitter.on(',').trimResults().trimResults(CharMatcher.is('(')).
     * trimResults(CharMatcher.is(')')).limit(2); JavaPairRDD<String, String>
     * userToItemList = strings.mapToPair( input -> { List<String> splitted =
     * Lists.newArrayList(splitterL1.split(input)); List<String> splitted1 =
     * Lists.newArrayList(); splitted.forEach(x ->
     * splitted1.add(StringUtils.strip(x.trim(), "()[]"))); return new
     * Tuple2<>(splitted1.get(0), splitted1.get(1)); });
     * 
     * final Splitter splitterL2 = Splitter.on(',').trimResults();
     * 
     * JavaPairRDD<String, List<Integer>> userToItemId
     * =userToItemList.mapToPair(x ->{ List<Integer> itemIds =
     * Lists.newArrayList(); Lists.newArrayList(splitterL2.split(x._2))
     * .forEach(y -> itemIds.add(Integer.parseInt(y))); return new
     * Tuple2<>(x._1, itemIds); });
     * 
     * return userToItemId; }
     */

    public GeneratedChoicesEvaluator(String choiceFileUri, int atN, int recoCount, String outputDir) {
        super();
        this.choiceFileUri = choiceFileUri;
        this.atN = atN;
        this.recoCount = recoCount;
        this.outputDir = outputDir;
    }

    private void generateMetrics(JavaSparkContext sc) {
        String fileUri = this.choiceFileUri;

        SQLContext sqlContext = new SQLContext(sc);
        DataFrame df = sqlContext.read().format("com.databricks.spark.avro").load(fileUri);

        JavaPairRDD<String, List<Integer>> usersToItems = df.javaRDD()
                .mapToPair(x -> new Tuple2<>(x.getString(0), x.getList(2))).mapToPair(x -> {
                    List<Integer> itemIds = Lists.newArrayList();
                    x._2.forEach(y -> itemIds.add(Integer.valueOf(y.toString())));
                    return new Tuple2<>(x._1, itemIds);
                });

        JavaPairRDD<String, List<Integer>> usersToTrainItems = df.javaRDD()
                .mapToPair(x -> new Tuple2<>(x.getString(0), x.getList(3))).mapToPair(x -> {
                    List<Integer> itemIds = Lists.newArrayList();
                    x._2.forEach(y -> itemIds.add(Integer.valueOf(y.toString())));
                    return new Tuple2<>(x._1, itemIds);
                });

        JavaPairRDD<String, List<List<Integer>>> userToChoices = df.javaRDD().mapToPair(x -> {
            String userId = x.getString(0);
            int recoCount = x.getInt(1);
            List<List<Integer>> choices = x.getList(4);
            return new Tuple2<>(userId, choices);
        });

        PerUserAccuracyGenerator accuracyGen = new PerUserAccuracyGenerator(this.atN, this.outputDir,
                this.recoCount);
        accuracyGen.generateAccuracyForUsers(usersToTrainItems, usersToItems, userToChoices, sc, false);
        accuracyGen.generateCoverageAcrossUsers(usersToItems, userToChoices, recommenderLists);
    }
}
