/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.evaluation.choices;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.DataFrame;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SQLContext;
import org.apache.spark.sql.functions;

import scala.Tuple2;

import com.clearspring.analytics.util.Lists;
import com.crayondata.item.processor.spark.UserCooccurrenceSimilarity;
import com.crayondata.recommender.Recommender;
import com.google.common.base.Optional;

/**
 * 
 * @author vivek
 *
 */
public class EnterpriseSimilarityAdapter implements ChoiceGenerator, Serializable {

	private String trainFileUri;
    private int topN;
    private String ouputDir;
    private int numPartitions; 
    private double simThreshold;
    private Optional<String> modelFileUri;
    
    private UserCooccurrenceSimilarity similarityProcessor;
    
	public EnterpriseSimilarityAdapter(String trainFileUri, int topN,
			String ouputDir, int numPartitions, double simThreshold,
			Optional<String> modelFileUri) {
		super();
		this.trainFileUri = trainFileUri;
		this.topN = topN;
		this.ouputDir = ouputDir;
		this.numPartitions = numPartitions;
		this.simThreshold = simThreshold;
		this.modelFileUri = modelFileUri;
	}
    
	public void initModel(JavaSparkContext jc){
		similarityProcessor = 
				new UserCooccurrenceSimilarity(trainFileUri, topN, ouputDir, simThreshold, numPartitions, modelFileUri);
		similarityProcessor.loadModel(jc);
	}

	@Override
	public List<Integer> getOrderedChoices(List<Integer> itemIds,
            String userId, boolean useCentroidLocation, boolean useAttrFilterFromProfile, int topN) {
		
		return null;
		/*return similarityProcessor.getOrderedChoices(itemIds);*/
	}

	@Override
	public List<List<Integer>> getOrderedChoicesForModels(
			List<Integer> itemIds, String userId, List<Recommender[]> models,
            boolean useCentroidLocation, boolean useAttrFilterFromProfile, int topN) {
		/*List<List<Integer>> result = Lists.newArrayList();
		result.add(similarityProcessor.getOrderedChoices(itemIds));
		return result;*/
		return null;
	}
	
	public DataFrame getScoredPairDataFrame(JavaSparkContext jc){
		return similarityProcessor.getLookupDataFrame(jc);
	}

	@Override
	public long getFailureCount() {
		// TODO Auto-generated method stub
		return 0;
	}
	
	public JavaPairRDD<String, List<List<Integer>>> getChoicesFromSimilarityModel(JavaPairRDD<String, List<Integer>> train, 
    		JavaSparkContext sc, final int topN){
    	SQLContext sqlContext = new SQLContext(sc);
    	JavaPairRDD<String, Integer> trainPairs = train.flatMapToPair(x -> {
    		List<Tuple2<String, Integer>> tuples = Lists.newArrayList();
    		x._2.forEach(y -> tuples.add(new Tuple2<>(x._1,y)));
    		return tuples;
    	});
    	
    	JavaRDD<Interaction> interactions = trainPairs.map(x -> new Interaction(x._1,x._2.intValue()));
    	
    	DataFrame trainDF = sqlContext.createDataFrame(interactions, Interaction.class);
    	DataFrame scoredPairDF = this.getScoredPairDataFrame(sc);
    	
    	trainDF.registerTempTable("train");
    	scoredPairDF.registerTempTable("scoredpair");
    	
    	DataFrame joined = trainDF.join(scoredPairDF, trainDF.col("itemId").equalTo(scoredPairDF.col("itemFromId")))
    		.select(trainDF.col("userId"), 
    				scoredPairDF.col("itemToId"), scoredPairDF.col("similarityScore"));
    	System.out.println(" Join done with columns :" + Arrays.asList(joined.columns()));
    	System.out.println(" Joined record count :" + joined.count());
    	DataFrame usersToItemsScores = joined.groupBy(trainDF.col("userId"), scoredPairDF.col("itemToId"))
    		.agg(functions.avg(scoredPairDF.col("similarityScore").as("avgSimilarityScore")));
    	System.out.println(" Group by completed with columns :" + Arrays.asList(usersToItemsScores.columns()));
    	System.out.println(" Grouped count :" + usersToItemsScores.count());
    	
    	/*List<String> colNames = Lists.newArrayList();
    	colNames.add("userId");colNames.add("itemToId"); colNames.add("avgSimilarityScore");
    	DataFrame resultDF = usersToItemsScores.toDF(JavaConversions.asScalaBuffer(colNames));*/
    	
    	return getChoicesFromDF(usersToItemsScores, topN);
    }
    
    private JavaPairRDD<String, List<List<Integer>>> getChoicesFromDF(DataFrame usersToItemsScores, final int topN){
    	System.out.println("Mapping grouped df into rows");
    	JavaRDD<Row> rowsRdd = usersToItemsScores.toJavaRDD();
    	JavaPairRDD<String, Tuple2<Integer, Double>> choicesRdd = rowsRdd.mapToPair(
    			row -> new Tuple2<>(row.getString(0), new Tuple2<>(row.getInt(1), row.getDouble(2))));
    	JavaPairRDD<String, Iterable<Tuple2<Integer, Double>>> choicesGrouped = 
    		choicesRdd.groupByKey();
    	System.out.println("Rdd Group by with key completed..");
    	JavaPairRDD<String, List<Tuple2<Integer, Double>>> topNChoicesRdd =
    	choicesGrouped.mapToPair(input ->{
    		ArrayList<Tuple2<Integer, Double>> item2List = new ArrayList<>();
        	CollectionUtils.addAll(item2List, input._2.iterator());
        	Collections.sort(item2List, (v1, v2) -> {
        		int cmp = v2._2.compareTo(v1._2);
        		if (cmp == 0)
        			cmp = v2._1.compareTo(v1._1);
        		return cmp;
        	});
        	if (item2List.size() > topN)
        		item2List.subList(topN, item2List.size()).clear();
        	item2List.trimToSize();
        	return new Tuple2<>(input._1, item2List);
    	});
    	System.out.println("Rdd filter by topN.." + topN + ".. completed..");
    	JavaPairRDD<String, List<List<Integer>>> topNChoiceList =
    			topNChoicesRdd.mapToPair(x ->{
    				List<List<Integer>> result = Lists.newArrayList();
    				List<Integer> choiceList = Lists.newArrayList();
    				x._2.stream().forEachOrdered(y -> choiceList.add(y._1));
    				result.add(choiceList);
    				return new Tuple2<>(x._1, result);
    			});
    	System.out.println(".. Returning completed choices..");
    	return topNChoiceList;
    }
    
    public class Interaction {
    	private String userId;
    	private int itemId;
    	public Interaction(){}
    	public Interaction(String userId, int itemId) {
			super();
			this.userId = userId;
			this.itemId = itemId;
		}
		public String getUserId() {
			return userId;
		}
		public void setUserId(String userId) {
			this.userId = userId;
		}
		public int getItemId() {
			return itemId;
		}
		public void setItemId(int itemId) {
			this.itemId = itemId;
		}
    }

}
