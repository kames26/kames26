
plot(accuracy~interactions, data=attr_data)


ggplot(attr_data, aes(interactions,accuracy)) + 
  annotate("rect", xmin = 0, xmax = 80, ymin = 0, ymax = 0.25, fill= "yellow")  + 
  annotate("rect", xmin = 81, xmax = 160, ymin = 0.26, ymax = 0.5 , fill= "blue") + 
  annotate("rect", xmin = 0, xmax = 80, ymin = 0.26, ymax = 0.5, fill= "green") + 
  annotate("rect", xmin = 81, xmax = 160, ymin = 0, ymax = 0.25, fill= "red") + 
  geom_point() +theme(text = element_text(size=20))+ggtitle("Interactions vs accuracy (Attribute Model)") +  labs(x="Interactions",y="Accuracy") #+ xlim(-10,10)+ ylim(-10,10)


qplot(attr_data$accuracy, geom="histogram",main = "Histogram for Accuracy", 
      xlab = "Accuracy",  
      fill=I("blue"), 
      col=I("red"))
#,scale_fill_gradient("Count", low = "green", high = "red")) 

qplot(attr_data$accuracy, geom="histogram",main = "Histogram for Accuracy(Attribute model)", 
      xlab = "Accuracy",  bins=10,
      fill=I("blue"), 
      col=I("red"))+theme(text = element_text(size=20))

ggplot(attr_data, aes(x=as.factor(round(interactions/10)), y=accuracy))+geom_boxplot(fill="chartreuse4")#+coord_flip()

qplot(as.factor(round(interactions/20)), accuracy, data = attr_data, fill=as.factor(round(interactions/20)))+ geom_boxplot() + scale_fill_brewer(name="Interactions (in 20s)")+theme(text = element_text(size=20))+ggtitle("Accuracy with interactions(Attribute model)") +  labs(x="Interactions (in 20s)",y="Accuracy")
