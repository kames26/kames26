/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.evaluation.choices;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicLong;

import com.crayondata.choice.rateableitem.Category;
import com.crayondata.choice.rateableitem.CreativeWork;
import com.crayondata.choice.rateableitem.LocalBusiness;
import com.crayondata.choice.rateableitem.RateableItemDao;
import com.crayondata.choice.rateableitem.RateableItemService;
import com.crayondata.choice.rateableitem.RateableItemService.SolrCoreAccessorFactory;
import com.crayondata.choice.rateableitem.solr.CreativeWorkDAOImpl;
import com.crayondata.choice.rateableitem.solr.LocalBusinessDAOImpl;
import com.crayondata.choice.userprofile.UserInteraction;
import com.crayondata.choice.userprofile.UserInteraction.InteractionType;
import com.crayondata.choice.userprofile.UserProfile;
import com.crayondata.choice.userprofile.UserProfileContextHolder;
import com.crayondata.choice.userprofile.builder.impl.UserProfileBuilder;
import com.crayondata.recommender.CrayonCategoricalAttributeRecommender;
import com.crayondata.recommender.CrayonNumericalAttributeRecommender;
import com.crayondata.recommender.Recommender;
import com.crayondata.recommender.RecommenderScenario;
import com.crayondata.recommender.context.UserContext;
import com.crayondata.recommender.factory.SearchRecommenderFactory;
import com.crayondata.recommender.factory.SearchRecommenderFactoryImpl;
import com.crayondata.recommender.recommendation.ScoredItem;
import com.crayondata.recommender.search.IRecommendBySearch;
import com.crayondata.recommender.search.impl.BlendingRecommender;
import com.crayondata.recommender.search.impl.DefaultFilterHandler;
import com.google.common.base.Optional;
import com.google.common.collect.HashBasedTable;
import com.google.common.collect.Table;

public class CategoryChoiceGenerator implements Serializable, ChoiceGenerator {

    /**
     *
     */
    private static final long serialVersionUID = 1L;

    private static String solrHost = "latest-solr.buildmaya.com"/* "dev.buildmaya.com" */;
    private static final String solrPort = "8983";
    private static final int chunkSize = 100;
    private static final int userId = 12345;

    private static final int minFillRate = -1;

    private static final int maxChoices = 18;

    private AtomicLong failureCount = new AtomicLong(0);

    private final Category cat;

    // private static final Recommender[] recommendersList = {
    // Recommender.TOPRATEDITEM };
    private static final Recommender[] defaultRecoList = { Recommender.TGFIRSTHOPNICHE,
        Recommender.TGFIRSTHOPPOPULAR, Recommender.TGSECONDHOPDISCOVERY, Recommender.ATTRIBUTE_NUMERICAL, Recommender.ATTRIBUTE_CATEGORICAL };
    // private static final Recommender[] recommendersList = {
    // Recommender.ATTRIBUTE };

    public CategoryChoiceGenerator(Category cat, String solrHost) {
        this.cat = cat;
        this.solrHost = solrHost;
    }

    private static BlendingRecommender initRecommender(SearchRecommenderFactory searchRecommenderFactory) {
        SolrCoreAccessorFactory coreAccessorFactory = new SolrCoreAccessorFactory(solrHost, solrPort);

        RateableItemService riService = new RateableItemService(coreAccessorFactory);
        UserProfileContextHolder<? extends UserProfile> contextHolder = new UserProfileContextHolder<>(null,
                null);

        BlendingRecommender recommender = new BlendingRecommender(new DefaultFilterHandler(minFillRate),
                /* new RandomWeightsProvider(), */ new ConstantWeigthsProvider(), searchRecommenderFactory,
                riService, contextHolder, maxChoices);

        return recommender;
    }

    private static SearchRecommenderFactory initRecommenderFactory() {
        SearchRecommenderFactoryImpl searchRecommenderFactory = new SearchRecommenderFactoryImpl(
                new CrayonCategoricalAttributeRecommender(), new CrayonNumericalAttributeRecommender());
        return searchRecommenderFactory;
    }

    private static UserProfileBuilder<UserProfile> initUserProfileBuilder() {
        RateableItemDao<LocalBusiness> localBusinessDAO = new LocalBusinessDAOImpl(solrHost, solrPort);
        RateableItemDao<CreativeWork> creativeWorkDAO = new CreativeWorkDAOImpl(solrHost, solrPort);
        return new UserProfileBuilder<UserProfile>(localBusinessDAO, creativeWorkDAO);
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.crayondata.evaluation.choices.ChoiceGenerator#getOrderedChoices(java.
     * util.List)
     */
    @Override
    public List<Integer> getOrderedChoices(List<Integer> itemIds, String userId,
            boolean useCentroidLocation, boolean useAttrFilterFromProfile, int topN) {
        /*
         * System.out.printf("Calling for choices for user:\t%s\n", userId);
         * System.out.println(" with:" + itemIds.size());
         */
        List<ScoredItem> choices = generateCategoryChoices(itemIds, defaultRecoList,
                useCentroidLocation, useAttrFilterFromProfile, topN);
        List<Integer> itemIdList = new ArrayList<>();
        for (ScoredItem item : choices) {
            itemIdList.add(item.getItem().getId());
        }

        return itemIdList;
    }

    public List<ScoredItem> generateCategoryChoices(List<Integer> itemIds, Recommender[] recommendersList,
            boolean setCentroidLocation, boolean useAttrFilterFromProfile, int topN) {

        SearchRecommenderFactory searchRecommenderFactory = initRecommenderFactory();
        BlendingRecommender recommender = initRecommender(searchRecommenderFactory);

        UserProfile userProfile = constructUserProfile(itemIds);

        UserContext userContext;
        if (!setCentroidLocation) {
            userContext = new UserContext(userId,
                    new Date());
        } else {
            userContext = new UserContext(userId, new Date(), userProfile.getCentroidLocations().get(cat));
        }

        userContext.setCategory(this.cat);
        if (setCentroidLocation && userProfile.getMaxDistance() != -1) {
            userContext.setMaxDistanceInKm(userProfile.getMaxDistance());
        } else {
            userContext.setMaxDistanceInKm(15);
        }
        if (useAttrFilterFromProfile) {
            // set filter attributes from profile
            Table<Category, String, Iterable<String>> userAttributePreference = userProfile.getUserAttributePreference();
            if (userAttributePreference != null && !userAttributePreference.isEmpty()) {
                Map<String, List<String>> filterAttributes = userContext.getFilterAttributes();
                if (cat.equals(Category.RESTAURANT)) {
                    Iterable<String> attributes = userAttributePreference.get(cat, "cuisine");
                    if (attributes != null) {
                        if (filterAttributes.containsKey("cuisine")) {
                            filterAttributes.get("cuisine").addAll((Collection<? extends String>) attributes);
                        } else {
                            filterAttributes.put("cuisine", new ArrayList<>((Collection<? extends String>) attributes));
                        }
                    }
                }
            }
        }
        int maxChoices = topN;
//        int maxChoices = (itemIds.size() <= 100) ? itemIds.size() : 100;
        // return recommender.recommend(userContext, userProfile, maxChoices);

        final Collection<IRecommendBySearch> recommenders = searchRecommenderFactory
                .getRecommenders(Arrays.asList(recommendersList));
        List<ScoredItem> result = Collections.emptyList();
        Optional<RecommenderScenario> scenario = Optional.absent();
        try {
            result = recommender.recommendWithRecommenders(userContext, userProfile, recommenders,
                    maxChoices, false, false, scenario);
        } catch (Exception e) {
            System.err.println(" Choice generation failed");
            e.printStackTrace();
            System.out.printf("Failing for:%d time\n", this.failureCount.incrementAndGet());
        }

        return result;
    }

    private UserProfile constructUserProfile(Iterable<Integer> itemIds) {
        UserProfileBuilder<UserProfile> builder = initUserProfileBuilder();

        List<UserInteraction> movieUserInteractions = new ArrayList<>();

        for (Integer itemId : itemIds) {
            movieUserInteractions.add(new UserInteraction(InteractionType.Like, this.cat, userId, itemId));
        }
        Table<Category, InteractionType, Iterable<UserInteraction>> userLikes = HashBasedTable.create();
        userLikes.put(this.cat, InteractionType.Like, movieUserInteractions);

        return builder.build(userId, userLikes);
    }

    public long getFailureCount() {
        return this.failureCount.get();
    }

    public static void main(String[] args) {
        if (args.length >= 2) {
            String fileUri = args[0];
            boolean isAvro = Boolean.parseBoolean(args[1].trim());
            System.out.printf("Args:%s and %s\n", args[0], args[1]);
            System.out.printf("Using the file:%s and the avro:%s flag passed for processing\n", fileUri,
                    String.valueOf(isAvro));
            if (isAvro) {
                System.out.println("Avro");
            } else {
                System.out.println("Text");
            }
        }

        Double[] input = { 1.0, 2.0, 3.0, 4.0, 5.0 };
        System.out.println(Arrays.asList(input).toString());
        String ouput = Arrays.asList(input).stream().map(x -> String.valueOf(x)).reduce((x, y) -> x + "," + y)
                .get();
        System.out.println(ouput);
    }

    @Override
    public List<List<Integer>> getOrderedChoicesForModels(List<Integer> itemIds, String userId,
            List<Recommender[]> models, boolean setCentroidLocation, boolean useAttrFilterFromProfile, int topN) {
        System.err.println(".. Generating choices for:" + userId);
        List<List<Integer>> result = new ArrayList<>();
        for (Recommender[] recoList : models) {
            List<ScoredItem> choices = generateCategoryChoices(itemIds, recoList, setCentroidLocation, useAttrFilterFromProfile, topN);
            List<Integer> itemIdList = new ArrayList<>();
            choices.forEach(item -> itemIdList.add(item.getItem().getId()));
            result.add(itemIdList);
        }
        System.err.println("Choice generation complete for:" + userId);

        return result;
    }

}
