/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.evaluation.metrics;

import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;

import scala.Tuple2;

/**
 * 
 * @author vivek
 *
 */
public class AccuracyFilesJoiner {

	private String dir1;
	private String dir2;
	private String outputDir;
	public AccuracyFilesJoiner(String dir1, String dir2, String outputDir) {
		super();
		this.dir1 = dir1;
		this.dir2 = dir2;
		this.outputDir = outputDir;
	}

	public static void main(String[] args) {
		SparkConf conf = new SparkConf().setAppName("Choice Evaliation applition").set("spark.executor.memory", "64g")
                .set("spark.num.executors", "1")/*.set("spark.executor.cores", "7").*/.set("spark.total.executor.cores", "15")
                .set("spark.storage.memoryFraction", "0.1");
        JavaSparkContext sc = new JavaSparkContext(conf);
        AccuracyFilesJoiner joiner = new AccuracyFilesJoiner(args[0], args[1], args[2]);
        joiner.joinAndPersistResults(sc);
	}

	public void joinAndPersistResults(JavaSparkContext sc){
		JavaPairRDD<String, String> firstRdd = sc.textFile(dir1).mapToPair(x -> {
			String userId = x.substring(0, x.indexOf(','));
			String restStr = x.substring(x.indexOf(',')+1);
			return new Tuple2<>(userId, restStr);
		});
		
		JavaPairRDD<String, String> secondRdd = sc.textFile(dir2).mapToPair(x -> {
			String userId = x.substring(0, x.indexOf(','));
			String rest1Str = x.substring(x.indexOf(',')+1);
			String rest2Str = rest1Str.substring(rest1Str.indexOf(',')+1);
			return new Tuple2<>(userId, rest2Str);
		});
		
		JavaRDD<String> joined = firstRdd.join(secondRdd).map(x ->
				x._1 + "," + x._2._1+","+x._2._2);
		joined.saveAsTextFile(this.outputDir+"/Merged");
	}
}
