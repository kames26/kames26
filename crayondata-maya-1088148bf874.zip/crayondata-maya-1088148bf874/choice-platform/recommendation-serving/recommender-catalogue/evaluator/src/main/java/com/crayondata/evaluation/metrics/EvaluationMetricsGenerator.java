/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.evaluation.metrics;

import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.mllib.evaluation.RankingMetrics;
import org.apache.spark.sql.DataFrame;
import org.apache.spark.sql.SQLContext;

import scala.Tuple2;

import com.crayondata.choice.rateableitem.Category;
import com.crayondata.evaluation.choices.ChoiceGenerator;
import com.crayondata.evaluation.choices.CategoryChoiceGenerator;
import com.crayondata.evaluation.choices.ItemSimilarityAdapter;
import com.crayondata.recommender.Recommender;
import com.google.common.base.Optional;

import java.util.Comparator;

/**
 * 
 * @author vivek
 *
 */
public class EvaluationMetricsGenerator implements Serializable {

    public static final String USER_ITEM_COUNT_FILE = "/UsersCount";
    public static final String USER_CHOICES_FILE = "/Choices";
    public static final String USER_LIKES_FILE = "/Users";
    public static final String USER_ACCURACY_FILE = "/UserMetrics";
    public static final String USER_RAW_METRIC_FILE = "/UserRawMetrics";
    public static final String USER_TOPN_CHOICES_FILE = "/TopNChoices";

    public static final boolean USE_USER_CENTROID = false;
    public static final boolean USE_USER_ATTRIBUTE_PREFERENCE = false;

    private Category cat = Category.MOVIE;

    private static String solrHost = "latest-solr.buildmaya.com";

    private static Optional<String> similaryFileUri = Optional.absent();

    public static final List<Recommender[]> recommenderLists;

    static {
        recommenderLists = new ArrayList<>();
        Recommender[] topRated = { Recommender.TOPRATEDITEM };
        Recommender[] attribute = { Recommender.ATTRIBUTE_NUMERICAL, Recommender.ATTRIBUTE_CATEGORICAL };
        Recommender[] tg1 = { Recommender.TGFIRSTHOPNICHE };
        Recommender[] tg2 = { Recommender.TGFIRSTHOPPOPULAR };
        Recommender[] tg3 = { Recommender.TGSECONDHOPDISCOVERY };
        Recommender[] tgall = { Recommender.TGFIRSTHOPNICHE, Recommender.TGFIRSTHOPPOPULAR,
                Recommender.TGSECONDHOPDISCOVERY };
        Recommender[] all = { Recommender.ATTRIBUTE_NUMERICAL, Recommender.ATTRIBUTE_CATEGORICAL,
                Recommender.TGFIRSTHOPNICHE, Recommender.TGFIRSTHOPPOPULAR,
                Recommender.TGSECONDHOPDISCOVERY };

        recommenderLists.add(topRated);
        recommenderLists.add(attribute);
        recommenderLists.add(tg1);
        recommenderLists.add(tg2);
        recommenderLists.add(tg3);
        recommenderLists.add(tgall);
        recommenderLists.add(all);
    }

    private static String fileUri = /* "data/movie_review" */ "data/ba9586bb-506c-4c96-a614-9d89aedabad4.avro";
    private static int MIN_INTERACTION = 11;
    private static boolean isAvro = true;
    private static int[] atNList = /* {6,9,12,15,18} */ { 6, 18 };

    protected int atN = 18;
    protected String dirPrefix = "target/Output/";

    protected ItemSimilarityAdapter similarityAdapter;

    private static int partitionCount = 256;

    public EvaluationMetricsGenerator() {}

    public void initSimilarityAdapter(JavaSparkContext jc) {
        System.out.println("Initializing similarity model..");
        long startTime = System.currentTimeMillis();
        this.similarityAdapter = new ItemSimilarityAdapter(cat, solrHost, partitionCount);
        this.similarityAdapter.initModel(jc, similaryFileUri);
        System.out.printf(".. Time taken for similarity model init:%d\n",
                (System.currentTimeMillis() - startTime));
    }

    public Category getCat() {
        return cat;
    }

    public void setCat(Category cat) {
        this.cat = cat;
    }

    public int getAtN() {
        return atN;
    }

    public void setAtN(int atN) {
        this.atN = atN;
    }

    public void setDirPrefix(String dirPrefix) {
        this.dirPrefix = dirPrefix;
    }

    public String getDirPrefix() {
        return this.dirPrefix;
    }

    public void generateEvalMetrics(JavaSparkContext sc) {
        this.initSimilarityAdapter(sc);

        JavaPairRDD<String, Tuple2<List<Integer>, List<Integer>>> usersToItems = getUsers(sc, isAvro,
                MIN_INTERACTION, fileUri).cache();

        JavaPairRDD<String, List<Integer>> train = usersToItems
                .mapToPair(input -> new Tuple2<>(input._1, input._2._1));
        JavaPairRDD<String, List<Integer>> test = usersToItems
                .mapToPair(input -> new Tuple2<>(input._1, input._2._2));

        usersToItems.saveAsTextFile(this.dirPrefix + USER_LIKES_FILE);

        System.out.println(".. Number of users:" + usersToItems.count());

        ChoiceGenerator choiceGenerator = new CategoryChoiceGenerator(cat, solrHost);
        final int topN = 18;
        JavaPairRDD<String, List<List<Integer>>> userToChoices = train.mapToPair(
                input -> new Tuple2<>(input._1, choiceGenerator.getOrderedChoicesForModels(input._2, input._1,
                        recommenderLists, USE_USER_CENTROID, USE_USER_ATTRIBUTE_PREFERENCE, topN)))
                .cache();
        long simStartTime = System.currentTimeMillis();
        JavaPairRDD<String, List<Integer>> simChoices = train.mapToPair(input -> new Tuple2<>(input._1,
                this.similarityAdapter.getOrderedChoices(input._2, input._1, false, false, topN)));
        System.out.printf("Time taken for similarity choices:%d\n",
                (System.currentTimeMillis() - simStartTime));

        userToChoices = userToChoices.join(simChoices).mapToPair(x -> {
            List<List<Integer>> result = x._2._1;
            result.add(x._2._2);
            return new Tuple2<>(x._1, result);
        }).cache();

        userToChoices.saveAsTextFile(this.dirPrefix + USER_CHOICES_FILE);

        System.out.printf("Number of choice generation failed..%d", choiceGenerator.getFailureCount());

        PerUserAccuracyGenerator accuracyGen = new PerUserAccuracyGenerator(atN, this.dirPrefix,
                recommenderLists.size() + 1);
        System.out.println(".. Generating per user accuracy..");
        accuracyGen.generateAccuracyForUsers(train, test, userToChoices, sc, true);

        printMoreStats(test, userToChoices, recommenderLists);

    }

    protected void printMoreStats(JavaPairRDD<String, List<Integer>> usersToItems,
            JavaPairRDD<String, List<List<Integer>>> userToChoices, List<Recommender[]> recoList) {
        int i = 0;
        for (Recommender[] recommenders : recoList) {
            System.out.println("Stats For recommenders..");
            Arrays.asList(recommenders).forEach(System.out::println);
            final int index = i;
            JavaPairRDD<String, List<Integer>> userToModelChoices = userToChoices
                    .mapToPair(input -> new Tuple2<>(input._1, input._2.get(index)));
            JavaRDD<Tuple2<List<Integer>, List<Integer>>> relevantDocs = usersToItems.join(userToModelChoices)
                    .values();

            // Instantiate the metrics object
            RankingMetrics metrics = RankingMetrics.of(relevantDocs);

            // Precision and NDCG at k
            Integer[] kVector = { 1, 3/* , 5,7,11 */ };
            for (Integer k : kVector) {
                try {
                    System.out.format("Precision at %d = %f\n", k, metrics.precisionAt(k));
                    System.out.format("NDCG at %d = %f\n", k, metrics.ndcgAt(k));
                } catch (Exception e) {

                }
            }

            // Mean average precision
            System.out.format("Mean average precision = %f\n", metrics.meanAveragePrecision());
            i++;
        }
    }

    public static void main(String[] args) throws IOException {
        Category cat = Category.MOVIE;
        if (args.length >= 3) {
            fileUri = args[0];
            isAvro = Boolean.parseBoolean(args[1].trim());
            System.out.printf("Args:%s and %s\n", args[0], args[1]);
            System.out.printf("Using the file:%s and the avro:%s flag passed for processing\n", fileUri,
                    String.valueOf(isAvro));
            if (isAvro)
                System.out.println("Avro");
            else
                System.out.println("Text");

            MIN_INTERACTION = Integer.parseInt(args[2]);
            System.out.printf("Using MIN interaction as:%d\n", MIN_INTERACTION);

            System.out.println("Using category:" + args[3]);
            cat = Category.parseCategory(args[3]);

            if (args.length >= 7) {
                System.out.println("atN list:" + args[4]);
                String[] tokens = args[4].split(",");
                int[] atNArgsList = new int[tokens.length];
                int i = 0;
                System.out.printf("Using the passed atN:");
                for (String token : tokens) {
                    atNArgsList[i] = Integer.parseInt(token);
                    System.out.printf("%d\t", atNArgsList[i]);
                    i++;
                }
                System.out.printf("\n");
                atNList = atNArgsList;

                solrHost = args[5];
                System.out.println(".. Solr host:" + solrHost);
                partitionCount = Integer.parseInt(args[6]);
                System.out.println(".. Using partition count::" + partitionCount);
            }
            if (args.length >= 8) {
                System.out.println(".. Similarity model will be loaded from:" + args[7]);
                similaryFileUri = Optional.of(args[7]);
            }
        } else
            System.out.println("File URI not mentioned using the default value:" + fileUri);
        SparkConf conf = new SparkConf().setAppName("Choice Evaliation applition")
                .set("spark.executor.memory", "64g").set("spark.num.executors", "1")
                /* .set("spark.executor.cores", "7"). */.set("spark.total.executor.cores", "15")
                .set("spark.storage.memoryFraction", "0.1");
        JavaSparkContext sc = new JavaSparkContext(conf);

        long startTime = System.currentTimeMillis();

        EvaluationMetricsGenerator metricsGenerator = new EvaluationMetricsGenerator();;
        for (int n : atNList) {
            long startTimeForN = System.currentTimeMillis();
            System.out.printf("Starting for atN:%d\n", n);
            metricsGenerator.setDirPrefix(metricsGenerator.getDirPrefix() + n);
            metricsGenerator.setAtN(n);
            metricsGenerator.setCat(cat);

            metricsGenerator.generateEvalMetrics(sc);
            System.out.printf("Completed for atN:%d\n", n);
            System.out.printf("Time taken for atN:%d, %d seconds\n", n,
                    (System.currentTimeMillis() - startTimeForN) / 1000);
        }

        long endTime = System.currentTimeMillis();
        System.out.println(".. Total Time taken :" + (endTime - startTime) / 1000);
    }

    protected JavaPairRDD<String, Integer> readReviewDataFromAvro(JavaSparkContext sc, String fileUri) {
        SQLContext sqlContext = new SQLContext(sc);
        DataFrame df = sqlContext.read().format("com.databricks.spark.avro").load(fileUri);
        return df.javaRDD().mapToPair(x -> new Tuple2<>(x.getString(1).intern(), x.getInt(0)));
    }

    protected JavaPairRDD<String, Integer> readReviewDataFromText(JavaSparkContext sc, String fileUri) {
        JavaRDD<String> rawData = sc.textFile(fileUri).cache();
        long totalLines = rawData.count();
        System.out.println("Total number of lines:" + totalLines);

        JavaPairRDD<String, Integer> userItemMapRdd = rawData.mapToPair(input -> {
            String[] tokens = input.split("\t");
            Tuple2<String, Integer> result = new Tuple2<>("", 0);
            try {
                if (tokens != null && tokens.length >= 2) {
                    result = new Tuple2<>(tokens[1], Integer.parseInt(tokens[0]));
                }
            } catch (Exception e) {
                System.err.printf("Ignoring record:%s\n", input);
            }
            return result;
        }).filter(input -> !input._1.isEmpty());

        return userItemMapRdd;
    }

    private JavaPairRDD<String, Tuple2<List<Integer>, List<Integer>>> getUsers(JavaSparkContext sc,
            boolean isAvro, final int minInteractions, String fileUri) {
        JavaPairRDD<String, Integer> userItemMapRdd;
        if (isAvro)
            userItemMapRdd = readReviewDataFromAvro(sc, fileUri);
        else
            userItemMapRdd = readReviewDataFromText(sc, fileUri);

        printStats(userItemMapRdd);

        JavaPairRDD<String, Integer> userItemCountRdd = userItemMapRdd
                .mapToPair(input -> new Tuple2<String, Integer>(input._1, 1))
                .reduceByKey((input1, input2) -> input1 + input2)
                .filter(input -> ((input._2 >= minInteractions) ? true : false));
        userItemCountRdd.map(input -> input._1 + "," + input._2)
                .saveAsTextFile(this.dirPrefix + USER_ITEM_COUNT_FILE);
        /* userItemCountRdd.saveAsTextFile(this.dirPrefix + "/UsersCount"); */

        final Map<String, Integer> userItemCountMap = userItemCountRdd.collectAsMap();

        JavaPairRDD<String, Integer> filteredUserItemRdd = userItemMapRdd
                .filter(input -> (userItemCountMap.containsKey(input._1) ? true : false));
        JavaPairRDD<String, Tuple2<List<Integer>, List<Integer>>> userToItemList = filteredUserItemRdd
                .groupByKey().mapToPair(input -> {
                    List<Integer> train = new ArrayList<>();
                    List<Integer> test = new ArrayList<>();
                    int size = userItemCountMap.get(input._1);
                    int trainSize = size / 2;
                    System.err.printf(".. Train size for user:%s\t%d\t%d\n", input._1, trainSize, size);
                    int index = 0;
                    for (Integer id : input._2) {
                        if (index < trainSize)
                            train.add(id);
                        else
                            test.add(id);
                        index++;
                    }
                    return new Tuple2<String, Tuple2<List<Integer>, List<Integer>>>(input._1,
                            new Tuple2<>(train, test));
                });
        return userToItemList;
    }

    protected void printStats(JavaPairRDD<String, Integer> userItemMapRdd) {
        System.out.println(".. Number of unique users:" + userItemMapRdd.keys().distinct().count());
        System.out.println(".. Number of unique products:" + userItemMapRdd.values().distinct().count());
        System.out.println(".. Number of reviews:" + userItemMapRdd.values().count());

        JavaRDD<Integer> userReviews = userItemMapRdd
                .mapToPair(input -> new Tuple2<String, Integer>(input._1, 1))
                .reduceByKey((input1, input2) -> input1 + input2).values();

        int minReviews = userReviews.min(new SerializableComaparator());
        int maxReviews = userReviews.max(new SerializableComaparator());
        double avgReviews = userReviews.fold(0, (x, y) -> x + y) * 1.0 / userReviews.count();
        System.out.println(".. Min reviews per user:" + minReviews);
        System.out.println(".. Max reviews per user:" + maxReviews);
        System.out.println(".. Avg reviews per user:" + avgReviews);
    }

    class SerializableComaparator implements Comparator<Integer>, Serializable {
        @Override
        public int compare(Integer o1, Integer o2) {
            return o1.compareTo(o2);
        }
    }

}
