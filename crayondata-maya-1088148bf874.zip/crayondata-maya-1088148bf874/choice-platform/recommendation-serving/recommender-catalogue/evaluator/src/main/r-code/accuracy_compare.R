install.packages("ggplot2")

library(ggplot2)

all_model_data <- read.csv("backup/all_model_results.csv", 
                           header=FALSE, stringsAsFactors=FALSE, sep=",")

tg_data <- read.csv("backup/tg_results.csv", 
                           header=FALSE, stringsAsFactors=FALSE, sep=",")

attr_data <- read.csv("backup/attr_results.csv", 
                           header=FALSE, stringsAsFactors=FALSE, sep=",")

colnames(all_model_data) <- c("user", "interactions", "accuracy")
colnames(tg_data) <- c("user", "interactions", "accuracy")
colnames(attr_data) <- c("user", "interactions", "accuracy")

sum(ifelse(is.na(attr_data$accuracy),1,0))
sum(ifelse(is.na(tg_data$accuracy),1,0))
sum(ifelse(is.na(all_model_data$accuracy),1,0))

attr_data$accuracy[is.na(attr_data$accuracy)] <- 0

nrow(attr_data)
attr_data$model <- rep("attr",nrow(attr_data))
tg_data$model <- rep("tg",nrow(tg_data))
all_model_data$model <- rep("all",nrow(all_model_data))

data <- all_model_data
data <- rbind(data, tg_data)
data <- rbind(data, attr_data)


ggplot(data, aes(x=as.factor(model), y=accuracy))+geom_boxplot(fill="chartreuse4")+theme(text = element_text(size=30))+ggtitle("Accuracy across models") +  labs(x="Model",y="Accuracy") 

table(as.factor(round(data$accuracy*100/10)),data$model)

mean(data$accuracy)
aggregate(data$accuracy, by=list(data$model), FUN=mean)
aggregate(data$accuracy, by=list(data$model), FUN=sd)
aggregate(data$accuracy, by=list(data$model), FUN=max)
