create_plots <- function(fileUri, plotDir, topN){
  accr_data <- read.csv(fileUri, 
                            header=FALSE, stringsAsFactors=FALSE, sep=",")
  
  colnames(accr_data) <- c("userid","interactions", "toprated", 
                               "attribute", "niche", "popular",
                               "discovery", "all_tg", "all_models", "sim_model")
  
  data.stacked_6 <- melt(accr_data, id.vars = 'userid', 
                         measure.vars = c("toprated","attribute", "niche", "popular",
                                          "discovery", "all_tg", "all_models", "sim_model"))
  
  title.suffix <- paste("@Top",topN, sep=" ")
  text.size <- 5
  boxplot_among <- ggplot(data.stacked_6) +
    geom_boxplot(aes(x=variable, y=value, color=variable))+theme(text = element_text(size=text.size))+ggtitle(paste("Accuracy across models ", title.suffix, sep=" ")) +  labs(x="Model",y="Accuracy") 
  
  text.size <- 5
  attr_plot <- qplot(as.factor(round(interactions/10)), attribute, data = accr_data, fill=as.factor(round(interactions/10)))+ geom_boxplot() + scale_fill_brewer(name="Interactions (in 10s)")+theme(text = element_text(size=text.size))+ggtitle(paste("Accuracy with interactions(Attribute model)", title.suffix, sep=" ")) +  labs(x="Interactions (in 10s)",y="Accuracy")
  niche_plot <- qplot(as.factor(round(interactions/10)), niche, data = accr_data, fill=as.factor(round(interactions/10)))+ geom_boxplot() + scale_fill_brewer(name="Interactions (in 10s)")+theme(text = element_text(size=text.size))+ggtitle(paste("Accuracy with interactions(Niche model)", title.suffix, sep=" ")) +  labs(x="Interactions (in 10s)",y="Accuracy")
  popular_plot <- qplot(as.factor(round(interactions/10)), popular, data = accr_data, fill=as.factor(round(interactions/10)))+ geom_boxplot() + scale_fill_brewer(name="Interactions (in 10s)")+theme(text = element_text(size=text.size))+ggtitle(paste("Accuracy with interactions(Popular model)", title.suffix, sep=" ")) +  labs(x="Interactions (in 10s)",y="Accuracy")
  discovery_plot <- qplot(as.factor(round(interactions/10)), discovery, data = accr_data, fill=as.factor(round(interactions/10)))+ geom_boxplot() + scale_fill_brewer(name="Interactions (in 10s)")+theme(text = element_text(size=text.size))+ggtitle(paste("Accuracy with interactions(Discovery model)", title.suffix, sep=" ")) +  labs(x="Interactions (in 10s)",y="Accuracy")
  all_tg_plot <- qplot(as.factor(round(interactions/10)), all_tg, data = accr_data, fill=as.factor(round(interactions/10)))+ geom_boxplot() + scale_fill_brewer(name="Interactions (in 10s)")+theme(text = element_text(size=text.size))+ggtitle(paste("Accuracy with interactions(All TG model)", title.suffix, sep=" ")) +  labs(x="Interactions (in 10s)",y="Accuracy")
  all_models_plot <- qplot(as.factor(round(interactions/10)), all_models, data = accr_data, fill=as.factor(round(interactions/10)))+ geom_boxplot() + scale_fill_brewer(name="Interactions (in 10s)")+theme(text = element_text(size=text.size))+ggtitle(paste("Accuracy with interactions(All models)", title.suffix, sep=" ")) +  labs(x="Interactions (in 10s)",y="Accuracy")
  sim_model_plot <- qplot(as.factor(round(interactions/10)), sim_model, data = accr_data, fill=as.factor(round(interactions/10)))+ geom_boxplot() + scale_fill_brewer(name="Interactions (in 10s)")+theme(text = element_text(size=text.size))+ggtitle(paste("Accuracy with interactions(Attribute similarity model)", title.suffix, sep=" ")) +  labs(x="Interactions (in 10s)",y="Accuracy")
  
  height<- 3 
  width <- 5 
  units<- 'in' 
  dpi <- 600
  
  ggsave(plot=boxplot_among, filename = paste(plotDir,"boxplot_among.jpg",sep="/"), height = height, width=width, units=units, dpi=dpi)
    
  ggsave(plot=attr_plot, filename = paste(plotDir,"attr_plot.jpg",sep="/"), height = height, width=width, units=units, dpi=dpi)
  ggsave(plot=niche_plot, filename = paste(plotDir,"niche_plot.jpg",sep="/"), height = height, width=width, units=units, dpi=dpi)
  ggsave(plot=popular_plot, filename = paste(plotDir,"popular_plot.jpg",sep="/"), height = height, width=width, units=units, dpi=dpi)
  ggsave(plot=discovery_plot, filename = paste(plotDir,"discovery_plot.jpg",sep="/"), height = height, width=width, units=units, dpi=dpi)
  
  ggsave(plot=all_tg_plot, filename = paste(plotDir,"all_tg_plot.jpg",sep="/"), height = height, width=width, units=units, dpi=dpi)
  ggsave(plot=all_models_plot, filename = paste(plotDir,"all_models_plot.jpg",sep="/"), height = height, width=width, units=units, dpi=dpi)
  ggsave(plot=sim_model_plot, filename = paste(plotDir,"sim_model_plot.jpg",sep="/"), height = height, width=width, units=units, dpi=dpi)
  
  summary(accr_data)
}
  