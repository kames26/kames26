/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.evaluation.choices;

import com.crayondata.choice.rateableitem.Category;
import com.crayondata.recommender.RecommenderScenario;
import com.crayondata.recommender.context.UserContext;
import com.crayondata.recommender.search.IRecommendBySearch;
import com.crayondata.recommender.search.IWeightsProvider;

public class RandomWeightsProvider implements IWeightsProvider {
    
    public RandomWeightsProvider() {
    }

    @Override
    public RecommenderWeights provideWeights(UserContext userContext, Object userProfile,
            Iterable<IRecommendBySearch> recommenders) {
        return new IWeightsProvider.RecommenderWeights();
    }

    @Override
    public RecommenderWeights provideWeights(UserContext userContext, Object userProfile, Iterable<IRecommendBySearch> recommenders, Category category, RecommenderScenario recommenderScenario) {
        return provideWeights(userContext, userProfile, recommenders);
    }

}
