/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.analysis;

import com.clearspring.analytics.util.Lists;
import com.crayondata.evaluation.metrics.enterprise.PropertiesLoader;
import com.google.common.collect.Iterables;
import java.io.IOException;
import java.io.Serializable;
import java.util.List;
import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.DataFrame;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.RowFactory;
import org.apache.spark.sql.SQLContext;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import scala.Tuple2;

/**
 * To extract subset of data. for eg. frequent/infrequent transactors
 *
 * @author somin
 */
public class DataExtractor implements Serializable {

    private String outputDir = "output";
    private String propFileUri;
    private String detailsFileUri;
    private String interactionsFileUri;
    
    private String trainFileUri;
    private String testFileUri;

    private static final Logger LOG = LoggerFactory.getLogger(DataExtractor.class);

    public DataExtractor(String propFileUri) {
        this.propFileUri = propFileUri;
    }

    private void initProps() throws IOException {
        PropertiesLoader propLoader = new PropertiesLoader(this.propFileUri);
        propLoader.loadProperties();

        this.detailsFileUri = System.getProperty("detailsFile");
        this.interactionsFileUri = System.getProperty("InteractionsFile");
        this.trainFileUri = System.getProperty("trainInteractionFile");
        this.testFileUri = System.getProperty("testInteractionFile");
    }

    private DataFrame readDataFromAvro(JavaSparkContext sc, String uri) {
        SQLContext sqlContext = new SQLContext(sc);
        DataFrame df = sqlContext.read().format("com.databricks.spark.avro").load(uri);
        return df;
    }

    private void writeDataAsAvro(JavaSparkContext sc, String uri, StructType schema, JavaRDD<Row> data) {
        SQLContext sqlContext = new SQLContext(sc);
        DataFrame affDF = sqlContext.createDataFrame(data, schema);
        affDF.write().format("com.databricks.spark.avro").save(uri);
    }

    private JavaPairRDD<Integer, String> extractInteractionsFromAvroFile(JavaSparkContext sc, String fileUri) {
        DataFrame dataFrame = readDataFromAvro(sc, fileUri);
        return dataFrame.javaRDD().mapToPair(x -> new Tuple2<>(x.getInt(0), x.getString(1).intern()));
    }

    private void saveInteractionsAsAvro(JavaSparkContext sc, JavaPairRDD<String, Integer> interactions, String uri) {
        String destination = outputDir + "/" + uri;
        JavaRDD<Row> affRow = interactions.map(x -> RowFactory.create(new Object[]{x._2, x._1}));
        writeDataAsAvro(sc, destination, getInteractionSchema(), affRow);
    }

    private void extractFrequentNonFrequentTransactors(JavaSparkContext sc) {
    	JavaPairRDD<Integer, String> trainInteractions = extractInteractionsFromAvroFile(sc, this.trainFileUri);
    	JavaPairRDD<Integer, String> testInteractions = extractInteractionsFromAvroFile(sc, this.testFileUri);
        JavaPairRDD<Integer, String> extractedInteractions = extractInteractionsFromAvroFile(sc, interactionsFileUri);
        JavaPairRDD<String, Integer> reversed = extractedInteractions.mapToPair(x -> new Tuple2<>(x._2, x._1));
        JavaPairRDD<String, Integer> user_trans_counts = reversed.groupByKey().mapToPair(
                x -> new Tuple2<>(x._1, Iterables.size(x._2))
        );
        Integer trans_sum = user_trans_counts.values().fold(0, (x, y) -> x + y);
        long trans_count = user_trans_counts.values().count();
        float trans_avg = 1.0f * trans_sum / trans_count;
        JavaPairRDD<String, Integer> high_trans = user_trans_counts.filter(x -> x._2 >= trans_avg);
        JavaPairRDD<String, Integer> low_trans = user_trans_counts.filter(x -> x._2 < trans_avg);
        JavaPairRDD<String, Integer> nonFreqTrans = reversed.join(low_trans).mapToPair(x -> new Tuple2<>(x._1, x._2._1));
        JavaPairRDD<String, Integer> freqTrans = reversed.join(high_trans).mapToPair(x -> new Tuple2<>(x._1, x._2._1));
        
        JavaPairRDD<String, Integer> nonFreqUsers = nonFreqTrans.keys().distinct().mapToPair(x -> new Tuple2<>(x,1));
        JavaPairRDD<String, Integer> freqUsers = freqTrans.keys().distinct().mapToPair(x -> new Tuple2<>(x,1));
        
        JavaPairRDD<String, Integer> nonFreqTrainTrans =
        		trainInteractions.mapToPair(x -> new Tuple2<>(x._2, x._1)).join(nonFreqUsers).mapToPair(x -> new Tuple2<>(x._1, x._2._1));
        JavaPairRDD<String, Integer> nonFreqTestTrans =
        		testInteractions.mapToPair(x -> new Tuple2<>(x._2, x._1)).join(nonFreqUsers).mapToPair(x -> new Tuple2<>(x._1, x._2._1));
        
        JavaPairRDD<String, Integer> freqTrainTrans =
        		trainInteractions.mapToPair(x -> new Tuple2<>(x._2, x._1)).join(freqUsers).mapToPair(x -> new Tuple2<>(x._1, x._2._1));
        JavaPairRDD<String, Integer> freqTestTrans =
        		testInteractions.mapToPair(x -> new Tuple2<>(x._2, x._1)).join(freqUsers).mapToPair(x -> new Tuple2<>(x._1, x._2._1));
        
        saveInteractionsAsAvro(sc, nonFreqTrans, "nonFrequentTransactions");
        saveInteractionsAsAvro(sc, nonFreqTrainTrans, "nonFrequentTrainTransactions");
        saveInteractionsAsAvro(sc, nonFreqTestTrans, "nonFrequentTestTransactions");
        
        saveInteractionsAsAvro(sc, freqTrans, "frequentTransactions");
        saveInteractionsAsAvro(sc, freqTrainTrans, "frequentTrainTransactions");
        saveInteractionsAsAvro(sc, freqTestTrans, "frequentTestTransactions");
        
        System.out.println("Total records " + extractedInteractions.count());
        System.out.println("Non-Frequent transactions records " + nonFreqTrans.count());
        System.out.println("Non-Frequent train trans count:" + nonFreqTrainTrans.count());
        System.out.println("Non-Frequent test trans count:" + nonFreqTestTrans.count());
        
        System.out.println("Frequent transactions records " + freqTrans.count());
        System.out.println("Frequent train trans count:" + freqTrainTrans.count());
        System.out.println("Frequent test trans count:" + freqTestTrans.count());
    }

    private StructType getInteractionSchema() {
        List<StructField> fields = Lists.newArrayList();
        fields.add(DataTypes.createStructField("itemId", DataTypes.IntegerType, false));
        fields.add(DataTypes.createStructField("userId", DataTypes.StringType, false));
        return DataTypes.createStructType(fields);
    }

    public static void main(String[] args) throws IOException {
        if (args.length < 1) {
            System.out.println("Usage::java DataExtractor <prop-filename>");
            System.exit(1);
        }

        SparkConf conf = new SparkConf().setAppName("Data Extractor Application").set("spark.executor.memory", "64g")
                .set("spark.num.executors", "1")/*.set("spark.executor.cores", "7").*/.set("spark.total.executor.cores", "15")
                .set("spark.storage.memoryFraction", "0.1");
        JavaSparkContext sc = new JavaSparkContext(conf);

        long startTime = System.currentTimeMillis();
        DataExtractor extractor = new DataExtractor(args[0]);
        extractor.initProps();
        extractor.extractFrequentNonFrequentTransactors(sc);
        long endTime = System.currentTimeMillis();
        System.out.println(".. Total Time taken :" + (endTime - startTime) / 1000);
    }
}
