#!/bin/bash

EVALUATOR_JAR="jars/evaluator.jar"
IS_AVRO=true
MIN_INTERACTIONS=11
CATEGORY="MOVIE"
DATA="data/ba9586bb-506c-4c96-a614-9d89aedabad4.avro"
AT_N="18,6"
SOLR_HOST="latest-solr.buildmaya.com"

spark-submit --master local[4] --class "com.crayondata.evaluation.metrics.EvaluationMetricsGenerator" $EVALUATOR_JAR $DATA $IS_AVRO $MIN_INTERACTIONS $CATEGORY $AT_N $SOLR_HOST >output/out.txt 2>output/err.txt &

echo "Started job with PID: $!"
