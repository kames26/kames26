Docker image for running the evaluator framework

## How to build
`mvn clean package docker:build`
This builds the image **docker.crayondata.com/evaluator-image**

## Execution
To start the container, use below command
`docker run -it -p 8080:8080 -p 4040:4040 docker.crayondata.com/evaluator-image`

The default directory is `/usr/local/evaluator`
It contains sub-directories as below
	jars	- contains the application jar for the evaluation framework
	data	- contains the sample data used for running the evaluator
	output	- directory where the output log and errors will be generated

A script `run.sh` is available to start the evaluator process for the default parameters
