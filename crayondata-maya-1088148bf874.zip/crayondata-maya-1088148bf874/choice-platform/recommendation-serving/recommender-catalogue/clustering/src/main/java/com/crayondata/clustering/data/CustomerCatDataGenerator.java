/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.clustering.data;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.TreeMap;

import org.apache.commons.math3.stat.descriptive.SummaryStatistics;
import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.mllib.linalg.DenseVector;
import org.apache.spark.mllib.linalg.Vector;
import org.apache.spark.mllib.random.RandomRDDs;
import org.apache.spark.mllib.rdd.RandomRDD;
import org.apache.spark.mllib.stat.MultivariateStatisticalSummary;
import org.apache.spark.mllib.stat.Statistics;

/**
 * Class for generating sample data for category wise spent for customers.
 * To be used for sample data for running clustering on top.
 * @author vivek
 *
 */
public class CustomerCatDataGenerator {

	private static final String CAT_CONF_FILE_URL = "src/main/resources/cust_cat.conf";
	private static final String CAT_DATA_OUTPUT = "cust_cat_output";
	private static final int PARTITION_COUNT = 64;
	long seed = 12345679L;
	
	private int custCount;
	private String custCatConfFileUri = null;
	private String outputDir = null;
	
	
	public static void main(String[] args) throws FileNotFoundException {
		SparkConf conf = new SparkConf().setAppName("Customer cat data generator");
        conf.setIfMissing("spark.executor.memory", "64g");
        conf.setIfMissing("spark.num.executors", "1");
        // conf.setIfMissing("spark.executor.cores", "7");
        conf.setIfMissing("spark.executor.cores", "15");
        conf.setIfMissing("spark.storage.memoryFraction", "0.1");

        JavaSparkContext sc = new JavaSparkContext(conf);
        if(args.length < 3){
        	System.err.println("Usage:: CustomerCatDataGenerator <cat-conf-file-uri> <customer_count> <output-dir>");
        	System.exit(0);
        }
        int custCount = Integer.parseInt(args[0]);
        CustomerCatDataGenerator catDataGen = new CustomerCatDataGenerator(custCount, 
        		args[1], args[2]);
        catDataGen.generateData(sc);
	}
	
	
	public CustomerCatDataGenerator(int custCount,
			String confFilUri, String outputDir){
		this.custCount = custCount;
		this.custCatConfFileUri = confFilUri;
		this.outputDir = outputDir;
	}
	
	public void parseConf(Map<Integer, Double> catMean, Map<Integer, Double> catStd) throws FileNotFoundException{
		Scanner scanner = new Scanner(new FileInputStream(this.custCatConfFileUri));
		while(scanner.hasNext()){
			String line = scanner.nextLine();
			System.out.println("Conf line read::>" + line);
			if(line.isEmpty())
				continue;
			String[] tokens = line.split(":");
			if(tokens.length<3){
				System.out.println("Skipping:" + line);
				continue;
			}
			double mean = Double.parseDouble(tokens[1]);
			double sd = Double.parseDouble(tokens[2]);
			int catId = Integer.parseInt(tokens[0]);
			
			catMean.put(catId, mean);
			catStd.put(catId, sd);
		}
			
	}
	
	public void generateData(JavaSparkContext sc) throws FileNotFoundException{
		Map<Integer, Double> catMean = new TreeMap<>();
		Map<Integer, Double> catStd = new TreeMap<>();
		parseConf(catMean, catStd);
		
		int catCount = catMean.size();
		
		JavaRDD<Vector> stdNormRdd  
			= RandomRDDs.normalJavaVectorRDD(sc, this.custCount, catCount, PARTITION_COUNT, seed);
		
		JavaRDD<Vector> dataVecRdd 
			= stdNormRdd.map(x -> {
			double[] data = x.toArray();
			double[] result = new double[data.length];
			int index=1;
			for(double z : data){
				double mean = catMean.get(index);
				double sd = catStd.get(index);
				double val = z*sd + mean;
				result[index-1]=val;
				index++;
			}
			
			Vector resultVec = new DenseVector(result);
			return resultVec;
		});
		
		MultivariateStatisticalSummary summary = 
				Statistics.colStats(dataVecRdd.rdd());
		
		System.out.println("Mean::" + summary.mean());
		System.out.println("Variance::" + summary.variance());
		double[] var = summary.variance().toArray();
		System.out.println("Std deviations:");
		for(double v : var){
			System.out.println(Math.sqrt(v));
		}
		System.out.println("Std deviations: End");
		System.out.println("Count::" + summary.numNonzeros());
		
		JavaRDD<String> toPrint = dataVecRdd.map(x -> {
			StringBuilder builder = new StringBuilder();
			double[] data = x.toArray();
			for(double y : data){
				if(builder.length() <= 0)
					builder.append(y);
				else
					builder.append(',').append(y);
			}
			return builder.toString();
		});
		
		toPrint = toPrint.zipWithIndex().map(x -> x._2+","+x._1);
		
		toPrint.saveAsTextFile(outputDir);
	}
	

}
