/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.clustering;

import java.util.ArrayList;
import java.util.List;

import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.mllib.clustering.KMeans;
import org.apache.spark.mllib.clustering.KMeansModel;
import org.apache.spark.mllib.linalg.DenseVector;
import org.apache.spark.mllib.linalg.Vector;
import org.apache.spark.mllib.stat.MultivariateStatisticalSummary;
import org.apache.spark.mllib.stat.Statistics;

import scala.Tuple2;

/**
 * 
 * @author vivek
 *
 */
public class CustCatClusterGenerator {

	private int clusterCount;
	private int iterCount;
	
	private String inputFileUri;
	private String outputDir;
	
	public static void main(String[] args) {
		SparkConf conf = new SparkConf().setAppName("Customer Cluster generator");
        conf.setIfMissing("spark.executor.memory", "64g");
        conf.setIfMissing("spark.num.executors", "1");
        // conf.setIfMissing("spark.executor.cores", "7");
        conf.setIfMissing("spark.executor.cores", "15");
        conf.setIfMissing("spark.storage.memoryFraction", "0.1");

        JavaSparkContext sc = new JavaSparkContext(conf);
        int clusterCount = Integer.parseInt(args[0]);
        int iterCount = Integer.parseInt(args[1]);
        String inputFile = args[2];
        String outputDir = args[3];
        
        CustCatClusterGenerator clusterGen = new CustCatClusterGenerator(clusterCount, 
        		iterCount, inputFile, outputDir);
        clusterGen.generateClusters(sc);
	}
	
	public CustCatClusterGenerator(int clusterCount, int iterCount, 
			String fileUri, String outputDir){
		this.clusterCount = clusterCount;
		this.iterCount = iterCount;
		this.inputFileUri = fileUri;
		this.outputDir = outputDir;
	}
	
	public void generateClusters(JavaSparkContext sc){
		JavaRDD<String> fileRdd = sc.textFile(this.inputFileUri);
		
		JavaPairRDD<Long,Vector> dataVecRdd = fileRdd.mapToPair(x ->{
			String[] tokens = x.split(",");
			long id = Long.parseLong(tokens[0]);
			double[] data = new double[tokens.length-1];
			for(int i=1;i<tokens.length;i++){
				data[i-1] = Double.parseDouble(tokens[i]);
			}
			Vector resultVec = new DenseVector(data);
			
			return new Tuple2<>(id,resultVec);
		}).cache();
		
		MultivariateStatisticalSummary summary = 
				Statistics.colStats(dataVecRdd.values().rdd());
		double[] means = summary.mean().toArray();
		double[] variances = summary.variance().toArray();
		double[] sd = new double[variances.length];
		for(int i=0;i<variances.length;i++)
			sd[i] = Math.sqrt(variances[i]);
		
		JavaPairRDD<Long, Vector> scaledData = scaleData(dataVecRdd,
				means, sd);
		
		KMeansModel clusters = KMeans.train(scaledData.values().rdd(), 
				this.clusterCount, this.iterCount);
		KMeansModel clustersB = sc.broadcast(clusters).getValue();
		
		this.printSummary(clusters, scaledData.values(), means, sd,
				sc);
		
		JavaPairRDD<Long, Integer> clusterRdd = scaledData.mapToPair(x -> {
			long id = x._1;
			int clusterId = clustersB.predict(x._2);
			return new Tuple2<>(id, clusterId);
		});
		
		JavaPairRDD<Long, Tuple2<Integer, Vector>> dataClusterIdRdd =  
			clusterRdd.join(dataVecRdd);
		
		JavaRDD<String> toPrint = dataClusterIdRdd.map(x ->{
			StringBuilder builder = new StringBuilder();
			builder.append(x._1.longValue()).append(',').append(x._2._1.intValue());
			double[] data = x._2._2.toArray();
			for(double y : data){
				builder.append(',').append(y);
			}
			
			return builder.toString();
		});
		
		toPrint.saveAsTextFile(outputDir + "/clustered_data");
		
		JavaRDD<String> toPrintClusterIds = dataClusterIdRdd.map(x -> {
			StringBuilder builder = new StringBuilder();
			builder.append(x._1.longValue()).append(',').append(x._2._1.intValue());
			return builder.toString();
		});
		
		toPrintClusterIds.saveAsTextFile(outputDir + "/clusterIds");
	}
	
	private JavaPairRDD<Long, Vector> scaleData(JavaPairRDD<Long,Vector> dataVecRdd, double[] means,
			double[] sd){
		
		JavaPairRDD<Long, Vector> scaledRdd = dataVecRdd.mapToPair(x -> {
			double[] data = x._2.toArray();
			double[] scaled = new double[data.length];
			for(int i=0;i<data.length;i++){
				scaled[i] = (data[i]-means[i])/sd[i];
			}
			
			Vector result = new DenseVector(scaled);
			return new Tuple2<>(x._1,result);
		});
		
		return scaledRdd;
	}
	
	private void printSummary(KMeansModel clusters, JavaRDD<Vector> data,
			double[] means, double[] sd,
			JavaSparkContext sc){
		System.out.println("Cluster centers:");
		for (Vector center: clusters.clusterCenters()) {
		  System.out.println(" " + center);
		}
		double cost = clusters.computeCost(data.rdd());
		System.out.println("Cost: " + cost);

		// Evaluate clustering by computing Within Set Sum of Squared Errors
		double WSSSE = clusters.computeCost(data.rdd());
		System.out.println("Within Set Sum of Squared Errors = " + WSSSE);
		
		// Denormalized/descaled cluster centers
		int clusterId = 0;
		List<String> clusterCenterList = new ArrayList<>();
		for (Vector center: clusters.clusterCenters()) {
			StringBuilder bf = new StringBuilder();
			bf.append(clusterId);
			double[] dataArr = center.toArray();
			System.out.printf("Cluster-center:::");
			for(int i=0;i<dataArr.length;i++){
				double denorm = (dataArr[i]*sd[i]) + means[i];
				System.out.printf("%f\t", denorm );
				bf.append(","+denorm);
			}
			System.out.println();
			clusterCenterList.add(bf.toString());
			clusterId++;
		}
		
		JavaRDD<String> toPrint = 
				sc.parallelize(clusterCenterList);
		toPrint.saveAsTextFile(this.outputDir + "/cluster_centers");
	}

}
