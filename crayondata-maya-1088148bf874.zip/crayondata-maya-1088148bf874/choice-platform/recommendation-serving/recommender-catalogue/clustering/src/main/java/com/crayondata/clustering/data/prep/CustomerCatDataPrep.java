/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.clustering.data.prep;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;

import scala.Tuple2;

/**
 * 
 * @author vivek
 *
 */
public class CustomerCatDataPrep {
	
	private String inputFileUri;
	private String outputDirUri;

	public static void main(String[] args) {
		SparkConf conf = new SparkConf().setAppName("Customer Cluster data prep");
        conf.setIfMissing("spark.executor.memory", "64g");
        conf.setIfMissing("spark.num.executors", "1");
        // conf.setIfMissing("spark.executor.cores", "7");
        conf.setIfMissing("spark.executor.cores", "15");
        conf.setIfMissing("spark.storage.memoryFraction", "0.1");

        JavaSparkContext sc = new JavaSparkContext(conf);

        if(args.length < 2){
        	System.err.println("Usage :: CustomerCatDataPrep <input-file-uri> <output-dir-uri> ");
        	return;
        }
        
        CustomerCatDataPrep dataPrep = new CustomerCatDataPrep(args[0], args[1]);
        dataPrep.prepareData(sc);
	}
	
	public CustomerCatDataPrep(String inputFileUri, String outputDirUri){
		this.inputFileUri = inputFileUri;
		this.outputDirUri = outputDirUri;
	}
	
	/**
	 * Input file format,
	 * 	customer_id,mcc_code,tran_amount,tran_count
	 * @param sc
	 */
	public void prepareData(JavaSparkContext sc){
		JavaRDD<String> textRdd = sc.textFile(inputFileUri).cache();
		JavaRDD<Integer> mccCodes = textRdd.map(x -> {
			String[] tokens = x.split(",");
			int mccCode = Integer.parseInt(tokens[1]);
			return mccCode;
		}).cache();
		List<Integer> allMccCodes = mccCodes.distinct().collect();
		final List<Integer> allMccCodesB = sc.broadcast(allMccCodes).value();

		JavaPairRDD<Integer, Tuple2<Integer, Double>> tranData = 
				textRdd.mapToPair(x -> {
					String[] tokens = x.split(",");
					int custId = Integer.parseInt(tokens[0]);
					int mccCode = Integer.parseInt(tokens[1]);
					double tranAmount = Double.parseDouble(tokens[2]);

					return new Tuple2<>(custId, new Tuple2<>(mccCode, tranAmount));
				});
		
		JavaPairRDD<Integer, Iterable<Tuple2<Integer, Double>>> userGrouped = 
			tranData.groupByKey();
		
		JavaPairRDD<Integer, Map<Integer, Double>> userMccTrans = 
				userGrouped.mapToPair(x -> {
					Map<Integer, Double> mccMap = new HashMap<>();

					for(Tuple2<Integer, Double> pair : x._2){
						mccMap.put(pair._1, pair._2);
					}

					/*for(int mccCode : allMccCodesB){
						mccMap.putIfAbsent(mccCode, 0.0);
					}*/

					return new Tuple2<>(x._1, mccMap);
				});
		
		JavaRDD<String> toPrint = userMccTrans.map(x -> {
			int custId = x._1;
			StringBuilder sb = new StringBuilder();
			sb.append(custId);
			for(int mccCode : allMccCodesB){
				double tranSum = 0.0;
				if(x._2.containsKey(mccCode))
					tranSum = x._2.get(mccCode);
				sb.append(","+ tranSum);
			}
			
			return sb.toString();
		});
		
		toPrint.saveAsTextFile(outputDirUri);

		StringBuilder sb = new StringBuilder();
		sb.append("customerId");
		for(int mccCode : allMccCodes){
			sb.append(","+mccCode);
		}
		
		List<String> headers = new ArrayList<>();
		headers.add(sb.toString());
		JavaRDD<String> headerRdd = sc.parallelize(headers);
		headerRdd.saveAsTextFile(outputDirUri+"/header");
		
		/*PrintWriter headerOut = null;
		try {
			headerOut = new PrintWriter(new FileOutputStream(outputDirUri+"/header.txt"));
			headerOut.println(sb.toString());
		} catch (FileNotFoundException e) {
			System.out.println("Header print failed...");
			e.printStackTrace();
		}finally {
			headerOut.close();
		}*/
	}

}
