/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayothon.webserver;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

import java.util.Collection;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.crayothon.DAO.RestaurantDAO;
import com.crayothon.DAO.UserProfileDAO;
import com.crayothon.DAO.UserProfileOutputFormat;
import com.crayothon.DAO.UserSimilarityDAO;
import com.crayothon.datamodel.Restaurant;
import com.crayothon.datamodel.UserProfileSummary;
import com.crayothon.datamodel.UserSimilarity;

@Api
@RestController
public class ApiController {
	
	@Autowired
	UserProfileDAO userProfileDAO;
	
	@Autowired
	UserSimilarityDAO userSimilarityDAO;
	
	@Autowired
	RestaurantDAO restaurantDAO;

	@ApiOperation(value = "getUserProfile", nickname = "getUserProfile")
	@ApiImplicitParams({ @ApiImplicitParam(name = "UserId", value = "", required = true, dataType = "string", paramType = "query", defaultValue = "") })
	@RequestMapping(value = "/crayothon/getUserProfile", method = RequestMethod.GET)
	public @ResponseBody UserProfileOutputFormat getUserProfile(@RequestParam("UserId")	String userId)
	{
		return userProfileDAO.findUserProfileById(userId);
	}
	
	@ApiOperation(value = "getAllUsers", nickname = "getAllUsers")
	@RequestMapping(value = "/crayothon/getAllUsers", method = RequestMethod.GET)
	public @ResponseBody List<UserProfileOutputFormat> getAllUsers()
	{
		return userProfileDAO.findAllUserProfiles();
	}
	
	@ApiOperation(value = "getAllUserIds", nickname = "getAllUserIds")
	@RequestMapping(value = "/crayothon/getAllUserIds", method = RequestMethod.GET)
	public @ResponseBody List<Integer> getAllUserIds()
	{
		return userProfileDAO.findAllUserProfileIds();
	}
	
	@ApiOperation(value = "getAllUserSummaries", nickname = "getAllUserSummaries")
	@RequestMapping(value = "/crayothon/getAllUserSummaries", method = RequestMethod.GET)
	public @ResponseBody List<UserProfileSummary> getAllUserSummaries()
	{
		return userProfileDAO.findAllUserProfileSummaries();
	}
	
	@ApiOperation(value = "getLikedRestaurants", nickname = "getLikedRestaurants")
	@ApiImplicitParams({ @ApiImplicitParam(name = "UserId", value = "", required = true, dataType = "string", paramType = "query", defaultValue = "") })
	@RequestMapping(value = "/crayothon/getLikedRestaurants", method = RequestMethod.GET)
	public @ResponseBody List<Restaurant> getLikedRestaurants(@RequestParam("UserId")	String userId)
	{
		return userProfileDAO.findLikedRestaurantsById(userId);
	}
	
	@ApiOperation(value = "getRecommendedRestaurants", nickname = "getRecommendedRestaurants")
	@ApiImplicitParams({ @ApiImplicitParam(name = "UserId", value = "", required = true, dataType = "string", paramType = "query", defaultValue = "") })
	@RequestMapping(value = "/crayothon/getRecommendedRestaurants", method = RequestMethod.GET)
	public @ResponseBody Collection<Restaurant> getRecommendedRestaurants(@RequestParam("UserId")	String userId)
	{
		return userSimilarityDAO.findRecommendedRestaurants(userId);
	}
	
/*	@ApiOperation(value = "getSimilarUsers", nickname = "getSimilarUsers")
	@ApiImplicitParams({ @ApiImplicitParam(name = "UserId", value = "", required = true, dataType = "string", paramType = "query", defaultValue = "") })
	@RequestMapping(value = "/crayothon/getSimilarUsers", method = RequestMethod.GET)
	public @ResponseBody List<UserProfile> getSimilarUsers(@RequestParam("UserId")	String userId)
	{
		return apiService.getSimilarUsers(userId);
	}
*/	
	@ApiOperation(value = "getSimilarUserIds", nickname = "getSimilarUserIds")
	@ApiImplicitParams({ @ApiImplicitParam(name = "UserId", value = "", required = true, dataType = "string", paramType = "query", defaultValue = "") })
	@RequestMapping(value = "/crayothon/getSimilarUserIds", method = RequestMethod.GET)
	public @ResponseBody List<String> getSimilarUserIds(@RequestParam("UserId")	String userId)
	{
		return userSimilarityDAO.findSimilarUserIds(userId);
	}
	
	@ApiOperation(value = "getSimilarUsers", nickname = "getSimilarUsers")
	@ApiImplicitParams({ @ApiImplicitParam(name = "UserId", value = "", required = true, dataType = "string", paramType = "query", defaultValue = "") })
	@RequestMapping(value = "/crayothon/getSimilarUsers", method = RequestMethod.GET)
	public @ResponseBody List<UserSimilarity> getSimilarUsers(@RequestParam("UserId")	String userId)
	{
		return userSimilarityDAO.findSimilarUsers(userId);
	}
	
	@ApiOperation(value = "getRestaurentDetails", nickname = "getRestaurentDetails")
	@ApiImplicitParams({ @ApiImplicitParam(name = "restaurantId", value = "", required = true, dataType = "int", paramType = "query", defaultValue = "") })
	@RequestMapping(value = "/crayothon/getRestaurentDetails", method = RequestMethod.GET)
	public @ResponseBody Restaurant getRestaurantDetails(@RequestParam("restaurantId")	Integer restaurantId)
	{
			return restaurantDAO.findRestaurantsbyId(restaurantId);
	}
}
