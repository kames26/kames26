/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayothon.DAO;

import java.io.IOException;
import java.util.List;

import org.apache.solr.client.solrj.SolrQuery;
import org.apache.solr.client.solrj.SolrServerException;
import org.apache.solr.client.solrj.response.QueryResponse;

import com.crayondata.service.SolrService;
import com.crayothon.datamodel.Restaurant;
import com.google.common.base.Joiner;
import com.typesafe.config.Config;
import com.typesafe.config.ConfigFactory;

public class RestaurantDAO extends SolrService{
	Config conf;
	
	private Joiner joiner = Joiner.on(' ');
	
	public RestaurantDAO() {
		conf = ConfigFactory.load();
		this.setSolrClient(conf.getString("solr.host"),conf.getString("solr.restaurantCore"));
	}
	
	public Restaurant findRestaurantsbyId(Integer id)
	{
		SolrQuery query = new SolrQuery();
		String queryString = "id:" + id.toString(); 
		query.setQuery(queryString);
		QueryResponse response = null;

		try {
			response = solrClient.query(query);
		} catch (SolrServerException | IOException e) {
			e.printStackTrace();
		}

		List<Restaurant> restaurants = response.getBeans(Restaurant.class);
		
		if(restaurants.size() == 0){
			return null;
		}
		return restaurants.get(0);	
	}
	
	public List<Restaurant> findAllRestaurantsbyId(List<Integer> ids)
	{
		SolrQuery query = new SolrQuery();
		String queryString = "id:(" + joiner.join(ids) + ")";
		query.setQuery(queryString);
		QueryResponse response = null;

		try {
			response = solrClient.query(query);
		} catch (SolrServerException | IOException e) {
			e.printStackTrace();
		}

		List<Restaurant> restaurants = response.getBeans(Restaurant.class);
		
		return restaurants;	
	}
	
}
