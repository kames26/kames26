/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayothon.datamodel;

import java.io.Serializable;
import java.util.Collection;

import org.apache.solr.client.solrj.beans.Field;

public class UserProfile implements Serializable {
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	@Field("id")
	private int id;
	@Field("UserId")
	String userId;
	@Field("Items")
	Collection<Integer> items; // IDs of the restaurants user rated
	@Field("CuisineAndScore")
	Collection<String> cuisineAndScoreMap; // cuisines and scores
	
	@Field("OptionAndScore")
	Collection<String> optionsAndScoreMap; // cuisines and scores
	
	@Field("PriceRange")
	private double priceRange;
	
	@Field("AmbienceRating")
	private double ambienceRating;
	
	@Field("FoodRating")
	private double foodRating;
	
	@Field("ServiceRating")
	private double serviceRating;
	
	@Field("ValueRating")
	private double valueRating;
	
	@Field("AggregatedRating")
	private double aggregatedRating;
	
	@Field("CuisinePerc")
	private float cuisinePerc;
	
	@Field("OptionPerc")
	private float optionPerc;
	
	@Field("LikedItemPerc")
	private float likedItemPerc;
	
	public UserProfile(){
		
	}
	
	public UserProfile(String userId, Collection<Integer> items) {
		super();
		this.userId = userId;
		this.items = items;
	}

	public Collection<String> getCuisineAndScoreMap() {
		return cuisineAndScoreMap;
	}

	public void setCuisineAndScoreMap(Collection<String> cuisineAndScoreMap) {
		this.cuisineAndScoreMap = cuisineAndScoreMap;
	}

	public Collection<String> getOptionsAndScoreMap() {
		return optionsAndScoreMap;
	}

	public void setOptionsAndScoreMap(Collection<String> optionsAndScoreMap) {
		this.optionsAndScoreMap = optionsAndScoreMap;
	}

	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public Collection<Integer> getItems() {
		return items;
	}
	public void setItems(Collection<Integer> items) {
		this.items = items;
	}
	
	public double getPriceRange() {
		return priceRange;
	}

	public void setPriceRange(double priceRange) {
		this.priceRange = priceRange;
	}

	public double getAmbienceRating() {
		return ambienceRating;
	}

	public void setAmbienceRating(double ambienceRating) {
		this.ambienceRating = ambienceRating;
	}

	public double getFoodRating() {
		return foodRating;
	}

	public void setFoodRating(double foodRating) {
		this.foodRating = foodRating;
	}

	public double getServiceRating() {
		return serviceRating;
	}

	public void setServiceRating(double serviceRating) {
		this.serviceRating = serviceRating;
	}

	public double getValueRating() {
		return valueRating;
	}

	public void setValueRating(double valueRating) {
		this.valueRating = valueRating;
	}

	public double getAggregatedRating() {
		return aggregatedRating;
	}

	public void setAggregatedRating(double aggregatedRating) {
		this.aggregatedRating = aggregatedRating;
	}

	public float getCuisinePerc() {
		return cuisinePerc;
	}

	public void setCuisinePerc(float cuisinePerc) {
		this.cuisinePerc = cuisinePerc;
	}

	public float getOptionPerc() {
		return optionPerc;
	}

	public void setOptionPerc(float optionPerc) {
		this.optionPerc = optionPerc;
	}

	public float getLikedItemPerc() {
		return likedItemPerc;
	}

	public void setLikedItemPerc(float likedItemPerc) {
		this.likedItemPerc = likedItemPerc;
	}
	
	
}