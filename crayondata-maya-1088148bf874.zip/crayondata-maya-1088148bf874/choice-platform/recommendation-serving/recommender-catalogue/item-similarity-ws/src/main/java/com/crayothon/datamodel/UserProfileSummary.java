/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayothon.datamodel;

import org.apache.solr.client.solrj.beans.Field;

public class UserProfileSummary {

	@Field("id")
	private int id;
	@Field("UserId")
	String userId;
	
	@Field("CuisinePerc")
	private float cuisinePerc;
	
	@Field("OptionPerc")
	private float optionPerc;
	
	@Field("LikedItemPerc")
	private float likedItemPerc;
	
	public UserProfileSummary() {
		super();
	}

	public UserProfileSummary(int id, String userId, float cuisinePerc,
			float optionPerc, float likedItemPerc) {
		super();
		this.id = id;
		this.userId = userId;
		this.cuisinePerc = cuisinePerc;
		this.optionPerc = optionPerc;
		this.likedItemPerc = likedItemPerc;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public float getCuisinePerc() {
		return cuisinePerc;
	}

	public void setCuisinePerc(float cuisinePerc) {
		this.cuisinePerc = cuisinePerc;
	}

	public float getOptionPerc() {
		return optionPerc;
	}

	public void setOptionPerc(float optionPerc) {
		this.optionPerc = optionPerc;
	}

	public float getLikedItemPerc() {
		return likedItemPerc;
	}

	public void setLikedItemPerc(float likedItemPerc) {
		this.likedItemPerc = likedItemPerc;
	}
	
	
}
