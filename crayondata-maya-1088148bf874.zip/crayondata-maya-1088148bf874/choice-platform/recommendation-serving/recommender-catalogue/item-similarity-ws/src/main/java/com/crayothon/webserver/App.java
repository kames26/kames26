/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayothon.webserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;

import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;
import static springfox.documentation.builders.PathSelectors.regex;

@SpringBootApplication
@EnableSwagger2
@ComponentScan("com.crayothon")
public class App {

	public static void main(String a[]) {
		ApplicationContext ctx = SpringApplication.run(App.class, a);
	}

	@Bean
	public Docket newsApi() {
		return new Docket(DocumentationType.SWAGGER_2).groupName("Crayothon")
				.apiInfo(apiInfo()).select().paths(regex("/crayothon.*"))
				.build();
	}
;
	private ApiInfo apiInfo() {
		return new ApiInfoBuilder()
				.title("Crayothon")
				.description("Crayothon")
				.termsOfServiceUrl(
						"http://www-03.ibm.com/software/sla/sladb.nsf/sla/bm?Open")
				.contact("CrayonData")
				.license("Apache License Version 2.0")
				.licenseUrl(
						"https://github.com/IBM-Bluemix/news-aggregator/blob/master/LICENSE")
				.version("2.0").build();
	}
}
