/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayothon.datamodel;

import java.io.Serializable;

import org.apache.solr.client.solrj.beans.Field;

public class UserSimilarity implements Serializable{
	
	@Field("id")
	String id;
	@Field("userFrom")
	String userFrom;
	@Field("userTo")
	String userTo;
	@Field("similarityValue")
	Float similarityValue;
	@Field("correlationValue")
	Float correlationValue;
	
	public UserSimilarity(){
		
	}
	public UserSimilarity(String userFrom, String userTo,
			Float similarityValue, Float correlationValue) {
		super();
		this.userFrom = userFrom;
		this.userTo = userTo;
		this.similarityValue = similarityValue;
		this.correlationValue = correlationValue;
	}

	public String getUserFrom() {
		return userFrom;
	}

	public void setUserFrom(String userFrom) {
		this.userFrom = userFrom;
	}
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getUserTo() {
		return userTo;
	}

	public void setUserTo(String userTo) {
		this.userTo = userTo;
	}

	public Float getSimilarityValue() {
		return similarityValue;
	}

	public void setSimilarityValue(Float similarityValue) {
		this.similarityValue = similarityValue;
	}

	public Float getCorrelationValue() {
		return correlationValue;
	}

	public void setCorrelationValue(Float correlationValue) {
		this.correlationValue = correlationValue;
	}

}
