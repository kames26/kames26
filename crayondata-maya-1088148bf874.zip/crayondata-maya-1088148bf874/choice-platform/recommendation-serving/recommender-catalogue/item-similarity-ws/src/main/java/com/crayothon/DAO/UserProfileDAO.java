/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayothon.DAO;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.solr.client.solrj.SolrQuery;
import org.apache.solr.client.solrj.SolrServerException;
import org.apache.solr.client.solrj.response.QueryResponse;

import com.crayondata.service.SolrService;
import com.crayothon.datamodel.Restaurant;
import com.crayothon.datamodel.UserProfile;
import com.crayothon.datamodel.UserProfileSummary;
import com.typesafe.config.Config;
import com.typesafe.config.ConfigFactory;

public class UserProfileDAO extends SolrService{
	
	
	Config conf;
	
	RestaurantDAO restDAO;
	
	public UserProfileDAO() {
		conf = ConfigFactory.load();
		this.setSolrClient(conf.getString("solr.host"),conf.getString("solr.userProfileCore"));
		this.restDAO = new RestaurantDAO();
	}
	
	public UserProfileOutputFormat findUserProfileById(String userId) {
		
		SolrQuery query = new SolrQuery();
		String queryString = "id:" + userId; 
		query.setQuery(queryString);
		QueryResponse response = null;

		try {
			response = solrClient.query(query);
		} catch (SolrServerException | IOException e) {
			e.printStackTrace();
		}

		List<UserProfile> userProfiles = response.getBeans(UserProfile.class);
		
		if(userProfiles.size() == 0)
			return null;
		
		UserProfileOutputFormat upof = new UserProfileOutputFormat();
		upof.getUserProfileOutputFormat(userProfiles.get(0));
		
		return upof;
	}

	public List<UserProfileOutputFormat> findAllUserProfiles() {
		
		SolrQuery query = new SolrQuery();
		String queryString = "*:*";
		query.set("rows", 100);
		query.setQuery(queryString);
		QueryResponse response = null;

		try {
			response = solrClient.query(query);
		} catch (SolrServerException | IOException e) {
			e.printStackTrace();
		}

		List<UserProfile> userProfiles = response.getBeans(UserProfile.class);
		
		List<UserProfileOutputFormat> upofs = new ArrayList<UserProfileOutputFormat>();
		
		for(UserProfile up : userProfiles)
		{
			UserProfileOutputFormat upof = new UserProfileOutputFormat();
			upof.getUserProfileOutputFormat(up);
			upofs.add(upof);
		}
		if(userProfiles.size() == 0)
			return null;
		
		return upofs;
	}

	public List<Integer> findAllUserProfileIds() {
		
		SolrQuery query = new SolrQuery();
		String queryString = "*:*";
		query.set("rows", 100);
		query.setQuery(queryString);
		QueryResponse response = null;

		try {
			response = solrClient.query(query);
		} catch (SolrServerException | IOException e) {
			e.printStackTrace();
		}

		List<UserProfile> userProfiles = response.getBeans(UserProfile.class);
		List<Integer> userIds = new ArrayList<Integer>();
		
		for(UserProfile userProfile : userProfiles)
		{
			userIds.add(userProfile.getId());
		}
		
		if(userIds.size() == 0)
			return null;
		
		return userIds;
	}
	
	public List<UserProfileSummary> findAllUserProfileSummaries() {
		
		SolrQuery query = new SolrQuery();
		String queryString = "*:*";
		query.set("rows", 100);
		query.setQuery(queryString);
		QueryResponse response = null;

		try {
			response = solrClient.query(query);
		} catch (SolrServerException | IOException e) {
			e.printStackTrace();
		}

		List<UserProfile> userProfiles = response.getBeans(UserProfile.class);
		List<UserProfileSummary> summaries = new ArrayList<>();
		
		for(UserProfile userProfile : userProfiles)
		{
			summaries.add(new UserProfileSummary(userProfile.getId(),
					userProfile.getUserId(),
					userProfile.getCuisinePerc(),
					userProfile.getOptionPerc(),
					userProfile.getLikedItemPerc()));
		}
		
		if(summaries.size() == 0)
			return null;
		
		return summaries;
	}
	
	public List<Restaurant> findLikedRestaurantsById(String userId)
	{
		SolrQuery query = new SolrQuery();
		String queryString = "id:" + userId;
		query.set("rows", 100);
		query.set("fl", "Items");
		query.setQuery(queryString);
		QueryResponse response = null;

		try {
			response = solrClient.query(query);
		} catch (SolrServerException | IOException e) {
			e.printStackTrace();
		}

		List<UserProfile> userProfiles = response.getBeans(UserProfile.class);
		if(userProfiles.size() == 0)
			return null;
		
		List<Integer> likedItemIds = (List<Integer>) userProfiles.get(0).getItems();
		List<Restaurant> likedRestaurants = this.restDAO.findAllRestaurantsbyId(likedItemIds);
		
		return likedRestaurants;
	}
}