/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayothon.datamodel;

import java.util.Collection;

import org.apache.solr.client.solrj.beans.Field;

public class Restaurant {
	@Field("id")
	Integer id;
	@Field("cuisine")
	Collection<String> cuisines;
	@Field("options")
	Collection<String> options;
	@Field("price")
	String priceRange;
	@Field("ambiencerating")
	int ambienceRating;
	@Field("foodrating")
	int foodRating;
	@Field("servicerating")
	int serviceRating;
	@Field("valuerating")
	int valueRating;
	@Field("aggregaterating")
	int aggregateRating;
	
	@Field("name")
	String name;
	
	@Field("description")
	String description;
	
	@Field("addresscountry")
	String addresscountry;
	
	@Field("geo")
	String geo;
	
	@Field("image")
	String image;
	
	
	public Restaurant(){
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Restaurant other = (Restaurant) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}



	public Restaurant(Integer id, Collection<String> cuisines,
			Collection<String> options, String priceRange,
			int ambienceRating, int foodRating, int serviceRating,
			int valueRating, int aggregateRating) {
		super();
		this.id = id;
		this.cuisines = cuisines;
		this.options = options;
		this.priceRange = priceRange;
		this.ambienceRating = ambienceRating;
		this.foodRating = foodRating;
		this.serviceRating = serviceRating;
		this.valueRating = valueRating;
		this.aggregateRating = aggregateRating;
	}
	public Integer getRestaurantId() {
		return id;
	}
	public void setRestaurantId(Integer restaurantId) {
		this.id = restaurantId;
	}
	public Collection<String> getCuisines() {
		return cuisines;
	}
	public void setCuisines(Collection<String> cuisines) {
		this.cuisines = cuisines;
	}
	public Collection<String> getOptions() {
		return options;
	}
	public void setOptions(Collection<String> options) {
		this.options = options;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getPriceRange() {
		return priceRange;
	}
	public void setPriceRange(String priceRange) {
		this.priceRange = priceRange;
	}
	public int getAmbienceRating() {
		return ambienceRating;
	}
	public void setAmbienceRating(int ambienceRating) {
		this.ambienceRating = ambienceRating;
	}
	public int getFoodRating() {
		return foodRating;
	}
	public void setFoodRating(int foodRating) {
		this.foodRating = foodRating;
	}
	public int getServiceRating() {
		return serviceRating;
	}
	public void setServiceRating(int serviceRating) {
		this.serviceRating = serviceRating;
	}
	public int getValueRating() {
		return valueRating;
	}
	public void setValueRating(int valueRating) {
		this.valueRating = valueRating;
	}
	public int getAggregateRating() {
		return aggregateRating;
	}
	public void setAggregateRating(int aggregateRating) {
		this.aggregateRating = aggregateRating;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getAddresscountry() {
		return addresscountry;
	}

	public void setAddresscountry(String addresscountry) {
		this.addresscountry = addresscountry;
	}

	public String getGeo() {
		return geo;
	}

	public void setGeo(String geo) {
		this.geo = geo;
	}

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}
}
