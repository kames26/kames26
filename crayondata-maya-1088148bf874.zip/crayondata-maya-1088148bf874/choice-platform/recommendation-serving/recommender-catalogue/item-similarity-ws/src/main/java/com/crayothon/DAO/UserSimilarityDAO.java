/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayothon.DAO;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.solr.client.solrj.SolrQuery;
import org.apache.solr.client.solrj.SolrServerException;
import org.apache.solr.client.solrj.response.QueryResponse;
import org.springframework.beans.factory.annotation.Autowired;

import com.crayondata.service.SolrService;
import com.crayothon.datamodel.Restaurant;
import com.crayothon.datamodel.UserProfile;
import com.crayothon.datamodel.UserSimilarity;
import com.typesafe.config.Config;
import com.typesafe.config.ConfigFactory;

public class UserSimilarityDAO extends SolrService{
	Config conf;
	
	@Autowired
	UserProfileDAO userProfileDAO;
	
	public UserSimilarityDAO() {
		conf = ConfigFactory.load();
		this.setSolrClient(conf.getString("solr.host"),conf.getString("solr.userSimilarityCore"));
	}
	
	public List<String> findSimilarUserIds(String userId) {
		SolrQuery query = new SolrQuery();
		String queryString = "userFrom:" + userId; 
		query.set("sort", "similarityValue desc");
		query.setQuery(queryString);
		QueryResponse response = null;

		try {
			response = solrClient.query(query);
		} catch (SolrServerException | IOException e) {
			e.printStackTrace();
		}

		List<UserSimilarity> userSimilarity = response.getBeans(UserSimilarity.class);
		if(userSimilarity.size() == 0)
			return null;
		
		List<String> userIds = new ArrayList<String>();
		
		for(UserSimilarity user : userSimilarity)
		{
			userIds.add(user.getUserTo());
		}
		
		if(userIds.size() == 0)
			return null;
		
		return userIds;
	}
	
	public List<UserSimilarity> findSimilarUsers(String userId) {
		SolrQuery query = new SolrQuery();
		String queryString = "userFrom:" + userId;
		query.set("sort", "similarityValue desc");
		query.setQuery(queryString);
		QueryResponse response = null;

		try {
			response = solrClient.query(query);
		} catch (SolrServerException | IOException e) {
			e.printStackTrace();
		}

		List<UserSimilarity> userSimilarity = response.getBeans(UserSimilarity.class);
		if(userSimilarity.size() == 0)
			return null;
		
		return userSimilarity;
	}
	
	
	//like by similar users
	public Collection<Restaurant> findRecommendedRestaurants(String userId)
		{
		
			List<String> similarUsers = findSimilarUserIds(userId);
			Set<Restaurant> likedRestaurantsBySimilarUsers = new HashSet<Restaurant>(); 
			
			List<Restaurant> likedRestaurantsByUser = userProfileDAO.findLikedRestaurantsById(userId);
			
			for(String similarUser : similarUsers)
			{
				likedRestaurantsBySimilarUsers.addAll(userProfileDAO.findLikedRestaurantsById(similarUser));
			}
			
			likedRestaurantsBySimilarUsers.removeAll(likedRestaurantsByUser);
			
			return likedRestaurantsBySimilarUsers;
		}
}
