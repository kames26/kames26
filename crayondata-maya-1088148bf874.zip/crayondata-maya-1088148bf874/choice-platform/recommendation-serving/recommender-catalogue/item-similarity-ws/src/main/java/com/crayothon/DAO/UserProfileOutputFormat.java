/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayothon.DAO;

import java.io.Serializable;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Pattern;

import com.crayothon.datamodel.UserProfile;

public class UserProfileOutputFormat implements Serializable {
	
	private int id;
	String userId;
	Collection<Integer> items; // IDs of the restaurants user rated
	Map<String,Float> cuisineAndScoreMap; // cuisines and scores
	Map<String,Float> optionsAndScoreMap; // cuisines and scores
	private double priceRange;
	private double ambienceRating;
	private double foodRating;
	private double serviceRating;
	private double valueRating;
	private double aggregatedRating;
	
	public String getUserId() {
		return userId;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public Collection<Integer> getItems() {
		return items;
	}
	public void setItems(Collection<Integer> items) {
		this.items = items;
	}
	
	public double getPriceRange() {
		return priceRange;
	}

	public Map<String, Float> getCuisineAndScoreMap() {
		return cuisineAndScoreMap;
	}
	public void setCuisineAndScoreMap(Map<String, Float> cuisineAndScoreMap) {
		this.cuisineAndScoreMap = cuisineAndScoreMap;
	}
	public Map<String, Float> getOptionsAndScoreMap() {
		return optionsAndScoreMap;
	}
	public void setOptionsAndScoreMap(Map<String, Float> optionsAndScoreMap) {
		this.optionsAndScoreMap = optionsAndScoreMap;
	}
	public void setPriceRange(double priceRange) {
		this.priceRange = priceRange;
	}

	public double getAmbienceRating() {
		return ambienceRating;
	}

	public void setAmbienceRating(double ambienceRating) {
		this.ambienceRating = ambienceRating;
	}

	public double getFoodRating() {
		return foodRating;
	}

	public void setFoodRating(double foodRating) {
		this.foodRating = foodRating;
	}

	public double getServiceRating() {
		return serviceRating;
	}

	public void setServiceRating(double serviceRating) {
		this.serviceRating = serviceRating;
	}

	public double getValueRating() {
		return valueRating;
	}

	public void setValueRating(double valueRating) {
		this.valueRating = valueRating;
	}

	public double getAggregatedRating() {
		return aggregatedRating;
	}

	public void setAggregatedRating(double aggregatedRating) {
		this.aggregatedRating = aggregatedRating;
	}
	
	public UserProfileOutputFormat getUserProfileOutputFormat(UserProfile userProfile)
	{
		/*Map<String,Float> cuisineAndScoreMap; // cuisines and scores
		Map<String,Float> optionsAndScoreMap; // cuisines and scores
*/		
		this.setId(userProfile.getId());
		this.setUserId(userProfile.getUserId());
		this.setItems(userProfile.getItems());
		this.setPriceRange(userProfile.getPriceRange());
		this.setAmbienceRating(userProfile.getAmbienceRating());
		this.setFoodRating(userProfile.getFoodRating());
		this.setServiceRating(userProfile.getServiceRating());
		this.setValueRating(userProfile.getValueRating());
		this.setAggregatedRating(userProfile.getAggregatedRating());
		
		Collection<String> cuisineAndScore = userProfile.getCuisineAndScoreMap();
		cuisineAndScoreMap = new HashMap<String,Float>();
		
		for(String str : cuisineAndScore ){
			String[] tokens = str.split(Pattern.quote("|"));
			cuisineAndScoreMap.put(tokens[0], Float.parseFloat(tokens[1]));
		}
		
		
		Collection<String>  optionsAndScore = userProfile.getOptionsAndScoreMap();
		optionsAndScoreMap = new HashMap<String,Float>();
		for(String str : optionsAndScore ){
			String[] tokens = str.split(Pattern.quote("|"));
			optionsAndScoreMap.put(tokens[0], Float.parseFloat(tokens[1]));
		}
		
		return this;
	}
}