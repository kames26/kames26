
<?php
/**
 *
 * @Project   Crayothon
 * @Company   Crayon
 * @author    Meeran ( UI Devloper)
 */
 
 
$ngr = 1;
$countmr = $ngr + 1;

$sg = $_GET['userid'];
$json=file_get_contents("http://taste-match.buildmaya.com:8080/crayothon/getUserProfile?UserId=$sg");
$data =  json_decode($json);


$sjson=file_get_contents("http://taste-match.buildmaya.com:8080/crayothon/getSimilarUsers?UserId=$sg");
$simg =  json_decode($sjson);


$likejson=file_get_contents("http://taste-match.buildmaya.com:8080/crayothon/getRecommendedRestaurants?UserId=$sg");
$likeimg =  json_decode($likejson);




					
				$array = json_decode(json_encode($simg), true);
				
				$arrlength = count($array);				
				for($x = 0; $x < $arrlength; $x++) {
					$wtf = $array[$x]['userTo'];
$trj=file_get_contents("http://taste-match.buildmaya.com:8080/crayothon/getUserProfile?UserId=$wtf");
$trt =  json_decode($trj);	
				}	
			

/*
echo '<pre>';
print_r($data);
echo '</pre>';
*/
?>

<?php							
$array = json_decode(json_encode($data), true);
//echo $array['0']['userId'];

$range = $array['cuisineAndScoreMap'];
$range_keys = array_keys($range);
$range_values = array_values($range);

$test = '';

for($i=0;$i<=(count($range_keys)-1);$i++)
{
	$test.='{
	"label": "'.$range_keys[$i].'",
	"value": "'.$range_values[$i].'"
	}, ';
}


/* Options */
$optionsg = $array['optionsAndScoreMap'];
$optionsg_keys = array_keys($optionsg);
$optionsg_values = array_values($optionsg);

$opt = '';
for($i=0;$i<=(count($optionsg_keys)-1);$i++)
{
	$opt.='{
	"label": "'.$optionsg_keys[$i].'",
	"value": "'.$optionsg_values[$i].'"
	}, ';
}
/* Options */

/* Ratings */
$priceRange = round($array['priceRange']);
$ambienceRating = round($array['ambienceRating']);
$foodRating = round($array['foodRating']);
$serviceRating = round($array['serviceRating']);
$valueRating = round($array['valueRating']);
$aggregatedRating = round($array['aggregatedRating']);
/* Ratings */

/* ######################################v############################################################## */

/*Similar User */
$simarray = json_decode(json_encode($trt), true);
//echo $simarray['0']['userId'];

$simrange = $simarray['cuisineAndScoreMap'];
$simrange_keys = array_keys($simrange);
$simrange_values = array_values($simrange);

$simtest = '';

for($i=0;$i<=(count($simrange_keys)-1);$i++)
{
	$simtest.='{
	"label": "'.$simrange_keys[$i].'",
	"value": "'.$simrange_values[$i].'"
	}, ';
}


/* Options */
$simoptionsg = $array['optionsAndScoreMap'];
$simoptionsg_keys = array_keys($simoptionsg);
$simoptionsg_values = array_values($simoptionsg);

$simopt = '';
for($i=0;$i<=(count($simoptionsg_keys)-1);$i++)
{
	$simopt.='{
	"label": "'.$simoptionsg_keys[$i].'",
	"value": "'.$simoptionsg_values[$i].'"
	}, ';
}
/* Options */

/* Ratings */
$simpriceRange = round($array['priceRange']);
$simambienceRating = round($array['ambienceRating']);
$simfoodRating = round($array['foodRating']);
$simserviceRating = round($array['serviceRating']);
$simvalueRating = round($array['valueRating']);
$simaggregatedRating = round($array['aggregatedRating']);
/* Ratings */
/*Similar User*/





?>




<?php							
	$array = json_decode(json_encode($simg), true);
	//echo'DD'. $array['0']['userTo'];
	$arrlength = count($array);
	
	$c1='';
 
   
	for($x = 0; $x < $arrlength; $x++) 
	 {
		$c1.='var revenueChart = new FusionCharts({
			type: "doughnut3d",
        renderAt: "chat1-'. $array[$x]['userTo'].'",
        width: "500",
        height: "400",
        dataFormat: "json",
        dataSource: {
            "chart": {
                "caption": "Cuisines",
                "paletteColors": "#0075c2,#1aaf5d,#f2c500,#f45b00,#8e0000",
                "bgColor": "#ffffff",
                "showBorder": "0",
                "use3DLighting": "0",
                "showShadow": "0",
                "enableSmartLabels": "0",
                "startingAngle": "310",
                "showLabels": "0",
                "showPercentValues": "1",
                "showLegend": "1",
                "legendShadow": "0",
                "legendBorderAlpha": "0",                                
                "decimals": "0",
                "captionFontSize": "14",
                "subcaptionFontSize": "14",
                "subcaptionFontBold": "0",
                "toolTipColor": "#ffffff",
                "toolTipBorderThickness": "0",
                "toolTipBgColor": "#000000",
                "toolTipBgAlpha": "80",
                "toolTipBorderRadius": "2",
                "toolTipPadding": "5",
            },
            "data": ['.
                $simtest.'
            ]
        }
    }).render();'; 
	 }
	 
	 
	 
	 
	
	 $c2='';
 
   
	for($x = 0; $x < $arrlength; $x++) 
	 {
		$c2.='var revenueChart = new FusionCharts({
			type: "doughnut3d",
        renderAt: "chat2-'. $array[$x]['userTo'].'",
        width: "500",
        height: "400",
        dataFormat: "json",
        dataSource: {
            "chart": {
                "caption": "Options",
                "paletteColors": "#0075c2,#1aaf5d,#f2c500,#f45b00,#8e0000",
                "bgColor": "#ffffff",
                "showBorder": "0",
                "use3DLighting": "0",
                "showShadow": "0",
                "enableSmartLabels": "0",
                "startingAngle": "310",
                "showLabels": "0",
                "showPercentValues": "1",
                "showLegend": "1",
                "legendShadow": "0",
                "legendBorderAlpha": "0",                                
                "decimals": "0",
                "captionFontSize": "14",
                "subcaptionFontSize": "14",
                "subcaptionFontBold": "0",
                "toolTipColor": "#ffffff",
                "toolTipBorderThickness": "0",
                "toolTipBgColor": "#000000",
                "toolTipBgAlpha": "80",
                "toolTipBorderRadius": "2",
                "toolTipPadding": "5",
            },
            "data": ['.
                $simopt.'
            ]
        }
    }).render();';
	 }
	 
	 $crgh='';
 
   
	for($x = 0; $x < $arrlength; $x++) 
	 {
		$crgh.='var topStores = new FusionCharts({
         type: "bar2d",
         renderAt: "chat3-'. $array[$x]["userTo"].'",
        width: "400",
        height: "300",
        dataFormat: "json",
        dataSource: {
            "chart": {
                "caption": "Ratings",                
                "paletteColors": "#0075c2",
                "bgColor": "#ffffff",
                "showBorder": "0",
                "showCanvasBorder": "0",
                "usePlotGradientColor": "0",
                "plotBorderAlpha": "10",
                "placeValuesInside": "1",
                "valueFontColor": "#ffffff",
                "showAxisLines": "1",
                "axisLineAlpha": "25",
                "divLineAlpha": "10",
                "alignCaptionWithCanvas": "0",
                "showAlternateVGridColor": "0",
                "captionFontSize": "14",
                "subcaptionFontSize": "14",
                "subcaptionFontBold": "0",
                "toolTipColor": "#ffffff",
                "toolTipBorderThickness": "0",
                "toolTipBgColor": "#000000",
                "toolTipBgAlpha": "80",
                "toolTipBorderRadius": "2",
                "toolTipPadding": "5"
            },
            
            "data": [
                {
                    "label": "PriceRange",
                    "value": "'.$simpriceRange.'"
                }, 
                {
                    "label": "AmbienceRating",
                      "value": "'.$simambienceRating.'"
                }, 
                {
                    "label": "FoodRating",
                      "value": "'.$simfoodRating.'"
                }, 
                {
                    "label": "ServiceRating",
                      "value": "'.$simserviceRating.'"
                }, 
                {
                    "label": "ValueRating",
                      "value": "'.$simvalueRating.'"
                },
				{
                    "label": "AggregatedRating",
                      "value": "'.$simaggregatedRating.'"
                }
            ]
        }
    })
    .render();';
	 
	 }
	 
	 
?>					
					
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Crayon Data</title>
<script src="js/jquery.min.js" type="text/javascript"></script>


     <link href='css/jquery.dataTables.min.css' rel='stylesheet' type='text/css'>
	<link href='bootstrap.min.css' rel='stylesheet' type='text/css'>
	<link rel="stylesheet" href="css/gridism.css">
	<link rel="stylesheet" href="css/normalize.css">
	<link rel="stylesheet" href="css/style.css">
	<link rel="stylesheet" href="css/scroll.css">
	<!-- tab jquery -->
		<script>
	$(function() {
	$( "#tabs" ).tabs();
	});
	</script>
	
	<!-- Carousel -->
	<script src="scripts/lib/jquery-1.7.1.min.js"></script>
	<script src="scripts/jq.carousel.js"></script>
    <!-- Carousel -->

	<!-- Donut Chart -->
	<script type="text/javascript" src="http://static.fusioncharts.com/code/latest/fusioncharts.js"></script>
<script type="text/javascript" src="http://static.fusioncharts.com/code/latest/themes/fusioncharts.theme.fint.js?cacheBust=56"></script>
<script type="text/javascript">
  
FusionCharts.ready(function () {
    var revenueChart = new FusionCharts({
        type: 'doughnut3d',
        renderAt: 'chart-container',
        width: '500',
        height: '400',
        dataFormat: 'json',
        dataSource: {
            "chart": {
                "caption": "Cuisines",
                /*"subCaption": "Last year",
                "numberPrefix": "$",*/
                "paletteColors": "#0075c2,#1aaf5d,#f2c500,#f45b00,#8e0000",
                "bgColor": "#ffffff",
                "showBorder": "0",
                "use3DLighting": "0",
                "showShadow": "0",
                "enableSmartLabels": "0",
                "startingAngle": "310",
                "showLabels": "0",
                "showPercentValues": "1",
                "showLegend": "1",
                "legendShadow": "0",
                "legendBorderAlpha": "0",                                
                "decimals": "0",
                "captionFontSize": "14",
                "subcaptionFontSize": "14",
                "subcaptionFontBold": "0",
                "toolTipColor": "#ffffff",
                "toolTipBorderThickness": "0",
                "toolTipBgColor": "#000000",
                "toolTipBgAlpha": "80",
                "toolTipBorderRadius": "2",
                "toolTipPadding": "5",
            },
            "data": [
               <?php echo $test; ?>
            ]
        }
    }).render();
});


<!--2nd chart-->
FusionCharts.ready(function () {
    var revenueChart = new FusionCharts({
        type: 'doughnut3d',
        renderAt: 'df-container',
        width: '500',
        height: '400',
        dataFormat: 'json',
        dataSource: {
            "chart": {
                "caption": "Options",
                /*"subCaption": "Last year",
                "numberPrefix": "$",*/
                "paletteColors": "#0075c2,#1aaf5d,#f2c500,#f45b00,#8e0000",
                "bgColor": "#ffffff",
                "showBorder": "0",
                "use3DLighting": "0",
                "showShadow": "0",
                "enableSmartLabels": "0",
                "startingAngle": "310",
                "showLabels": "0",
                "showPercentValues": "1",
                "showLegend": "1",
                "legendShadow": "0",
                "legendBorderAlpha": "0",                                
                "decimals": "0",
                "captionFontSize": "14",
                "subcaptionFontSize": "14",
                "subcaptionFontBold": "0",
                "toolTipColor": "#ffffff",
                "toolTipBorderThickness": "0",
                "toolTipBgColor": "#000000",
                "toolTipBgAlpha": "80",
                "toolTipBorderRadius": "2",
                "toolTipPadding": "5",
            },
            "data": [
                <?php echo $opt; ?>
            ]
        }
    }).render();
});



<!--Bar chart-->
FusionCharts.ready(function () {
    var topStores = new FusionCharts({
        type: 'bar2d',
        renderAt: 'bchart-container',
        width: '400',
        height: '300',
        dataFormat: 'json',
        dataSource: {
            "chart": {
                "caption": "Ratings",
                /*"yAxisName": "Sales (In USD)",
                "numberPrefix": "$",*/
                "paletteColors": "#0075c2",
                "bgColor": "#ffffff",
                "showBorder": "0",
                "showCanvasBorder": "0",
                "usePlotGradientColor": "0",
                "plotBorderAlpha": "10",
                "placeValuesInside": "1",
                "valueFontColor": "#ffffff",
                "showAxisLines": "1",
                "axisLineAlpha": "25",
                "divLineAlpha": "10",
                "alignCaptionWithCanvas": "0",
                "showAlternateVGridColor": "0",
                "captionFontSize": "14",
                "subcaptionFontSize": "14",
                "subcaptionFontBold": "0",
                "toolTipColor": "#ffffff",
                "toolTipBorderThickness": "0",
                "toolTipBgColor": "#000000",
                "toolTipBgAlpha": "80",
                "toolTipBorderRadius": "2",
                "toolTipPadding": "5"
            },
            
            "data": [
                {
                    "label": "PriceRange",
                    "value": "<?php echo $priceRange; ?>"
                }, 
                {
                    "label": "AmbienceRating",
                      "value": "<?php echo $ambienceRating; ?>"
                }, 
                {
                    "label": "FoodRating",
                      "value": "<?php echo $foodRating; ?>"
                }, 
                {
                    "label": "ServiceRating",
                      "value": "<?php echo $serviceRating; ?>"
                }, 
                {
                    "label": "ValueRating",
                      "value": "<?php echo $valueRating; ?>"
                },
				{
                    "label": "AggregatedRating",
                      "value": "<?php echo $aggregatedRating; ?>"
                }
            ]
        }
    })
    .render();
});


/* ####################################################################################*/


FusionCharts.ready(function () {
	
    <?php echo $c1; ?>
	
	
});
FusionCharts.ready(function () {
    <?php echo $c2; ?>
});

FusionCharts.ready(function () {
    <?php echo $crgh; ?>
});

</script>
	<!-- Donut Chart -->
	
 <!-- Bar chart -->
 <!-- Bar chart --> 
	
</head>


<body class="wrap wider">

<div id="wrapper">
    <!-- Header start -->
     <div id="header">
	<!-- <span id="user_name">User ID : </span>-->
	 <div class="circle_small" style="background-image: 
		url('profile.jpg')">
		
		</div>
		
	  <!--Logo --> 
       <div id="logo"><a href="index.php"><img src="img/crayon.png"/></a></div> 
	 </div>
	<!-- Header end --> 
	
	

	<div id="user_wrapper">
	   <div id="srw_left">
	   <div style="border:1px solid #F05284;height:45px;font-size:20px;color:#fff;padding:6px;width:100%;background:#F05284;font-weight:bold;">
			Users ID : <?php echo $sg; ?>
			</div>
			<div>
		      <div style="float:left;" id="chart-container">Cuisines</div>			
		    </div>
		  
		  
		  <div style="float:left;margin-top:45px;" id="df-container">Options</div>
		  <br clear="all"/>
		  <div  style="margin-left:15px;float:left;" id="bchart-container">ratings</div>
				
	   </div> 
	   
	   <div id="srw_right">
			<div class="drf">
			<div style="border:1px solid #16B288;height:45px;font-size:20px;color:#fff;padding:6px;width:100%;background:#16B288;font-weight:bold;">
			Users Like You
			</div>
			<?php							
				$array = json_decode(json_encode($simg), true);
				//echo'DD'. $array['0']['userTo'];
				$arrlength = count($array);				
				for($x = 0; $x < $arrlength; $x++) {
					
					echo '<div class="box">
					<div class="top">
					<div id="us_id">
					<span class="user-tabs-current" data-url="" data-target="blank">User ID : '.$array[$x]['userTo'].'&nbsp;<i>(Click)</i> - &nbsp; <span style="color:#16B288;">Similarity Score -</span> '.$array[$x]['similarityValue'].'</span>
					</div>
			</div>
			
			  <div class="bottom"><!-- view part -->
					<div>
					<div style="float:left;" id="chat1-'.$array[$x]['userTo'].'">Cuisines</div>			
					</div>
					<div style="float:left;margin-top:45px;border-left:2px solid #d6d6d6;" id="chat2-'.$array[$x]['userTo'].'">Options</div>
					<br clear="all"/>
					<div  style="margin-left:15px;float:left;" id="chat3-'.$array[$x]['userTo'].'">ratings</div>
					<br clear="all"/>
			   </div>
			
			</div>';	
				}	
			?>
			
			
			
			</div>
			
			<div style="margin-top:15px;">
			   <div style="border:1px solid #913192;height:40px;font-size:18px;color:#fff;padding:6px;width:100%;background:#913192;font-weight:bold;margin-bottom:4px;">
			   Also Liked
			</div>
				<!-- Carousel -->			
				<div class="carousel">
				<div id="carousel" class="carousel_inner">
				
				<?php
				$array = json_decode(json_encode($likeimg), true);				
				$arrlength = count($array);				
				for($x = 0; $x < $arrlength; $x++) {
					echo '<div class="carousel_box"><a alt="'.$array[$x]['name'].'"  href="res.php?resid='.$array[$x]['restaurantId'].'"><img style="width:140px;height:140px;" src="https://dpimages.crayondata.com/high-res-image/'.$array[$x]['image'].'"/></a></div>';
				}
				?>
				</div>
				<p class="btns">
				<input type="button" id="carousel_prev" value="<">
				<input type="button" id="carousel_next" value=">">
				</p>
				</div>
				<!-- Carousel -->			  
			</div>
			
			
	   </div> 
	
	</div>
	
	
	
	

   
   
   

</div>  
 
  
  

<style type="text/css">
.drf .box {
 
}

.drf .box .top {

  cursor: pointer;
}

.drf .box .bottom {  
  width:98%;
  display: none;
}


<!-- Carousel -->
#carousel {
  margin: 0 auto;
  width: 640px;
  height: 150px;
  background: rgba(0, 0, 0, 0.2) none repeat scroll 0 0;
  overflow: hidden;
}
#carousel .carousel_box {
  float: left;
  
  width: 152px;
  height: 140px;
  color: #000;
  line-height: 140px;
  text-align: center;
  font-size: 123%;
}
<!-- Carousel -->
</style>
	
  

<script type="text/javascript">
$('.top').on('click', function() {
	$parent_box = $(this).closest('.box');
	$parent_box.siblings().find('.bottom').slideUp();
	$parent_box.find('.bottom').slideToggle(1000, 'swing');
});

<!-- Carousel -->
var $carousel = $('#carousel').carousel();
  
$('#carousel_prev').on('click', function(ev) {
  $carousel.carousel('prev');
});
$('#carousel_next').on('click', function(ev) {
  $carousel.carousel('next');
});
<!-- Carousel -->
</script>
  
	
</body>
</html>
