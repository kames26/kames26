<?php

/**
 *
 * @Project   Crayothon
 * @Company   Crayon
 * @author    Meeran ( UI Devloper)
 */
 
 
$resdg = $_GET['resid'];

$trjson=file_get_contents("http://taste-match.buildmaya.com:8080/crayothon/getRestaurentDetails?restaurantId=$resdg");
$trdata =  json_decode($trjson);
$array = json_decode(json_encode($trdata), true);


$restaurantId = $array['restaurantId'];
$name = $array['name'];
$addresscountry = $array['addresscountry'];
$priceRange = $array['priceRange'];
$ambienceRating = $array['ambienceRating'];
$foodRating = $array['foodRating'];
$serviceRating = $array['serviceRating'];
$valueRating = $array['valueRating'];
$aggregateRating = $array['aggregateRating'];
$geo = $array['geo'];
$image = $array['image'];

?>

<!DOCTYPE HTML>
<html lang="en-US">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Crayon Data</title> 
  
   <link href='css/jquery.dataTables.min.css' rel='stylesheet' type='text/css'>
	<link href='bootstrap.min.css' rel='stylesheet' type='text/css'>
	<link rel="stylesheet" href="css/gridism.css">
	<link rel="stylesheet" href="css/normalize.css">
	<link rel="stylesheet" href="css/style.css">
	<link rel="stylesheet" href="css/scroll.css">
        <!--Scroll-->
		<link href="scroll/flexcrollstyles.css" rel="stylesheet" type="text/css" />
		<script type='text/javascript' src="scroll/flexcroll.js"></script>
		<!-- Scroll-->
    <!-- tab jquery -->
	<link rel="stylesheet" href="js/tab/jquery-ui.css">
	<script src="js/tab/jquery-1.10.2.js"></script>
	<script src="js/tab/jquery-ui.js"></script>
	<!-- tab jquery -->
		<script>
	$(function() {
	$( "#tabs" ).tabs();
	});
	
		$.fn.pageMe = function(opts){
    var $this = this,
        defaults = {
            perPage: 10,
            showPrevNext: false,
            hidePageNumbers: false
        },
        settings = $.extend(defaults, opts);
    
    var listElement = $this;
    var perPage = settings.perPage; 
    var children = listElement.children();
    var pager = $('.pager');
    
    if (typeof settings.childSelector!="undefined") {
        children = listElement.find(settings.childSelector);
    }
    
    if (typeof settings.pagerSelector!="undefined") {
        pager = $(settings.pagerSelector);
    }
    
    var numItems = children.size();
    var numPages = Math.ceil(numItems/perPage);

    pager.data("curr",0);
    
    if (settings.showPrevNext){
        $('<li><a href="#" class="prev_link">«</a></li>').appendTo(pager);
    }
    
    var curr = 0;
    while(numPages > curr && (settings.hidePageNumbers==false)){
        $('<li><a href="#" class="page_link">'+(curr+1)+'</a></li>').appendTo(pager);
        curr++;
    }
    
    if (settings.showPrevNext){
        $('<li><a href="#" class="next_link">»</a></li>').appendTo(pager);
    }
    
    pager.find('.page_link:first').addClass('active');
    pager.find('.prev_link').hide();
    if (numPages<=1) {
        pager.find('.next_link').hide();
    }
      pager.children().eq(1).addClass("active");
    
    children.hide();
    children.slice(0, perPage).show();
    
    pager.find('li .page_link').click(function(){
        var clickedPage = $(this).html().valueOf()-1;
        goTo(clickedPage,perPage);
        return false;
    });
    pager.find('li .prev_link').click(function(){
        previous();
        return false;
    });
    pager.find('li .next_link').click(function(){
        next();
        return false;
    });
    
    function previous(){
        var goToPage = parseInt(pager.data("curr")) - 1;
        goTo(goToPage);
    }
     
    function next(){
        goToPage = parseInt(pager.data("curr")) + 1;
        goTo(goToPage);
    }
    
    function goTo(page){
        var startAt = page * perPage,
            endOn = startAt + perPage;
        
        children.css('display','none').slice(startAt, endOn).show();
        
        if (page>=1) {
            pager.find('.prev_link').show();
        }
        else {
            pager.find('.prev_link').hide();
        }
        
        if (page<(numPages-1)) {
            pager.find('.next_link').show();
        }
        else {
            pager.find('.next_link').hide();
        }
        
        pager.data("curr",page);
      	pager.children().removeClass("active");
        pager.children().eq(page+1).addClass("active");
    
    }
};

$(document).ready(function(){
    
  $('#myTable').pageMe({pagerSelector:'#myPager',showPrevNext:true,hidePageNumbers:false,perPage:20});
    
});
		
		
		
		
	</script>
	
	
		
	
</head>


<body class="wrap wider">

<div id="wrapper">
    <!-- Header start -->
     <div id="header">
	   <div id="site_name">Restaurant  Details</div>
	  <!--Logo --> 
       <div id="logo"><a href="index.php"><img src="img/crayon.png"/></a></div> 
	 </div>
	<!-- Header end --> 

	

<div>
  <div class="container" style="margin-top:15px;">
    <div class="row">
      <div class="table-responsive">
        <table style="width:450px;-webkit-box-shadow: 10px 10px 57px -18px rgba(0,0,0,0.75);
-moz-box-shadow: 10px 10px 57px -18px rgba(0,0,0,0.75);
box-shadow: 10px 10px 57px -18px rgba(0,0,0,0.75);" class="table table-hover">
          
				<td id="lf" style="background:#534847;color:#fff;">#</td>
				<td style="background:#534847;color:#fff;">Details</td> 
				
					
				
				 
				
				
				
				
				
			
         
         
			<form name="" method="POST">
			<?php							
				$array = json_decode(json_encode($trdata), true);
				//echo $array['0']['userId'];
                //$arrlength = count($array); 
				//$count=1;
					echo '<tr>
					         <td id="lf" style="color:#F05284;">Restaurant ID </td>
							 <td>'.$restaurantId.'</td>
						  </tr>	 
					<tr><td id="lf" style="color:#16B288;">Name</td><td>'.$name.'</td></tr>	
					<tr><td id="lf" style="color:#F79237;">Country</td><td>'.$addresscountry.'</td></tr>	
					
					<tr><td id="lf" style="color:#2C56A6;">Ambience Rating</td><td>'.$ambienceRating.'</td></tr>	
					<tr><td id="lf" style="color:#1A78B9;">Food Rating</td><td>'.$foodRating.'</td></tr>	
					<tr><td id="lf" style="color:#F05284;">Service Rating</td>	<td>'.$serviceRating.'</td></tr>	
					<tr><td id="lf" style="color:#ff9f9c;">Value Rating</td><td>'.$valueRating.'</td></tr>	
					<tr><td id="lf" style="color:#FEC433;">Aggregate Rating</td> <td>'.$aggregateRating.'</td></tr>	
					<tr><td id="lf" style="color:#913192;">Geo</td><td>'.$geo.'</td></tr>	
					
					
				
					<tr>';				
						?>
                
           
          
            </form>
			
			
         
        </table> 
        
		
      </div>
	  
	  
		<div style="float:left;position:absolute;top:70px;right:130px;border:6px solid #8B8687;-webkit-box-shadow: 10px 10px 49px -1px rgba(0,0,0,0.75);
-moz-box-shadow: 10px 10px 49px -1px rgba(0,0,0,0.75);
box-shadow: 10px 10px 49px -1px rgba(0,0,0,0.75);">
		  <img style="width:550px;height:330px;" src="https://dpimages.crayondata.com/high-res-image/<?php echo $image; ?>"/>
		</div>
		
      
	</div>
</div>
</div>  
 
 
  
		<div id="button-wrap-inner" style="position:absolute;left:45%;">
		<?php echo "<a class='btn' href=\"javascript:history.go(-1)\">GO BACK</a>"; ?>
		</div>
  


	
  <style type="text/css">
  .table > tbody > tr > td, .table > tbody > tr > th, .table > tfoot > tr > td, .table > tfoot > tr > th, .table > thead > tr > td, .table > thead > tr > th
  {
	  border:1px solid #d6d6d6;
	  font-weight:bold;
  }
  #lf
  {
	  text-align:right;
	  padding-right:15px;
  }
  </style>
 
  
  
</body>
</html>
