<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Crayon Data</title>
<script src="js/jquery.min.js" type="text/javascript"></script>
<script>
    $( document ).ready(function() {
         $.ajax({
                    type: "POST",
                    url: "https://latest-lifestyle.buildmaya.com/api/profile/authenticate",
                    contentType: "application/json",
                    data:"",
                    success: function(data) {                        
                        var access_token = data['authToken'];
						alert(access_token);
            
                    },
                });
                
        
                
    });
</script>
 <link href='http://fonts.googleapis.com/css?family=Source+Code+Pro|Montserrat:700|Open+Sans:300italic,400italic,700italic,400,300,700' rel='stylesheet' type='text/css'>
    <link href='https://cdn.datatables.net/1.10.12/css/jquery.dataTables.min.css' rel='stylesheet' type='text/css'>
	<link href='bootstrap.min.css' rel='stylesheet' type='text/css'>
	<link rel="stylesheet" href="css/gridism.css">
	<link rel="stylesheet" href="css/normalize.css">
	<link rel="stylesheet" href="css/style.css">
	<link rel="stylesheet" href="css/scroll.css">
</head>


<body class="wrap wider">

<div id="wrapper">
    <!-- Header start -->
     <div id="header">
	   <div id="site_name">Crayon Data</div>
	  <!--Logo --> 
       <div id="logo"><img src="img/crayon.png"/></div> 
	 </div>
	<!-- Header end --> 

	

<div>
  <div class="container">
    <div class="row">
      <div class="table-responsive">
        <table class="table table-hover">
          <thead>
            <tr>
              <th>#</th>
              <th>R1</th>
              <th>R2</th>
              <th>R3</th>
              <th>R4</th>
              <th>R5</th>
              <th>R6</th>
            </tr>
          </thead>
          <tbody id="myTable">
            <tr>
              <td>1</td>
              <td>AA</td>
              <td>BBB</td>
              <td>CCC</td>
              <td>DDD</td>
              <td>EEE</td>
              <td>FFF</td>
            </tr>
            <tr>
              <td>2</td>
              <td>Table cell</td>
              <td>Table cell</td>
              <td>Table cell</td>
              <td>Table cell</td>
              <td>Table cell</td>
              <td>Table cell</td>
            </tr>
            <tr>
              <td>3</td>
              <td>Table cell</td>
              <td>Table cell</td>
              <td>Table cell</td>
              <td>Table cell</td>
              <td>Table cell</td>
              <td>Table cell</td>
            </tr>
           
			
			
          </tbody>
        </table>   
      </div>
      <div class="col-md-12 text-center">
      <ul class="pagination pagination-lg pager" id="myPager"></ul>
      </div>
	</div>
</div>
</div>  
 
  
  


	
  

  
  
  
</body>
</html>