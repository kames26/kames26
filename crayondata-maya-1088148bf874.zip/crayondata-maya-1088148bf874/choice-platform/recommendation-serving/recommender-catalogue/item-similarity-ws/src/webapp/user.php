<?php

/**
 *
 * @Project   Crayothon
 * @Company   Crayon
 * @author    Meeran ( UI Devloper)
 */
 
 
 
$uidg = $_GET['userid'];
$simuser = $uidg;
//http://10.0.0.125:8080/crayothon/getUserProfile?UserId=76
$json=file_get_contents("http://taste-match.buildmaya.com:8080/crayothon/getUserProfile?UserId=$uidg");
$data =  json_decode($json);


/* user - Res Details */
$deresjson=file_get_contents("http://taste-match.buildmaya.com:8080/crayothon/getLikedRestaurants?UserId=$uidg");
$deresdata =  json_decode($deresjson);
//restaurantId
/*
echo '<pre>';
print_r($deresdata);
echo '</pre>';
*/



/*
echo '<pre>';
print_r($data);
echo '</pre>';
*/

?>

<?php							
$array = json_decode(json_encode($data), true);
//echo $array['0']['userId'];

$range = $array['cuisineAndScoreMap'];
$range_keys = array_keys($range);
$range_values = array_values($range);

$test = '';

for($i=0;$i<=(count($range_keys)-1);$i++)
{
	$test.='{
	"label": "'.$range_keys[$i].'",
	"value": "'.$range_values[$i].'"
	}, ';
}


/* Options */
$optionsg = $array['optionsAndScoreMap'];
$optionsg_keys = array_keys($optionsg);
$optionsg_values = array_values($optionsg);

$opt = '';
for($i=0;$i<=(count($optionsg_keys)-1);$i++)
{
	$opt.='{
	"label": "'.$optionsg_keys[$i].'",
	"value": "'.$optionsg_values[$i].'"
	}, ';
}
/* Options */

/* Ratings */
$priceRange = round($array['priceRange']);
$ambienceRating = round($array['ambienceRating']);
$foodRating = round($array['foodRating']);
$serviceRating = round($array['serviceRating']);
$valueRating = round($array['valueRating']);
$aggregatedRating = round($array['aggregatedRating']);
/* Ratings */

?>




<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Crayon Data</title>
<script src="js/jquery.min.js" type="text/javascript"></script>

  <link href='css/jquery.dataTables.min.css' rel='stylesheet' type='text/css'>
	<link href='bootstrap.min.css' rel='stylesheet' type='text/css'>
	<link rel="stylesheet" href="css/gridism.css">
	<link rel="stylesheet" href="css/normalize.css">
	<link rel="stylesheet" href="css/style.css">
	<link rel="stylesheet" href="css/scroll.css">
		<script>
	$(function() {
	$( "#tabs" ).tabs();
	});
	</script>
	
	<!-- Donut Chart -->
	<script type="text/javascript" src="http://static.fusioncharts.com/code/latest/fusioncharts.js"></script>
<script type="text/javascript" src="http://static.fusioncharts.com/code/latest/themes/fusioncharts.theme.fint.js?cacheBust=56"></script>
<script type="text/javascript">
 FusionCharts.ready(function () {
    var revenueChart = new FusionCharts({
        type: 'doughnut3d',
        renderAt: 'chart-container',
        width: '400',
        height: '300',
        dataFormat: 'json',
        dataSource: {
            "chart": {
                "caption": "Cuisines",
                /*"subCaption": "Last year",
                "numberPrefix": "$",*/
                "paletteColors": "#0075c2,#1aaf5d,#f2c500,#f45b00,#8e0000",
                "bgColor": "#ffffff",
                "showBorder": "0",
                "use3DLighting": "0",
                "showShadow": "0",
                "enableSmartLabels": "0",
                "startingAngle": "310",
                "showLabels": "0",
                "showPercentValues": "1",
                "showLegend": "1",
                "legendShadow": "0",
                "legendBorderAlpha": "0",                                
                "decimals": "0",
                "captionFontSize": "14",
                "subcaptionFontSize": "14",
                "subcaptionFontBold": "0",
                "toolTipColor": "#ffffff",
                "toolTipBorderThickness": "0",
                "toolTipBgColor": "#000000",
                "toolTipBgAlpha": "80",
                "toolTipBorderRadius": "2",
                "toolTipPadding": "5",
            },
            "data": [
               <?php echo $test; ?>
            ]
        }
    }).render();
});


<!--2nd chart-->
FusionCharts.ready(function () {
    var revenueChart = new FusionCharts({
        type: 'doughnut3d',
        renderAt: 'df-container',
        width: '400',
        height: '300',
        dataFormat: 'json',
        dataSource: {
            "chart": {
                "caption": "Options",
                /*"subCaption": "Last year",
                "numberPrefix": "$",*/
                "paletteColors": "#0075c2,#1aaf5d,#f2c500,#f45b00,#8e0000",
                "bgColor": "#ffffff",
                "showBorder": "0",
                "use3DLighting": "0",
                "showShadow": "0",
                "enableSmartLabels": "0",
                "startingAngle": "310",
                "showLabels": "0",
                "showPercentValues": "1",
                "showLegend": "1",
                "legendShadow": "0",
                "legendBorderAlpha": "0",                                
                "decimals": "0",
                "captionFontSize": "14",
                "subcaptionFontSize": "14",
                "subcaptionFontBold": "0",
                "toolTipColor": "#ffffff",
                "toolTipBorderThickness": "0",
                "toolTipBgColor": "#000000",
                "toolTipBgAlpha": "80",
                "toolTipBorderRadius": "2",
                "toolTipPadding": "5",
            },
            "data": [
                <?php echo $opt; ?>
            ]
        }
    }).render();
});



<!--Bar chart-->
FusionCharts.ready(function () {
    var topStores = new FusionCharts({
        type: 'bar2d',
        renderAt: 'bchart-container',
        width: '400',
        height: '300',
        dataFormat: 'json',
        dataSource: {
            "chart": {
                "caption": "Ratings",
                /*"yAxisName": "Sales (In USD)",
                "numberPrefix": "$",*/
                "paletteColors": "#0075c2",
                "bgColor": "#ffffff",
                "showBorder": "0",
                "showCanvasBorder": "0",
                "usePlotGradientColor": "0",
                "plotBorderAlpha": "10",
                "placeValuesInside": "1",
                "valueFontColor": "#ffffff",
                "showAxisLines": "1",
                "axisLineAlpha": "25",
                "divLineAlpha": "10",
                "alignCaptionWithCanvas": "0",
                "showAlternateVGridColor": "0",
                "captionFontSize": "14",
                "subcaptionFontSize": "14",
                "subcaptionFontBold": "0",
                "toolTipColor": "#ffffff",
                "toolTipBorderThickness": "0",
                "toolTipBgColor": "#000000",
                "toolTipBgAlpha": "80",
                "toolTipBorderRadius": "2",
                "toolTipPadding": "5"
            },
            
            "data": [
                {
                    "label": "PriceRange",
                    "value": "<?php echo $priceRange; ?>"
                }, 
                {
                    "label": "AmbienceRating",
                      "value": "<?php echo $ambienceRating; ?>"
                }, 
                {
                    "label": "FoodRating",
                      "value": "<?php echo $foodRating; ?>"
                }, 
                {
                    "label": "ServiceRating",
                      "value": "<?php echo $serviceRating; ?>"
                }, 
                {
                    "label": "ValueRating",
                      "value": "<?php echo $valueRating; ?>"
                },
				{
                    "label": "AggregatedRating",
                      "value": "<?php echo $aggregatedRating; ?>"
                }
            ]
        }
    })
    .render();
});

</script>
	<!-- Donut Chart -->
	
 <!-- Bar chart -->
 <!-- Bar chart --> 
	
</head>


<body class="wrap wider">





<div id="wrapper">
    <!-- Header start -->
     <div id="header">
	 
	 <span id="user_name">User ID : <?php echo $uidg; ?></span>
		<div class="circle" style="background-image: 
		url('profile.jpg')">
		<div style="margin-left: 87px; margin-top: 76px;"> <img src="img/heart.png"/></div>
		</div>
	  <!--Logo --> 
       <div id="logo"><a href="index.php"><img src="img/crayon.png"/></a></div> 
	 </div>
	<!-- Header end --> 
	
	

	<div id="user_wrapper">
	   <div id="rw_left">
	       <div style="border:1px solid #16B288;height:45px;font-size:20px;color:#fff;padding:6px;width:100%;background:#16B288;font-weight:bold;">
			Liked Restaurants
			</div>
			<?php							
			$array = json_decode(json_encode($deresdata), true);
			//echo $array['0']['userId'];
			$arrlength = count($array); 
			//$count=1;
			for($x = 0; $x < 10; $x++) 
				{
				 echo '<div id="res_id"><span data-target="blank" data-url="" class="su-tabs-current"><a style="color:#000;" href="res.php?resid='.$array[$x]['restaurantId'].'">'.$array[$x]['name'].'</a></span></div>';							
				}
				?>

				<br clear="all"/>

			
			</div>
	   
	   <div id="rw_right">
	   <div style="border:1px solid #F05284;margin-left: 56px;width:750px;height:45px;font-size:20px;color:#fff;padding:6px;background:#F05284;font-weight:bold;">
			Taste Profile
			</div>
	      <div>
		    <div style="float:left;" id="chart-container">Cuisines</div>			
		  </div>
		  
		 
		  <div style="float:left;border-left:3px solid #d6d6d6;" id="df-container">Options</div>
		  <br clear="all"/>
		  <div  style="margin-left:15px;float:left;" id="bchart-container">ratings</div>
		     <form name="" method="POST">
				<div  style="margin-top:55px;margin-left:35px;float:left;">
				<div id="button-wrap-inner">
				<a class="btn" href="similar.php?userid=<?php echo $simuser; ?>">Similar Users</a>
				</div>
				</div>
				</form>
	   </div> 
	
	</div>


</div>  
 
  
  


	
  
	
</body>
</html>
