
<?php
/**
 *
 * @Project   Crayothon
 * @Company   Crayon
 * @author    Meeran ( UI Devloper)
 */
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Crayon Data</title>
<script src="js/jquery.min.js" type="text/javascript"></script>
 
   <link href='css/jquery.dataTables.min.css' rel='stylesheet' type='text/css'>
	<link href='bootstrap.min.css' rel='stylesheet' type='text/css'>
	<link rel="stylesheet" href="css/gridism.css">
	<link rel="stylesheet" href="css/normalize.css">
	<link rel="stylesheet" href="css/style.css">
	<link rel="stylesheet" href="css/scroll.css">
        <!--Scroll-->
		<link href="scroll/flexcrollstyles.css" rel="stylesheet" type="text/css" />
		<script type='text/javascript' src="scroll/flexcroll.js"></script>
		<!-- Scroll-->
    <!-- tab jquery -->
	<link rel="stylesheet" href="js/tab/jquery-ui.css">
	<script src="js/tab/jquery-1.10.2.js"></script>
	<script src="js/tab/jquery-ui.js"></script>
	<!-- tab jquery -->
	
	
	<script>
	$(function() {
	$( "#tabs" ).tabs();
	});
	
		$.fn.pageMe = function(opts){
    var $this = this,
        defaults = {
            perPage: 2,
            showPrevNext: false,
            hidePageNumbers: false
        },
        settings = $.extend(defaults, opts);
    
    var listElement = $this;
    var perPage = settings.perPage; 
    var children = listElement.children();
    var pager = $('.pager');
    
    if (typeof settings.childSelector!="undefined") {
        children = listElement.find(settings.childSelector);
    }
    
    if (typeof settings.pagerSelector!="undefined") {
        pager = $(settings.pagerSelector);
    }
    
    var numItems = children.size();
    var numPages = Math.ceil(numItems/perPage);

    pager.data("curr",0);
    
    if (settings.showPrevNext){
        $('<li><a href="#" class="prev_link">«</a></li>').appendTo(pager);
    }
    
    var curr = 0;
    while(numPages > curr && (settings.hidePageNumbers==false)){
        $('<li><a href="#" class="page_link">'+(curr+1)+'</a></li>').appendTo(pager);
        curr++;
    }
    
    if (settings.showPrevNext){
        $('<li><a href="#" class="next_link">»</a></li>').appendTo(pager);
    }
    
    pager.find('.page_link:first').addClass('active');
    pager.find('.prev_link').hide();
    if (numPages<=1) {
        pager.find('.next_link').hide();
    }
      pager.children().eq(1).addClass("active");
    
    children.hide();
    children.slice(0, perPage).show();
    
    pager.find('li .page_link').click(function(){
        var clickedPage = $(this).html().valueOf()-1;
        goTo(clickedPage,perPage);
        return false;
    });
    pager.find('li .prev_link').click(function(){
        previous();
        return false;
    });
    pager.find('li .next_link').click(function(){
        next();
        return false;
    });
    
    function previous(){
        var goToPage = parseInt(pager.data("curr")) - 1;
        goTo(goToPage);
    }
     
    function next(){
        goToPage = parseInt(pager.data("curr")) + 1;
        goTo(goToPage);
    }
    
    function goTo(page){
        var startAt = page * perPage,
            endOn = startAt + perPage;
        
        children.css('display','none').slice(startAt, endOn).show();
        
        if (page>=1) {
            pager.find('.prev_link').show();
        }
        else {
            pager.find('.prev_link').hide();
        }
        
        if (page<(numPages-1)) {
            pager.find('.next_link').show();
        }
        else {
            pager.find('.next_link').hide();
        }
        
        pager.data("curr",page);
      	pager.children().removeClass("active");
        pager.children().eq(page+1).addClass("active");
    
    }
};

$(document).ready(function(){
    
  $('#myTable').pageMe({pagerSelector:'#myPager',showPrevNext:true,hidePageNumbers:false,perPage:20});
    
});
		
		
		
		
	</script>
</head>


<body class="wrap wider">

<div id="wrapper">
    <!-- Header start -->
     <div id="header">
	   <div id="site_name">Crayon Data</div>
	  <!--Logo --> 
       <div id="logo"><a href="index.php"><img src="img/crayon.png"/></a></div> 
	 </div>
	<!-- Header end --> 

<?php
$json=file_get_contents("http://taste-match.buildmaya.com:8080/crayothon/getAllUserSummaries");
$data =  json_decode($json);
/*
echo '<pre>';
print_r($data);
echo '</pre>';
*/
?>

<div>
  <div class="container">
    <div class="row">
      <div class="table-responsive">
        <table class="table table-hover">
          <thead>
            <tr>
				<th>#</th>
				<th>Users</th> 
				<th>CuisinePerc</th>
				<th>optionPerc</th>	
				<th>likedItemPerc</th>		  
            </tr>
          </thead>
          <tbody id="myTable">
         
			<form name="" method="POST">
			<?php							
				$array = json_decode(json_encode($data), true);
				//echo $array['0']['userId'];
                $arrlength = count($array); 
				$count=1;
				for($x = 0; $x < $arrlength; $x++) 
				{
					echo '<tr><td>'.$count.'</td>
					<td><a style="color:#000;" href="user.php?userid='.$array[$x]['id'].'">'.$array[$x]['id'].'</a></td>
					<td>'.$array[$x]['cuisinePerc'].'</td>
					<td>'.$array[$x]['optionPerc'].'</td>
					<td>'.$array[$x]['likedItemPerc'].'</td>
					<tr>';					
					$count++;	?>
                
                <?php				 
				}
				
			?>
          
            </form>
			
			
          </tbody>
        </table>   
      </div>
      <div class="col-md-12 text-center">
      <ul class="pagination pagination-lg pager" id="myPager"></ul>
      </div>
	</div>
</div>
</div>  
 
  
  


	
  

  
  
  
</body>
</html>