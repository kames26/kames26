/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.recommender.search;

import java.util.Collection;
import java.util.Collections;

import org.springframework.data.geo.Distance;
import org.springframework.data.geo.Point;
import org.springframework.data.solr.core.query.Criteria;
import org.springframework.data.solr.core.query.FilterQuery;
import org.springframework.data.solr.core.query.SimpleFilterQuery;

import com.crayondata.choice.rateableitem.Category;
import com.crayondata.choice.userprofile.UserProfile;
import com.crayondata.recommender.context.UserContext;
import com.google.common.base.Optional;

public class FilterHandlerMock implements IFilterHandler {
    private static final String GEO_LAT = "47.39041121158791";
    private static final String GEO_LON = "10.9145932196729";

    @Override
    public Iterable<FilterQuery> generateFilterSubQuery(UserContext userContext, UserProfile userProfile,
            boolean ignoreLocationFilter) {
        final Point location = new Point(Double.valueOf(GEO_LAT), Double.valueOf(GEO_LON));
        final Criteria closeBy = new Criteria("geo").within(location, new Distance(5));
        final FilterQuery filterSubQuery = new SimpleFilterQuery(closeBy);
        return Collections.singletonList(filterSubQuery);
    }

    @Override
    public FilterQuery generateCategoryFilter(Category category) {
        final SimpleFilterQuery filterSubQuery = new SimpleFilterQuery();
        return filterSubQuery;
    }

    @Override
    public Optional<FilterQuery> generateJoinFilterQuery(Collection<String> tags) {
        return Optional.of(new SimpleFilterQuery());
    }

    @Override
    public Optional<FilterQuery> generateLocationFilterQuery(Category category, Optional<Point> location,
            Distance distance) {
        final SimpleFilterQuery filterSubQuery = new SimpleFilterQuery();
        return Optional.of(filterSubQuery);
    }
}
