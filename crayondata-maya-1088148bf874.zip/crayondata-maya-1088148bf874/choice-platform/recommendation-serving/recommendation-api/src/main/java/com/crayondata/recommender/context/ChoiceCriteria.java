/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.recommender.context;

/**
 * Criteria object that contains context and filters to be applied for choice
 * delivery. This object will be part of all choice delivery requests.
 */
public class ChoiceCriteria {

    private ChoiceContext currentContext;

    private Filter filter;

    public ChoiceCriteria() {}

    public Filter getFilter() {
        return filter;
    }

    public ChoiceContext getCurrentContext() {
        return currentContext;
    }

    public void setFilter(Filter filter) {
        this.filter = filter;
    }

    public void setCurrentContext(ChoiceContext currentContext) {
        this.currentContext = currentContext;
    }

    @Override
    public String toString() {
        return "ChoiceCriteria [currentContext=" + currentContext + ", filter=" + filter + "]";
    }
}
