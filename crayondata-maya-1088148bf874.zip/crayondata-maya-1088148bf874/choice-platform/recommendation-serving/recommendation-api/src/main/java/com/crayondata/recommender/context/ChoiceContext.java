/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.recommender.context;

import java.util.Date;

import org.springframework.data.geo.Point;

import com.google.common.base.Optional;

public class ChoiceContext {

    private final Optional<Point> location;
    private final Date timestamp;

    public ChoiceContext(Optional<Point> location, Date timestamp) {
        this.location = location;
        this.timestamp = timestamp;
    }

    public Optional<Point> getLocation() {
        return location;
    }

    public Date getTimestamp() {
        return timestamp;
    }

    public Date getTime() {
        return timestamp;
    }

    @Override
    public String toString() {
        return "Context [location=" + location + ", timestamp=" + timestamp + "]";
    }
}
