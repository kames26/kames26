/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.recommender.recommendation;

import java.util.Collections;
import java.util.Map;
import java.util.Optional;

import com.crayondata.choice.rateableitem.ItemScores;
import com.crayondata.choice.rateableitem.RateableItem;

public class ScoredItem<T extends RateableItem> {

    private final T item;
    private final double score;

    public ScoredItem(T item, double score) {
        this.item = item;
        this.score = score;
    }

    public T getItem() {
        return this.item;
    }

    public double getScore() {
        return this.score;
    }

    public Map<String, Float> getRecommenderScores() {
        final Optional<ItemScores> itemScores = item.getItemScores();
        if (itemScores.isPresent()) {
            return itemScores.get().getRecommenderScores();
        }
        return Collections.emptyMap();
    }

    public Map<String, Float> getRawRecommenderScores() {
        final Optional<ItemScores> itemScores = item.getItemScores();
        if (itemScores.isPresent()) {
            return itemScores.get().getRawRecommenderScores();
        }
        return Collections.emptyMap();
    }

    @Override
    public String toString() {
        return "ScoredItem [item=" + item + ", score=" + score + "]";
    }
}