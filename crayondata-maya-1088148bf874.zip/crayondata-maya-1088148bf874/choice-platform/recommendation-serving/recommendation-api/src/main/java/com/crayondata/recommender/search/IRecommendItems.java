/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.recommender.search;

import java.util.List;

import org.springframework.data.solr.core.query.FilterQuery;

import com.crayondata.choice.userprofile.UserProfile;
import com.crayondata.recommender.Recommender;
import com.crayondata.recommender.RecommenderScenario;
import com.crayondata.recommender.context.UserContext;
import com.crayondata.recommender.recommendation.ScoredItem;
import com.google.common.base.Optional;

public interface IRecommendItems {

    static final String USER_HISTORY = "USER_HISTORY";
    static final String GEO_FILED_NAME = "geo";
    static final String RATING_FIELD_NAME = "aggregaterating";

    // Known Items
    static final String RECENTLY_INTERACTED_ITEMS = "RECENTLY_INTERACTED_ITEMS";
    static final String RECENTLY_SEEN_ITEMS = "RECENTLY_SEEN_ITEMS";

    List<ScoredItem> recommend(UserContext userContext, UserProfile userProfile,
            Iterable<Recommender> recommenders, int maxChoices, 
            boolean applyMinScoreFilter, boolean fallBackRecommender, Optional<RecommenderScenario> scenario);

    List<ScoredItem> recommend(UserContext userContext, Optional<RecommenderScenario> scenario);

    List<ScoredItem> recommend(UserContext userContext, UserProfile userProfile, int maxChoices,
    		Optional<RecommenderScenario> scenario);

    List<ScoredItem> recommend(UserContext userContext, Iterable<Recommender> recommenderTypes,
    		Optional<RecommenderScenario> scenario);

    public List<ScoredItem> recommendNearBy(UserContext userContext, UserProfile userProfile,
            Optional<FilterQuery> useCaseSpecificFilterQuery, Iterable<Recommender> recommendersToUse,
            Optional<RecommenderScenario> scenario);

    List<ScoredItem> recommend(UserContext userContext, UserProfile userProfile,
            Iterable<Recommender> recommenderTypes, 
            Optional<RecommenderScenario> scenario);

}
