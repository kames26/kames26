/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.recommender.search;

import java.util.Collections;
import java.util.Map;

import org.springframework.data.solr.core.query.Query;

import com.crayondata.choice.userprofile.UserProfile;
import com.crayondata.recommender.Recommender;
import com.crayondata.recommender.context.UserContext;
import com.google.common.base.Optional;

public interface IRecommendBySearch {
    Optional<RecommenderSearchParameters> generateSearchSubQuery(UserContext userContext,
            UserProfile userProfile);

    Recommender getName();

    public static class RecommenderSearchParameters {
        private final Query recommenderQuery;
        private final Map<String, String> modelParameters;
        private final float scaleMin;
        private final float scaleMax;

        private RecommenderSearchParameters(Query recommenderQuery, Map<String, String> modelParameters) {
            this.recommenderQuery = recommenderQuery;
            this.modelParameters = modelParameters;
            this.scaleMin = 0;
            this.scaleMax = 1;
        }

        public RecommenderSearchParameters(Query recommenderQuery, Map<String, String> modelParameters,
                float scaleMin, float scaleMax) {
            this.recommenderQuery = recommenderQuery;
            this.modelParameters = modelParameters;
            this.scaleMin = scaleMin;
            this.scaleMax = scaleMax;
        }

        public Query getRecommenderQuery() {
            return recommenderQuery;
        }

        public Map<String, String> getModelParameters() {
            return modelParameters;
        }

        public float getScaleMin() {
            return scaleMin;
        }

        public float getScaleMax() {
            return scaleMax;
        }

        public static RecommenderSearchParameters create(Query recommenderQuery,
                Map<String, String> modelParameters) {
            return new RecommenderSearchParameters(recommenderQuery, modelParameters);
        }

        public static RecommenderSearchParameters create(Query recommenderQuery) {
            return new RecommenderSearchParameters(recommenderQuery, Collections.emptyMap());
        }

        @Override
        public String toString() {
            return "RecommenderSearchParameters [recommenderQuery=" + recommenderQuery + ", modelParameters="
                    + modelParameters + ", scaleMin=" + scaleMin + ", scaleMax=" + scaleMax + "]";
        }
    }
}
