/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.recommender;

import java.util.Collection;
import java.util.List;

import com.crayondata.choice.rateableitem.RateableItem;
import com.crayondata.recommender.context.UserContext;
import com.crayondata.recommender.recommendation.ScoredItem;

/**
 * Interface for the recommenders
 *
 * @author somin
 */
public interface IRecommender {

    /**
     * Provides recommendations based on user context
     *
     * @param userContext
     *            Represents the context of the user asking for recommendations
     * @return List of recommendations as list of {@link ScoredItem}
     */
    public List<ScoredItem> recommend(UserContext userContext, Collection<RateableItem> getAttrList);

    public List<ScoredItem> recommend(UserContext userContext);
}
