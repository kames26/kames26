/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.recommender.context;

import java.util.Collection;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

import com.crayondata.choice.rateableitem.Category;
import com.crayondata.choice.userprofile.UserInteraction;
import com.crayondata.choice.userprofile.UserInteraction.InteractionType;
import com.crayondata.recommender.Recommender;
import com.google.common.collect.Table;

public class ChoiceRequest {
	
	String analyticId;
	
	UserContext userContext;
	
	Collection<Category> categories;
	
	Table<Category, InteractionType, Iterable<UserInteraction>> userLikes;
	
	EnumSet<Recommender> recommenderTypes;
	
	boolean minChoiceFilter = true;
	
	private AtomicInteger index;
	
	private AtomicInteger total;
	
	private String purpose;

	private String customerCountry;
	
	static Map<Category, Integer> maxChoiceNumbers = new HashMap<Category, Integer>();
	
	public ChoiceRequest(AtomicInteger index, AtomicInteger total, String purpose, String analyticId, Collection<Category> categories, String customerCountry, UserContext userContext, Table<Category, InteractionType, Iterable<UserInteraction>> userLikes, EnumSet<Recommender> recommenderTypes) {
		this.index = index;
		this.total = total;
		this.purpose = purpose;
		this.analyticId = analyticId;
		this.categories = categories;
		this.customerCountry = customerCountry;
		this.userContext = userContext;
		this.userLikes = userLikes;
		this.recommenderTypes = recommenderTypes;
		total.incrementAndGet();
	}

	public String getAnalyticId() {
		return analyticId;
	}

	public void setAnalyticId(String analyticId) {
		this.analyticId = analyticId;
	}

	public UserContext getUserContext() {
		return userContext;
	}

	public void setUserContext(UserContext userContext) {
		this.userContext = userContext;
	}

	public EnumSet<Recommender> getRecommenderTypes() {
		return recommenderTypes;
	}

	public void setRecommenderTypes(EnumSet<Recommender> recommenderTypes) {
		this.recommenderTypes = recommenderTypes;
	}

	public Table<Category, InteractionType, Iterable<UserInteraction>> getUserLikes() {
		return userLikes;
	}

	public void setUserLikes(Table<Category, InteractionType, Iterable<UserInteraction>> userLikes) {
		this.userLikes = userLikes;
	}

	public boolean isMinChoiceFilter() {
		return minChoiceFilter;
	}

	public void setMinChoiceFilter(boolean minChoiceFilter) {
		this.minChoiceFilter = minChoiceFilter;
	}

	public static int getMaxChoice(Category category) {
		return maxChoiceNumbers.get(category);
	}

	public static void setMaxChoice(Category category, int maxChoice) {
		maxChoiceNumbers.put(category, maxChoice);
	}

	public AtomicInteger getIndex() {
		return index;
	}

	public AtomicInteger getTotal() {
		return total;
	}

	public String getPurpose() {
		return purpose;
	}

	public String getCustomerCountry() {
		return customerCountry;
	}

	public void setCustomerCountry(String customerCountry) {
		this.customerCountry = customerCountry;
	}

	public Collection<Category> getCategories() {
		return categories;
	}

	public void setCategories(Collection<Category> categories) {
		this.categories = categories;
	}
	
}
