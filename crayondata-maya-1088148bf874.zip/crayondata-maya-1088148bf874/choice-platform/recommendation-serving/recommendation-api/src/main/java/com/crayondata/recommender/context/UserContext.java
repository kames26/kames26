/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.recommender.context;

import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.data.geo.Point;

import com.crayondata.choice.rateableitem.Category;
import com.google.common.base.Optional;
import com.google.common.collect.Maps;

public class UserContext {

    private final int userId;

    private final Date timestamp;
    private final Optional<Point> location;

    // TODO Below is actually UserCriteria, which should be in a separate class,
    // Liam
    private Map<String, List<String>> filterAttributes = Maps.newHashMap();
    private final Map<String, List<String>> keywords = Maps.newHashMap();
    private List<String> tags;
    private int maxDistanceInKm;
    private int minDistanceInKm = -1;

    private Category category;
    private Integer similarToId;

    private boolean ignoreHistoryForThisRequest;
    // TODO Above is actually UserCriteria, which should be in a separate class,
    // Liam

    public UserContext(int userId, Date timestamp, Optional<Point> location) {
        this.userId = userId;
        this.timestamp = timestamp;
        this.location = location;
    }
    
    public UserContext(int userId, Date timestamp){
        this.userId = userId;
        this.timestamp = timestamp;
        this.location = Optional.absent();
    }

    public UserContext(int userId, Date timestamp, double latitude, double longitude) {
        this.userId = userId;
        this.timestamp = timestamp;
        final Point point = new Point(latitude, longitude);
        this.location = Optional.of(point);
    }

    public List<String> getTags() {
        return tags;
    }

    public void setTags(List<String> tags) {
        this.tags = tags;
    }

    public int getUserId() {
        return userId;
    }

    public Category getCategory() {
        return category;
    }

    // public List<Integer> getLikedEntities() {
    // return likedEntities;
    // }

    // public Map<String, List<String>> getLikedAttributes() {
    // return likedAttributes;
    // }

    public Optional<Point> getLocation() {
        return this.location;
    }

    // TODO change to Distance class
    public int getMaxDistanceInKm() {
        return maxDistanceInKm;
    }

    public Map<String, List<String>> getFilterAttributes() {
        return filterAttributes;
    }

    public void setFilterAttributes(Map<String, List<String>> filterAttributes) {
        this.filterAttributes = filterAttributes;
    }

    public void setCategory(Category category) {
        this.category = category;
    }

    // public void setLikedEntities(List<Integer> likedEntities) {
    // this.likedEntities = likedEntities;
    // }

    public void setMaxDistanceInKm(int maxDistanceInKm) {
        this.maxDistanceInKm = maxDistanceInKm;
    }

    public int getMinDistanceInKm() {
        return minDistanceInKm;
    }

    public void setMinDistanceInKm(int minDistanceInKm) {
        this.minDistanceInKm = minDistanceInKm;
    }

    public Map<String, List<String>> getKeywords() {
        return keywords;
    }

    public Date getTimestamp() {
        return timestamp;
    }

    public Integer getSimilarToId() {
        return similarToId;
    }

    public void setSimilarToId(Integer similarToId) {
        this.similarToId = similarToId;
    }

    public Collection<Integer> getSessionRecommendations(Category category) {
        return Collections.emptyList();
    }

    public void setIgnoreHistoryForThisRequest(boolean ignoreHistoryForThisRequest) {
        this.ignoreHistoryForThisRequest = ignoreHistoryForThisRequest;
    }

    public boolean isIgnoreHistoryForThisRequest() {
        return ignoreHistoryForThisRequest;
    }

    @Override
    public String toString() {
        return "UserContext [userId=" + userId + ", timestamp=" + timestamp + ", location=" + location
                + ", filterAttributes=" + filterAttributes + ", keywords=" + keywords + ", tags=" + tags
                + ", maxDistanceInKm=" + maxDistanceInKm + ", minDistanceInKm=" + minDistanceInKm
                + ", category=" + category + ", similarToId=" + similarToId + ", ignoreHistoryForThisRequest="
                + ignoreHistoryForThisRequest + "]";
    }
}
