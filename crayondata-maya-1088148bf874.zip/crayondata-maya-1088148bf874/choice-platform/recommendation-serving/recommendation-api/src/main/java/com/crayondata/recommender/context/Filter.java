/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.recommender.context;

import java.util.Collections;
import java.util.List;
import java.util.Map;

public class Filter {

    public static final int REST_MAX_DISTANCE_DEF = 10;
    public static final int HOTEL_MAX_DISTANCE_DEF = 15;
    public static final int DEFAULT = 10;

    private Map<String, List<String>> attributes;

    /*private int maxDistanceInKm = Integer.MAX_VALUE;*/
    private int maxDistanceInKm = DEFAULT;

    private boolean ignoreUserProfile;

    private Integer similarToItemId;

    private List<String> tags;

    public Integer getSimilarToItemId() {
        return similarToItemId;
    }

    public void setSimilarToItemId(Integer similarToItemId) {
        this.similarToItemId = similarToItemId;
    }

    public Filter() {
        attributes = Collections.emptyMap();
    }

    public Map<String, List<String>> getAttributes() {
        return attributes;
    }

    public void setAttributes(Map<String, List<String>> attributes) {
        this.attributes = attributes;
    }

    public int getMaxDistanceInKm() {
        return maxDistanceInKm;
    }

    public void setMaxDistanceInKm(int maxDistanceInKm) {
        this.maxDistanceInKm = maxDistanceInKm;
    }

    public boolean getIgnoreUserProfile() {
        return ignoreUserProfile;
    }

    public void setIgnoreUserProfile(boolean ignoreUserProfile) {
        this.ignoreUserProfile = ignoreUserProfile;
    }

    public List<String> getTags() {
        return tags;
    }

    public void setTags(List<String> tags) {
        this.tags = tags;
    }

    @Override
    public String toString() {
        return "Filter [attributes=" + attributes + ", maxDistanceInKm=" + maxDistanceInKm
                + ", ignoreUserProfile=" + ignoreUserProfile + ", similarToItemId=" + similarToItemId
                + ", tags=" + tags + "]";
    }
}
