/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.recommender.search;

import java.util.Collection;

import org.springframework.data.geo.Distance;
import org.springframework.data.geo.Point;
import org.springframework.data.solr.core.query.FilterQuery;

import com.crayondata.choice.rateableitem.Category;
import com.crayondata.choice.userprofile.UserProfile;
import com.crayondata.recommender.context.UserContext;
import com.google.common.base.Optional;

public interface IFilterHandler {
    public Iterable<FilterQuery> generateFilterSubQuery(UserContext userContext, UserProfile userProfile,
            boolean ignoreLocationFilter);

    public FilterQuery generateCategoryFilter(Category category);

    public Optional<FilterQuery> generateJoinFilterQuery(Collection<String> tags);

    public Optional<FilterQuery> generateLocationFilterQuery(Category category, Optional<Point> location,
            Distance distance);
}