/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.recommender.search.impl;

import static com.crayondata.choice.rateableitem.Category.HOTEL;
import static com.crayondata.choice.rateableitem.Category.MOVIE;
import static com.crayondata.choice.rateableitem.Category.OTHER;
import static com.crayondata.choice.rateableitem.Category.RESTAURANT;
import static com.crayondata.choice.userprofile.UserInteraction.InteractionType.Like;
import static com.crayondata.choice.userprofile.model.CategoryAttributeStatsTracker.CategoricalAttribute.cuisines;
import static com.crayondata.choice.userprofile.model.CategoryAttributeStatsTracker.CategoricalAttribute.options;
import static com.crayondata.choice.userprofile.model.CategoryAttributeStatsTracker.CategoricalAttribute.speciality;
import static com.crayondata.recommender.search.impl.BlendingRecommenderTestData.TEST_USERID;
import static com.crayondata.recommender.search.impl.BlendingRecommenderTestData.allUserInteractions;
import static com.crayondata.recommender.search.impl.BlendingRecommenderTestData.generateUserInteractions;
import static com.crayondata.recommender.search.impl.BlendingRecommenderTestData.testHotelUserInteractions;
import static com.crayondata.recommender.search.impl.BlendingRecommenderTestData.testMovieUserInteractions;
import static com.crayondata.recommender.search.impl.BlendingRecommenderTestData.testRestaurantUserInteractions;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyInt;
import static org.mockito.Matchers.same;

import java.util.Collections;
import java.util.Date;
import java.util.EnumSet;
import java.util.List;
import java.util.Map;
import java.util.Random;

import org.apache.commons.math3.stat.Frequency;
import org.apache.commons.math3.stat.descriptive.StatisticalSummary;
import org.apache.commons.math3.stat.descriptive.SynchronizedSummaryStatistics;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.SpringApplicationContextLoader;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.crayondata.choice.rateableitem.Category;
import com.crayondata.choice.rateableitem.LocalBusiness;
import com.crayondata.choice.rateableitem.RateableItem;
import com.crayondata.choice.userprofile.IUserProfileContextHolder;
import com.crayondata.choice.userprofile.UserInteraction;
import com.crayondata.choice.userprofile.UserInteraction.InteractionType;
import com.crayondata.choice.userprofile.UserInteractionService;
import com.crayondata.choice.userprofile.UserProfile;
import com.crayondata.choice.userprofile.UserProfile.UserModels;
import com.crayondata.choice.userprofile.UserProfileContextHolder;
import com.crayondata.choice.userprofile.builder.IUserProfileBuilder;
import com.crayondata.choice.userprofile.builder.impl.RateableItemStatsBuilder.IsSpecialityFequency;
import com.crayondata.choice.userprofile.builder.impl.UserProfileBuilder;
import com.crayondata.choice.userprofile.model.AttributeWeightModel;
import com.crayondata.choice.userprofile.model.CategoryAttributeStatsTracker;
import com.crayondata.choice.userprofile.model.CategoryAttributeStatsTracker.CategoricalAttribute;
import com.crayondata.choice.userprofile.model.CategoryAttributeStatsTracker.NumericalAttribute;
import com.crayondata.choice.userprofile.model.CrayonAttributeRecommenderUserModel;
import com.crayondata.recommender.Recommender;
import com.crayondata.recommender.RecommenderScenario;
import com.crayondata.recommender.context.UserContext;
import com.crayondata.recommender.recommendation.ScoredItem;
import com.google.common.base.Optional;
import com.google.common.collect.HashBasedTable;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Table;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = RecommenderIntegrationTestConfig.class, loader = SpringApplicationContextLoader.class)
public class BlendingRecommenderIT {

    @Autowired
    private IUserProfileContextHolder<? extends UserProfile> actualContextHolder;

    @Autowired
    private BlendingRecommender recommender;

    private IUserProfileContextHolder<? extends UserProfile> mockContextHolder;

    private UserContext userContext;
    // private UserProfile userProfile;
    private UserInteractionService mockUserInteractionDao;

    private Optional<RecommenderScenario> defaultScenario = Optional.absent();

    @After
    public void tearDown() throws Exception {}

    @Test
    public void testRestaurantRecommendationQuery() {

        userContext.setCategory(Category.RESTAURANT);
        final UserProfile userProfile = /*
                                         * mockContextHolder.get(TEST_USERID);
                                         */ constructUserProfile();
        final List<ScoredItem> scoredItems = recommender.recommend(userContext, userProfile, 0,
                defaultScenario);
        checkScoredResults(scoredItems);

        Assert.assertEquals(18, scoredItems.size());
    }

    @Test
    public void testRestaurantRecommendationQueryContext() {

        userContext.setCategory(Category.RESTAURANT);
        final UserProfile userProfile = /*
                                         * mockContextHolder.get(TEST_USERID);
                                         */ constructUserProfile();
        final List<ScoredItem> scoredItems = recommender.recommend(userContext, userProfile, 0,
                Optional.of(RecommenderScenario.THINGS_TO_DO));
        checkScoredResults(scoredItems);
        Assert.assertEquals(18, scoredItems.size());
    }

    @Test
    public void testRestaurantRecommendationNoAttributeRecommender() {
        userContext.setCategory(Category.RESTAURANT);
        final UserProfile userProfile = /*
                                         * mockContextHolder.get(TEST_USERID);
                                         */ constructUserProfile();
        final EnumSet<Recommender> recommendersToUse = EnumSet
                .complementOf(EnumSet.of(Recommender.ATTRIBUTE_CATEGORICAL, Recommender.ATTRIBUTE_NUMERICAL));
        final List<ScoredItem> scoredItems = recommender.recommend(userContext, userProfile,
                recommendersToUse, Optional.absent());
        checkScoredResults(scoredItems);

        Assert.assertEquals(18, scoredItems.size());
    }

    @Test
    public void testRestaurantRecommendationQueryDiscovery() {

        userContext.setCategory(Category.RESTAURANT);
        final UserProfile userProfile = /*
                                         * mockContextHolder.get(TEST_USERID);
                                         */ constructUserProfile();
        final List<ScoredItem> scoredItems = recommender.recommend(userContext, userProfile, 0,
                Optional.of(RecommenderScenario.DISCOVERY));
        checkScoredResults(scoredItems);

        Assert.assertEquals(18, scoredItems.size());
    }

    public static final CategoryAttributeStatsTracker EMPTY_MOVIE = new CategoryAttributeStatsTracker(
            Category.RESTAURANT, Collections.emptyMap(), Collections.emptyMap());

    public static final CategoryAttributeStatsTracker EMPTY_HOTEL = new CategoryAttributeStatsTracker(
            Category.RESTAURANT, Collections.emptyMap(), Collections.emptyMap());

    private static final UserContext TEST_USER_CONTEXT = new UserContext(TEST_USERID, new Date(), 1.2806,
            103.788);

    @Test
    public void testRestaurantRecommendationForSimilarTo() {
        final UserProfile userProfile = actualContextHolder.buildTempUserProfile(TEST_USERID, RESTAURANT,
                ImmutableList.of(301575016));

        userContext.setCategory(Category.RESTAURANT);
        final List<ScoredItem> scoredItems = recommender.recommend(userContext, userProfile, 0,
                defaultScenario);

        checkScoredResults(scoredItems);

        Assert.assertEquals(18, scoredItems.size());
    }

    @Test
    public void testMovieRecommendationForSimilarTo() {
        final UserProfile userProfile = actualContextHolder.buildTempUserProfile(TEST_USERID, MOVIE,
                ImmutableList.of(200258343));

        userContext.setCategory(Category.MOVIE);
        final List<ScoredItem> scoredItems = recommender.recommend(userContext, userProfile, 0,
                defaultScenario);

        checkScoredResults(scoredItems);

        Assert.assertEquals(18, scoredItems.size());
    }

    private static void checkScoredResults(final List<ScoredItem> scoredItems) {
        Assert.assertFalse(scoredItems.isEmpty());
        scoredItems.forEach(x -> Assert.assertTrue(x.getScore() > 0));
    }
    // {fq=category:Restaurant&fq=-(id:301420300)&mQryScaleMin9=0.1&recscores=true&mQryBoost8=1.0&mQryBoost9=1.0&qn=9&wt=javabin&mQry1={!func}div(1,add(1,geodist(geo,1.281012,103.841754)))&mQryScaleMax2=0.2&mQry2={!func}recip(dist(1,aggregaterating,$LOCAL_BUSINESS_AGGREGATE_RATING),1,1,1)&minScore=1.0E-4&qt=/recommend&query=true&mQryRecommenderName2=ATTRIBUTE_NUMERICAL&mQryBoost4=1.0&mQry9={!func}abs(aggregaterating)&mQryRecommenderName1=GEOSPATIAL&mQryBoost5=1.0&mQryRecommenderName4=TGSECONDHOPDISCOVERY&mQryBoost6=1.0&mQry7={!tg+df%3Dent_popular_items+v%3D$USER_HISTORY}&sort=score+desc,aggregaterating+desc&mQryRecommenderName3=TGFIRSTHOPPOPULAR&mQryBoost7=1.0&mQry8={!tg+df%3Dent_discovery_items+v%3D$USER_HISTORY}&rows=30&mQry5={!tg+df%3Dent_niche_items+v%3D$USER_HISTORY}&mQryRecommenderName6=TGFIRSTHOPNICHE&mQryBoost1=1.0&mQryRecommenderName5=ENTERPRISETGFIRSTHOPNICHE&mQry6={!tg+df%3Dniche_items+v%3D$USER_HISTORY}&version=2&mQryBoost2=1.0&mQry3={!tg+df%3Dpopular_items+v%3D$USER_HISTORY}&mQryRecommenderName8=ENTERPRISETGSECONDHOPDISCOVERY&mQryBoost3=1.0&mQry4={!tg+df%3Ddiscovery_items+v%3D$USER_HISTORY}&mQryRecommenderName7=ENTERPRISETGFIRSTHOPPOPULAR&mQryRecommenderName9=TOPRATEDITEM&mQryScaleMin2=0.1&USER_HISTORY=301420300+301420300+301420300+301420300&multiQuery=true}
    // hits=0 hits=2180 status=400 QTime=15
    // ERROR - 2016-08-31 07:28:00.982; [ x:LocalBusiness]
    // org.apache.solr.common.SolrException

    @Autowired
    private IUserProfileBuilder profileBuilder;

    @Test
    public void testRestaurantRecommendationWithShortUserHistory() {

        userContext.setCategory(Category.RESTAURANT);

        ImmutableList<UserInteraction> emptyInteractions = ImmutableList.of();

        Table<Category, InteractionType, Iterable<UserInteraction>> testUserInteractions = HashBasedTable
                .create();
        testUserInteractions.put(Category.RESTAURANT, Like, generateUserInteractions(RESTAURANT,
                new int[] { 301420300, 301420300, 301420300, 301420300 }));
        testUserInteractions.put(Category.HOTEL, Like, emptyInteractions);
        testUserInteractions.put(Category.MOVIE, Like, emptyInteractions);

        final UserProfile userProfile = profileBuilder.build(userContext.getUserId(), testUserInteractions);
        final List<ScoredItem> scoredItems = recommender.recommend(userContext, userProfile, 0,
                defaultScenario);
        checkScoredResults(scoredItems);

        Assert.assertEquals(18, scoredItems.size());
    }

    @Test
    public void testRestaurantRecommendationWithNoInteraction() {

        userContext.setCategory(Category.RESTAURANT);

        ImmutableList<UserInteraction> emptyInteractions = ImmutableList.of();

        Map<UserModels, AttributeWeightModel> models = Maps.newHashMap();

        Table<Category, InteractionType, Iterable<UserInteraction>> emptyUserInteractions = HashBasedTable
                .create();
        emptyUserInteractions.put(Category.RESTAURANT, Like, emptyInteractions);
        emptyUserInteractions.put(Category.HOTEL, Like, emptyInteractions);
        emptyUserInteractions.put(Category.MOVIE, Like, emptyInteractions);

        UserProfile userProfile = new UserProfile(userContext.getUserId(), emptyUserInteractions, models);
        final List<ScoredItem> scoredItems = recommender.recommend(userContext, userProfile, 0,
                defaultScenario);
        checkScoredResults(scoredItems);

        Assert.assertEquals(18, scoredItems.size());
    }

    @Test
    public void testMovieRecommendationWithNoInteraction() {

        userContext.setCategory(Category.MOVIE);

        ImmutableList<UserInteraction> emptyInteractions = ImmutableList.of();

        Map<UserModels, AttributeWeightModel> models = Maps.newHashMap();

        Table<Category, InteractionType, Iterable<UserInteraction>> emptyUserInteractions = HashBasedTable
                .create();
        emptyUserInteractions.put(Category.RESTAURANT, Like, emptyInteractions);
        emptyUserInteractions.put(Category.HOTEL, Like, emptyInteractions);
        emptyUserInteractions.put(Category.MOVIE, Like, emptyInteractions);

        UserProfile userProfile = new UserProfile(userContext.getUserId(), emptyUserInteractions, models);
        final List<ScoredItem> scoredItems = recommender.recommend(userContext, userProfile, 0,
                defaultScenario);
        checkScoredResults(scoredItems);

        Assert.assertEquals(10, scoredItems.size());
    }

    @Test
    @Ignore
    public void testMovieRecommendationForList() {
        final UserProfile userProfile = constructUserProfile();

        userContext.setCategory(Category.MOVIE);
        userContext.setTags(Lists.newArrayList("POP307"));

        final List<ScoredItem> scoredItems = recommender.recommend(userContext, userProfile, 0,
                defaultScenario);
        userContext.setTags(Collections.emptyList());// TODO remove

        checkScoredResults(scoredItems);

        Assert.assertEquals(18, scoredItems.size());
    }

    @Test
    @Ignore
    public void testMovieRecommendationForListWithNoInteraction() {
        userContext.setCategory(Category.MOVIE);
        userContext.setTags(Lists.newArrayList("POP307"));

        ImmutableList<UserInteraction> emptyInteractions = ImmutableList.of();

        Map<UserModels, AttributeWeightModel> models = Maps.newHashMap();

        Table<Category, InteractionType, Iterable<UserInteraction>> emptyUserInteractions = HashBasedTable
                .create();
        emptyUserInteractions.put(Category.RESTAURANT, Like, emptyInteractions);
        emptyUserInteractions.put(Category.HOTEL, Like, emptyInteractions);
        emptyUserInteractions.put(Category.MOVIE, Like, emptyInteractions);

        UserProfile userProfile = new UserProfile(userContext.getUserId(), emptyUserInteractions, models);
        final List<ScoredItem> scoredItems = recommender.recommend(userContext, userProfile, 0,
                defaultScenario);

        userContext.setTags(Collections.emptyList());// TODO remove

        checkScoredResults(scoredItems);

        Assert.assertEquals(18, scoredItems.size());
    }

    @Test
    public void testHotelRecommendationQuery() {

        userContext.setCategory(Category.HOTEL);
        final UserProfile userProfile = /*
                                         * mockContextHolder.get(TEST_USERID);
                                         */ constructUserProfile();
        final List<ScoredItem> scoredItems = recommender.recommend(userContext, userProfile, 0,
                defaultScenario);
        checkScoredResults(scoredItems);
        Assert.assertEquals(18, scoredItems.size());

        Assert.assertEquals(11.076723F, scoredItems.get(0).getScore(), delta);
        Assert.assertEquals(6.787F, scoredItems.get(1).getScore(), delta);
        Assert.assertEquals(6.596208F, scoredItems.get(2).getScore(), delta);
        final LocalBusiness localBusiness = (LocalBusiness) scoredItems.get(3).getItem();
        Assert.assertEquals("Hotel", localBusiness.getCategory());
        Assert.assertEquals(70, localBusiness.getAggregateRating());
        Assert.assertEquals("Singapore", localBusiness.getAddressCity());
        Assert.assertEquals(1, localBusiness.getBrand());
        Assert.assertEquals(82, localBusiness.getValueRating().intValue());

        final RateableItem scoredItem2 = scoredItems.get(4).getItem();
        Assert.assertEquals("Hotel", scoredItem2.getCategory());
        Assert.assertEquals(82, scoredItem2.getAggregateRating());
    }

    private static final double delta = 0.1;

    @Test
    public void testMovieRecommendationQuery() {

        userContext.setCategory(Category.MOVIE);
        final UserProfile userProfile = /*
                                         * mockContextHolder.get(TEST_USERID);
                                         */ constructUserProfile();
        final List<ScoredItem> scoredItems = recommender.recommend(userContext, userProfile,
                EnumSet.allOf(Recommender.class), 0, true, true, defaultScenario);
        checkScoredResults(scoredItems);

        Assert.assertEquals(18, scoredItems.size());

        Assert.assertEquals(10.0F, scoredItems.get(0).getScore(), delta);
        Assert.assertEquals(9.3F, scoredItems.get(1).getScore(), delta);
        Assert.assertEquals(9.228571F, scoredItems.get(2).getScore(), delta);
        Assert.assertEquals(8.223213F, scoredItems.get(3).getScore(), delta);
        Assert.assertEquals(8.071427F, scoredItems.get(4).getScore(), delta);
        Assert.assertEquals(7.7821426F, scoredItems.get(5).getScore(), delta);
        Assert.assertEquals(200369067, scoredItems.get(5).getItem().getId());
        Assert.assertEquals(7.5336437F, scoredItems.get(6).getScore(), delta);
        Assert.assertEquals(7.3875F, scoredItems.get(7).getScore(), delta);
        Assert.assertEquals(6.9214277F, scoredItems.get(8).getScore(), delta);

        Assert.assertEquals(6.808928F, scoredItems.get(9).getScore(), delta);
        Assert.assertEquals(6.808928F, scoredItems.get(10).getScore(), delta);

        Assert.assertEquals(6.776786F, scoredItems.get(11).getScore(), delta);
        Assert.assertEquals(6.753571F, scoredItems.get(12).getScore(), delta);
    }

    /* @Test */
    public void testRestaurantRecommenderWillWorkOutsideHTTPThread() {

        userContext.setCategory(Category.RESTAURANT);
        recommender.recommend(userContext, Recommender.ALL, defaultScenario);
    }

    private static CategoryAttributeStatsTracker createRestaurantAttributeWeights() {
        final Frequency cuisinesFrequency = new Frequency();
        cuisinesFrequency.incrementValue("British", 12);
        cuisinesFrequency.incrementValue("European", 3);
        cuisinesFrequency.incrementValue("Asian", 6);
        cuisinesFrequency.incrementValue("Indian", 12);
        cuisinesFrequency.incrementValue("Chinese", 4);

        final Frequency optionsFrequency = new Frequency();
        optionsFrequency.incrementValue("Dinner", 4);
        optionsFrequency.incrementValue("Brunch", 3);
        optionsFrequency.incrementValue("Lunch", 7);

        final Frequency isSpecialityFequency = new IsSpecialityFequency();
        isSpecialityFequency.addValue(1);
        isSpecialityFequency.addValue(1);
        isSpecialityFequency.addValue(0); // TODO review this, Liam

        final Map<CategoricalAttribute, Frequency> distinctAttrCount = ImmutableMap.of(cuisines,
                cuisinesFrequency, speciality, isSpecialityFequency, options, optionsFrequency);

        final ImmutableMap<NumericalAttribute, StatisticalSummary> numericalAttributeStats = ImmutableMap.of(
                NumericalAttribute.LOCAL_BUSINESS_AGGREGATE_RATING,
                generateRandomAttributeStats()/*
                                               * , NumericalAttribute.
                                               * LOCAL_BUSINESS_AMBIENCE_RATING,
                                               * generateRandomAttributeStats(),
                                               * NumericalAttribute.
                                               * LOCAL_BUSINESS_LOCATION_RATING,
                                               * generateRandomAttributeStats(),
                                               * NumericalAttribute.
                                               * LOCAL_BUSINESS_VALUE_RATING,
                                               * generateRandomAttributeStats(),
                                               * NumericalAttribute.
                                               * LOCAL_BUSINESS_SERVICE_RATING,
                                               * generateRandomAttributeStats()
                                               */);

        return new CategoryAttributeStatsTracker(Category.RESTAURANT, numericalAttributeStats,
                distinctAttrCount);

    }

    private static StatisticalSummary generateRandomAttributeStats() {
        final Random random = new Random(12343);
        final SynchronizedSummaryStatistics statisticalSummary = new SynchronizedSummaryStatistics();
        for (int i = 0; i < 20; i++) {
            statisticalSummary.addValue(random.nextInt(100));
        }
        return statisticalSummary;
    }

    private static AttributeWeightModel constructAttributeWeightModel() {
        // TODO, lazy compute these
        Map<Category, CategoryAttributeStatsTracker> catAttrWeights = ImmutableMap.of(Category.RESTAURANT,
                createRestaurantAttributeWeights(), Category.HOTEL, createHotelAttributeWeights(),
                Category.MOVIE, createMovieAttributeWeights());

        return new CrayonAttributeRecommenderUserModel(catAttrWeights, Maps.newHashMap());
    }

    private static CategoryAttributeStatsTracker createHotelAttributeWeights() {

        final String[] testAmenities = new String[] { "No Smoking", "Room Service", "No Air Conditioner",
                "Shoeshine", "Facilities For Disabled Guests", "Fax", "Maid Service", "Ticket Service",
                "Air Conditioner", "Parking Available", "Rent Car", "Tour Help Desk", "Laundry", "Market",
                "Free Internet", "Elevator", "Newspapars", "Ski Storage", "Business Centre" };

        final Frequency amenitiesFrequency = generateRandomAttributeFrequencies(testAmenities);

        final Map<CategoricalAttribute, Frequency> distinctAttrCount = ImmutableMap
                .of(CategoricalAttribute.amenities, amenitiesFrequency);

        final ImmutableMap<NumericalAttribute, StatisticalSummary> numericalAttributeStats = ImmutableMap.of(
                NumericalAttribute.LOCAL_BUSINESS_AGGREGATE_RATING,
                generateRandomAttributeStats()/*
                                               * , NumericalAttribute.
                                               * LOCAL_BUSINESS_CLEANLINESS_RATING,
                                               * generateRandomAttributeStats(),
                                               * NumericalAttribute.
                                               * LOCAL_BUSINESS_LOCATION_RATING,
                                               * generateRandomAttributeStats(),
                                               * NumericalAttribute.
                                               * LOCAL_BUSINESS_VALUE_RATING,
                                               * generateRandomAttributeStats(),
                                               * NumericalAttribute.
                                               * LOCAL_BUSINESS_SERVICE_RATING,
                                               * generateRandomAttributeStats()
                                               */);

        return new CategoryAttributeStatsTracker(Category.HOTEL, numericalAttributeStats, distinctAttrCount);
    }

    private static CategoryAttributeStatsTracker createMovieAttributeWeights() {

        final String[] testDirectors = new String[] { "Eddie Romero", "Sam Raimi", "Michael Fields",
                "Jonathan Liebesman", "Mirra Bank", "Steven Hilliard Stern", "Sarah Harding", "Frank Todaro",
                "Yôjirô Takita" };

        final String[] testGenres = new String[] { "Action", "Adventure", "Horror", "Science fiction",
                "Fantasy", "Science Fiction", "Action", "Adventure", "Thriller", "Fantasy", "Mystery",
                "Science Fiction", "Comedy", "WorldCinema", "Art Films", "Action", "Adventure", "Fantasy",
                "Comedy", "Science Fiction", "Action", "Drama", "Thriller", "Drama", "Comedy", "Comedy",
                "Romance" };

        final String[] testActors = new String[] { "Kim Ramos", "Lenore Stevens", "Eddie Garcia",
                "John Ashley", "George Nader", "Kenneth J. Warren", "Sid Haig", "Vic Diaz",
                "Andres Centenera", "Angelo Ventura", "Patrick Wayne", "Gil Arceo", "Leigh Christian",
                "Thomas Haden Church", "Daniel Gillies", "Kathryn Bryding", "Aasif Mandvi", "Marc Vann",
                "Anne Gartland", "Mageina Tovah", "Jim Coope", "Jason Ortiz", "Donna Murphy", "Alfred Molina",
                "Carol Chaikin", "Steve Valentine", "James Franco", "Bill E. Rogers", "Tobey Maguire",
                "Robert Curtis Brown", "Joe Manganiello", "Robert Curtis-Brown", "Alan Cohn", "Tanya Sinovec",
                "Tim Maculan", "Nasir Stewart", "Theresa Russell", "Willem Dafoe", "Sonya Maddox",
                "Michael McLaughlin", "Toni Wynne", "Joe Virzi", "Dan Cummings", "Bill Nunn", "Elya Baskin",
                "Vanessa Ferlito", "Elizabeth Banks", "Dylan Baker", "Lucy Gordon", "John Paxton",
                "Austin Hendrickson", "Christina Cindrich", "Lorne Raimi", "Dean Edwards", "Stan Lee",
                "Menachem Mendel", "Boymelgreen", "Becky Ann Baker", "Margaret Laney", "Bryce Dallas Howard",
                "Edward Padilla", "Aimee Miles", "Samantha Ressler", "Henry Raimi", "Michael Papajohn",
                "Ron King", "Emilio Rivera", "Bruce Campbell", "Jessi Collins", "Menachem Mendel Boym...",
                "April D. Parker", "Paul Terrell Clayton", "Ronald King", "James Cromwell", "Rosemary Harris",
                "Andre B. Blake", "Kirsten Dunst", "Joe Bays", "Timothy Patrick Quil...", "Keith Woulard",
                "Derrick Thomas", "Carolyn Neff", "Andre Blake", "Bonnie Somerville", "Vance Hammond",
                "Dan Callahan", "Ted Raimi", "Rogelio T. Ramos", "Brooke Adams", "J.K. Simmons",
                "Joel McHale", "Taylor Hemhauser", "Emma Raimi", "Gregg L. Daniel", "Hal Fishman",
                "Mark Kubr", "Perla Haney-Jardine", "Cliff Robertson", "Tim De Zarn", "Topher Grace",
                "Mike Alexander", "Reynaldo Gellegos", "Anne Gartian", "Rey Gallegos", "Megan Mcnulty",
                "Eric Ruark", "Eben Gordon", "David Ian Lee", "Rob Humphrey", "Rob Fortunato", "Shevy Katan",
                "Erik Ruark", "Robert Humphrey", "Max Worertendyke", "Andy Waldschmidt", "Rick Birnbaum",
                "Vinnie Penn", "Tony Shalhoub", "K. Todd Freeman", "Rick Chambers", "Chris Wylde",
                "Alan Ritchson", "Johnny Knoxville", "Madison Mason", "Leyna Nguyen", "Abby Elliott",
                "Pete Ploszek", "Derek Mears", "Danny Woodburn", "Taran Killam", "Harley Pasternak",
                "Whoopi Goldberg", "Mikal A. Vega", "William Fichtner", "Jeremy Howard", "Minae Noji",
                "Venida Evans", "Paul Fitzgerald", "Will Arnett", "Braeson Herold", "Tohoru Masamune",
                "Megan Fox", "Malina Weissman", "Chance Kelly", "Noel Fisher", "Lawrence Dane",
                "Peter Dvorsky", "Gale Garnett", "Reg Dreger", "Tom Harvey", "Louis Di Bianco",
                "George Bloomfield", "Tommy Lee Jones", "R.D. Reid", "Yaphet Kotto", "Denis Simpson",
                "Dennis O'Connor", "Eric Peterson", "Carl Marotte", "Helen Shaver", "Peter Davison",
                "Niamh Cusack", "Amanda Walker", "Caroline Loncq", "Adrian Lukis", "Jax Williams",
                "Sandra Huggett", "Joseph Friend", "Heather Cameron-McLintock", "Jenny Howe",
                "Ashvin-Kumar Joshi", "Sadie Shimmin", "Patrick Pearson", "Philip Wright", "Carmen Bonafont",
                "Tibor Feldman", "Mike O'Malley", "Mary Birdsong", "Arthur J. Nascarella", "Judy Frane",
                "Phyllis Somerville", "Gene Canfield", "Jill Tracy", "J.K. Simmons", "Lenny Venito",
                "Peter Appel", "Frank Senger", "Scott Bryce", "Charles White", "Joel Wiersema",
                "Jack Farrell", "Eileen Montelione", "Toshiya Fujita", "Genjitsu Shu", "Yukiko Tachibana",
                "Miki Yoshimura", "Hakuryû", "Shozo Takagi", "Miyoko Inagawa", "Motoko Namamura",
                "Misa Shimizu", "Wuthi Kongwawet", "Masato Hagiwara", "Ittoku Kishibe", "Morio Kazama",
                "Akira Otaka", "Chiharu Kuri", "Ittoku Kishibe" };

        final Frequency genreFrequencies = generateRandomAttributeFrequencies(testGenres);
        final Frequency actorFrequencies = generateRandomAttributeFrequencies(testActors);
        final Frequency directorFrequencies = generateRandomAttributeFrequencies(testDirectors);

        final Map<CategoricalAttribute, Frequency> distinctAttrCount = ImmutableMap.of(
                CategoricalAttribute.genre, genreFrequencies, CategoricalAttribute.cast, actorFrequencies,
                CategoricalAttribute.director, directorFrequencies);

        final ImmutableMap<NumericalAttribute, StatisticalSummary> numericalAttributeStats = ImmutableMap
                .of(NumericalAttribute.LOCAL_BUSINESS_AGGREGATE_RATING, generateRandomAttributeStats());

        return new CategoryAttributeStatsTracker(Category.MOVIE, numericalAttributeStats, distinctAttrCount);
    }

    private static Frequency generateRandomAttributeFrequencies(String[] testAmenities) {
        final Random random = new Random(12343);
        final Frequency amenitiesFrequency = new Frequency();
        for (String amenity : testAmenities) {
            amenitiesFrequency.incrementValue(amenity, random.nextInt(35));
        }

        return amenitiesFrequency;
    }

    private static Map<UserModels, AttributeWeightModel> constructUserModels() {
        final AttributeWeightModel attributeWeightModel = constructAttributeWeightModel();
        Map<UserModels, AttributeWeightModel> userModels = ImmutableMap.of(
                UserModels.CrayonNumAttributeRecommender, attributeWeightModel,
                UserModels.CrayonCatAttributeRecommender, attributeWeightModel);

        return userModels;
    }

    private static Table<Category, InteractionType, Iterable<UserInteraction>> getUserInteractions() {

        Table<Category, InteractionType, Iterable<UserInteraction>> userInteractions = HashBasedTable
                .create();
        userInteractions.put(Category.RESTAURANT, Like, testRestaurantUserInteractions);
        userInteractions.put(Category.HOTEL, Like, testHotelUserInteractions);
        userInteractions.put(Category.MOVIE, Like, testMovieUserInteractions);

        return userInteractions;
    }

    private UserProfile constructUserProfile() {
        final int userId = userContext.getUserId();
        return new UserProfile(userId, getUserInteractions(), constructUserModels());
    }

    @Before
    public void setUp() throws Exception {

        this.mockUserInteractionDao = Mockito.mock(UserInteractionService.class);
        Mockito.when(mockUserInteractionDao.getAllUserInteractions()).thenReturn(allUserInteractions);
        Mockito.when(mockUserInteractionDao.getByUserIdAndItemCategoryAndType(anyInt(), same(HOTEL), any()))
                .thenReturn(testHotelUserInteractions);
        Mockito.when(mockUserInteractionDao.getByUserIdAndItemCategoryAndType(anyInt(), same(MOVIE),
                any(InteractionType.class))).thenReturn(testMovieUserInteractions);
        Mockito.when(mockUserInteractionDao.getByUserIdAndItemCategoryAndType(anyInt(), same(RESTAURANT),
                any(InteractionType.class))).thenReturn(testRestaurantUserInteractions);
        Mockito.when(mockUserInteractionDao.getByUserIdAndItemCategoryAndType(anyInt(), same(OTHER),
                any(InteractionType.class))).thenReturn(Collections.emptyList());

        final IUserProfileBuilder mockUserProfileBuilder = Mockito.mock(IUserProfileBuilder.class);

        this.mockContextHolder = new UserProfileContextHolder<>(mockUserInteractionDao,
                mockUserProfileBuilder);

        this.userContext = TEST_USER_CONTEXT;

        this.userContext.setCategory(Category.RESTAURANT);
        this.userContext.setMaxDistanceInKm(15);

        final UserProfile mockUserProfile = constructUserProfile();
        Mockito.when(mockUserProfileBuilder.build(anyInt(), any())).thenReturn(mockUserProfile);

        /*
         * this.mockContextHolder =
         * Mockito.mock(UserProfileContextHolder.class);
         * Mockito.when(mockContextHolder.get(TEST_USERID)).thenReturn(
         * constructUserProfile());
         */
    }
}
