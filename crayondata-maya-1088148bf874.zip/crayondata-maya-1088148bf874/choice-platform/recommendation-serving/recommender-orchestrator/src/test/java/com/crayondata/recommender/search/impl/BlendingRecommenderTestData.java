/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.recommender.search.impl;

import static com.crayondata.choice.userprofile.UserInteraction.InteractionType.Like;

import com.crayondata.choice.rateableitem.Category;
import com.crayondata.choice.userprofile.UserInteraction;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.Iterables;

public class BlendingRecommenderTestData {
    static final int TEST_USERID = 1234;

    static final ImmutableList<UserInteraction> testRestaurantUserInteractions = generateUserInteractions(
            Category.RESTAURANT,
            new int[] { 303613874, 300247424, 300918274, 302351074, 303966074, 301284824, 303056974,
                    300530124, 302889824, 302075074, 301421424, 301635574, 302526674, 302810174, 303878324,
                    303106024, 301508824, 302390574 });

    static final ImmutableList<UserInteraction> testHotelUserInteractions = generateUserInteractions(
            Category.HOTEL,

            new int[] { 101192894, 100106799, 100735244, 100796356, 100881493, 101527829, 100244202,
                    100738452, 100143452, 100025652, 100167902, 100875252, 100573852, 100106352, 100519202,
                    100291952, 100763652, 100951602, 101279702, 100788202, 100931652, 101492052, 101275902,
                    100913752, 100962414, 100667498, 100116064, 100648190, 101206455, 101438655, 100037410,
                    100273702, 100086709, 101378033, 100528945, 100437795, 100795570, 100756506, 100739749,
                    100969752, 101060240, 100521957, 100751469, 101378973, 101281730, 101343626, 100878820,
                    100118271, 100348168, 100451402, 101359140, 100091878, 100513616, 100990067, 100087129,
                    101598789, 100680351, 100806568, 100501533, 100814910, 100512029, 100266652, 100517876,
                    101210191, 101062032, 101370271, 100015052, 100091244, 100105362, 101277177, 100872534,
                    100586958, 101140272, 100817493, 100804961, 100684767, 101345862, 100660117, 101062032,
                    100091878, 100513616, 100990067, 100804961, 100517876, 101140272, 100817493, 100501533,
                    100814910, 100266652, 101210191, 100680351, 100806568, 100684767, 101345862, 100660117,
                    100105362, 101277177, 100872534, 100586958, 100512029, 101370271, 100087129, 101598789,
                    100015052, 100091244 });

    static final ImmutableList<UserInteraction> testMovieUserInteractions = generateUserInteractions(
            Category.MOVIE,
            new int[] { 200064693, 200258343, 200275143, 200228393, 200243343, 200333593, 200293393,
                    200197243, 200163793, 200130243, 200137743, 200111293, 200338793, 200339393, 200075843,
                    200169993, 200254043, 200360393, 200138843, 200061893 });

    static final Iterable<UserInteraction> allUserInteractions = Iterables.concat(testMovieUserInteractions,
            testHotelUserInteractions, testRestaurantUserInteractions);

    static ImmutableList<UserInteraction> generateUserInteractions(Category cat, int[] itemIds) {
        ImmutableList.Builder<UserInteraction> listBuilder = ImmutableList.builder();

        for (int id : itemIds) {
            listBuilder.add(new UserInteraction(Like, cat, TEST_USERID, id));
        }

        return listBuilder.build();
    }
}
