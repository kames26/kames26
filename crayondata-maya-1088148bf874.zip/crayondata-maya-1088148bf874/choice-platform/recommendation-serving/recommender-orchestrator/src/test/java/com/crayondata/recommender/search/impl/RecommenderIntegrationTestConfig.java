/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.recommender.search.impl;

import com.crayondata.choice.rateableitem.Category;
import static com.crayondata.choice.rateableitem.Category.HOTEL;
import static com.crayondata.choice.rateableitem.Category.MOVIE;
import static com.crayondata.choice.rateableitem.Category.OTHER;
import static com.crayondata.choice.rateableitem.Category.RESTAURANT;
import static com.crayondata.recommender.search.impl.BlendingRecommenderTestData.allUserInteractions;
import static com.crayondata.recommender.search.impl.BlendingRecommenderTestData.testHotelUserInteractions;
import static com.crayondata.recommender.search.impl.BlendingRecommenderTestData.testMovieUserInteractions;
import static com.crayondata.recommender.search.impl.BlendingRecommenderTestData.testRestaurantUserInteractions;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyInt;
import static org.mockito.Matchers.same;

import java.util.Collections;

import org.mockito.Mockito;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.FilterType;
import org.springframework.context.annotation.Primary;

import com.crayondata.choice.userprofile.UserInteraction.InteractionType;
import com.crayondata.choice.userprofile.UserInteractionService;
import com.crayondata.choice.userprofile.services.UserInteractionServiceImpl;
import com.crayondata.recommender.RecommenderScenario;
import com.crayondata.recommender.context.UserContext;
import com.crayondata.recommender.search.IRecommendBySearch;
import com.crayondata.recommender.search.IWeightsProvider;

@Configuration
@EnableAutoConfiguration
@ComponentScan(basePackages = { "com.crayondata" }, lazyInit = true, excludeFilters = {
        @ComponentScan.Filter(type = FilterType.ASSIGNABLE_TYPE, value = RecommenderWeightsProvider.class),
        @ComponentScan.Filter(type = FilterType.ASSIGNABLE_TYPE, value = UserInteractionServiceImpl.class) })
public class RecommenderIntegrationTestConfig {
    // everything done by component scan

    @Bean
    @Primary
    UserInteractionService getMockUserInteractionDao() {

        final UserInteractionService mockUserInteractionDao = Mockito.mock(UserInteractionService.class);
        Mockito.when(mockUserInteractionDao.getAllUserInteractions()).thenReturn(allUserInteractions);
        Mockito.when(mockUserInteractionDao.getByUserIdAndItemCategoryAndType(anyInt(), same(HOTEL),
                any(InteractionType.class))).thenReturn(testHotelUserInteractions);
        Mockito.when(mockUserInteractionDao.getByUserIdAndItemCategoryAndType(anyInt(), same(MOVIE),
                any(InteractionType.class))).thenReturn(testMovieUserInteractions);
        Mockito.when(mockUserInteractionDao.getByUserIdAndItemCategoryAndType(anyInt(), same(RESTAURANT),
                any(InteractionType.class))).thenReturn(testRestaurantUserInteractions);
        Mockito.when(mockUserInteractionDao.getByUserIdAndItemCategoryAndType(anyInt(), same(OTHER),
                any(InteractionType.class))).thenReturn(Collections.emptyList());
        return mockUserInteractionDao;
    }

    @Bean
    @Primary
    public IWeightsProvider getRandomWeightProvider() {
        // return new PredefinedWeightsProvider();
        return new IWeightsProvider() {
            @Override
            public RecommenderWeights provideWeights(UserContext userContext, Object userProfile,
                    Iterable<IRecommendBySearch> recommenders) {
                return new IWeightsProvider.RecommenderWeights();
            }

            @Override
            public IWeightsProvider.RecommenderWeights provideWeights(UserContext userContext,
                    Object userProfile, Iterable<IRecommendBySearch> recommenders, Category category,
                    RecommenderScenario recommenderScenario) {
                return provideWeights(userContext, userProfile, recommenders);
            }
        };
    }

}
