/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.recommender.search.impl;

import com.crayondata.choice.rateableitem.Category;
import com.crayondata.recommender.RecommenderScenario;
import com.crayondata.recommender.context.UserContext;
import com.crayondata.recommender.search.IRecommendBySearch;
import com.crayondata.recommender.search.IWeightsProvider;
import java.util.Arrays;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service(value = "PredefinedWeightsProvider")
public class PredefinedWeightsProvider implements IWeightsProvider {

    // predefined weightages - weights are in same order as in
    // com.crayondata.recommender.Recommender
    // TODO move to DB/config
    
    //TODO, changed by Liam for cold start users
    private static final float[] WT_THINGS_TO_DO_REST = { 1, 1, 1, 1, 1, 0.2f, 0, 0, 0, 0.4f };
    private static final float[] WT_THINGS_TO_DO_HOTEL = { 1, 1, 1, 1, 1, 0.2f, 0, 0, 0, 0.4f };
    
    private static final float[] WT_THINGS_TO_DO_MOVIE = { 1, 1, 1, 1, 1, 0, 0, 0, 0, 0.1f };

    private static final float[] WT_DISCOVERY_REST = { 1, 1, 1, 1, 1, 0.1f, 0, 0, 0, 0.1f };
    private static final float[] WT_DISCOVERY_HOTEL = { 1, 1, 1, 1, 1, 0, 0, 0, 0, 0.1f };
    private static final float[] WT_DISCOVERY_MOVIE = { 1, 1, 1, 1, 1, 0, 0, 0, 0, 0.1f };

    private static final float[] WT_POPULIST_REST = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 1 };
    private static final float[] WT_POPULIST_HOTEL = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 1 };
    private static final float[] WT_POPULIST_MOVIE = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 1 };

    private static final float[] WT_SIMILAR_TO_REST = { 0, 0, 0, 1, 1, 0, 0, 0, 0, 0 };
    private static final float[] WT_SIMILAR_TO_HOTEL = { 0, 0, 0, 1, 1, 0, 0, 0, 0, 0 };
    private static final float[] WT_SIMILAR_TO_MOVIE = { 0, 0, 0, 1, 1, 0, 0, 0, 0, 0 };

    private static final float[] WT_REFINEMENT_REST = { 1, 1, 1, 1, 1, 0.1f, 0, 0, 0, 0.1f };
    private static final float[] WT_REFINEMENT_HOTEL = { 1, 1, 1, 1, 1, 0.1f, 0, 0, 0, 0.1f };
    private static final float[] WT_REFINEMENT_MOVIE = { 1, 1, 1, 1, 1, 0, 0, 0, 0, 0.1f };

    private static final float[] WT_RESTAURANTS_NEAR_BY = { 0, 0, 0, 0, 0, 1, 0, 0, 0, 1 };
    private static final float[] WT_BARS_NEAR_BY = { 0, 0, 0, 0, 0, 1, 0, 0, 0, 1 };

    private static final float[] WT_FALLBACK_REST = { 0, 0, 0, 0, 0, 1, 0, 0, 0, 1 };
    private static final float[] WT_FALLBACK_HOTEL = { 0, 0, 0, 0, 0, 0.1f, 0, 0, 0, 1 };
    private static final float[] WT_FALLBACK_MOVIE = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 1 };

    private static final float[] WT_DEFAULT = { 1, 1, 1, 1, 1, 1, 1, 1, 1, 1 };
    private static final Logger logger = LoggerFactory.getLogger(PredefinedWeightsProvider.class);

    public PredefinedWeightsProvider() {}

    @Override
    public RecommenderWeights provideWeights(UserContext userContext, Object userProfile,
            Iterable<IRecommendBySearch> recommenders) {
        return provideWeights(userContext, userProfile, recommenders, Category.CROSS,
                RecommenderScenario.DEFAULT);
    }

    @Override
    public RecommenderWeights provideWeights(UserContext userContext, Object userProfile,
            Iterable<IRecommendBySearch> recommenders, Category category,
            RecommenderScenario recommenderScenario) {
        float[] weights;
        switch (category) {
        case RESTAURANT:
            weights = getWeightsForRestaurants(recommenderScenario);
            break;
        case HOTEL:
            weights = getWeightsForHotels(recommenderScenario);
            break;
        case MOVIE:
            weights = getWeightsForMovies(recommenderScenario);
            break;
        default:
            weights = WT_DEFAULT;
            logger.warn("Defaulting to weights: " + Arrays.toString(WT_DEFAULT));
            break;
        }
        return new PredefinedRecommenderWeights(weights);
    }

    private float[] getWeightsForRestaurants(RecommenderScenario scenario) {
        float[] weights;
        switch (scenario) {
        case THINGS_TO_DO:
            weights = WT_THINGS_TO_DO_REST;
            break;
        case DISCOVERY:
            weights = WT_DISCOVERY_REST;
            break;
        case POPULIST:
            weights = WT_POPULIST_REST;
            break;
        case SIMILAR_TO:
            weights = WT_SIMILAR_TO_REST;
            break;
        case REFINEMENT:
            weights = WT_REFINEMENT_REST;
            break;
        case RESTAURANTS_NEAR_BY:
            weights = WT_RESTAURANTS_NEAR_BY;
            break;
        case BARS_NEAR_BY:
            weights = WT_BARS_NEAR_BY;
            break;
        case FALLBACK:
            weights = WT_FALLBACK_REST;
            break;
        default:
            weights = WT_DEFAULT;
            logger.warn("Defaulting to weights: " + Arrays.toString(WT_DEFAULT));
            break;
        }
        return weights;
    }

    private float[] getWeightsForHotels(RecommenderScenario scenario) {
        float[] weights;
        switch (scenario) {
        case THINGS_TO_DO:
            weights = WT_THINGS_TO_DO_HOTEL;
            break;
        case DISCOVERY:
            weights = WT_DISCOVERY_HOTEL;
            break;
        case POPULIST:
            weights = WT_POPULIST_HOTEL;
            break;
        case SIMILAR_TO:
            weights = WT_SIMILAR_TO_HOTEL;
            break;
        case REFINEMENT:
            weights = WT_REFINEMENT_HOTEL;
            break;
        case FALLBACK:
            weights = WT_FALLBACK_HOTEL;
            break;
        default:
            weights = WT_DEFAULT;
            logger.warn("Defaulting to weights: " + Arrays.toString(WT_DEFAULT));
            break;
        }
        return weights;
    }

    private float[] getWeightsForMovies(RecommenderScenario scenario) {
        float[] weights;
        switch (scenario) {
        case THINGS_TO_DO:
            weights = WT_THINGS_TO_DO_MOVIE;
            break;
        case DISCOVERY:
            weights = WT_DISCOVERY_MOVIE;
            break;
        case POPULIST:
            weights = WT_POPULIST_MOVIE;
            break;
        case SIMILAR_TO:
            weights = WT_SIMILAR_TO_MOVIE;
            break;
        case REFINEMENT:
            weights = WT_REFINEMENT_MOVIE;
            break;
        case FALLBACK:
            weights = WT_FALLBACK_MOVIE;
            break;
        default:
            weights = WT_DEFAULT;
            logger.warn("Defaulting to weights: " + Arrays.toString(WT_DEFAULT));
            break;
        }
        return weights;
    }

}
