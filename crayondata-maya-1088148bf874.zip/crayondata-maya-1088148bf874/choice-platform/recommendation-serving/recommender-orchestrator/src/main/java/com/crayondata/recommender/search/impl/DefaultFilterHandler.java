/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.recommender.search.impl;

import static com.crayondata.choice.userprofile.UserInteraction.InteractionType.Collected;
import static com.crayondata.choice.userprofile.UserInteraction.InteractionType.Dislike;
import static com.crayondata.choice.userprofile.UserInteraction.InteractionType.Later;
import static com.crayondata.choice.userprofile.UserInteraction.InteractionType.Like;
import static com.crayondata.choice.userprofile.UserInteraction.InteractionType.WishList;

import java.time.Duration;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.geo.Distance;
import org.springframework.data.geo.Point;
import org.springframework.data.solr.core.query.Criteria;
import org.springframework.data.solr.core.query.FilterQuery;
import org.springframework.data.solr.core.query.Join;
import org.springframework.data.solr.core.query.SimpleFilterQuery;
import org.springframework.stereotype.Service;

import com.crayondata.choice.rateableitem.Category;
import com.crayondata.choice.userprofile.UserProfile;
import com.crayondata.recommender.context.UserContext;
import com.crayondata.recommender.search.IFilterHandler;
import com.crayondata.recommender.search.IRecommendItems;
import com.google.common.base.Optional;
import com.google.common.base.Predicate;
import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;

@Service
public class DefaultFilterHandler implements IFilterHandler {

    private static final Logger LOG = LoggerFactory.getLogger(DefaultFilterHandler.class);

    // private static final String $_RECENTLY_SEEN_ITEMS = "$" +
    // IRecommendItems.RECENTLY_SEEN_ITEMS;
    // private static final String $_RECENTLY_INTERACTED_ITEMS = "$" +
    // IRecommendItems.RECENTLY_INTERACTED_ITEMS;
    private static final String TAGS_CORE_NAME = "FilterTags";
    private static final String TAGS_FIELD_NAME = "tags";

    private final double minAcceptableFillRate;

    @Autowired
    public DefaultFilterHandler(@Value("${filter.minfillrate:0.5}") double minAcceptableFillRate) {
        this.minAcceptableFillRate = minAcceptableFillRate;
    }

    @Override
    public Iterable<FilterQuery> generateFilterSubQuery(UserContext userContext, UserProfile userProfile,
            boolean ignoreLocationFilter) {
        final Collection<FilterQuery> filterQueries = Lists.newArrayList();
        // setupTagsFilter(filterQuery);

        final FilterQuery categoryCriteria = getCategoryCriteria(userContext.getCategory());
        filterQueries.add(categoryCriteria);

        final Optional<FilterQuery> itemsToExcluedCriteria = generateExcludeItemsSubQuery(
                userContext.getCategory(), userContext.getTags(), userProfile, userContext.getTimestamp());
        if (itemsToExcluedCriteria.isPresent()) {
            filterQueries.add(itemsToExcluedCriteria.get());
        }

        //// TODO Fill rate criteria comes part of the refinement.
        //// VIVEK - It can not be part of refinement as we need to do
        //// > condition whereas we do equals condition in refinement.
        final Optional<FilterQuery> fillRateCriteria = generateFillRateSubQuery(minAcceptableFillRate);
        if (fillRateCriteria.isPresent()) {
            filterQueries.add(fillRateCriteria.get());
        }

        if (!ignoreLocationFilter) {
            final Distance distance = new Distance(userContext.getMaxDistanceInKm());
            final Optional<FilterQuery> locationCriteria = generateLocationFilterQuery(
                    userContext.getCategory(), userContext.getLocation(), distance);
            if (locationCriteria.isPresent()) {
                filterQueries.add(locationCriteria.get());
            }
            final Optional<FilterQuery> minDistanceCrit = generateMinDistanceQuery(userContext);
            if (minDistanceCrit.isPresent()) {
                filterQueries.add(minDistanceCrit.get());
            }
        }

        final Optional<FilterQuery> refinementCriteria = generateRefinementSubQuery(
                userContext.getFilterAttributes());
        if (refinementCriteria.isPresent()) {
            filterQueries.add(refinementCriteria.get());
        }

        return filterQueries;
    }

    private static FilterQuery getCategoryCriteria(Category category) {
        final String categoryFilter;
        switch (category) {
        case RESTAURANT:
            categoryFilter = "Restaurant";
            break;
        case HOTEL:
            categoryFilter = "Hotel";
            break;
        case MOVIE:
            categoryFilter = "Movie";
            break;
        case OTHER:
            categoryFilter = "Other";
            break;
        case CROSS:
            categoryFilter = "Cross";
            break;
        default:
            categoryFilter = Criteria.WILDCARD;
            break;
        }

        final Criteria categoryCriteria = Criteria.where("category").is(categoryFilter);
        return new SimpleFilterQuery(categoryCriteria);
    }

    private static Optional<FilterQuery> generateMinDistanceQuery(UserContext userContext) {
        if (!userContext.getCategory().isLocalBusiness() || userContext.getMinDistanceInKm() < 0)
            return Optional.absent();
        final Optional<Point> usersLocation = userContext.getLocation();
        if (!usersLocation.isPresent()) {
            return Optional.absent();
        }
        final Distance distance = new Distance(userContext.getMinDistanceInKm());
        final Criteria locationFilter = new Criteria("geo").within(usersLocation.get(), distance)
                .notOperator();

        return Optional.of(new SimpleFilterQuery(locationFilter));
    }

    private static Optional<FilterQuery> generateRefinementSubQuery(
            Map<String, List<String>> userSpecifiedRefinements) {
        if (userSpecifiedRefinements.isEmpty()) {
            return Optional.absent();
        }
        final FilterQuery filterQuery = new SimpleFilterQuery();
        for (Entry<String, List<String>> attributeCriteria : userSpecifiedRefinements.entrySet()) {
            final Criteria attributeValuesCriteria = Criteria.where(attributeCriteria.getKey())
                    .is(attributeCriteria.getValue());
            filterQuery.addCriteria(attributeValuesCriteria);
        }
        return Optional.of(filterQuery);
    }

    private static Optional<FilterQuery> generateExcludeItemsSubQuery(Category category,
            Collection<String> tags, UserProfile userProfile, Date choiceDate) {

        // final Collection<Integer> sessionRecommendations = // TODO
        // userContext.getSessionRecommendations(userContext.getCategory());

        final Iterable<Integer> itemsToFilterOutIfNotPopulist = userProfile.getItemsFromUserHistory(category,
                Duration.ofDays(2), choiceDate, Like, Later, WishList, Collected);

        final Iterable<Integer> itemsToAlwaysFilterOut = userProfile.getItemsFromUserHistory(category,
                Duration.ofDays(Integer.MAX_VALUE), choiceDate, Dislike);

        final Iterable<Integer> itemsFromUserHistory;
        if (isPopulist(tags)) {
            itemsFromUserHistory = itemsToAlwaysFilterOut;
        } else {
            itemsFromUserHistory = Iterables.concat(itemsToAlwaysFilterOut, itemsToFilterOutIfNotPopulist);
        }

        if (Iterables.isEmpty(itemsFromUserHistory)) {
            return Optional.absent();
        }
        return Optional
                .of(new SimpleFilterQuery(Criteria.where("id").notOperator().in(itemsFromUserHistory)));
    }

    private static Optional<FilterQuery> generateFillRateSubQuery(double minAcceptableFillRate) {
        if (minAcceptableFillRate < 0) {
            LOG.debug("Got negative min-acceptable fillrate {}. Disabling fillrate filter.",
                    minAcceptableFillRate);
            return Optional.absent();
        }
        LOG.debug("Enabling fillrate filter with condition >= {}", minAcceptableFillRate);
        final Criteria greaterThanEqual = Criteria.where("fillratescore")
                .greaterThanEqual(minAcceptableFillRate);
        return Optional.of(new SimpleFilterQuery(greaterThanEqual));
    }

    @Override
    public FilterQuery generateCategoryFilter(Category category) {
        final FilterQuery filterQuery = new SimpleFilterQuery();
        // setupTagsFilter(filterQuery);

        ///////////////
        String categoryFilter = null;
        switch (category) {
        case HOTEL:
            categoryFilter = "Hotel";
            break;
        case RESTAURANT:
            categoryFilter = "Restaurant";
            break;
        case MOVIE:
            categoryFilter = "Movie";
            break;
        default:
            break;
        }

        final Criteria categoryCriteria;
        if (categoryFilter != null) {
            categoryCriteria = Criteria.where("category").is(categoryFilter);
            filterQuery.addCriteria(categoryCriteria);
        }

        return filterQuery;
    }

    @Override
    public Optional<FilterQuery> generateJoinFilterQuery(Collection<String> tags) {
        if (tags != null && !tags.isEmpty()) {
            final FilterQuery filterQuery = new SimpleFilterQuery();
            final String joinFieldName = "id";
            final Join join = new Join.Builder(joinFieldName).fromIndex(TAGS_CORE_NAME).to(joinFieldName);
            filterQuery.setJoin(join);
            filterQuery.addCriteria(Criteria.where(TAGS_FIELD_NAME).in(tags));
            return Optional.of(filterQuery);
        }
        return Optional.absent();
    }

    @Override
    public Optional<FilterQuery> generateLocationFilterQuery(Category category, Optional<Point> location,
            Distance distance) {

        if (!category.isLocalBusiness()) {
            return Optional.absent();
        }

        if (!location.isPresent()) {
            return Optional.absent();
        }

        final Criteria locationFilter = new Criteria("geo").within(location.get(), distance);
        return Optional.of(new SimpleFilterQuery(locationFilter));
    }

    private static boolean isPopulist(Collection<String> tags) {
        if (tags == null) {
            return false;
        }
        return Iterables.any(tags, new Predicate<String>() {
            @Override
            public boolean apply(String input) {
                if (input.toLowerCase().startsWith("pop")) {
                    LOG.debug(
                            "This recommendation call is related to a POPULIST due to the presence of tag: {} ",
                            input);
                    return true;
                }
                return false;
            }
        });
    }
}
