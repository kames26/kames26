/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.recommender.search.impl;

import static com.crayondata.recommender.Recommender.ATTRIBUTE_CATEGORICAL;
import static com.crayondata.recommender.Recommender.ATTRIBUTE_NUMERICAL;

import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.stream.Collectors;

import org.apache.solr.client.solrj.SolrQuery;
import org.apache.solr.common.params.CommonParams;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Sort;
import org.springframework.data.geo.Distance;
import org.springframework.data.solr.core.QueryParsers;
import org.springframework.data.solr.core.query.Criteria;
import org.springframework.data.solr.core.query.FilterQuery;
import org.springframework.data.solr.core.query.Query;
import org.springframework.data.solr.core.query.SimpleQuery;
import org.springframework.data.solr.core.query.SimpleStringCriteria;
import org.springframework.stereotype.Service;

import com.crayondata.choice.rateableitem.Category;
import com.crayondata.choice.rateableitem.ItemScores;
import com.crayondata.choice.rateableitem.RateableItem;
import com.crayondata.choice.rateableitem.RateableItemService;
import com.crayondata.choice.userprofile.IUserProfileContextHolder;
import com.crayondata.choice.userprofile.UserProfile;
import com.crayondata.recommender.Recommender;
import com.crayondata.recommender.RecommenderScenario;
import com.crayondata.recommender.context.UserContext;
import com.crayondata.recommender.factory.SearchRecommenderFactory;
import com.crayondata.recommender.recommendation.ScoredItem;
import com.crayondata.recommender.search.IFilterHandler;
import com.crayondata.recommender.search.IRecommendBySearch;
import com.crayondata.recommender.search.IRecommendBySearch.RecommenderSearchParameters;
import com.crayondata.recommender.search.IRecommendItems;
import com.crayondata.recommender.search.IWeightsProvider;
import com.crayondata.recommender.search.IWeightsProvider.RecommenderWeights;
import com.google.common.base.Joiner;
import com.google.common.base.Optional;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.ImmutableMap.Builder;
import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

@Service
public class BlendingRecommender implements IRecommendItems {

    private static final Logger LOG = LoggerFactory.getLogger(BlendingRecommender.class);

    public static final String NUMBER_OF_QUERIES_PARAM = "qn";
    public static final String MULTI_QUERY_PREFIX = "mQry";
    public static final String MULTI_QUERY_BOOST_PREFIX = "mQryBoost";
    public static final String MULTI_QUERY_SCALE_MIN = "mQryScaleMin";
    public static final String MULTI_QUERY_SCALE_MAX = "mQryScaleMax";
    public static final String MULTI_QUERY_RECOMMENDER_NAME = "mQryRecommenderName";

    // private static final SimpleField REC_RAW_SCORES_PROJECTION = new
    // SimpleField(Scorable._RAWSCORE_FIELD);
    // private static final SimpleField REC_SCORES_PROJECTION = new
    // SimpleField(Scorable._SCORE_FIELD);
    // private static final SimpleField
    // REC_SCORES_DOCUMENT_AUGMENTING_PROJECTION = new SimpleField(
    // "[rawscores]");

    private static float DEFAULT_MIN_ITEM_SCORE = 0.0001F;

    private static final Sort REC_SORT_ORDER = new Sort(Sort.Direction.DESC, "score", "aggregaterating");

    private final Integer MAX_CHOICES;
    private static final Joiner csvJoiner = Joiner.on(" ");

    private final Collection<IRecommendBySearch> allSearchRecommenders;
    private final IFilterHandler filterHandler;
    private final IWeightsProvider recommenderWeightsProvider;
    private final RateableItemService rateableItemService;
    private final IUserProfileContextHolder<? extends UserProfile> userProfileContextHolder;
    private final SearchRecommenderFactory recommenderFactory;
    private final QueryParsers queryParsers;

    private final boolean returnIndividualRecommenderScores;

    @Autowired
    public BlendingRecommender(IFilterHandler filterHandler,
            @Qualifier("PredefinedWeightsProvider") IWeightsProvider recommenderWeightsProvider,
            SearchRecommenderFactory recommenderFactory, RateableItemService rateableItemService,
            IUserProfileContextHolder<? extends UserProfile> userProfileContextHolder,
            @Value("${api.maxchoices:18}") int maxChoices) {

        this.allSearchRecommenders = recommenderFactory.getAllRecommenders();
        this.filterHandler = filterHandler;
        this.recommenderWeightsProvider = recommenderWeightsProvider;
        this.rateableItemService = rateableItemService;
        this.userProfileContextHolder = userProfileContextHolder;
        this.recommenderFactory = recommenderFactory;
        this.MAX_CHOICES = maxChoices;

        this.queryParsers = new QueryParsers();
        this.returnIndividualRecommenderScores = true;
    }

    @Override
    public List<ScoredItem> recommend(UserContext userContext, Optional<RecommenderScenario> scenario) {
        return recommendWithRecommenders(userContext, this.allSearchRecommenders, scenario);
    }

    @Override
    public List<ScoredItem> recommend(UserContext userContext, Iterable<Recommender> recommenderTypes,
            Optional<RecommenderScenario> scenario) {
        Collection<IRecommendBySearch> recommenders = recommenderFactory.getRecommenders(recommenderTypes);
        return recommendWithRecommenders(userContext, recommenders, scenario);
    }

    @Override
    public List<ScoredItem> recommend(UserContext userContext, UserProfile userProfile, int maxChoices,
            Optional<RecommenderScenario> scenario) {
        return recommendWithRecommenders(userContext, userProfile, this.allSearchRecommenders, maxChoices,
                true, true, scenario);
    }

    @Override
    public List<ScoredItem> recommend(UserContext userContext, UserProfile userProfile,
            Iterable<Recommender> recommenderTypes, Optional<RecommenderScenario> scenario) {
        Collection<IRecommendBySearch> recommenders = recommenderFactory.getRecommenders(recommenderTypes);
        return recommendWithRecommenders(userContext, userProfile, recommenders, 0, true, true, scenario);
    }

    @Override
    public List<ScoredItem> recommendNearBy(UserContext userContext, UserProfile userProfile,
            Optional<FilterQuery> useCaseSpecificFilterQuery, Iterable<Recommender> recommendersToUse,
            Optional<RecommenderScenario> scenario) {

        final int maxChoices = MAX_CHOICES;

        final Query recCompositeSubQuery = new SimpleQuery();

        final Distance distance = new Distance(userContext.getMaxDistanceInKm());

        final Optional<FilterQuery> locationFilterQuery = filterHandler
                .generateLocationFilterQuery(userContext.getCategory(), userContext.getLocation(), distance);
        if (locationFilterQuery.isPresent()) {
            recCompositeSubQuery.addFilterQuery(locationFilterQuery.get());
        }
        if (useCaseSpecificFilterQuery.isPresent()) {
            recCompositeSubQuery.addFilterQuery(useCaseSpecificFilterQuery.get());
        }
        recCompositeSubQuery.addFilterQuery(filterHandler.generateCategoryFilter(userContext.getCategory()));
        recCompositeSubQuery.addCriteria(new Criteria());

        // addFields(userContext.getCategory(), recCompositeSubQuery);

        final Map<Recommender, Map<String, String>> queryParameters = constructSearchQuery(
                recCompositeSubQuery, userContext, userProfile,
                recommenderFactory.getRecommenders(recommendersToUse), true, scenario);
        if (queryParameters.isEmpty()) {
            LOG.debug("None of the requested recommenders(" + recommendersToUse
                    + ") can provide items, probably as there are no interations. Returning empty result set");
            return Collections.emptyList();
        }
        final ImmutableMap<String, String> queryVariableValuesForSubsitution = buildQueryVariableValuesForSubstitution(
                queryParameters, userContext, userProfile);

        final int numberRecommendersUsed = queryParameters.size();
        return retrieveItemsWithQuery(recCompositeSubQuery, userContext.getCategory(),
                queryVariableValuesForSubsitution, maxChoices, false, numberRecommendersUsed);
    }

    @Override
    public List<ScoredItem> recommend(UserContext userContext, UserProfile userProfile,
            Iterable<Recommender> recommendersToUse, int maxChoices, boolean applyMinScoreFilter,
            boolean fallBackRecommender, Optional<RecommenderScenario> scenario) {
        final Collection<IRecommendBySearch> recommenders = recommenderFactory
                .getRecommenders(recommendersToUse);
        return recommendWithRecommenders(userContext, userProfile, recommenders, maxChoices,
                applyMinScoreFilter, fallBackRecommender, scenario);
    }

    public List<ScoredItem> recommendWithRecommenders(UserContext userContext, UserProfile userProfile,
            Collection<IRecommendBySearch> recommenders, int maxChoices, boolean applyMinScoreFilter,
            boolean fallBackRecommender, Optional<RecommenderScenario> scenario) {
        if (maxChoices <= 0) {
            maxChoices = MAX_CHOICES;
        }

        final Query recCompositeSubQuery = new SimpleQuery();

        final Map<Recommender, Map<String, String>> queryParameters = constructSearchQuery(
                recCompositeSubQuery, userContext, userProfile, recommenders, fallBackRecommender, scenario);
        if (queryParameters.isEmpty()) {
            LOG.debug("None of the requested recommenders(" + recommenders
                    + ") can provide items, probably as there are no interations. Returning empty result set");
            return Collections.emptyList();
        }

        final boolean ignoreLocationFilter = (userContext.getMaxDistanceInKm() == 0);
        final Iterable<FilterQuery> filterSubQuery = filterHandler.generateFilterSubQuery(userContext,
                userProfile, ignoreLocationFilter);

        for (FilterQuery filterQuery : filterSubQuery) {
            recCompositeSubQuery.addFilterQuery(filterQuery);
        }

        final Optional<FilterQuery> joinQuery = filterHandler.generateJoinFilterQuery(userContext.getTags());
        if (joinQuery.isPresent()) {
            recCompositeSubQuery.addFilterQuery(joinQuery.get());
        }
        final ImmutableMap<String, String> queryVariableValuesForSubsitution = buildQueryVariableValuesForSubstitution(
                queryParameters, userContext, userProfile);

        final int numberRecommendersUsed = queryParameters.size();
        return retrieveItemsWithQuery(recCompositeSubQuery, userContext.getCategory(),
                queryVariableValuesForSubsitution, maxChoices, applyMinScoreFilter, numberRecommendersUsed);
    }

    private Map<Recommender, Map<String, String>> constructSearchQuery(Query combinedRecommenderSubQuery,
            UserContext userContext, UserProfile userProfile, Iterable<IRecommendBySearch> recommenders,
            boolean fallBackRecommender, Optional<RecommenderScenario> scenario) {

        final Category cat = userContext.getCategory();

        final Collection<IRecommendBySearch> recommendersClone = Lists.newArrayList(recommenders);

        final Map<IRecommendBySearch, Optional<RecommenderSearchParameters>> recommenderQueryMapping = new HashMap<>();

        for (IRecommendBySearch recommender : recommendersClone) {
            final Optional<RecommenderSearchParameters> recommenderSubQuery = recommender
                    .generateSearchSubQuery(userContext, userProfile);
            recommenderQueryMapping.put(recommender, recommenderSubQuery);
        }

        final Iterable<RecommenderSearchParameters> presentInstances = recommenderQueryMapping.values()
                .stream().filter(x -> x.isPresent()).map(x -> x.get()).collect(Collectors.toList());
        if (Iterables.isEmpty(presentInstances) && fallBackRecommender) {
            final List<IRecommendBySearch> fallbackRecommenders = new ArrayList<>();
            if (cat.isLocalBusiness() && userContext.getLocation().isPresent()) {
                fallbackRecommenders.add(recommenderFactory.getRecommender(Recommender.GEOSPATIAL));
                fallbackRecommenders.add(recommenderFactory.getRecommender(Recommender.TOPRATEDITEM));
            } else {
                fallbackRecommenders.add(recommenderFactory.getRecommender(Recommender.TOPRATEDITEM));
            }

            LOG.debug(
                    "Using {} recommender for {} category as none of the requested recommenders({}) can recommend items, probably as there are no interations.",
                    fallbackRecommenders, cat, recommenders);
            return constructSearchQuery(combinedRecommenderSubQuery, userContext, userProfile,
                    fallbackRecommenders, false, Optional.of(RecommenderScenario.FALLBACK));
        }

        final RecommenderWeights recommenderWeights;
        if (scenario.isPresent())
            recommenderWeights = recommenderWeightsProvider.provideWeights(userContext, userProfile,
                    recommendersClone, cat, scenario.get());
        else
            recommenderWeights = recommenderWeightsProvider.provideWeights(userContext, userProfile,
                    recommendersClone);

        LOG.debug("Combination label: {}", recommenderWeights.getCombinationLabel());
        LOG.debug("Combination weight: {}", recommenderWeights.getLabelWeightageString());
        recommenderWeights.normalizeWeights(recommenderQueryMapping.keySet());

        final ImmutableMap.Builder<Recommender, Map<String, String>> queryParameters = ImmutableMap.builder();
        int queryCounter = 1;
        for (Entry<IRecommendBySearch, Optional<RecommenderSearchParameters>> entry : recommenderQueryMapping
                .entrySet()) {
            final IRecommendBySearch recommender = entry.getKey();
            final Optional<RecommenderSearchParameters> recParams = entry.getValue();
            if (!recParams.isPresent()) {
                LOG.debug("Recommender {} did not return search criteria.", recommender.getName());
                continue;
            }

            final RecommenderSearchParameters recommenderSearchParameters = recParams.get();

            final SolrQuery recommenderSubQuerySolrQuery = buildSolrQuery(
                    recommenderSearchParameters.getRecommenderQuery());

            String searchQueryAsString = URLDecoder.decode(recommenderSubQuerySolrQuery.toString())
                    .substring(2);

            // if (returnIndividualRecommenderScores) {
            // combinedRecommenderSubQuery.addProjectionOnField(REC_SCORES_DOCUMENT_AUGMENTING_PROJECTION);
            // combinedRecommenderSubQuery.addProjectionOnField(REC_SCORES_PROJECTION);
            // combinedRecommenderSubQuery.addProjectionOnField(REC_RAW_SCORES_PROJECTION);
            // }

            final float recommenderBoost = recommenderWeights.get(recommender.getName());
            final String queryString = searchQueryAsString;
            final Criteria criteria = new SimpleStringCriteria(queryString);
            criteria.setPartIsOr(true);
            combinedRecommenderSubQuery.addCriteria(criteria);

            final Map<String, String> modelParameters = recommenderSearchParameters.getModelParameters();

            final Builder<String, String> recommenderQueryParams = ImmutableMap.<String, String> builder()
                    .putAll(modelParameters).put(MULTI_QUERY_PREFIX + queryCounter, queryString)
                    .put(MULTI_QUERY_BOOST_PREFIX + queryCounter, Float.toString(recommenderBoost))
                    .put(MULTI_QUERY_RECOMMENDER_NAME + queryCounter, recommender.getName().toString());

            switch (recommender.getName()) {
            case TOPRATEDITEM:
            case ATTRIBUTE_CATEGORICAL:
            case ATTRIBUTE_NUMERICAL:
                recommenderQueryParams.put(MULTI_QUERY_SCALE_MIN + queryCounter, "0.1");
                break;
            }

            if (recommender.getName() == ATTRIBUTE_CATEGORICAL) {
                recommenderQueryParams.put(MULTI_QUERY_SCALE_MAX + queryCounter, "10");
            } else if (recommender.getName() == ATTRIBUTE_NUMERICAL) {
                recommenderQueryParams.put(MULTI_QUERY_SCALE_MAX + queryCounter, "0.2");
            }

            queryParameters.put(recommender.getName(), recommenderQueryParams.build());
            queryCounter++;
        }

        return queryParameters.build();
    }

    private List<ScoredItem> retrieveItemsWithQuery(Query finalQuery, Category category,
            Map<String, String> queryVariableValuesForSubsitution, int maxChoices,
            boolean applyMinScoreFilter, int numberRecommendersUsed) {

        finalQuery.setRows(maxChoices);
        finalQuery.addSort(REC_SORT_ORDER);

        final SolrQuery solrQuery = buildSolrQuery(finalQuery);
        solrQuery.remove(CommonParams.Q);
        for (Entry<String, String> queryVariable : queryVariableValuesForSubsitution.entrySet()) {
            solrQuery.setParam(queryVariable.getKey(), queryVariable.getValue());
        }

        solrQuery.setParam(NUMBER_OF_QUERIES_PARAM, Integer.toString(numberRecommendersUsed));

        if (applyMinScoreFilter) {
            solrQuery.setParam("minScore", Float.toString(DEFAULT_MIN_ITEM_SCORE));
        }

        // Use Crayon Solr plugin
        solrQuery.setRequestHandler("/recommend");
        solrQuery.setParam("multiQuery", true);
        solrQuery.setParam("query", true);
        
        if (returnIndividualRecommenderScores) {
            solrQuery.setParam("recscores", true);
        }

        final Collection<? extends RateableItem> results = rateableItemService
                .sendRecommenderQueryToSolr(category, solrQuery);

        return computeScoredItems(results);
    }

    private SolrQuery buildSolrQuery(Query query) {
        final SolrQuery solrQuery = queryParsers.getForClass(query.getClass()).constructSolrQuery(query);
        return solrQuery;
    }

    private List<ScoredItem> computeScoredItems(Collection<? extends RateableItem> itemList) {
        final List<ScoredItem> scoredItmList = new ArrayList<>();
        for (RateableItem item : itemList) {
            final ItemScores itemScores = item.getItemScores().get();
            final Map<String, Float> recommenderScores = itemScores.getRecommenderScores();
            final Float overallScore = recommenderScores.get("overall_score");
            if (overallScore <= 0) {
                LOG.warn("Discarding item: {} as it has an overall score of zero. Recommender scores: {}",
                        item.getId(), recommenderScores);
                continue;
            }
            LOG.debug("Item: {}, scaled recommender scores: {}", item.getId(), recommenderScores);
            if (returnIndividualRecommenderScores) {
                LOG.debug("Item: {}, raw recommender scores: {}", item.getId(),
                        itemScores.getRawRecommenderScores());
            }
            final ScoredItem sItem = new ScoredItem(item, overallScore);
            scoredItmList.add(sItem);
        }
        return scoredItmList;
    }

    private static ImmutableMap<String, String> buildQueryVariableValuesForSubstitution(
            Map<Recommender, Map<String, String>> queryParameters, UserContext userContext,
            UserProfile userProfile) {

        final Iterable<Integer> likedItemsUserFromHistory = userProfile
                .getUserLikes(userContext.getCategory());
        Optional<String> userHistoryAsCsv = Optional.absent();
        if (likedItemsUserFromHistory != null && !Iterables.isEmpty(likedItemsUserFromHistory)) {
            userHistoryAsCsv = Optional.of(csvJoiner.join(likedItemsUserFromHistory));
        }
        final Map<String, String> queryVariableValuesForSubsitution = Maps.newHashMap();
        if (userHistoryAsCsv.isPresent()) {
            queryVariableValuesForSubsitution.put(USER_HISTORY, userHistoryAsCsv.get());
        }

        // final Iterable<Integer> getAllItemsInteractedWith =
        // userProfile.getItemsFromUserHistory(
        // userContext.getCategory(), Duration.ofDays(2),
        // InteractionType.values());
        // Optional<String> recentlyInteractedItemsAsCsv = Optional.absent();
        //
        // if (getAllItemsInteractedWith != null &&
        // !Iterables.isEmpty(getAllItemsInteractedWith)) {
        // recentlyInteractedItemsAsCsv =
        // Optional.of(csvJoiner.join(getAllItemsInteractedWith));
        // }

        // final Collection<Integer> recentlySeenItems = userContext
        // .getSessionRecommendations(userContext.getCategory());
        // Optional<String> recentlySeenItemsAsCsv = Optional.absent();
        //
        // if (recentlySeenItems != null && !recentlySeenItems.isEmpty()) {
        // recentlySeenItemsAsCsv =
        // Optional.of(csvJoiner.join(recentlySeenItems));
        // }

        // if (recentlyInteractedItemsAsCsv.isPresent()) {
        // queryVariableValuesForSubsitution.put(RECENTLY_INTERACTED_ITEMS,
        // recentlyInteractedItemsAsCsv.get());
        // }
        //
        // if (recentlySeenItemsAsCsv.isPresent()) {
        // queryVariableValuesForSubsitution.put(RECENTLY_SEEN_ITEMS,
        // recentlySeenItemsAsCsv.get());
        // }

        final Builder<String, String> builder = ImmutableMap.<String, String> builder();
        for (Map<String, String> recommederQuery : queryParameters.values()) {
            builder.putAll(recommederQuery);
        }
        return builder.putAll(queryVariableValuesForSubsitution).build();
    }

    private List<ScoredItem> recommendWithRecommenders(UserContext userContext,
            Collection<IRecommendBySearch> recommenders, Optional<RecommenderScenario> scenario) {

        if (userContext.isIgnoreHistoryForThisRequest()) {
            final Integer similarToItemId = userContext.getSimilarToId();
            final UserProfile tempUserProfile;
            if (similarToItemId != null) {
                tempUserProfile = userProfileContextHolder.buildTempUserProfile(userContext.getUserId(),
                        userContext.getCategory(), Collections.singleton(similarToItemId));
            } else {
                final UserProfile userProfile = userProfileContextHolder.get(userContext.getUserId());
                tempUserProfile = userProfile.mute();
            }
            // clear flag but mute for this request
            userContext.setIgnoreHistoryForThisRequest(false);
            return recommendWithRecommenders(userContext, tempUserProfile, recommenders, 0, true, true,
                    scenario);
        }
        final UserProfile userProfile = userProfileContextHolder.get(userContext.getUserId());
        return recommendWithRecommenders(userContext, userProfile, recommenders, 0, true, true, scenario);
    }
}
