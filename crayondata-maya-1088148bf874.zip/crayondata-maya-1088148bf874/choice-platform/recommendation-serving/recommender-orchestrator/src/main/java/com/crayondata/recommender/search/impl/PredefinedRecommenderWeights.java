/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.recommender.search.impl;

import com.crayondata.recommender.Recommender;
import com.crayondata.recommender.search.IWeightsProvider.RecommenderWeights;
import java.util.Arrays;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author somin
 */
public class PredefinedRecommenderWeights extends RecommenderWeights {

    private static final float DEFAULT_WEIGHT = 1;
    private static final List<Recommender> recommenderList = Arrays.asList(Recommender.values());

    private static final Logger logger = LoggerFactory.getLogger(PredefinedRecommenderWeights.class);

    private final float[] weights;

    public PredefinedRecommenderWeights(float[] weights) {
        this.weights = weights;
    }

    @Override
    public float get(Recommender recommender) {
        int recommenderIndex = recommenderList.indexOf(recommender);
        if (recommenderIndex == -1) {
            logger.warn("Unrecognized recommender {}: something went wrong", recommender);
            return 0;
        } else if (recommenderIndex < weights.length) {
            return weights[recommenderIndex];
        } else {
            logger.info("Recommender {} lies out of combination label range: {}>{}", recommender,
                    recommenderIndex, weights.length);
            logger.info("Using default weightage of {}", DEFAULT_WEIGHT);
            return DEFAULT_WEIGHT;
        }
    }

    @Override
    public String getLabelWeightageString() {
        return Arrays.toString(weights);
    }

    @Override
    public String getCombinationLabel() {
        return "Predefined";
    }

}
