/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.recommender;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.math3.stat.descriptive.SummaryStatistics;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.geo.Point;
import org.springframework.data.solr.core.query.FilterQuery;
import org.springframework.stereotype.Service;

import com.crayondata.choice.rateableitem.Category;
import com.crayondata.choice.rateableitem.ItemSummary;
import com.crayondata.choice.rateableitem.RateableItem;
import com.crayondata.choice.rateableitem.solr.LocalBusinessBean;
import com.crayondata.choice.userprofile.ChoiceCollection;
import com.crayondata.choice.userprofile.DeliveredChoice;
import com.crayondata.choice.userprofile.IUserProfileContextHolder;
import com.crayondata.choice.userprofile.RecommenderDetail;
import com.crayondata.choice.userprofile.UserProfile;
import com.crayondata.choice.userprofile.repositories.ChoiceCollectionRepo;
import com.crayondata.choice.userprofile.services.DeliveredChoiceService;
import com.crayondata.recommender.context.ChoiceContext;
import com.crayondata.recommender.context.ChoiceCriteria;
import com.crayondata.recommender.context.ChoiceRequest;
import com.crayondata.recommender.context.Filter;
import com.crayondata.recommender.context.UserContext;
import com.crayondata.recommender.recommendation.ScoredItem;
import com.crayondata.recommender.search.impl.BlendingRecommender;
import com.google.common.base.Optional;

@Service(value = "DefaultRecommenderOrchestrator")
public class RecommenderOrchestrator {
    private static final Logger LOG = LoggerFactory.getLogger(RecommenderOrchestrator.class);

    @Autowired
    private DeliveredChoiceService deliveredChoiceService;

    @Autowired
    private ChoiceCollectionRepo choiceCollectionRepo;

    @Autowired
    private IUserProfileContextHolder<? extends UserProfile> userProfileContextHolder;

    @Autowired
    private BlendingRecommender blendingRecommender;

    // TODO, we need to log choices to DB if Lifestyle is used. Need to remove
    // this requirement ASAP - Liam
    private final boolean lifestyleAppInUse = false;

    public Collection<ItemSummary> recommend(UserContext userContext, UserProfile mutedProfile,
            Iterable<Recommender> recommendersToUse, int populistMaxChoices,
            Optional<RecommenderScenario> scenario) {
        return recommend(userContext, mutedProfile, recommendersToUse, populistMaxChoices, true, scenario);
    }

    public Collection<ItemSummary> recommend(UserContext userContext, UserProfile userProfile,
            Iterable<Recommender> recommendersToUse, int maxChoices, boolean applyMinScoreFilter,
            Optional<RecommenderScenario> scenario) {
        final List<ScoredItem> scoeredItems = blendingRecommender.recommend(userContext, userProfile,
                recommendersToUse, maxChoices, applyMinScoreFilter, true, scenario);
        final ChoiceCollection choiceCollection = getChoiceCollection(scoeredItems, userContext,
                recommendersToUse);
        return constructItemSummary(choiceCollection);
    }

    public List<ItemSummary> getRecommendations(int userId, Category category, ChoiceCriteria criteria,
            boolean ignoreUserInteractions, Iterable<Recommender> recommendersToUse,
            Optional<RecommenderScenario> scenario) {
        final ChoiceContext currentContext = criteria.getCurrentContext();
        final Optional<Point> location = currentContext.getLocation();
        final UserContext userContext = new UserContext(userId, currentContext.getTimestamp(), location);
        userContext.setCategory(category);

        if (ignoreUserInteractions) {
            Integer similarToItemId = criteria.getFilter().getSimilarToItemId();
            userContext.setSimilarToId(similarToItemId);
            userContext.setIgnoreHistoryForThisRequest(true);
            criteria.getFilter().setIgnoreUserProfile(true);
        }

        setFiltersInUserContext(criteria, userContext);

        List<ScoredItem> recommendedItems = blendingRecommender.recommend(userContext, recommendersToUse,
                scenario);
        final ChoiceCollection choiceCollection = getChoiceCollection(recommendedItems, userContext,
                recommendersToUse);
        List<ItemSummary> recommendations = constructItemSummary(choiceCollection);

        return recommendations;
    }

    public List<ChoiceCollection> getRecommendations(List<ChoiceRequest> requests) {
        List<ChoiceCollection> choiceCollections = new ArrayList<>();
        // int windowSize = requests.size() / 20;
        SummaryStatistics stats = new SummaryStatistics();
        for (ChoiceRequest request : requests) {
            UserContext userContext = request.getUserContext();
            UserProfile userProfile = userProfileContextHolder.buildUserProfile(request.getUserContext()
                    .getUserId(), request.getUserLikes());

            List<ScoredItem> recommendedItems = new ArrayList<>();
            for (Category category : request.getCategories()) {
                userContext.setCategory(category);
                long startTime = System.currentTimeMillis();
                final List<ScoredItem> recommendations = blendingRecommender.recommend(userContext,
                        userProfile, request.getRecommenderTypes(), ChoiceRequest.getMaxChoice(category),
                        request.isMinChoiceFilter(), false, Optional.of(RecommenderScenario.DEFAULT));
                long timeForRequest = System.currentTimeMillis() - startTime;
                stats.addValue(timeForRequest);
                LOG.trace("{}: {}/{} | {} | {}ms | {} | {} records", request.getPurpose(),
                        request.getIndex(), request.getTotal(), request.getAnalyticId(), timeForRequest,
                        request.getRecommenderTypes(), recommendedItems.size());

                recommendedItems.addAll(recommendations);
            }
            request.getIndex().incrementAndGet();

            final ChoiceCollection choiceCollection = getChoiceCollection(recommendedItems, userContext,
                    request.getRecommenderTypes(), false);
            choiceCollections.add(choiceCollection);
        }

        if (lifestyleAppInUse) {
            final Iterator<ChoiceCollection> persistedCollectionsIter = choiceCollectionRepo.save(
                    choiceCollections).iterator();
            final List<DeliveredChoice> deliveredChoices = new ArrayList<>();
            for (int i = 0; i < choiceCollections.size(); i++) {
                final ChoiceCollection choiceCollection = choiceCollections.get(i);
                final ChoiceCollection persistedChoiceCollection = persistedCollectionsIter.next();
                choiceCollection.setId(persistedChoiceCollection.getId());

                for (DeliveredChoice choice : choiceCollection.getChoices()) {
                    choice.setChoiceCollectionId(persistedChoiceCollection.getId());
                    deliveredChoices.add(choice);
                }
            }
            deliveredChoiceService.persistDeliveredChoices(deliveredChoices);
        }

        LOG.info("Completed {} solr requests with statistics about solr query time for each request: {}",
                requests.size(), stats);

        return choiceCollections;
    }

    public List<ItemSummary> getCityLocalChoices(int userId, ChoiceCriteria criteria,
            Optional<FilterQuery> useCaseSpecificFilterQuery, Iterable<Recommender> recommendersToUse,
            Optional<RecommenderScenario> scenario) {

        final ChoiceContext currentContext = criteria.getCurrentContext();
        final Optional<Point> location = currentContext.getLocation();
        final UserContext userContext = new UserContext(userId, currentContext.getTime(), location);

        final Category category = Category.RESTAURANT;
        userContext.setCategory(category);

        setFiltersInUserContext(criteria, userContext);

        final UserProfile userProfile = userProfileContextHolder.get(userContext.getUserId());
        final UserProfile userprofile = userProfile.mute();

        final List<ScoredItem> recommendedItems = blendingRecommender.recommendNearBy(userContext,
                userprofile, useCaseSpecificFilterQuery, recommendersToUse, scenario);

        final ChoiceCollection choiceCollection = getChoiceCollection(recommendedItems, userContext,
                recommendersToUse);
        List<ItemSummary> recommendations = constructItemSummary(choiceCollection);

        return recommendations;
    }

    public void setFiltersInUserContext(ChoiceCriteria criteria, UserContext userContext) {
        Filter filter = criteria.getFilter();
        if (filter != null) {
            // filter attributes logic
            setupAttributeFilters(userContext, filter);
            userContext.setIgnoreHistoryForThisRequest(criteria.getFilter().getIgnoreUserProfile());

            userContext.setMaxDistanceInKm(filter.getMaxDistanceInKm());
            LOG.debug("Setting max distance as {}", userContext.getMaxDistanceInKm());

            setTagsInUserContext(userContext, filter);
        }
    }

    private void setTagsInUserContext(UserContext userContext, Filter filter) {
        if (userContext.getTags() == null) {
            userContext.setTags(filter.getTags());
        } else if (filter.getTags() != null) {
            userContext.getTags().addAll(filter.getTags());
        }
    }

    private static List<ItemSummary> constructItemSummary(ChoiceCollection choiceCollection) {
        int choiceBatchId = choiceCollection.getId();
        List<DeliveredChoice> choices = choiceCollection.getChoices();
        List<ItemSummary> itemSummaryList = new ArrayList<>(choices.size());
        for (DeliveredChoice choice : choices) {
            ItemSummary itemSummary = new ItemSummary(choice.getItemId(), choice.getItemName(),
                    choice.getDescription(), choice.getImage(), Category.parseCategory(choiceCollection
                            .getCategory()));
            itemSummary.setChoiceBatchId(choiceBatchId);
            itemSummary.setScore(choice.getNetScore());
            final Optional<String> explanator = ExplanationCreator.getExplanation(choice);
            if (explanator.isPresent()) {
                itemSummary.setExplanator(explanator.get());
            }
            itemSummaryList.add(itemSummary);
        }
        return itemSummaryList;
    }

    private static void setupAttributeFilters(UserContext userContext, Filter filter) {
        Map<String, List<String>> attributes = filter.getAttributes();
        if (attributes != null && !attributes.isEmpty()) {
            userContext.setFilterAttributes(attributes);
        }
    }

    private ChoiceCollection getChoiceCollection(List<ScoredItem> items, UserContext userContext,
            Iterable<Recommender> recommenders) {
        return getChoiceCollection(items, userContext, recommenders, true);
    }

    private ChoiceCollection getChoiceCollection(List<ScoredItem> items, UserContext userContext,
            Iterable<Recommender> recommenders, boolean persistedChoiceCollection) {
        ChoiceCollection choiceCollection = new ChoiceCollection();
        choiceCollection.setCategory(userContext.getCategory() != null ? userContext.getCategory().name()
                : null);
        choiceCollection.setRecommenders(recommenders.toString());
        if (persistedChoiceCollection) {
            choiceCollection = choiceCollectionRepo.save(choiceCollection);
        }
        int choiceBatchId = choiceCollection.getId() != null ? choiceCollection.getId() : 0;

        List<DeliveredChoice> deliveredChoices = new ArrayList<>(items.size());
        for (ScoredItem item : items) {
            final String locationString = userContext.getLocation().isPresent() ? userContext.getLocation()
                    .get().toString() : "Unknown";
            DeliveredChoice dChoice = new DeliveredChoice(userContext.getUserId() + "", choiceBatchId, item
                    .getItem().getId(), locationString, item.getScore(), userContext.getTimestamp(),
                    userContext.getTimestamp());
            RateableItem rateableItem = item.getItem();
            if (rateableItem != null) {
                dChoice.setCategory(rateableItem.getCategory());
                dChoice.setItemName(rateableItem.getName());
                dChoice.setDescription(rateableItem.getDescription());
                dChoice.setImage(rateableItem.getImage());

                if (rateableItem instanceof LocalBusinessBean) {
                    LocalBusinessBean localBusiness = (LocalBusinessBean) rateableItem;
                    dChoice.setHasOffer(localBusiness.hasOffer());
                    dChoice.setExternalCategory(localBusiness.getExternalCategory());
                }

                final Map<String, Float> recommenderScores = item.getRawRecommenderScores();
                if (recommenderScores != null) {
                    for (String recommenderScoreAlias : recommenderScores.keySet()) {
                        final Optional<Recommender> recommender = Recommender
                                .fromRawScoreAlias(recommenderScoreAlias);
                        if (!recommender.isPresent()) {
                            continue;
                        }

                        final RecommenderDetail recDetail = new RecommenderDetail();
                        recDetail.setRecommender(recommender.get());
                        recDetail.setScore(recommenderScores.get(recommenderScoreAlias));
                        recDetail.setWeight(0);
                        recDetail.setChoice(dChoice);
                        dChoice.getRecommenderDetails().add(recDetail);
                    }
                }
            }
            deliveredChoices.add(dChoice);
        }

        choiceCollection.getChoices().addAll(deliveredChoices);
        return choiceCollection;
    }
}
