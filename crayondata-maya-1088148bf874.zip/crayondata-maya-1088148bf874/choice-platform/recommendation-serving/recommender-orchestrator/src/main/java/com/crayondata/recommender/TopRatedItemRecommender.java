/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.recommender;

import org.springframework.data.solr.core.query.Criteria;
import org.springframework.data.solr.core.query.SimpleQuery;
import org.springframework.data.solr.core.query.SimpleStringCriteria;

import com.crayondata.choice.userprofile.UserProfile;
import com.crayondata.recommender.context.UserContext;
import com.crayondata.recommender.search.IRecommendBySearch;
import com.crayondata.recommender.search.IRecommendItems;
import com.google.common.base.Optional;

public class TopRatedItemRecommender implements IRecommendBySearch {

    private static final String format = "{!func}abs(%s)";

    @Override
    public Optional<RecommenderSearchParameters> generateSearchSubQuery(UserContext userContext,
            UserProfile userProfile) {
        final Criteria crit = new SimpleStringCriteria(
                String.format(format, IRecommendItems.RATING_FIELD_NAME));

        return Optional.of(RecommenderSearchParameters.create(new SimpleQuery(crit)));
    }

    @Override
    public Recommender getName() {
        return Recommender.TOPRATEDITEM;
    }
}
