/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.recommender;

import static com.crayondata.recommender.Recommender.ATTRIBUTE_CATEGORICAL;
import static com.crayondata.recommender.Recommender.ATTRIBUTE_NUMERICAL;
import static com.crayondata.recommender.Recommender.TGFIRSTHOPNICHE;
import static com.crayondata.recommender.Recommender.TGFIRSTHOPPOPULAR;
import static com.crayondata.recommender.Recommender.TGSECONDHOPDISCOVERY;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.crayondata.choice.userprofile.DeliveredChoice;
import com.crayondata.choice.userprofile.RecommenderDetail;
import com.google.common.annotations.VisibleForTesting;
import com.google.common.base.Optional;
import com.google.common.collect.ImmutableMap;

class ExplanationCreator {
    private static final Logger LOG = LoggerFactory.getLogger(ExplanationCreator.class);

    private static final Map<Recommender, Explanation> recommenderExplanators = ImmutableMap.of(
            TGFIRSTHOPPOPULAR, Explanation.create("This is popular among people with similar taste", 1),
            TGFIRSTHOPNICHE, Explanation.create("People with similar taste also like this", 2),
            TGSECONDHOPDISCOVERY,
            Explanation.create("People with similar taste were pleasantly surprised by these", 3),
            ATTRIBUTE_CATEGORICAL,
            Explanation.create("People with similar taste were pleasantly surprised by these", 4),
            ATTRIBUTE_NUMERICAL, Explanation.create("Because this is similar to <productName>", 5));

    @VisibleForTesting
    static Optional<String> getExplanation(final Map<String, Float> recommenderScores) {
        final Optional<Recommender> highestScoringRecommenderForThisItem = getMaxRecommender(
                recommenderScores);
        if (highestScoringRecommenderForThisItem.isPresent()) {
            return Optional.of(
                    recommenderExplanators.get(highestScoringRecommenderForThisItem.get()).getExplanator());
        }
        LOG.debug("Unable to generate recommendation explanation for scores: {}", recommenderScores);
        return Optional.absent();
    }

    static Optional<String> getExplanation(DeliveredChoice choice) {
        List<RecommenderDetail> recommenderDetails = choice.getRecommenderDetails();
        final Map<String, Float> recommenderScores = new HashMap<>();
        for (RecommenderDetail recDetail : recommenderDetails) {
            recommenderScores.put(recDetail.getRecommender().name(), recDetail.getScore());
        }

        return getExplanation(recommenderScores);
    }

    private static Integer getPriority(Recommender recommender) {
        if (recommenderExplanators.containsKey(recommender)) {
            return recommenderExplanators.get(recommender).getPriority();
        }
        LOG.warn("Unconfigured recommender: " + recommender);
        return 0; // FIXME
    }

    private static Optional<Recommender> getMaxRecommender(Map<String, Float> recommenderScores) {
        Recommender maxRecommender = null;
        double maxScore = 0;

        for (Entry<Recommender, Explanation> entry : recommenderExplanators.entrySet()) {
            Recommender currentRecommender = entry.getKey();
            final String scoreAlias = currentRecommender.getScoreAlias();
            if (!recommenderScores.containsKey(scoreAlias)) {
                continue;
            }

            double currentScore = recommenderScores.get(scoreAlias);

            if (currentScore > maxScore) {
                // new max score
                maxScore = currentScore;
                maxRecommender = currentRecommender;
            } else if (currentScore == maxScore) {
                // same as current max score, check priority
                if (getPriority(currentRecommender) < getPriority(maxRecommender)) {
                    // new recommender is of higher priority, set as max
                    // recommender
                    maxScore = currentScore;
                    maxRecommender = currentRecommender;
                }
            } else if (maxRecommender == null) {
                // first recommender in list, initialize max recommender
                maxScore = currentScore;
                maxRecommender = currentRecommender;
            }
        }
        return Optional.fromNullable(maxRecommender);
    }

    private static class Explanation {
        private final String explanator;
        private final int priority;

        static Explanation create(String explanator, int priority) {
            return new Explanation(explanator, priority);
        }

        private Explanation(String explanator, int priority) {
            this.explanator = explanator;
            this.priority = priority;
        }

        public String getExplanator() {
            return explanator;
        }

        public int getPriority() {
            return priority;
        }
    }

}
