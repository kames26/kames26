/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.recommender.factory;

import java.util.ArrayList;
import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.crayondata.recommender.CrayonCategoricalAttributeRecommender;
import com.crayondata.recommender.CrayonNumericalAttributeRecommender;
import com.crayondata.recommender.Recommender;
import com.crayondata.recommender.TasteGraphRecommender;
import com.crayondata.recommender.TopRatedItemRecommender;
import com.crayondata.recommender.geospatial.GeoSpatialSearchRecommender;
import com.crayondata.recommender.search.IRecommendBySearch;
import com.google.common.collect.ImmutableList;

@Component
public class SearchRecommenderFactoryImpl implements SearchRecommenderFactory {

    private static final String NICHE_ITEMS_FIELDNAME = "niche_items";
    private static final String POPULAR_ITEMS_FIELDNAME = "popular_items";
    private static final String DISCOVERY_ITEMS_FIELDNAME = "discovery_items";
    private static final String ENT_NICHE_ITEMS_FIELDNAME = "ent_niche_items";
    private static final String ENT_POPULAR_ITEMS_FIELDNAME = "ent_popular_items";
    private static final String ENT_DISCOVERY_ITEMS_FIELDNAME = "ent_discovery_items";

    private final IRecommendBySearch nicheTGRecommender;
    private final IRecommendBySearch popularTGRecommender;
    private final IRecommendBySearch discoveryTGRecommender;
    private final IRecommendBySearch entNicheTGRecommender;
    private final IRecommendBySearch entPopularTGRecommender;
    private final IRecommendBySearch entDiscoveryTGRecommender;

    private final IRecommendBySearch numericalAttributeRecommender;
    private final IRecommendBySearch categoricalAttributeRecommender;

    private final IRecommendBySearch geoSpatialRecommender;

    private final IRecommendBySearch topRatedItemRecommender;

    private final Collection<IRecommendBySearch> allRecommenders;

    @Autowired
    public SearchRecommenderFactoryImpl(CrayonCategoricalAttributeRecommender categoricalAttributeRecommender,
            CrayonNumericalAttributeRecommender numericalAttributeRecommender) {
        this.categoricalAttributeRecommender = categoricalAttributeRecommender;
        this.numericalAttributeRecommender = numericalAttributeRecommender;

        this.nicheTGRecommender = new TasteGraphRecommender(Recommender.TGFIRSTHOPNICHE,
                NICHE_ITEMS_FIELDNAME);
        this.popularTGRecommender = new TasteGraphRecommender(Recommender.TGFIRSTHOPPOPULAR,
                POPULAR_ITEMS_FIELDNAME);
        this.discoveryTGRecommender = new TasteGraphRecommender(Recommender.TGSECONDHOPDISCOVERY,
                DISCOVERY_ITEMS_FIELDNAME);

        this.entNicheTGRecommender = new TasteGraphRecommender(Recommender.ENTERPRISETGFIRSTHOPNICHE,
                ENT_NICHE_ITEMS_FIELDNAME);
        this.entPopularTGRecommender = new TasteGraphRecommender(Recommender.ENTERPRISETGFIRSTHOPPOPULAR,
                ENT_POPULAR_ITEMS_FIELDNAME);
        this.entDiscoveryTGRecommender = new TasteGraphRecommender(Recommender.ENTERPRISETGSECONDHOPDISCOVERY,
                ENT_DISCOVERY_ITEMS_FIELDNAME);

        this.geoSpatialRecommender = new GeoSpatialSearchRecommender();
        this.topRatedItemRecommender = new TopRatedItemRecommender();

        this.allRecommenders = ImmutableList.of(geoSpatialRecommender, nicheTGRecommender,
                popularTGRecommender, discoveryTGRecommender, entNicheTGRecommender, entPopularTGRecommender,
                entDiscoveryTGRecommender, categoricalAttributeRecommender, numericalAttributeRecommender);
    }

    @Override
    public IRecommendBySearch getRecommender(Recommender recommender) {

        IRecommendBySearch result = null;
        switch (recommender) {
        case TGFIRSTHOPNICHE:
            result = nicheTGRecommender;
            break;
        case TGFIRSTHOPPOPULAR:
            result = popularTGRecommender;
            break;
        case TGSECONDHOPDISCOVERY:
            result = discoveryTGRecommender;
            break;
        case ENTERPRISETGFIRSTHOPNICHE:
            result = entNicheTGRecommender;
            break;
        case ENTERPRISETGFIRSTHOPPOPULAR:
            result = entPopularTGRecommender;
            break;
        case ENTERPRISETGSECONDHOPDISCOVERY:
            result = entDiscoveryTGRecommender;
            break;
        case ATTRIBUTE_CATEGORICAL:
            result = categoricalAttributeRecommender;
            break;
        case ATTRIBUTE_NUMERICAL:
            result = numericalAttributeRecommender;
            break;
        case TOPRATEDITEM:
            result = topRatedItemRecommender;
            break;
        case GEOSPATIAL:
            result = geoSpatialRecommender;
            break;
        default:
            System.err.println("No such recommender:" + recommender);
            break;
        }
        return result;
    }

    @Override
    public Collection<IRecommendBySearch> getAllRecommenders() {
        return this.allRecommenders;
    }

    @Override
    public Collection<IRecommendBySearch> getRecommenders(Iterable<Recommender> recommenders) {
        Collection<IRecommendBySearch> result = new ArrayList<>();
        for (Recommender recType : recommenders) {
            result.add(getRecommender(recType));
        }

        return result;
    }

}
