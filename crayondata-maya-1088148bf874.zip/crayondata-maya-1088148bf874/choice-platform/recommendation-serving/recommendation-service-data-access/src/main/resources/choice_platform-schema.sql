DROP TABLE IF EXISTS `delivered_choice_table`;
CREATE TABLE `delivered_choice_table` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `choice_batch_id` int(11) DEFAULT NULL,
  `choiceTimestamp` datetime DEFAULT NULL,
  `item_id` int(11) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `net_score` double DEFAULT NULL,
  `timestamp` datetime DEFAULT NULL,
  `user_id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `recommender_details_table`;
CREATE TABLE `recommender_details_table` (
 `id` int(11) NOT NULL AUTO_INCREMENT,
 `choice_id` varchar(255) DEFAULT NULL,
 `rank` int(11) DEFAULT NULL,
 `recommender` varchar(255) DEFAULT NULL,
 `weight` int(11) DEFAULT NULL,
 PRIMARY KEY (`id`)
 )ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;