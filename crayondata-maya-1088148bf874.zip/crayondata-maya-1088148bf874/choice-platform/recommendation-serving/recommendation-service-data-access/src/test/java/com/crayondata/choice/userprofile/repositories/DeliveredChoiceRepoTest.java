/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.choice.userprofile.repositories;

import static org.junit.Assert.assertEquals;

import java.util.Calendar;
import java.util.Iterator;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.crayondata.choice.userprofile.DeliveredChoice;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:hsql-test-context.xml" })
public class DeliveredChoiceRepoTest {

    @Autowired
    DeliveredChoiceRepo repo;

    private DeliveredChoice record1;
    private DeliveredChoice record2;
    private DeliveredChoice record3;

    @Before
    public void setup() {
        record1 = new DeliveredChoice();
        record1.setChoiceCollectionId(1);
        record1.setUserId("user 1");
        record1.setItemId(1);

        record2 = new DeliveredChoice();
        record2.setChoiceCollectionId(1);
        record2.setUserId("user 2");
        record2.setItemId(2);

        record3 = new DeliveredChoice();
        record3.setChoiceCollectionId(1);
        record3.setUserId("user 3");
        record3.setItemId(3);

        repo.deleteAll();
        assertEquals(0, repo.count());
    }

    @Test
    public void testSaveAndRetrieveBack() {
        record1 = repo.save(record1);
        assertEquals(1, repo.count());

        record2 = repo.save(record2);
        record3 = repo.save(record3);
        assertEquals(3, repo.count());

        record1 = repo.save(record1);
        assertEquals(3, repo.count());

        Iterator<DeliveredChoice> allDataInter = repo.findAll().iterator();
        assertEquals("user 1", allDataInter.next().getUserId());
        assertEquals("user 2", allDataInter.next().getUserId());
        assertEquals("user 3", allDataInter.next().getUserId());
    }
}
