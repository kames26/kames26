/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.engageapp.controller;

import com.crayondata.maya.choice.ChoiceAPI;
import com.crayondata.maya.choice.UserAPI;
import com.crayondata.maya.choice.service.ChoiceControllerService;
import com.crayondata.maya.choice.service.RequestValidationService;
import com.crayondata.maya.data.access.util.JsonUtils;
import com.crayondata.maya.data.model.campaign.Campaign;
import com.crayondata.maya.data.model.entity.Choices;
import com.crayondata.maya.data.model.entity.Item;
import com.crayondata.maya.model.api.InteractRequest;
import com.crayondata.maya.model.api.ItemRequest;
import com.crayondata.maya.model.api.ItemResponse;
import com.crayondata.maya.model.common.Interaction;
import com.crayondata.maya.model.enums.CampaignType;
import com.crayondata.maya.model.rest.CampaignResponse;
import com.crayondata.maya.model.rest.ChoiceRequest;
import com.crayondata.maya.model.rest.Response;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import java.util.HashMap;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import springfox.documentation.annotations.ApiIgnore;

/**
 * Engage App Rest API Consumer Class.
 *
 * @author mano
 *
 */
@RestController
@CrossOrigin
@RequestMapping("/api/v2/")
@Api(tags = "Choice API", description = "To retrieve choices and to interact with it")
public class EngageAppChoiceController {

    private static final Logger LOGGER = LoggerFactory.getLogger(EngageAppChoiceController.class);

    @Autowired
    private ChoiceAPI choiceApi;

    @Autowired
    private JsonUtils json;

    @Autowired
    private ChoiceControllerService choiceControllerService;

    @Autowired
    private RequestValidationService requestValidationService;

    @Autowired
    private UserAPI userApi;

    private final HttpHeaders headers;

    /**
     * Initialize the controller.
     *
     */
    public EngageAppChoiceController() {
        headers = new HttpHeaders();
        initHttpHeaders();

    }

    private void initHttpHeaders() {
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.set("Authorization", "auth");
        headers.set("User-Access-Token", "abcdef");
    }

    /*@RequestMapping("/getName")
    public String displayName(@RequestParam String userName) {
        return userName;
    }*/

    /**
     * Method to fetch the choices for give choice request payload.
     *
     * @param accessToken
     *            for input request
     * @param request
     *            as body
     * @param headers
     *            for input request
     * @return choices
     */
    @ApiResponses({ @ApiResponse(code = 200, message = "Choices returned", response = Choices.class),
            @ApiResponse(code = 404, message = "Not Found", response = Response.class) })
    @RequestMapping(value = "choices", method = RequestMethod.POST, produces = "application/json", consumes = "application/json")
    @ApiOperation(value = "Get choices for a user based on context and filters")
    public ResponseEntity<?> getChoices(
            @RequestHeader(value = "User-Access-Token", required = true) String accessToken,
            @RequestBody(required = true) ChoiceRequest request,
            @ApiIgnore(value = "This parameter will be auto populated with header details."
                    + " Should not expose in Swagger") @RequestHeader MultiValueMap<String, String> headers) {
        long startTime = System.nanoTime();
        LOGGER.debug("Choice request for user: {} before Validation: {}", accessToken, request);
        request = requestValidationService.validate(request);
        LOGGER.debug("Choice request for user: {} after Validation: {}", accessToken, request);

        com.crayondata.maya.model.api.ApiResponse<Choices> choices = choiceControllerService
                .formChoiceRequest(request, accessToken, headers);
        LOGGER.debug("/choices completed with {} ms ", (System.nanoTime() - startTime) / 1000000);
        switch (choices.getStatus()) {
        case SUCCESS:
            return new ResponseEntity<>(asChoicesJson(choices.getResponse()), HttpStatus.OK);
        case NOT_FOUND:
            return new ResponseEntity<>(new Response(404, choices.getMessage()), HttpStatus.NOT_FOUND);
        case BAD_REQUEST:
            return new ResponseEntity<>(Response.BAD_REQUEST, HttpStatus.NOT_FOUND);
        case ERROR:
        default:
            return new ResponseEntity<>(Response.FAILURE, HttpStatus.INTERNAL_SERVER_ERROR);
        }

    }

    /**
     * method to fetch the items for given item Id.
     *
     * @param itemId
     *            for the requested item
     * @param accessToken
     *            as header request
     * @return items
     */
    @ApiResponses({ @ApiResponse(code = 200, message = "Get Item", response = Item.class) })
    @RequestMapping(value = "items/{itemId}", produces = "application/json", method = RequestMethod.GET)
    @ApiOperation(value = "Get details of an item recommended in choice")
    public ResponseEntity<?> getItems(@PathVariable(required = true) String itemId,
            @RequestHeader(value = "User-Access-Token", required = true) String accessToken) {
        ItemRequest itemRequest = new ItemRequest(accessToken, itemId);
        ItemResponse itemResponse = choiceApi.getItem(itemRequest);
        if (itemResponse.hasItem()) {
            return new ResponseEntity<>(itemResponse.getItem(), HttpStatus.OK);
        }
        if (itemResponse.isError()) {
            return new ResponseEntity<>(Response.FAILURE, HttpStatus.INTERNAL_SERVER_ERROR);
        }

        return new ResponseEntity<>(Response.NOT_FOUND, HttpStatus.NOT_FOUND);

    }

    /**
     * Method to fetch the user interactions.
     *
     * @param accessToken
     *            for the interactions
     * @param interaction
     *            as request body
     * @return userIntetactions.
     */
    @ApiResponses({ @ApiResponse(code = 200, message = "Interact") })
    @ApiOperation(value = "Interact on an item recommended in choice")
    @RequestMapping(value = "interact", produces = "application/json", consumes = "application/json", method = RequestMethod.POST)
    public ResponseEntity<Response> userInteraction(
            @RequestHeader(value = "User-Access-Token", required = true) String accessToken,
            @RequestBody(required = true) Interaction interaction) {
        InteractRequest request = new InteractRequest(accessToken, interaction);
        com.crayondata.maya.model.api.ApiResponse<Boolean> response = choiceApi.interact(request);
        switch (response.getStatus()) {
        case SUCCESS:
            return new ResponseEntity<>(Response.SUCCESS, HttpStatus.OK);
        case BAD_REQUEST:
            return new ResponseEntity<>(Response.BAD_REQUEST, HttpStatus.BAD_REQUEST);
        case NOT_FOUND:
            return new ResponseEntity<>(Response.NOT_FOUND, HttpStatus.NOT_FOUND);
        case ERROR:
        default:
            return new ResponseEntity<>(Response.FAILURE, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * Rest Consumer for User Campaign.
     *
     * @param campaignUserId
     *            for userCampaign
     * @param campaignType
     *            for userCampaign
     * @return userCampaigns
     */
    @ApiResponses({ @ApiResponse(code = 200, message = "User Campaigns", response = Campaign.class) })
    @RequestMapping(value = "campaigns", produces = "application/json", method = RequestMethod.GET)
    @ApiOperation(value = "Get campaigns for user")
    public ResponseEntity<?> userCampaign(
            @RequestHeader(value = "User-Access-Token", required = true) String userId,
            @RequestParam(value = "campaignUserId", required = false) String campaignUserId,
            @RequestParam(value = "campaignType", required = false) CampaignType campaignType) {

        com.crayondata.maya.model.api.CampaignResponse response = userApi.getCampaigns(userId, campaignUserId,
                campaignType);
        if (response.hasCampaigns()) {
            CampaignResponse response2 = new CampaignResponse(response.getCampaigns());
            return new ResponseEntity<>(response2, HttpStatus.OK);
        }

        if (response.isError()) {
            return new ResponseEntity<>(Response.FAILURE, HttpStatus.INTERNAL_SERVER_ERROR);
        }

        return new ResponseEntity<>(Response.NOT_FOUND, HttpStatus.NOT_FOUND);
    }

    /**
     * Rest Consumer for User Likes.
     *
     * @param userId
     *            for user likes
     * @return user likes
     */
    @RequestMapping(value = "likes", produces = "application/json", method = RequestMethod.GET)
    public ResponseEntity<?> userLikes(
            @RequestHeader(value = "User-Access-Token", required = true) String userId) {
        com.crayondata.maya.model.api.ChoiceResponse response = userApi.getLikes(userId);
        if (response.hasChoices()) {
            return new ResponseEntity<>(response.getChoices(), HttpStatus.OK);
        }
        if (response.isError()) {
            return new ResponseEntity<>(Response.FAILURE, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return new ResponseEntity<>(Response.NOT_FOUND, HttpStatus.NOT_FOUND);
    }

    private JsonNode asChoicesJson(Choices choices) {
        ObjectNode node = (ObjectNode) json.asJsonNode(choices);
        ArrayNode items = (ArrayNode) node.get("items");
        for (JsonNode item : items) {
            ObjectNode objectNode = (ObjectNode) item;
            ObjectNode itemJson = (ObjectNode) objectNode.remove("item");
            ObjectNode scoredItemJson = (ObjectNode) objectNode.remove("scoredItem");
            objectNode.setAll(itemJson);
            objectNode.setAll(scoredItemJson);
            objectNode.remove("itemId");
            objectNode.set("liked", objectNode.remove("liked"));
        }
        movePropertiesOut(json, items);
        return node;
    }

    private static void movePropertiesOut(JsonUtils json, ArrayNode items) {
        // items.iterator().forEachRemaining(item ->
        // movePropertiesOut((ObjectNode) item));
        items.forEach(item -> mapLocationsToOffers(json, (ObjectNode) item));
        items.forEach(item -> movePropertiesOut(json, (ObjectNode) item));
    }

    private static void movePropertiesOut(JsonUtils json, ObjectNode item) {
        json.moveObjectPropertiesUp(item);
        JsonNode offers = item.get("offers");
        if (offers != null && offers instanceof ArrayNode) {
            json.moveArrayPropertiesUp((ArrayNode) offers);
        }
    }

    private static void mapLocationsToOffers(JsonUtils json, ObjectNode item) {
        Map<String, JsonNode> locMap = new HashMap<>();
        JsonNode locations = item.get("locations");
        if (locations != null && locations.isArray()) {
            locations.forEach(loc -> locMap.put(loc.get("id").asText(), loc));
            for (JsonNode location : locations) {
                ObjectNode loc = (ObjectNode) location;
                loc.remove("offers");
                String key = loc.get("id").asText();
                loc.remove("id");
                locMap.put(key, loc);
            }
        }

        JsonNode offers = item.get("offers");
        ArrayNode newOffers = json.newArrayNode();
        if (offers != null && offers.isArray()) {
            for (JsonNode offer : offers) {
                if (offer.get("locations") != null && !offer.get("locations").isNull()) {
                    ArrayNode offerLoc = (ArrayNode) offer.get("locations");
                    ArrayNode newOfferLoc = json.newArrayNode();
                    offerLoc.forEach(locStr -> newOfferLoc.add(locMap.get(locStr.asText())));
                    ObjectNode newOffer = json.newObjectNode();
                    newOffer.setAll((ObjectNode) offer);
                    newOffer.set("locations", newOfferLoc);
                    newOffers.add(newOffer);
                } else {
                    newOffers.add(offer);
                }
            }
        }
        item.set("offers", newOffers);
        item.remove("locations");
    }
}
