/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.engageapp.filters;

import java.io.IOException;
import java.time.OffsetDateTime;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AccessLogFilter implements Filter {

    private static final Logger LOGGER = LoggerFactory.getLogger(AccessLogFilter.class);

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
        throws IOException, ServletException {
        long start = System.currentTimeMillis();
        chain.doFilter(request, response);
        HttpServletRequest servletRequest = ((HttpServletRequest) request);
        String path = servletRequest.getMethod() + " " + servletRequest.getRequestURI();
        int status = ((HttpServletResponse) response).getStatus();
        OffsetDateTime timestamp = OffsetDateTime.now();
        LOGGER.info("{\"@timestamp\":\"{}\",\"path\":\"{}\",\"status\": {},\"timeTaken\": {}}",
            timestamp, path, status, System.currentTimeMillis() - start);
    }

    @Override
    public void destroy() {
    }

}
