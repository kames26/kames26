/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.engageapp.controller;

import com.crayondata.maya.choice.UserAPI;
import com.crayondata.maya.data.model.campaign.Campaign;
import com.crayondata.maya.model.enums.CampaignType;
import com.crayondata.maya.model.rest.CampaignResponse;
import com.crayondata.maya.model.rest.Response;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

@CrossOrigin
public class EngageAppUserController {

    @Autowired
    private UserAPI userApi;

    /**
     * Method to fetch the user campaign.
     *
     * @param userId for the campaign
     * @param campaignUserId for the campaign
     * @param campaignType for the campaign
     * @return campaigns
     */
    @ApiResponses({
        @ApiResponse(code = 200, message = "User Campaigns", response = Campaign.class)})
    @RequestMapping(value = "campaigns", produces = "application/json", method = RequestMethod.GET)
    @ApiOperation(value = "Get campaigns for user")
    public ResponseEntity<?> userCampaigns(
        @RequestHeader(value = "User-Access-Token", required = true) String userId,
        @RequestParam(value = "campaignUserId", required = false) String campaignUserId,
        @RequestParam(value = "campaignType", required = false) CampaignType campaignType) {

        com.crayondata.maya.model.api.CampaignResponse response = userApi.getCampaigns(userId,
            campaignUserId, campaignType);
        if (response.hasCampaigns()) {
            CampaignResponse response2 = new CampaignResponse(response.getCampaigns());
            return new ResponseEntity<>(response2, HttpStatus.OK);
        }

        if (response.isError()) {
            return new ResponseEntity<>(Response.FAILURE, HttpStatus.INTERNAL_SERVER_ERROR);
        }

        return new ResponseEntity<>(Response.NOT_FOUND, HttpStatus.NOT_FOUND);
    }

    /**
     * Method to fetch the userLikes.
     *
     * @param userId as input
     * @return yes if liked no otherwise
     */
    @RequestMapping(value = "likes", produces = "application/json", method = RequestMethod.GET)
    public ResponseEntity<?> userLikes(
        @RequestHeader(value = "User-Access-Token", required = true) String userId) {
        com.crayondata.maya.model.api.ChoiceResponse response = userApi.getLikes(userId);
        if (response.hasChoices()) {
            return new ResponseEntity<>(response.getChoices(), HttpStatus.OK);
        }
        if (response.isError()) {
            return new ResponseEntity<>(Response.FAILURE, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return new ResponseEntity<>(Response.NOT_FOUND, HttpStatus.NOT_FOUND);
    }

}
