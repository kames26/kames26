/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.engageapp.service;

import com.crayondata.engageapp.model.Search;
import com.crayondata.engageapp.utils.ResponseJsonUtil;
import com.crayondata.maya.data.access.DataAccessService;
import com.crayondata.maya.data.access.util.JsonUtils;
import com.crayondata.maya.data.entity.ItemService;
import com.crayondata.maya.data.model.entity.Item;
import com.crayondata.maya.data.model.profile.UserProfile;
import com.crayondata.maya.data.profile.InteractionService;
import com.crayondata.maya.data.profile.UserProfileService;
import com.crayondata.maya.model.common.GeoCode;
import com.crayondata.maya.model.enums.InteractionType;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class EngageAppDataService {

    private static final Logger LOGGER = LoggerFactory.getLogger(EngageAppDataService.class);

    @Value("${choice.list.maxcount}")
    private int maxCount;

    @Autowired
    private ItemService itemService;

    @Autowired
    private JsonUtils jsonUtils;

    @Autowired
    private UserProfileService userProfileService;

    @Autowired
    private InteractionService interactionService;

    /**
     * Method to fetch the interaction type for search api.
     *
     * @param merchantList List of merchants
     * @param accessToken Token representing user
     * @param search Search request
     * @return search API response with boolean tag(liked)
     */
    public List<JsonNode> getSearchInteraction(List<Item> merchantList, String accessToken,
        Search search) {
        Set<String> intrIdSet = new HashSet<>();
        String userId = accessToken;
        JsonNode responseObject;
        List<JsonNode> searchResponseObject = new ArrayList<>();
        for (Item singleItem : merchantList) {
            intrIdSet.add(singleItem.getId());
        }
        UserProfile dynamicUserProfile = userProfileService.getDynamicUserProfile(userId);
        userId = userProfileService.getUseableUserId(dynamicUserProfile);
        Set<String> liked = interactionService.getExistingInteractions(userId, intrIdSet,
            InteractionType.LIKE);
        if (liked != null) {
            for (Item item : merchantList) {
                responseObject = jsonUtils.asJsonNode(item);
                ((ObjectNode) responseObject).put("liked", liked.contains(item.getId()));
                ResponseJsonUtil.reformatItemJson(jsonUtils, (ObjectNode) responseObject);
                searchResponseObject.add(responseObject);
            }
        }
        return searchResponseObject;
    }

    /**
     * Gets items within a particular distance from the given location, having at-least one of the
     * tags mentioned.
     *
     * @param search Search query representing the location, distance and tags
     * @return List of Items matching the given tags, within the given distance
     */
    public List<Item> getItemsByDistanceAndTags(Search search) {
        List<Item> itemsList = Collections.emptyList();
        if (search != null && search.getLocation() != null) {
            com.crayondata.engageapp.model.GeoCode geoCode = search.getLocation().getGeoCode();
            GeoCode geoCode1 = new com.crayondata.maya.model.common.GeoCode(
                Double.toString(geoCode.getLatitude()), Double.toString(geoCode.getLongitude()));
            double distanceInKms = search.getLocation().getDistanceInKms();
            itemsList = itemService.getItemsNearBy(geoCode1, (int) Math.ceil(distanceInKms));
            LOGGER.debug("Got {} items for Geocode {}", itemsList.size(), geoCode1);

            List<String> inputTags = search.getTags();
            if (inputTags != null && !inputTags.isEmpty()) {
                itemsList.removeIf(i -> {
                    List<String> tags = i.getTags();
                    if (tags == null || tags.isEmpty()) {
                        return true;
                    }
                    return Collections.disjoint(tags, inputTags);
                });
            }
            LOGGER.debug("After filtering tags: {} records", itemsList.size());
            int count = search.getMaxCount();
            count = count > maxCount ? maxCount : count;
            count = count > itemsList.size() ? itemsList.size() : count;
            itemsList = itemsList.subList(0, count);
            LOGGER.debug("After limit: {} records", itemsList.size());
        }
        return itemsList;
    }
}
