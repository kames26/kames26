/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.engageapp.service;

import com.crayondata.maya.data.model.entity.Choices;
import com.crayondata.maya.model.api.ApiResponse;
import com.crayondata.maya.model.rest.Response;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;


@Component
public class HttpResponseBuilder {
    /**
     * Method for the API response return status.
     * @param apiResponse as a body
     * @return response status
     */
    public ResponseEntity<?> buildResponseEntity(ApiResponse<?> apiResponse) {
        switch (apiResponse.getStatus()) {
            case SUCCESS:
                Object response = apiResponse.getResponse();
                if (response instanceof Choices) {
                    return new ResponseEntity<>(apiResponse.getResponse(), HttpStatus.OK);
                } else {
                    return new ResponseEntity<>(apiResponse.getResponse(), HttpStatus.OK);
                }
            case BAD_REQUEST:
                if (apiResponse.getMessage() != null) {
                    return new ResponseEntity<>(new Response(400, apiResponse.getMessage()),
                        HttpStatus.BAD_REQUEST);
                } else {
                    return new ResponseEntity<>(Response.BAD_REQUEST, HttpStatus.BAD_REQUEST);
                }
            case NOT_FOUND:
                if (apiResponse.getMessage() != null) {
                    return new ResponseEntity<>(new Response(404, apiResponse.getMessage()),
                        HttpStatus.NOT_FOUND);
                } else {
                    return new ResponseEntity<>(Response.NOT_FOUND, HttpStatus.NOT_FOUND);
                }
            case ERROR:
            default:
                if (apiResponse.getMessage() != null) {
                    return new ResponseEntity<>(new Response(500, apiResponse.getMessage()),
                        HttpStatus.INTERNAL_SERVER_ERROR);
                } else {
                    return new ResponseEntity<>(Response.FAILURE, HttpStatus.INTERNAL_SERVER_ERROR);
                }
        }
    }
}

