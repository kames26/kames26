/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.engageapp.controller;

import com.crayondata.engageapp.model.GeoCode;
import com.crayondata.engageapp.model.Search;
import com.crayondata.engageapp.model.SearchResponse;
import com.crayondata.engageapp.service.EngageAppDataService;
import com.crayondata.maya.data.model.entity.Item;
import com.crayondata.maya.model.rest.Response;
import com.fasterxml.jackson.databind.JsonNode;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import java.util.ArrayList;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin
@RequestMapping("/api/merchant/")
public class SearchController {

    private static final Logger logger = LoggerFactory.getLogger(SearchController.class);

    @Autowired
    private EngageAppDataService engageAppService;

    /**
     * API end point to fetch the merchants for given tags.
     *
     * @param search Request body containing filters for the merchants
     * @param accessToken Token representing the User for whom merchants are requested
     * @return list of merchants
     */
    @ApiResponses({
        @ApiResponse(code = 200, message = "Items search", response = SearchResponse.class),
        @ApiResponse(code = 404, message = "Not found", response = Response.class)})
    @RequestMapping(value = "/search", method = RequestMethod.GET,
        consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> searchTags(@RequestBody Search search,
        @RequestHeader(value = "User-Access-Token", required = true) String accessToken) {
        logger.debug("Search input tag {}", search.getTags());
        List<Item> merchantList = new ArrayList<Item>();
        GeoCode inputGeoCode = search.getLocation().getGeoCode();
        if (inputGeoCode != null) {
            logger.debug("Search input geo location {} {}", inputGeoCode.getLatitude(),
                inputGeoCode.getLongitude());
            merchantList = engageAppService.getItemsByDistanceAndTags(search);
            logger.debug("Merchants search Result size for given input tag{}", merchantList.size());
        }
        List<JsonNode> node = engageAppService.getSearchInteraction(merchantList, accessToken,
            search);
        if (node != null) {
            return new ResponseEntity<>(new SearchResponse(node, search.getTags()),
                HttpStatus.OK);
        } else {
            return new ResponseEntity<>(Response.NOT_FOUND, HttpStatus.NOT_FOUND);
        }
    }

}
