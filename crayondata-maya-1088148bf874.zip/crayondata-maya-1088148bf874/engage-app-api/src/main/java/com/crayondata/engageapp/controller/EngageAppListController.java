/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.engageapp.controller;

import com.crayondata.engageapp.service.HttpResponseBuilder;
import com.crayondata.maya.choice.ListAPI;
import com.crayondata.maya.data.model.entity.DataList;
import com.fasterxml.jackson.databind.JsonNode;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;


@RestController
@CrossOrigin
@RequestMapping("/api/v2/list")
@Api(tags = "Data List API", description = "To retrieve values of a predefined list of data")
public class EngageAppListController {

    @Autowired
    private ListAPI listApi;

    @Autowired
    private HttpResponseBuilder builder;
    
    @ApiResponses({ @ApiResponse(code = 200, message = "List Returned",
        response = DataList.class) })
    @RequestMapping(value = "/{id}", produces = "application/json", method = RequestMethod.GET)
    @ApiOperation(value = "Get list data")
    public ResponseEntity<?> getList(@PathVariable(required = true) String id) {
        com.crayondata.maya.model.api.ApiResponse<JsonNode> dataList = listApi.getDataList(id);
        return builder.buildResponseEntity(dataList);
    }
}
