/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.maya.choice;

import static com.crayondata.maya.data.utils.ObjectUtils.defaultIfNull;
import static com.crayondata.maya.model.api.ApiResponse.Status.NOT_FOUND;

import com.crayondata.maya.choice.service.ChoiceItemScoreGenerator;
import com.crayondata.maya.choice.service.ChoiceListService;
import com.crayondata.maya.choice.service.ItemPropertyModifier;
import com.crayondata.maya.choice.service.RecommenderService;
import com.crayondata.maya.choice.utils.Constants;
import com.crayondata.maya.choice.utils.Pair;
import com.crayondata.maya.choice.utils.ResponseBuilder;
import com.crayondata.maya.choice.utils.Uuid;
import com.crayondata.maya.data.access.util.DBConstants;
import com.crayondata.maya.data.access.util.JsonUtils;
import com.crayondata.maya.data.access.util.TasteScoreUtils;
import com.crayondata.maya.data.choice.ChoiceService;
import com.crayondata.maya.data.entity.ItemService;
import com.crayondata.maya.data.model.config.ChoiceApiConfig;
import com.crayondata.maya.data.model.entity.ChoiceItem;
import com.crayondata.maya.data.model.entity.ChoiceList;
import com.crayondata.maya.data.model.entity.Choices;
import com.crayondata.maya.data.model.entity.DeliveredChoices;
import com.crayondata.maya.data.model.entity.GeneratedChoices;
import com.crayondata.maya.data.model.entity.Item;
import com.crayondata.maya.data.model.entity.OfferDetails;
import com.crayondata.maya.data.model.entity.OfferLocation;
import com.crayondata.maya.data.model.entity.ScoredItem;
import com.crayondata.maya.data.model.entity.TrackingInformation;
import com.crayondata.maya.data.model.entity.TrackingInformationItem;
import com.crayondata.maya.data.model.profile.RedeemedOffers;
import com.crayondata.maya.data.model.profile.TagScore;
import com.crayondata.maya.data.model.profile.UserProfile;
import com.crayondata.maya.data.model.recommendation.RecommendRequest;
import com.crayondata.maya.data.profile.InteractionService;
import com.crayondata.maya.data.profile.UserProfileService;
import com.crayondata.maya.data.profile.UserTagService;
import com.crayondata.maya.model.api.ApiResponse;
import com.crayondata.maya.model.api.ApiResponse.Status;
import com.crayondata.maya.model.api.ChoiceRequest;
import com.crayondata.maya.model.api.InteractRequest;
import com.crayondata.maya.model.api.ItemRequest;
import com.crayondata.maya.model.api.ItemResponse;
import com.crayondata.maya.model.api.PaginationResponse;
import com.crayondata.maya.model.api.SimilarItemResponse;
import com.crayondata.maya.model.common.GeoCode;
import com.crayondata.maya.model.common.Interaction;
import com.crayondata.maya.model.enums.InteractionType;
import com.crayondata.maya.model.enums.ItemType;
import com.crayondata.maya.model.enums.Languages;
import com.crayondata.maya.model.enums.UserType;
import com.crayondata.maya.model.rest.ChoiceListRequest;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.PriorityQueue;
import java.util.Set;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.MultiValueMap;

@Service
public class ChoiceAPIImpl implements ChoiceAPI {

    private static final Logger LOGGER = LoggerFactory.getLogger(ChoiceAPIImpl.class);

    @Autowired
    private UserProfileService userProfileService;

    @Autowired
    private RecommenderService recommenderService;

    @Autowired
    private InteractionService interactionService;

    @Autowired
    private ItemService itemService;

    @Autowired
    private ChoiceService choiceService;

    @Autowired
    private ChoiceListService choiceListService;

    @Autowired
    private ItemPropertyModifier itemPropertyModifier;

    @Autowired
    private JsonUtils json;

    @Autowired
    private ResponseBuilder responseBuilder;

    @Autowired
    private Uuid uuid;

    @Value("${interaction.recordViews:true}")
    private boolean recordViews;

    @Value("${user.enable.anonymous:false}")
    private boolean enableAnonUser;

    @Value("${offer.filter.distance:50}")
    private double offerDistance;

    @Value("${offer.online.top:true}")
    private boolean onlineOfferFirst;

    @Autowired
    private UserTagService userTagService;

    @Value("${recommender.preferredcategorycount:2}")
    private Integer preferredCategoryCount;

    @Value("${dlvr.persist.headers:}")
    private String[] headersToPersist;

    @Value("${testcontrol.enable:false}")
    private boolean isTestControlEnabled;

    @Value("${save.interactions.history}")
    private boolean saveIntrHistory;

    @Value("${recommend.nonOffer:false}")
    private boolean recommendNonOffers;

    @Value("${pagination.enabled}")
    private boolean paginate;

    @Value("${pagination.pageSize}")
    private int pageSize;

    @Value("${tracking.link.generation}")
    private boolean trackingLinkGeneration;

    @Value("${offer.props.modify}")
    private boolean modifyOfferProps;

    @Autowired
    private ChoiceApiConfig choiceApiConfig;

    @Autowired
    private ChoiceItemScoreGenerator itemScoreGenerator;

    @Autowired
    TasteScoreUtils tasteScoreUtils;

    @Override
    public ApiResponse<Choices> choices(ChoiceRequest request,
        MultiValueMap<String, String> headers) {

        String choiceId = uuid.nextId();
        MDC.put("choiceId", choiceId);
        String city = null;
        GeoCode geoCode = null;

        if (request.getLocation() != null) {
            city = request.getLocation().getCity();
            geoCode = request.getLocation().getGeocode();
        }

        boolean filterNonOffers = true;
        boolean recommendNonOffers = defaultIfNull(choiceApiConfig.getGlobalConfig()
            .getRecommendNonOffer(), this.recommendNonOffers);
        if (recommendNonOffers && request.getItemType() != ItemType.OFFER) {
            filterNonOffers = false;
        }
        LOGGER.info("Filter Non Offers: {}", filterNonOffers);
        Map<String, Boolean> recommendationFlags = request.getFlags() == null
            ? new HashMap<>() : request.getFlags();
        recommendationFlags.put(Constants.FLAG_FILTER_NON_OFFERS, filterNonOffers);

        String sessionId = request.getUserId();
        UserProfile userProfile = userProfileService.getUnifiedUserProfile(sessionId);
        List<String> categories = userProfileService.getNPreferredCategories(request.getCategory(),
            userProfile, preferredCategoryCount);
        RecommendRequest recommendRequest = new RecommendRequest(request.getCount(),
            request.getCampaignId(), request.getItemType(), categories, userProfile,
            request.getServedAt(), city, geoCode, recommendationFlags, request.getFilterBy());
        long startTime = System.nanoTime();
        List<ScoredItem> scoredItems = recommenderService.recommend(recommendRequest);
        LOGGER.info("TimeTaken recommenderService.recommend {} ms",
            (System.nanoTime() - startTime) / 1000000);

        if (scoredItems.isEmpty()) {
            return new ApiResponse<>(ApiResponse.Status.NOT_FOUND,
                "Choices not found for the given input");
        }

        // purge unnecessary headers before persisting request to DB
        retainOnlyRequiredHeaders(request.getHeaders());

        OffsetDateTime choiceGenerationTime = OffsetDateTime.now();
        PaginationResponse paginationResponse = null;
        if (request.getFlags().get(Constants.FLAG_PAGINATE)) {
            GeneratedChoices generatedChoices = new GeneratedChoices(choiceId, request, scoredItems,
                choiceGenerationTime);
            choiceService.saveGeneratedChoices(generatedChoices);
            int pageSize = defaultIfNull(choiceApiConfig.getGlobalConfig().getPaginationPageSize(),
                this.pageSize);
            int pageCount = (int) Math.ceil(scoredItems.size() * 1f / pageSize);
            paginationResponse = new PaginationResponse(pageCount);
            if (scoredItems.size() > pageSize) {
                scoredItems = scoredItems.subList(0, pageSize);
            }
        }

        List<ChoiceItem> choiceItems = populateScoredItemDetails(request, userProfile, scoredItems);

        DeliveredChoices deliveredChoices = new DeliveredChoices(choiceId, choiceApiConfig.getId(),
            request, scoredItems, choiceGenerationTime);
        choiceService.saveDeliveredChoices(deliveredChoices);

        Choices choices = new Choices(choiceId, choiceItems, deliveredChoices.getCreated(),
            paginationResponse);
        return new ApiResponse<>(choices);
    }

    @Override
    public ApiResponse<?> getChoiceList(String externalUserId, String userId,
        ChoiceListRequest request, MultiValueMap<String, String> headers) {
        if (userProfileService.processSessionAndKnownUserId(userId,
            request.getKnownUserId()) == null) {
            LOGGER.info("Could not find user profile with id: {}", userId);
            return new ApiResponse<>(NOT_FOUND, "Requested user id not found");
        }
        UserProfile dynamicUserProfile = userProfileService.getDynamicUserProfile(userId);
        request.setKnownUserId(dynamicUserProfile.getKnownUserId());
        String resolvedUserId = userProfileService.getUseableUserId(dynamicUserProfile);

        String choiceListId = uuid.nextId();
        MDC.put("choiceId", choiceListId);
        long startTime = System.nanoTime();
        List<Choices> choices = choiceListService.getChoiceList(externalUserId, resolvedUserId,
            dynamicUserProfile, request);
        if (choices == null || choices.isEmpty()) {
            return new ApiResponse<>(Status.NOT_FOUND,
                "Choices not found for given request");
        }

        LOGGER.info("Time taken to get choice list : {} ms",
            (System.nanoTime() - startTime) / 1000000);
        ChoiceList choiceList = new ChoiceList(choiceListId, choices);
        return new ApiResponse<>(choiceList);
    }

    /**
     * Populates the item details over the ScoredItems provided by the recommenders.
     * Additionally, this method does some operations like sorting offers, filtering offers etc.
     *
     * @param request     The actual choice request, with context
     * @param userProfile Profile of the user requesting choices
     * @param scoredItems ScoredItems generated as choices that needs to be enhanced with details
     * @return List of choices
     */
    private List<ChoiceItem> populateScoredItemDetails(ChoiceRequest request,
        UserProfile userProfile, List<ScoredItem> scoredItems) {
        Map<String, ScoredItem> idScoredItems = new HashMap<>();
        for (ScoredItem scoredItem : scoredItems) {
            idScoredItems.put(scoredItem.getItemId(), scoredItem);
        }

        List<String> itemIds = new ArrayList<>(idScoredItems.keySet());

        List<Item> items;

        UserType userType = userProfile.getUserType();
        boolean filterNonOffers = request.getFlags().get(Constants.FLAG_FILTER_NON_OFFERS);
        // If control user don't sort
        if (isTestControlEnabled && userType != null && userType.equals(UserType.CONTROL)) {
            items = filterOffers(itemService.getItems(itemIds), request.getServedAt(),
                filterNonOffers);
        } else {
            String city = null;
            GeoCode geoCode = null;

            if (request.getLocation() != null) {
                city = request.getLocation().getCity();
                geoCode = request.getLocation().getGeocode();
            }
            items = filterAndSortOffers(itemService.getItems(itemIds), request.getServedAt(), city,
                geoCode, filterNonOffers);
        }

        Map<String, Item> idItems = new HashMap<>();
        for (Item item : items) {
            idItems.put(item.getId(), item);
        }

        String useableUserId = userProfileService.getUseableUserId(userProfile);
        Set<String> liked = interactionService.getExistingInteractions(useableUserId,
            new HashSet<>(itemIds), InteractionType.LIKE);

        return scoredItems.stream().map(ScoredItem::getItemId)
            .filter(idItems::containsKey)
            .map(id -> new ChoiceItem(idItems.get(id), idScoredItems.get(id), liked.contains(id)))
            .collect(Collectors.toList());
    }

    private List<Item> filterOffers(List<Item> items, OffsetDateTime choiceServedAt,
        boolean filterNonOffers) {
        LOGGER.debug("Choices before filter: {}", items.size());
        items.forEach(item -> item.getOffers().removeIf(offer -> !offer.isValid(choiceServedAt)));
        if (filterNonOffers) {
            items.removeIf(item -> item.getOffers().isEmpty());
            LOGGER.debug("Choices after removing empty offers: {}", items.size());
        } else {
            LOGGER.debug("Choices without removing any empty offers: {}", items.size());
        }
        return items;
    }

    private List<Item> filterAndSortOffers(List<Item> items, OffsetDateTime choiceServedAt,
        String city, GeoCode geoCode, boolean filterNonOffers) {
        LOGGER.debug("Choices before filter and sort: {}", items.size());
        for (Item item : items) {
            filterAndSortOffers(item, choiceServedAt, city, geoCode);
        }
        if (filterNonOffers) {
            items.removeIf(item -> item.getOffers().isEmpty());
            LOGGER.debug("Choices after removing empty offers: {}", items.size());
        } else {
            LOGGER.debug("Choices without removing any empty offers: {}", items.size());
        }
        return items;
    }

    private Item filterAndSortOffers(Item item, OffsetDateTime choiceServedAt,
        String city, GeoCode geoCode) {
        item.getOffers().removeIf(offer -> !offer.isValid(choiceServedAt));
        if (!item.getOffers().isEmpty()) {
            sortOffers(item, city, geoCode);
        }
        return item;
    }

    private void sortOffers(Item item, String city, GeoCode geoCode) {
        // WARNING: This method not only sorts offers, but also removes some offers
        if (city != null) {
            Set<String> cityOffers = item.getLocations().stream()
                .filter(loc -> city.matches(loc.getCity()))
                .map(OfferLocation::getOffers)
                .flatMap(List::stream)
                .collect(Collectors.toSet());
            List<OfferDetails> offersToBeFiltered = item.getOffers().stream()
                .filter(offer -> !offer.getIsOnline() && !cityOffers.contains(offer.getId()))
                .collect(Collectors.toList());
            if (item.getOffers().size() != offersToBeFiltered.size()) {
                // remove the filtered offers if its not all offers
                item.getOffers().removeAll(offersToBeFiltered);
            }
            Set<String> cityLocIds = item.getLocations().stream()
                .filter(loc -> city.matches(loc.getCity()))
                .map(OfferLocation::getId)
                .collect(Collectors.toSet());
            item.getOffers().forEach(offer -> {
                if (offer.getLocations() != null && !offer.getLocations().isEmpty()) {
                    List<String> locToBeFiltered = offer.getLocations().stream()
                        .filter(loc -> !cityLocIds.contains(loc))
                        .collect(Collectors.toList());
                    if (offer.getLocations().size() != locToBeFiltered.size()) {
                        // remove the filtered locations if its not all locations
                        offer.getLocations().removeAll(locToBeFiltered);
                    }
                }
            });
        }

        if (geoCode != null) {
            double offerDistance = defaultIfNull(choiceApiConfig.getGlobalConfig()
                .getOfferFilterDistance(), this.offerDistance);
            Map<String, Double> distanceMap = new HashMap<>();
            item.getLocations().forEach(loc -> {
                if (GeoCode.isValid(loc.getGeoCode())) {
                    distanceMap.put(loc.getId(), geoCode.distanceFrom(loc.getGeoCode()));
                }
            });
            item.getOffers().removeIf(offer -> {
                List<String> locations = offer.getLocations();
                List<String> farOffOffers = locations.stream()
                    .filter(loc -> distanceMap.getOrDefault(loc, offerDistance + 1) > offerDistance)
                    .collect(Collectors.toList());
                locations.removeAll(farOffOffers);
                if (locations.isEmpty()) {
                    // must be some reason for this recommendation(say padding etc)
                    locations.addAll(farOffOffers);
                }
                return (!offer.getIsOnline() && offer.getLocations().isEmpty());
            });

            item.getOffers().sort((o1, o2) -> {
                if (o1.getIsOnline() && o2.getIsOnline()) {
                    return 0;
                }
                if (o2.getIsOnline()) {
                    return onlineOfferFirst ? 1 : -1;
                }
                if (o1.getIsOnline()) {
                    return onlineOfferFirst ? -1 : 1;
                }
                double d1 = o1.getLocations().stream()
                    .mapToDouble(loc -> distanceMap.getOrDefault(loc, offerDistance)).min()
                    .orElse(offerDistance);
                double d2 = o2.getLocations().stream()
                    .mapToDouble(loc -> distanceMap.getOrDefault(loc, offerDistance)).min()
                    .orElse(offerDistance);
                return Double.compare(d1, d2);
            });
        }
    }

    @Override
    public ItemResponse getItem(ItemRequest request) {
        String userId = request.getUserId();
        String externalUserId = request.getExternalUserId();
        String itemId = request.getItemId();
        String lang = request.getLang();
        if (itemId == null) {
            LOGGER.info("Item Id not present in get item request for user: {}", userId);
            return new ItemResponse();
        }
        Item item = itemService.getItem(itemId, ItemType.MERCHANT, lang);
        if (item == null) {
            LOGGER.info("Unable to get item {} for user: {}", itemId, userId);
            return new ItemResponse();
        }
        // filtering based on current time. temp fix
        item = filterAndSortOffers(item, OffsetDateTime.now(), null, null);

        // get proper user ID based on profile to record interactions
        UserProfile userProfile = userProfileService.getDynamicUserProfile(userId);
        userId = userProfileService.getUseableUserId(userProfile);

        TrackingInformation trackingInformation = choiceService.getTrackingInfo();
        if (trackingLinkGeneration == true) {
            item = itemPropertyModifier.generateTrackingLink(item,externalUserId,
                trackingInformation);
        }

        if (modifyOfferProps == true) {
            itemPropertyModifier.modifyOfferProps(item.getOffers(),
                trackingInformation.getClient());
        }
        JsonNode responseObject = json.asJsonNode(item);
        responseBuilder.movePropertiesOut((ObjectNode) responseObject);

        updateInteractionDetails(responseObject, DBConstants.LIKED, ItemType.MERCHANT,
            InteractionType.LIKE, userId, itemId);
        updateInteractionDetails(responseObject, DBConstants.WISHLISTED, ItemType.MERCHANT,
            InteractionType.WISHLIST, userId, itemId);

        JsonNode jsonNode = responseObject.get("offers");
        if (jsonNode != null) {
            ArrayNode offerDetails = (ArrayNode)jsonNode;
            for (JsonNode offerDetail : offerDetails) {
                String offerId = offerDetail.get("id").asText();
                updateInteractionDetails(offerDetail, DBConstants.CLAIMED, ItemType.OFFER,
                    InteractionType.CLAIM, userId, offerId);
                updateInteractionDetails(offerDetail, DBConstants.REDEEMED, ItemType.OFFER,
                    InteractionType.REDEEM, userId, offerId);
            }
        }
        if (recordViews) {
            // Register a VIEW interaction, when user requests item details
            com.crayondata.maya.data.model.profile.Interaction userInteraction
                = new com.crayondata.maya.data.model.profile.Interaction(
                DBConstants.asItemKey(itemId), OffsetDateTime.now());
            boolean success = interactionService
                .saveInteraction(userId, ItemType.MERCHANT, InteractionType.VIEW, userInteraction);
            boolean saveIntrHistory = defaultIfNull(choiceApiConfig.getGlobalConfig()
                .getSaveInteractionsHistory(), this.saveIntrHistory);
            if (success && saveIntrHistory) {
                interactionService
                    .saveInteractionHistory(userId, ItemType.MERCHANT,
                    InteractionType.VIEW, userInteraction);
            }
            userTagService.updateUserTagVector(userId, itemId, InteractionType.VIEW,
                ItemType.MERCHANT);
            Double score = 1.0;
            userProfileService.updatePreferredCategories(userId, itemId, score, ItemType.MERCHANT);
            interactionService.recordItemInteraction(itemId, InteractionType.VIEW,
                userInteraction.getTimestamp());
            if (!success) {
                LOGGER.debug("Unable to register VIEW interaction for user {} and item {}", userId,
                    itemId);
            }
        }
        return new ItemResponse(responseObject);
    }

    @Override
    public ApiResponse<Choices> getChoicesById(String userId, String choiceId) {

        DeliveredChoices deliveredChoices = choiceService.getDeliveredChoices(userId, choiceId);
        if (deliveredChoices == null) {
            return new ApiResponse<>(ApiResponse.Status.NOT_FOUND,
                "Delivered choices requested not found");
        }

        List<ScoredItem> scoredItems = deliveredChoices.getChoices();
        Map<String, ScoredItem> idScoredItems = new HashMap<>();
        for (ScoredItem scoredItem : scoredItems) {
            idScoredItems.put(scoredItem.getItemId(), scoredItem);
        }

        List<String> itemIds = new ArrayList<>(idScoredItems.keySet());

        List<Item> items = itemService.getItems(itemIds);
        Map<String, Item> idItems = new HashMap<>();
        for (Item item : items) {
            idItems.put(item.getId(), item);
        }

        String useableUserId = userProfileService.getUseableUserId(
            userProfileService.getUnifiedUserProfile(userId));
        Set<String> liked = interactionService.getExistingInteractions(useableUserId,
            new HashSet<>(itemIds), InteractionType.LIKE);
        List<ChoiceItem> choiceItems = itemIds.stream()
            .map(id -> new ChoiceItem(idItems.get(id), idScoredItems.get(id), liked.contains(id)))
            .collect(Collectors.toList());

        Choices choices = new Choices(choiceId, choiceItems, deliveredChoices.getCreated(), null);

        return new ApiResponse<>(choices);
    }

    @Override
    public ApiResponse<Choices> getChoicesByPage(String userId, String choiceId, int pageNo) {
        boolean paginate = defaultIfNull(choiceApiConfig.getGlobalConfig().getPaginate(),
            this.paginate);
        if (!paginate) {
            return new ApiResponse<>(ApiResponse.Status.BAD_REQUEST,
                "Pagination feature is not enabled");
        }

        GeneratedChoices generatedChoices = choiceService.getGeneratedChoices(userId, choiceId);
        if (generatedChoices == null) {
            return new ApiResponse<>(ApiResponse.Status.NOT_FOUND,
                "Paginated choices requested not found");
        }

        ChoiceRequest request = generatedChoices.getRequest();
        List<ScoredItem> scoredItems = generatedChoices.getChoices();
        UserProfile userProfile = userProfileService.getUnifiedUserProfile(userId);

        int pageSize = defaultIfNull(choiceApiConfig.getGlobalConfig().getPaginationPageSize(),
            this.pageSize);
        int pageStart = (pageNo - 1) * pageSize;
        int pageEnd = Math.min(pageStart + pageSize, scoredItems.size());
        if (pageStart < 0 || pageStart >= pageEnd) {
            return new ApiResponse<>(ApiResponse.Status.BAD_REQUEST,
                "Invalid page number");
        }

        int pageCount = (int) Math.ceil(scoredItems.size() * 1f / pageSize);
        PaginationResponse paginationResponse = new PaginationResponse(pageNo, pageCount);

        scoredItems = scoredItems.subList(pageStart, pageEnd);
        List<ChoiceItem> choiceItems = populateScoredItemDetails(request, userProfile, scoredItems);

        String paginatedChoiceId = choiceId + "_" + pageNo;
        DeliveredChoices deliveredChoices = new DeliveredChoices(paginatedChoiceId,
            choiceApiConfig.getId(), request, scoredItems, OffsetDateTime.now());
        choiceService.saveDeliveredChoices(deliveredChoices);

        Choices choices = new Choices(choiceId, choiceItems, generatedChoices.getCreated(),
            paginationResponse);
        return new ApiResponse<>(choices);
    }

    /**
     * Retains only the headers of interest, which is read from configuration.
     *
     * @param headers Map of headers. This Map will be modified in place.
     */
    private void retainOnlyRequiredHeaders(Map<String, String> headers) {
        if (headersToPersist == null || headersToPersist.length == 0) {
            // should not persist headers
            headers.keySet().clear();
        } else {
            List<String> headersToPersistList = Arrays.asList(headersToPersist);
            if (headersToPersistList.contains("*")) {
                // persist all
            } else {
                headers.keySet().retainAll(headersToPersistList);
            }
        }
        //empty string check
        for (Map.Entry<String,String> entry : headers.entrySet()) {
            if (entry.getValue() != null && entry.getValue().equals("")) {
                entry.setValue(null);
            }
        }
    }

    @Override
    public ApiResponse<List<Item>> getSimilarItems(String userId, String itemId,
        int count, String lang) {

        Item item = itemService.getItem(itemId);
        if (item == null) {
            LOGGER.info("Item with itemId {} does not exist", itemId);
            return new ApiResponse<>(ApiResponse.Status.NOT_FOUND,
                "Item with itemId " + itemId + " does not exist");
        }
        List<String> cities = item.getCities();
        String category = item.getCategory();
        List<Item> itemsByCategoryAndCity = new ArrayList<>();

        if (!CollectionUtils.isEmpty(cities) && category != null) {
            itemsByCategoryAndCity.addAll(itemService.getItemsByCategoryAndCity(category, cities));
        } else {
            if (category != null) {
                itemsByCategoryAndCity.addAll(itemService.getAllItemsByCategory(category));
            } else {
                cities.forEach(x -> itemsByCategoryAndCity.addAll(itemService.getItemsInCity(x)));
            }
        }

        Map<String, Double> itemScores = itemsByCategoryAndCity.stream()
            .collect(Collectors.toMap(x -> x.getId(), x ->
            item.computeSimilarityScores(x), (x1, x2) -> x1));

        Map<String, Double> sortedMap = itemScores.entrySet().stream()
            .sorted(Map.Entry.<String, Double>comparingByValue().reversed()).collect(Collectors
            .toMap(Map.Entry::getKey, Map.Entry::getValue, (e1, e2) -> e1, LinkedHashMap::new));

        sortedMap.remove(itemId);
        int limit = Math.min(count, sortedMap.size());
        Map<String, Integer> tasteMatchScores =
            itemScoreGenerator.generateTasteMatchScores(sortedMap);
        List<String> similarItemIds =
            tasteMatchScores.keySet().stream().limit(limit).collect(Collectors.toList());
        List<Item> items = itemService.getItems(similarItemIds, ItemType.MERCHANT, lang);
        Map<String, Item> itemMap =
            items.stream().collect(Collectors.toMap(x -> x.getId(), x -> x));
        List<Item> modifiedItems = similarItemIds.stream().map(x -> itemScoreGenerator
            .updateItemWithTasteMatchScore(tasteMatchScores.get(x), itemMap.get(x)))
            .collect(Collectors.toList());
        Map<String, TagScore> userTagVectors =
            userTagService.getCombinedUserTagVectors(userId, category);
        Map<String, Item> similarItems =
            modifiedItems.stream().collect(Collectors.toMap(x -> x.getId(), x -> x));
        tasteScoreUtils.setItemsWithTasteMatchScoreReason(similarItems, userTagVectors);
        return new ApiResponse<>(modifiedItems);
    }

    private SimilarItemResponse rankItemsOnTags(List<Item> items, List<String> tags, int count) {

        if (CollectionUtils.isEmpty(items) || CollectionUtils.isEmpty(tags)) {
            return new SimilarItemResponse();
        }
        PriorityQueue<Pair<Item, Integer>> top = new PriorityQueue<>(
            (o1, o2) -> o2.right().compareTo(o1.right()));
        items.forEach(item -> {
            int size = item.getTags().stream().filter(tags::contains)
                .collect(Collectors.toList()).size();
            if (size > 0) {
                top.add(new Pair<>(item, size));
            }
        });
        List<Item> topItems = top.stream().limit(count).map(Pair::left)
            .collect(Collectors.toList());
        Map<String, Object> summary = new LinkedHashMap<>();
        top.stream().limit(count).forEach(
            value -> {
                summary.put(value.left().getId(), value.right());
            }
        );
        return new SimilarItemResponse(topItems, summary);
    }

    private void updateInteractionDetails(JsonNode jsonNode, String property,
        ItemType itemType, InteractionType interactionType,
        String userId, String itemId) {
        boolean interacted = false;
        if (interactionType == InteractionType.REDEEM) {
            List<RedeemedOffers> redeemedOffersList = interactionService.getRedeemedOffers(userId,
                Languages.en.name());
            if (redeemedOffersList != null) {
                Optional<RedeemedOffers> redeemedOffer =
                    redeemedOffersList.stream().filter(x -> x.getOfferId()
                    .equalsIgnoreCase(itemId)
                    && x.getStatus().equalsIgnoreCase("approved")).findFirst();
                interacted = redeemedOffer.isPresent();
            }
        } else {
            interacted = interactionService.isInteractionExists(userId, itemId,
                itemType, interactionType);
        }
        if (interacted) {
            ((ObjectNode)jsonNode).put(property, true);
        } else {
            ((ObjectNode)jsonNode).put(property, false);
        }
    }

}
