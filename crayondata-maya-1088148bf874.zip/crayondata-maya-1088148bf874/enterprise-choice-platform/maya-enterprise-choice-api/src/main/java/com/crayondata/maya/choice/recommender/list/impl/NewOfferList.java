/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.maya.choice.recommender.list.impl;

import com.crayondata.maya.choice.recommender.list.ChoiceListRecommender;
import com.crayondata.maya.choice.service.ChoiceItemScoreGenerator;
import com.crayondata.maya.data.model.entity.Item;
import com.crayondata.maya.data.model.entity.OfferDetails;
import com.crayondata.maya.data.model.recommendation.ChoiceListRecommendRequest;
import com.crayondata.maya.model.enums.ChoiceListType;
import com.crayondata.maya.model.enums.Languages;
import com.crayondata.maya.model.rest.ChoiceListRequest;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class NewOfferList implements ChoiceListRecommender {

    @Value("${new.offer.validity.days}")
    private int days;

    @Override
    public List<Item> generateChoices(ChoiceListRecommendRequest request) {
        ChoiceListRequest choiceRequest = request.getChoiceRequest();
        Map<String, Item> items = getFilteredChoices(ChoiceListType.CATEGORY_BASED, request,
            choiceRequest.getLang());
        List<Item> newOfferItems = getNewOfferList(items);
        if (isUserChoicePresent(ChoiceListType.CATEGORY_BASED, request)
            && newOfferItems.isEmpty()) {
            items = request.getLangToFilteredItems().get(Languages
                .valueOf(choiceRequest.getLang()));
            newOfferItems = getNewOfferList(items);
        }

        int limit = Math.min(request.getChoiceRequest().getChoiceCount(), newOfferItems.size());
        request.setChoiceCount(ChoiceListType.NEW_OFFERS.name(), newOfferItems.size());
        List<Item> itemsWithLimit = newOfferItems.stream()
            .limit(limit).collect(Collectors.toList());
        return itemsWithLimit;
    }

    @Override
    public ChoiceListType getListType() {
        return ChoiceListType.NEW_OFFERS;
    }

    @Override
    public ChoiceItemScoreGenerator getItemScoreGenerator() {
        return null;
    }

    private List<Item> getNewOfferList(Map<String, Item> items) {
        List<Item> clonedItems = items.values().stream().map(item -> item.clone())
            .collect(Collectors.toList());
        OffsetDateTime currentDate = OffsetDateTime.now();
        Predicate<OfferDetails> isNewOffer = offer -> offer.getValidFrom()
            .isAfter(currentDate)
            && offer.isNewOffer(currentDate, days);

        for (Item item : clonedItems) {
            List<OfferDetails> newOffers = item.getOffers().stream()
                .filter(isNewOffer).collect(Collectors.toList());
            item.setOffers(newOffers);
        }

        List<Item> newOfferItems = clonedItems.stream().filter(x -> x.getOffers() != null
            && !x.getOffers().isEmpty()).collect(Collectors.toList());

        newOfferItems.stream().forEach(item -> item.getOffers()
            .stream().sorted(Comparator.comparing(offer -> offer.getDiffBtwnDates(
            offer.getValidFrom(), currentDate))));
        return newOfferItems;
    }
}
