/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.maya.choice;

import com.crayondata.maya.data.review.ReviewService;
import com.crayondata.maya.model.api.ApiResponse;
import com.crayondata.maya.model.api.AppFeedbackRequest;
import com.crayondata.maya.model.api.AppFeedbackResponse;
import com.crayondata.maya.model.api.ReviewItemRequest;
import com.crayondata.maya.model.api.ReviewMerchantResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class ReviewAPIImpl implements ReviewAPI {

    private static final Logger LOGGER = LoggerFactory.getLogger(UserAPIImpl.class);

    @Autowired
    private ReviewService reviewService;

    private ApiResponse.Status validateSaveReviewRequest(ReviewItemRequest reviewItemsRequest) {
        String merchantId = reviewItemsRequest.getMerchantId();
        int rating = reviewItemsRequest.getRating();
        String review = reviewItemsRequest.getReview();
        if (merchantId == null || merchantId.trim().isEmpty()) {
            LOGGER.info("merchantId not present in interaction request");
            return ApiResponse.Status.BAD_REQUEST;
        }
        if (review == null || review.trim().isEmpty()) {
            LOGGER.info("review not present in interaction request");
            return ApiResponse.Status.BAD_REQUEST;
        }
        if (rating == 0) {
            LOGGER.info("rating not present in interaction request");
            return ApiResponse.Status.BAD_REQUEST;
        }

        return ApiResponse.Status.SUCCESS;
    }

    private ApiResponse.Status validateFeedbackRequest(AppFeedbackRequest appFeedbackRequest) {
        String topic = appFeedbackRequest.getTopic();
        String review = appFeedbackRequest.getReviewAndSuggestion();
        int rating = appFeedbackRequest.getRating();
        if (topic == null || topic.trim().isEmpty()) {
            LOGGER.info("Topic not present in interaction request");
            return ApiResponse.Status.BAD_REQUEST;
        }
        if (review == null || review.trim().isEmpty()) {
            LOGGER.info("Review not present in interaction request");
            return ApiResponse.Status.BAD_REQUEST;
        }
        if (rating == 0) {
            LOGGER.info("Rating not present in interaction request");
            return ApiResponse.Status.BAD_REQUEST;
        }

        return ApiResponse.Status.SUCCESS;
    }

    @Override
    public ApiResponse<Boolean> saveReview(ReviewItemRequest reviewItemsRequest, String userId) {
        ApiResponse.Status validationResponse = validateSaveReviewRequest(reviewItemsRequest);
        if (ApiResponse.Status.SUCCESS != validationResponse) {
            return new ApiResponse<>(validationResponse, false, "");
        }
        String merchantId = reviewItemsRequest.getMerchantId();
        int rating = reviewItemsRequest.getRating();
        String review = reviewItemsRequest.getReview();

        boolean status = reviewService.saveReview(merchantId, rating, review, userId);

        if (status == true) {
            return new ApiResponse<>(true);
        } else {
            return new ApiResponse<>(ApiResponse.Status.NOT_FOUND,"Not found");

        }

    }

    @Override
    public ApiResponse<Boolean> saveFeedback(AppFeedbackRequest appFeedbackRequest, String userId) {


        String review = appFeedbackRequest.getReviewAndSuggestion();
        int rating = appFeedbackRequest.getRating();
        String topic = appFeedbackRequest.getTopic();
        String attachment = null;
        ApiResponse.Status validationResponse = validateFeedbackRequest(appFeedbackRequest);
        if (ApiResponse.Status.SUCCESS != validationResponse) {
            return new ApiResponse<>(validationResponse, false, "");
        }
        boolean status = reviewService.saveFeedback(topic,review,rating,attachment,userId);

        if (status == true) {
            return new ApiResponse<>(true);
        } else {
            return new ApiResponse<>(ApiResponse.Status.ERROR,
                    "Merchant review not updated due to some error");
        }
    }

    @Override
    public ApiResponse<ReviewMerchantResponse> getReviewDetails(String merchantId) {

        ApiResponse<ReviewMerchantResponse> response = reviewService.getMerchantReview(merchantId);
        if (response == null) {
            return new ApiResponse<>(ApiResponse.Status.NOT_FOUND,"Not found");
        }
        return response;

    }

    @Override
    public ApiResponse<AppFeedbackResponse> getFeedback(String userId) {
        ApiResponse<AppFeedbackResponse> response = reviewService.getFeedback(userId);
        if (response == null) {
            return new ApiResponse<>(ApiResponse.Status.NOT_FOUND,"Not found");
        }
        return response;
    }
}


