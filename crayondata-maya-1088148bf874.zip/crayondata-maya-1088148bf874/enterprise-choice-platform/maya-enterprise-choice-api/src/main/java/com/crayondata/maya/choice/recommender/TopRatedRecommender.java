/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.maya.choice.recommender;

import static com.crayondata.maya.data.utils.ObjectUtils.defaultIfNull;

import com.crayondata.maya.choice.service.FilterService;
import com.crayondata.maya.choice.service.RandomItemService;
import com.crayondata.maya.choice.utils.Constants;
import com.crayondata.maya.data.entity.ItemService;
import com.crayondata.maya.data.model.config.ChoiceApiConfig;
import com.crayondata.maya.data.model.entity.Item;
import com.crayondata.maya.data.model.entity.ScoredItem;
import com.crayondata.maya.data.model.profile.ItemInteraction;
import com.crayondata.maya.data.model.recommendation.RecommendRequest;
import com.crayondata.maya.data.model.recommendation.RecommenderType;
import com.crayondata.maya.data.profile.InteractionService;
import com.crayondata.maya.data.profile.UserProfileService;
import com.crayondata.maya.model.common.GeoCode;
import com.crayondata.maya.model.enums.InteractionType;
import com.crayondata.maya.model.explanator.IExplanator;
import com.crayondata.maya.model.explanator.TopRatedExplanator;

import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

/**
 * Trending / Popularity based recommender.
 *
 * @author sundar
 */
@Service
public class TopRatedRecommender implements IRecommender {

    private static final Logger LOGGER = LoggerFactory.getLogger(TopRatedRecommender.class);

    private static final String PREFIX_INTERACTION_INTENSITY = "interaction.intensity.";

    @Value("${toprated.return.location.results}")
    private boolean RETURN_LOCATION_RESULTS;

    @Autowired
    private ItemService itemService;

    @Autowired
    private FilterService filterService;

    @Autowired
    private InteractionService interactionService;

    @Autowired
    private Environment environment;

    @Autowired
    private UserProfileService userProfileService;

    @Autowired
    private ChoiceApiConfig choiceApiConfig;

    @Value("${recommender.explanator:false}")
    private boolean isExplanatorEnabled;

    @Value("${recommender.explanator.top.message.random:Random choice}")
    private String randomMessage;

    @Value("${recommender.explanator.top.message.popular:Popular choice}")
    private String popularMessage;

    @Value("${recommender.explanator.top.message.popular.nearby:Popular nearby choice}")
    private String popularNearbyMessage;

    @Value("${recommender.explanator.top.message.random.nearby:Random nearby choice}")
    private String randomNearbyMessage;

    @Override
    public RecommenderType getType() {
        return RecommenderType.TOPRATED;
    }

    @Override
    public List<ScoredItem> recommend(RecommendRequest recommendRequest) {
        String userId = userProfileService.getUseableUserId(recommendRequest.getUserProfile());
        OffsetDateTime choiceServedAt = recommendRequest.getChoiceServedAt();

        Set<String> itemsToBeFilteredOut = filterService.getDoNotShowItems(userId, choiceServedAt);
        int newCount = itemsToBeFilteredOut.size() + recommendRequest.getCount();
        long startTime = System.nanoTime();
        List<ScoredItem> recommendations = recommendTopRatedItems(recommendRequest, newCount);
        LOGGER.info("Time Taken : recommendTopRatedItems{} ms",
            (System.nanoTime() - startTime) / 1000000);
        List<ScoredItem> filteredItems = filterService.filterInteractedItems(recommendations,
            itemsToBeFilteredOut);
        /*
        // No need to restrict recommendations here, as its followed by offer and choice blenders
        filteredItems = (recommendRequest.getCount() < filteredItems.size())
                ? filteredItems.subList(0, recommendRequest.getCount()) : filteredItems;
        */
        return filteredItems;
    }

    private List<ScoredItem> recommendTopRatedItems(RecommendRequest recommendRequest, int count) {
        // int count = recommendRequest.getCount();
        final List<String> categories = recommendRequest.getCategories();
        final List<Item> itemsNearBy = recommendRequest.getFilteredItems();
        Map<String, List<String>> filters = recommendRequest.getFilters();

        boolean returnLocationResults = defaultIfNull(choiceApiConfig.getGlobalConfig()
            .getTopratedReturnLocationResults(), RETURN_LOCATION_RESULTS);
        boolean locationConstraint = recommendRequest.getFlags()
            .getOrDefault("locationConstraint", returnLocationResults);
        boolean explain = recommendRequest.getFlags().getOrDefault(Constants.KEY_EXPLAIN, false);
        boolean normalizeScoreByDist = recommendRequest.getFlags()
            .get(Constants.KEY_NORMALIZE_SCORE);
        LOGGER.info("Location Constraint to: {}", locationConstraint);
        LOGGER.info("Normalize Score By Distance: {}", normalizeScoreByDist);
        LOGGER.info("Valid Geo: {}", GeoCode.isValid(recommendRequest.getChoiceLoc()));

        List<ScoredItem> nearByScoredItems = new ArrayList<>();
        if (itemsNearBy != null && !itemsNearBy.isEmpty()) {

            List<String> itemsToReturnIds = itemsNearBy.stream().map(Item::getId).distinct()
                .collect(Collectors.toList());
            long startTime = System.nanoTime();
            List<ScoredItem> scoredItems = enhanceScoreWithTemporalAspect(itemsNearBy,
                recommendRequest.getChoiceServedAt(), normalizeScoreByDist,
                recommendRequest.getChoiceLoc());
            LOGGER.info("Time Taken : enhanceScoreWithTemporalAspect{} {}",
                (System.nanoTime() - startTime) / 1000000, "ms");

            if (scoredItems.size() < count) {
                LOGGER.info("Did not get temporal info for any location items. Randomizing...");
                List<String> topRatedItems = scoredItems.stream().map(x -> x.getItemId())
                    .collect(Collectors.toList());
                itemsToReturnIds.removeAll(topRatedItems);
                // No point sorting by score as all scores are supposed to be equal
                List<ScoredItem> randomChoices = randomizeItems(itemsToReturnIds,
                    count - topRatedItems.size());
                if (isExplanatorEnabled && explain) {
                    addTopRatedExplanations(randomChoices, randomNearbyMessage);
                    addTopRatedExplanations(scoredItems, popularNearbyMessage);
                }
                scoredItems.addAll(randomChoices);
                nearByScoredItems = scoredItems;
            } else {
                scoredItems.sort(Comparator.naturalOrder());
                if (isExplanatorEnabled && explain) {
                    addTopRatedExplanations(scoredItems, popularNearbyMessage);
                }
                nearByScoredItems = scoredItems;
            }
        }

        // return if the configuration is set
        if (locationConstraint) {
            return nearByScoredItems;
        }

        // set contains true if online and false if non-online
        Set<Boolean> isOnlineOrOffline = itemsNearBy != null
            ? itemsNearBy.stream().map(Item::getIsOnline).collect(Collectors.toSet()) :
            Collections.emptySet();

        if (isOnlineOrOffline.contains(Boolean.FALSE)) {
            // has non-online items too, return them
            return nearByScoredItems;
        }

        boolean usePadding = recommendRequest.getFlags().getOrDefault("padResults", true);
        LOGGER.info("Resetting padding to {}, based on Top rated results", usePadding);

        if (nearByScoredItems.size() >= count || !usePadding) {
            return nearByScoredItems;
        }

        int remCount = count - nearByScoredItems.size();
        List<Item> items = new ArrayList<>();
        OffsetDateTime choiceServedAt = recommendRequest.getChoiceServedAt();
        for (String category : categories) {
            List<Item> categoryItems = filterService.filterExpiredOffers(
                itemService.getAllItemsByCategoryAndTagFilter(category, filters), choiceServedAt,
                recommendRequest.getFlags().getOrDefault(Constants.FLAG_FILTER_NON_OFFERS,
                true));
            LOGGER.info("Num of Items got for Category {} and filter {} is: {}", category, filters,
                categoryItems.size());
            items.addAll(categoryItems);
        }

        List<String> itemIds = items.stream().map(Item::getId).collect(Collectors.toList());

        List<ScoredItem> scoredItems = enhanceScoreWithTemporalAspect(items,
            recommendRequest.getChoiceServedAt(), normalizeScoreByDist,
            recommendRequest.getChoiceLoc());
        if (scoredItems.size() < remCount) {
            LOGGER.info("Did not get temporal info for any items. Randomizing...");
            List<String> topRatedItems = scoredItems.stream().map(ScoredItem::getItemId)
                .collect(Collectors.toList());
            itemIds.removeAll(topRatedItems);
            List<ScoredItem> randomChoices = randomizeItems(itemIds,
                remCount - topRatedItems.size());
            if (isExplanatorEnabled && explain) {
                addTopRatedExplanations(randomChoices, randomMessage);
                addTopRatedExplanations(scoredItems, popularMessage);
            }
            scoredItems.addAll(randomChoices);
            nearByScoredItems.addAll(scoredItems);
        }
        scoredItems.sort(Comparator.naturalOrder());
        List<ScoredItem> returnScoredItems =
            count < scoredItems.size() ? scoredItems.subList(0, remCount) : scoredItems;
        LOGGER.info("Returning {} items", returnScoredItems.size());
        if (isExplanatorEnabled && explain) {
            addTopRatedExplanations(returnScoredItems, popularMessage);
        }
        return returnScoredItems;
    }

    private List<ScoredItem> randomizeItems(List<String> itemIds, int count) {
        long startTime = System.nanoTime();
        List<String> randomizedIds = RandomItemService.selectRandom(count, itemIds);
        List<ScoredItem> scoredItems = randomizedIds.stream()
            .map(item -> new ScoredItem(item, 1, RecommenderType.TOPRATED))
            .collect(Collectors.toList());
        LOGGER.info("Time Taken : randomizeItems{} {}", (System.nanoTime() - startTime) / 1000000,
            "ms");
        return scoredItems;
    }

    private List<ScoredItem> enhanceScoreWithTemporalAspect(List<Item> items,
        OffsetDateTime choiceServedAt, boolean normalizeScoreByDist, GeoCode choiceLoc) {
        List<ScoredItem> modifiedRecommendations = new ArrayList<>(items.size());
        List<String> itemIds = items.stream().map(Item::getId).collect(Collectors.toList());
        Map<String, Map<String, ItemInteraction>> itemInteractions = interactionService
            .getItemInteractionByIds(itemIds);
        Map<String, Map<String, ItemInteraction>> itemTransactions = interactionService
            .getItemTransactionByIds(itemIds);
        boolean isValidChoiceLoc = GeoCode.isValid(choiceLoc);
        Map<String, Integer> globalInteractionIntensity = choiceApiConfig.getGlobalConfig()
            .getInteractionIntensity();

        for (Item item : items) {
            String itemId = item.getId();
            Map<String, ItemInteraction> itemInteraction = itemInteractions.get(itemId);
            Map<String, ItemInteraction> itemTransaction = itemTransactions.get(itemId);
            Map<String, ItemInteraction> mergedItemIntrTran = mergeItemIntrAndTrxn(itemInteraction,
                itemTransaction);
            if (mergedItemIntrTran == null) {
                continue;
            }
            float itemScore = 0f;
            for (Map.Entry<String, ItemInteraction> entry : mergedItemIntrTran.entrySet()) {
                float score = entry.getValue().getUpdatedScore(choiceServedAt);
                int intensity;
                if (globalInteractionIntensity != null) {
                    intensity = globalInteractionIntensity.getOrDefault(entry.getKey(), 0);
                } else {
                    intensity = Integer.parseInt(environment
                        .getProperty(PREFIX_INTERACTION_INTENSITY + entry.getKey(), "0"));
                }
                itemScore += intensity * score;
            }
            if (normalizeScoreByDist && isValidChoiceLoc) {
                double distance = choiceLoc.getClosestGeoDistance(item.offerGeoCodes());
                itemScore /= Math.sqrt(distance + 1);
            }
            if (itemScore > 0) {
                modifiedRecommendations
                    .add(new ScoredItem(itemId, itemScore, RecommenderType.TOPRATED));
            }
        }
        return modifiedRecommendations;
    }

    private Map<String, ItemInteraction> mergeItemIntrAndTrxn(
        Map<String, ItemInteraction> itemInteraction,
        Map<String, ItemInteraction> itemTransaction) {

        if (itemInteraction == null && itemTransaction == null) {
            return null;
        }
        if (itemInteraction == null) {
            return itemTransaction;
        }
        if (itemTransaction == null) {
            return itemInteraction;
        }
        // both not null then merge
        Map<String, ItemInteraction> mergedItemIntrTran = new HashMap<>();

        for (InteractionType interactionType : InteractionType.values()) {
            ItemInteraction itemIntr = itemInteraction.get(interactionType.toString());
            ItemInteraction itemTrxn = itemTransaction.get(interactionType.toString());
            ItemInteraction tempMergedItemIntrTran;
            if (itemIntr == null && itemTrxn == null) {
                // LOGGER.info("Item Interaction document not found for Item: {}", itemId);
                continue;
            } else if (itemIntr == null) {
                tempMergedItemIntrTran = itemTrxn;
            } else if (itemTrxn == null) {
                tempMergedItemIntrTran = itemIntr;
            } else {
                OffsetDateTime lastUpdated = itemIntr.getLastUpdated();
                float trxnSum = itemTrxn.calculateHoursElapsed(lastUpdated);
                float intrSum = itemIntr.calculateHoursElapsed(lastUpdated);
                float sum = trxnSum + intrSum;
                int count = itemTrxn.getCount() + itemIntr.getCount();
                tempMergedItemIntrTran = new ItemInteraction(sum, count, lastUpdated);
            }
            if (tempMergedItemIntrTran != null) {
                mergedItemIntrTran.put(interactionType.toString(), tempMergedItemIntrTran);
            }
        }
        if (mergedItemIntrTran.isEmpty()) {
            return null;
        }
        return mergedItemIntrTran;
    }

    private void addTopRatedExplanations(List<ScoredItem> scoredItems, String message) {
        if (message == null) {
            return;
        }
        for (ScoredItem si : scoredItems) {
            IExplanator topExplanator = new TopRatedExplanator();
            topExplanator.setMessage(message);
            if (si.getExplanation() == null) {
                Map<RecommenderType, IExplanator> explanation = new HashMap<>();
                explanation.put(RecommenderType.TOPRATED, topExplanator);
                si.setExplanation(explanation);
            } else {
                si.getExplanation().put(RecommenderType.TOPRATED, topExplanator);
            }
        }
    }
}
