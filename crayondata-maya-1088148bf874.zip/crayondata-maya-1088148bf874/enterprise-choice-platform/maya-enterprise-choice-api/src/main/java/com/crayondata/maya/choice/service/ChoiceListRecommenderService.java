/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.maya.choice.service;

import static java.util.Map.Entry.comparingByValue;

import com.crayondata.maya.choice.recommender.list.factory.ChoiceListFactory;
import com.crayondata.maya.choice.recommender.list.impl.CampaignListService;
import com.crayondata.maya.choice.utils.ResponseBuilder;
import com.crayondata.maya.choice.utils.Uuid;
import com.crayondata.maya.data.access.util.DBConstants;
import com.crayondata.maya.data.access.util.JsonUtils;
import com.crayondata.maya.data.access.util.TasteScoreUtils;
import com.crayondata.maya.data.choice.ChoiceService;
import com.crayondata.maya.data.list.DataListService;
import com.crayondata.maya.data.model.entity.ChoiceItem;
import com.crayondata.maya.data.model.entity.Choices;
import com.crayondata.maya.data.model.entity.Item;
import com.crayondata.maya.data.model.entity.OfferDetails;
import com.crayondata.maya.data.model.entity.TrackingInformation;
import com.crayondata.maya.data.model.profile.Interaction;
import com.crayondata.maya.data.model.profile.RedeemedOffers;
import com.crayondata.maya.data.model.profile.TagScore;
import com.crayondata.maya.data.model.recommendation.ChoiceListRecommendRequest;
import com.crayondata.maya.data.profile.InteractionService;
import com.crayondata.maya.model.common.GeoCode;
import com.crayondata.maya.model.common.Location;
import com.crayondata.maya.model.enums.ChoiceListType;
import com.crayondata.maya.model.enums.InteractionType;
import com.crayondata.maya.model.enums.ItemType;
import com.crayondata.maya.model.enums.Languages;
import com.crayondata.maya.model.rest.ChoiceListRequest;
import com.crayondata.maya.model.rest.ChoiceListTypeRequest;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ArrayNode;
import java.time.OffsetDateTime;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class ChoiceListRecommenderService {
    private static final String CHOICE_TYPES_PREFIX = "choiceTypes";

    @Autowired
    ChoiceListFactory choiceListFactory;

    @Autowired
    DataListService dataListService;

    @Autowired
    DistanceService distanceService;

    @Autowired
    InteractionService interactionService;

    @Autowired
    FilterService filterService;

    @Autowired
    ChoiceService choiceService;

    @Autowired
    CampaignListService campaignListService;

    @Autowired
    TasteScoreUtils tasteScoreUtils;

    @Autowired
    ItemPropertyModifier itemPropertyModifier;

    @Autowired
    ResponseBuilder responseBuilder;

    @Autowired
    JsonUtils jsonUtils;

    @Autowired
    Uuid uuid;

    @Value("${tracking.link.generation}")
    private boolean trackingLinkGeneration;

    @Value("${offer.props.modify}")
    private boolean modifyOfferProps;

    @Value("${tag.exclusion.list}")
    private String[] exclusionList;

    /**
     * Get recommended choice list.
     *
     * @param recommendRequest contains request sent from client and filtered items
     * @return
     */
    public List<Choices> recommendChoices(ChoiceListRecommendRequest recommendRequest) {
        ChoiceListRequest choiceRequest = recommendRequest.getChoiceRequest();
        String lang = choiceRequest.getLang();
        List<ChoiceListTypeRequest> reqChoiceList = choiceRequest.getChoiceList();
        String[] choiceListTypes = (reqChoiceList != null)
            ? reqChoiceList.stream().filter(x -> !ChoiceListType.CAMPAIGN.name()
            .equals(x.getChoiceListType().name()))
            .map(x -> x.getChoiceListType().name()).toArray(String[]::new)
            : choiceListFactory.getChoiceListTypes();
        Map<String, List<Item>> listTypeToItems = new LinkedHashMap<>();
        Map<String, String> choiceTypeLabelMap = getChoiceTypeLabelMap(lang);
        boolean includeCampaigns = choiceRequest.isIncludeCampaigns();
        if (includeCampaigns) {
            Map<String, List<Item>> campaignChoices =
                campaignListService.generateChoices(recommendRequest);
            if (!campaignChoices.isEmpty()) {
                listTypeToItems.putAll(campaignChoices);
                Map<String, String> finalChoiceTypeLabelMap = choiceTypeLabelMap;
                campaignChoices.keySet().forEach(x -> finalChoiceTypeLabelMap.put(x, x));
            }
        }
        if (choiceListTypes.length > 0) {
            Map<String, List<Item>> listChoices = Stream.of(choiceListTypes)
                .map(x -> choiceListFactory.getChoiceList(ChoiceListType.valueOf(x)))
                .collect(Collectors.toMap(x -> x.getListType().name(), x ->
                x.generateChoices(recommendRequest), (e1, e2) -> e1,
                LinkedHashMap::new));
            if (!listChoices.isEmpty()) {
                listTypeToItems.putAll(listChoices);
            }
        }

        choiceTypeLabelMap = getListNamesWithTags(listTypeToItems, choiceTypeLabelMap);
        List<Choices> choices = convertItemsIntoChoices(recommendRequest.getExternalUserId(),
            recommendRequest.getUserId(), recommendRequest.getUserInteractions(),
            listTypeToItems, recommendRequest.getTotalChoiceCount(),
            choiceRequest.getLocation(), choiceTypeLabelMap,
            recommendRequest.getUserTagVectors());
        return choices;
    }

    private Map<String, String> getListNamesWithTags(Map<String, List<Item>>
        listTypeToItems, Map<String, String> choiceTypeLabelMap) {
        Map<String, String> map = listTypeToItems.entrySet().stream().collect(
            Collectors.toMap(x -> x.getKey(), x ->
            getModifiedListName(choiceTypeLabelMap.get(x.getKey()),
            x.getValue()), (x, y) -> x, LinkedHashMap::new));
        return map;
    }

    private String getModifiedListName(String listName, List<Item> items) {
        if (!listName.contains("$TAG$")) {
            return listName;
        }
        Map<String, Integer> frequencyofTags =
            items.stream().filter(x -> x.getTags() != null && !x.getTags().isEmpty())
            .flatMap(x -> x.getTags().stream())
            .collect(Collectors.toMap(y -> y, y -> 1, Integer::sum));
        if (frequencyofTags.isEmpty()) {
            return listName;
        }

        if (exclusionList != null) {
            List<String> list = Arrays.asList(exclusionList);
            for (String tag : list) {
                tag = tag.trim();
                frequencyofTags.remove(tag);
            }
        }
        Map<String, Integer> sortedMap =
            frequencyofTags.entrySet().stream()
            .sorted(Collections.reverseOrder(comparingByValue()))
            .collect(Collectors.toMap(x -> replaceHyphen(x.getKey()), x ->
            x.getValue(), (x, y) -> x, LinkedHashMap::new));

        int size = Math.min(sortedMap.size(), 2);
        String tags = sortedMap.keySet().stream().limit(size)
            .collect(Collectors.joining(" & "));
        if (tags != null && !tags.isEmpty()) {
            String newlist = listName.replace("$TAG$", tags);
            return newlist;
        }
        return listName;
    }

    private String replaceHyphen(String key) {
        String newKey = key.replaceAll("-", " ");
        return newKey;
    }

    private List<Choices> convertItemsIntoChoices(String externalUserId, String userId,
        Map<ItemType, Map<InteractionType, List<Interaction>>> interactions,
        Map<String, List<Item>> listTypeToItems,
        Map<String, Integer> listChoiceTotalCount,
        Location location, Map<String, String> choiceTypeLabelMap,
        Map<String, TagScore> userTagVectors) {

        List<String> wishlistedItems = getInteractionDetails(interactions, ItemType.MERCHANT,
            InteractionType.WISHLIST);

        List<String> disLikedItems = getInteractionDetails(interactions, ItemType.MERCHANT,
            InteractionType.DISLIKE);

        List<String> claimedOffers = getInteractionDetails(interactions, ItemType.OFFER,
            InteractionType.CLAIM);

        List<RedeemedOffers> redeemedOffersList = interactionService.getRedeemedOffers(userId,
            Languages.en.name());
        List<String> redeemedOffers = redeemedOffersList != null
            ? redeemedOffersList.stream().map(x -> x.getOfferId())
            .collect(Collectors.toList()) : Collections.emptyList();

        TrackingInformation trackingInfo = choiceService.getTrackingInfo();
        List<String> finalRedeemedOffers = redeemedOffers;
        List<Choices> choiceList = listTypeToItems.entrySet().stream()
            .filter(x -> x.getValue() != null && !x.getValue().isEmpty())
            .map(x -> {
                String listId = uuid.nextId();
                Integer totalCount = listChoiceTotalCount.get(x.getKey());
                Map<String, Item> items =
                    x.getValue().stream().collect(Collectors.toMap(y -> y.getId(), y -> y));
                tasteScoreUtils.setItemsWithTasteMatchScoreReason(items, userTagVectors);
                List<ChoiceItem> choiceItems = getChoiceItemList(externalUserId, wishlistedItems,
                    claimedOffers, finalRedeemedOffers, disLikedItems,
                    x.getKey(), x.getValue(), location, trackingInfo);
                Choices choices = new Choices(listId, choiceTypeLabelMap.get(x.getKey()),
                    totalCount, choiceItems, OffsetDateTime.now(), null);
                return choices; }).collect(Collectors.toList());
        return choiceList;
    }

    private Map<String, String> getChoiceTypeLabelMap(String lang) {
        JsonNode jsonNode = dataListService.getDataList(CHOICE_TYPES_PREFIX, lang);
        Map<String, String> map = new HashMap<>();
        if (jsonNode != null) {
            ArrayNode arrayNode = (ArrayNode) jsonNode;
            for (JsonNode json : arrayNode) {
                String label = json.get("label").asText();
                String value = json.get("value").asText();
                map.put(value, label);
            }
        }
        return map;
    }

    private List<ChoiceItem> getChoiceItemList(String externalUserId, List<String> wishlistedItems,
        List<String> claimedOffers, List<String> redeemedOffers, List<String> disLikedItems,
        String choiceListType, List<Item> items, Location location,
        TrackingInformation trackingInfo) {
        filterService.filterExpiredOffers(items, OffsetDateTime.now(), true);
        items = filterService.filterDislikedItems(items, disLikedItems);
        List<ChoiceItem> choiceitemList = items.stream().map(item -> {
            if (!ChoiceListType.NEAR_BY.name().equals(choiceListType) && !item.getIsOnline()
                && location != null) {
                GeoCode geocode = location.getGeocode();
                String city = location.getCity();
                if (geocode == null && city != null) {
                    geocode = distanceService.getGeoCode(city);
                }
                double distance = (geocode != null) ? geocode
                    .getClosestGeoDistance(item.getGeoCodes()) : 0.0;
                distanceService.setItemWithDistance(distance, item);
            } else {
                distanceService.setItemWithDistance(0.0, item);
            }

            if (trackingLinkGeneration == true) {
                itemPropertyModifier.generateTrackingLink(item, externalUserId, trackingInfo);
            }

            if (modifyOfferProps == true) {
                itemPropertyModifier.modifyOfferProps(item.getOffers(),
                    trackingInfo.getClient());
            }

            boolean wishlisted = wishlistedItems.contains(item.getId());
            updateOfferInteractionDetails(DBConstants.CLAIMED, item.getOffers(), claimedOffers);
            updateOfferInteractionDetails(DBConstants.REDEEMED, item.getOffers(), redeemedOffers);

            ChoiceItem choiceItem = new ChoiceItem(item, null, null, wishlisted);
            return choiceItem;
        }).collect(Collectors.toList());
        return choiceitemList;
    }

    private List<String> getInteractionDetails(Map<ItemType, Map<InteractionType,
        List<Interaction>>> interactions, ItemType itemType,
        InteractionType interactionType) {
        List<Interaction> items = (interactions != null
            && interactions.get(itemType) != null) ? interactions
            .get(itemType).get(interactionType) : null;

        List<String> itemIds  = (items != null)
            ? items.stream().map(x -> DBConstants.stripItemKeyIfExists(x.getItemId()))
            .collect(Collectors.toList()) : Collections.emptyList();
        return itemIds;
    }

    private void updateOfferInteractionDetails(String property, List<OfferDetails> offers,
        List<String> interactedIds) {
        if (offers != null) {
            offers.forEach(offer -> {
                offer.getProperties().put(property, interactedIds
                    .contains(offer.getId()));
            });
        }
    }
}
