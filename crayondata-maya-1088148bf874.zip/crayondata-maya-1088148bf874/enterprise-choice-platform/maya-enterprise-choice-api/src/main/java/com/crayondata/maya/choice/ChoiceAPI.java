/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.maya.choice;

import com.crayondata.maya.data.model.entity.Choices;
import com.crayondata.maya.data.model.entity.Item;
import com.crayondata.maya.data.model.recommendation.RecommenderType;
import com.crayondata.maya.model.api.ApiResponse;
import com.crayondata.maya.model.api.ChoiceRequest;
import com.crayondata.maya.model.api.InteractRequest;
import com.crayondata.maya.model.api.ItemRequest;
import com.crayondata.maya.model.api.ItemResponse;
import com.crayondata.maya.model.api.SimilarItemResponse;

import com.crayondata.maya.model.rest.ChoiceListRequest;
import java.util.List;
import org.springframework.util.MultiValueMap;

/**
 * The API abstraction for choices and the interactions with them.
 */
public interface ChoiceAPI {

    /**
     * Generates choices based on the given request.
     *
     * @param request Choice request
     * @param headers Request headers
     * @return Choices generated
     */
    ApiResponse<Choices> choices(ChoiceRequest request, MultiValueMap<String, String> headers);

    /**
     * Generates choice list based on given request.
     *
     * @param externalUserId externalId of the user to map with internal user Id
     * @param userId id of the user
     * @param request Choice request
     * @param headers Request headers
     * @return Generated Choice list
     */
    ApiResponse<?> getChoiceList(String externalUserId, String userId,
        ChoiceListRequest request, MultiValueMap<String, String> headers);

    /**
     * Gives the details of an item. This may be considered as a VIEW interaction.
     *
     * @param request Item request
     * @return Item details response
     */
    ItemResponse getItem(ItemRequest request);

    /**
     * Gets the choices by the given choiceId for the user. These are previously generated choices.
     *
     * @param userId   Id of the user
     * @param choiceId Id of the choices
     * @return Choices response
     */
    ApiResponse<Choices> getChoicesById(String userId, String choiceId);

    /**
     * Gets the choices by the given choiceId for the user by page.
     * The choices must have been generated earlier and persisted.
     *
     * @param userId   Id of the user
     * @param choiceId Id of the choices
     * @param pageNo   Page number for the choices view
     * @return Choices response
     */
    ApiResponse<Choices> getChoicesByPage(String userId, String choiceId, int pageNo);

    /**
     * Finds items that are similar to the given item identified by itemId. Similarity is
     * determined by commonality of tags.
     *
     * @param userId Id of the user
     * @param itemId Id of the item
     * @param count  Number of similar items to return.
     * @param lang  Language selected by the user
     * @return Similar items response
     */
    ApiResponse<List<Item>> getSimilarItems(String userId, String itemId,
        int count, String lang);
}
