/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.maya.choice.service;

import com.crayondata.maya.data.entity.ItemService;
import com.crayondata.maya.data.model.entity.Item;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;

//@Service
public class RandomItemService {

    private static final Random RANDOM_ALL = new Random();

    private List<String> itemIds;
    private Map<String, List<String>> categoryItemIdMap;

    @Autowired
    private ItemService itemService;

    /**
     * Initialize the service.
     */
    @PostConstruct
    public void init() {
        List<Item> items = itemService.getAllItemsByCategory(null);

        itemIds = new ArrayList<>(items.size());
        categoryItemIdMap = new HashMap<>();

        items.forEach(item -> {
            itemIds.add(item.getId().intern());
            String category = item.getCategory();
            categoryItemIdMap.putIfAbsent(category, new ArrayList<>());
            categoryItemIdMap.get(category).add(item.getId().intern());
        });
    }

    public List<String> getRandomItems(int n) {
        return selectRandom(n, itemIds);
    }

    /**
     * Get random items of the given category.
     *
     * @param n Number of items needed
     * @param category Category of items needed
     * @return List of item ids
     */
    public List<String> getRandomItemsByCategory(int n, String category) {
        if (!categoryItemIdMap.containsKey(category)) {
            return new ArrayList<>();
        }

        List<String> catItemIds = categoryItemIdMap.get(category);
        return selectRandom(n, catItemIds);
    }

    /**
     * Selects 'n' random elements from the given list.
     *
     * @param n Number of elements to select
     * @param list List from which to randomize
     * @return List of selected elements
     */
    public static <T> List<T> selectRandom(int n, List<T> list) {
        if (n == 0 || list.isEmpty()) {
            return new ArrayList<>();
        }

        if (n >= list.size()) {
            return list;
        }

        List<T> returnList = new ArrayList<>(n);
        Set<T> uniqueSet = new HashSet<>(n);
        do {
            T item = list.get(RANDOM_ALL.nextInt(list.size()));
            if (!uniqueSet.contains(item)) {
                uniqueSet.add(item);
                returnList.add(item);
            }
        } while (returnList.size() < n);
        return returnList;
    }
}
