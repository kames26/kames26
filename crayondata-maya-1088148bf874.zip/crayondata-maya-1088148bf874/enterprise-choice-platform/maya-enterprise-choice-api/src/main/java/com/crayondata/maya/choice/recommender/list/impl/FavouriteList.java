/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.maya.choice.recommender.list.impl;

import com.crayondata.maya.choice.recommender.list.ChoiceListRecommender;
import com.crayondata.maya.choice.service.ChoiceItemScoreGenerator;
import com.crayondata.maya.data.entity.ItemService;
import com.crayondata.maya.data.model.entity.Item;
import com.crayondata.maya.data.model.profile.Interaction;
import com.crayondata.maya.data.model.recommendation.ChoiceListRecommendRequest;
import com.crayondata.maya.data.profile.InteractionService;
import com.crayondata.maya.model.enums.ChoiceListType;
import com.crayondata.maya.model.enums.InteractionType;
import com.crayondata.maya.model.enums.ItemType;
import com.crayondata.maya.model.rest.ChoiceListRequest;
import java.time.OffsetDateTime;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class FavouriteList implements ChoiceListRecommender {

    @Autowired
    InteractionService interactionService;

    @Autowired
    ItemService itemService;

    @Override
    public List<Item> generateChoices(ChoiceListRecommendRequest request) {
        ChoiceListRequest choiceRequest = request.getChoiceRequest();
        String userId = request.getUserId();
        String category = choiceRequest.getCategory();
        List<Interaction> interactions = interactionService
            .getInteractionsWithUserIdAndInteractionType(userId, ItemType.MERCHANT,
            InteractionType.WISHLIST);
        if (interactions == null || interactions.isEmpty()) {
            return Collections.emptyList();
        }
        Map<String, OffsetDateTime> interactionTimestamp = interactions.stream()
            .collect(Collectors.toMap(Interaction::getItemId, Interaction::getTimestamp));
        List<String> itemIds = interactions.stream().map(x -> x.getItemId())
            .collect(Collectors.toList());
        List<Item> items = itemService.getItems(itemIds, ItemType.MERCHANT,
            choiceRequest.getLang());
        items.sort((o1, o2) -> {
            return interactionTimestamp.get(o2.getId())
                .compareTo(interactionTimestamp.get(o1.getId()));
        });

        Predicate<Item> categFilter = x -> "All".equalsIgnoreCase(category)
            || category.equalsIgnoreCase(x.getCategory());

        request.setChoiceCount(ChoiceListType.FAVOURITES.name(), items.size());
        int limit = Math.min(choiceRequest.getChoiceCount(), items.size());
        List<Item> filteredItems = items.stream().filter(categFilter)
            .limit(limit).collect(Collectors.toList());
        return filteredItems;
    }

    @Override
    public ChoiceListType getListType() {
        return ChoiceListType.FAVOURITES;
    }

    @Override
    public ChoiceItemScoreGenerator getItemScoreGenerator() {
        return null;
    }
}
