/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.maya.choice;

import com.crayondata.maya.data.model.entity.FavouritePlace;
import com.crayondata.maya.model.api.ApiResponse;
import java.util.List;
import java.util.Map;

public interface UserTasteAPI {

    /**
     * Stores the user's favourite places.
     *
     * @param userId Id of the user
     * @param category category of the liked items
     * @param favouritePlaces of the user
     * @return {@link ApiResponse} containing the status of the operation
     */
    ApiResponse<Boolean> saveUserFavouriteItems(String userId, String category,
        List<FavouritePlace> favouritePlaces);

    /**
     * Stores the user's liked offer tags.
     *
     * @param userId Id of the user
     * @param category category selected by user
     * @param likedOfferTags of the user
     * @return {@link ApiResponse} containing the status of the operation
     */
    ApiResponse<Boolean> saveUserFavouriteTags(String userId,
        String category, List<String> likedOfferTags);


    /**
     * Gets the user's favorites.
     * @param userId id of the user
     * @param category category
     * @return user's selected items
     */
    ApiResponse<Map<String, Object>> getUserOnboardedInfo(String userId, String category);
}
