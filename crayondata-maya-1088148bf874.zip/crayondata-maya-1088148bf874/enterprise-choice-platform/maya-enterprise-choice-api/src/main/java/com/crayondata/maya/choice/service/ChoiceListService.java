/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.maya.choice.service;

import com.crayondata.maya.data.access.key.KeyStoreDataAccessService;
import com.crayondata.maya.data.access.model.JsonDocument;
import com.crayondata.maya.data.access.util.DBConstants;
import com.crayondata.maya.data.access.util.JsonUtils;
import com.crayondata.maya.data.choice.TGScoreService;
import com.crayondata.maya.data.entity.ItemService;
import com.crayondata.maya.data.list.DataListService;
import com.crayondata.maya.data.model.entity.Choices;
import com.crayondata.maya.data.model.entity.Item;
import com.crayondata.maya.data.model.profile.Interaction;
import com.crayondata.maya.data.model.profile.TagScore;
import com.crayondata.maya.data.model.profile.UserChoice;
import com.crayondata.maya.data.model.profile.UserChoices;
import com.crayondata.maya.data.model.profile.UserProfile;
import com.crayondata.maya.data.model.profile.UserTagVector;
import com.crayondata.maya.data.model.recommendation.ChoiceListRecommendRequest;
import com.crayondata.maya.data.profile.InteractionService;
import com.crayondata.maya.data.profile.UserTagService;
import com.crayondata.maya.model.common.Location;
import com.crayondata.maya.model.enums.ChoiceListType;
import com.crayondata.maya.model.enums.InteractionType;
import com.crayondata.maya.model.enums.ItemType;
import com.crayondata.maya.model.enums.Languages;
import com.crayondata.maya.model.rest.ChoiceListRequest;
import com.crayondata.maya.model.rest.ChoiceListTypeRequest;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class ChoiceListService {
    @Autowired
    FilterService filterService;

    @Autowired
    ChoiceListRecommenderService recommenderService;

    @Autowired
    DistanceService distanceService;

    @Value("${choice.list.count}")
    int choiceCount;

    @Value("${choice.list.types.batch.generation}")
    String[] batchChoiceListTypes;

    @Value("${category.based.filtered.lists}")
    String[] categoryBasedFilteredLists;
    
    @Autowired
    KeyStoreDataAccessService keyStoreDataAccessService;

    @Autowired
    DataListService dataListService;

    @Autowired
    InteractionService interactionService;

    @Autowired
    ItemService itemService;

    @Autowired
    JsonUtils jsonUtils;

    @Autowired
    ObjectMapper objectMapper;

    @Autowired
    TGScoreService tgScoreService;

    @Autowired
    UserTagService userTagService;

    /**
     * Get choice list.
     *
     * @param externalUserId external id of the user to map internal user id
     * @param userId id of the user
     * @param choiceRequest choice request
     * @return list of choices for each choicelist type
     */
    public List<Choices> getChoiceList(String externalUserId, String userId,
        UserProfile userProfile, ChoiceListRequest choiceRequest) {
        String lang = choiceRequest.getLang();
        String category = choiceRequest.getCategory();
        int count = choiceRequest.getChoiceCount() == 0 ? choiceCount :
            choiceRequest.getChoiceCount();
        choiceRequest.setChoiceCount(count);

        Map<ItemType, Map<InteractionType, List<Interaction>>> userInteractions =
            interactionService.getInteractionsForUserId(userId);

        Map<String, List<String>> similarItems = getSimilarItems(userInteractions);
        Map<Languages, Map<String, Item>> filteredItems = getFilteredItems(
            choiceRequest.getLocation(), choiceRequest.getCategory(), lang);
        ChoiceListRecommendRequest recommenderRequest = new ChoiceListRecommendRequest(
            externalUserId, userId, userProfile, choiceRequest, filteredItems,
            getChoicesForUser(userId, category, choiceRequest.getChoiceList()),
            userInteractions, similarItems, userTagService.getCombinedUserTagVectors(
            userId, category));

        List<Choices> choices = recommenderService.recommendChoices(recommenderRequest);
        return choices;
    }

    private Map<String, List<String>> getSimilarItems(Map<ItemType, Map<InteractionType,
        List<Interaction>>> userInteractions) {
        if (userInteractions == null || userInteractions.isEmpty()) {
            return Collections.emptyMap();
        }
        Set<String> itemIds = new HashSet<>();
        for (ItemType itemType : userInteractions.keySet()) {
            Map<InteractionType, List<Interaction>> interactionTypeListMap =
                userInteractions.get(itemType);
            List<String> interactedItemIds = null;
            List<List<Interaction>> interactionList =
                interactionTypeListMap.entrySet().stream().map(x -> x.getValue())
                .collect(Collectors.toList());

            if (itemType == ItemType.OFFER) {
                interactedItemIds = interactionList.stream().flatMap(Collection::stream)
                    .map(x -> itemService.getItem(x.getItemId(), ItemType.OFFER))
                    .filter(y -> y != null)
                    .map(y -> y.getId())
                    .collect(Collectors.toList());
            } else {
                interactedItemIds = interactionList.stream()
                       .flatMap(Collection::stream).map(x ->
                        DBConstants.stripItemKeyIfExists(x.getItemId()))
                        .collect(Collectors.toList());
            }
            itemIds.addAll(interactedItemIds);
        }
        return tgScoreService.getSimilarItems(new ArrayList<>(itemIds));
    }

    private Map<Languages, Map<String, Item>> getFilteredItems(Location location, String category,
        String lang) {
        List<Item> filteredItems = new ArrayList<>();
        if (category == null || DBConstants.CATEGORY_ALL.equalsIgnoreCase(category)) {
            List<Item> itemsBasedOnLoc =
                filterService.getItemsBasedOnLocation(location, lang);
            if (itemsBasedOnLoc != null) {
                filteredItems.addAll(itemsBasedOnLoc);
            }
        } else {
            List<Item> itemsByLocAndCategoryForLang = filterService
                .getItemsByLocAndCategoryForLang(location, category, lang);
            if (itemsByLocAndCategoryForLang != null) {
                filteredItems.addAll(itemsByLocAndCategoryForLang);
            }
        }

        List<Item> itemsWithOnlineOffers = null;
        if (location != null) {
            itemsWithOnlineOffers = itemService
                .getItemsWithOnlineOffersForCountry(location.getCountry(), lang);
        }
        if (itemsWithOnlineOffers != null && !itemsWithOnlineOffers.isEmpty()) {
            Set<String> filteredItemIds = filteredItems.stream().map(Item::getId)
                .collect(Collectors.toSet());
            itemsWithOnlineOffers.stream()
                .filter(item -> DBConstants.CATEGORY_ALL.equalsIgnoreCase(category)
                    || item.getCategory().equalsIgnoreCase(category))
                .filter(item -> filteredItemIds.isEmpty()
                    || !filteredItemIds.contains(item.getId()))
                .forEach(item -> filteredItems.add(item));
        }
        Map<Languages, Map<String, Item>> langToItems = new HashMap<>();
        Map<String, Item> filteredItemsMap = !filteredItems.isEmpty() ? filteredItems.stream()
            .collect(Collectors.toMap(x -> x.getId(), x -> x)) : new HashMap<>();
        langToItems.put(Languages.valueOf(lang), filteredItemsMap);
        return langToItems;
    }

    private Map<ChoiceListType, Map<String, UserChoice>> getChoicesForUser(String userId,
        String category, List<ChoiceListTypeRequest> choiceListTypeRequest) {
        Map<ChoiceListType, Map<String, UserChoice>> listChoices = new HashMap<>();
        if (choiceListTypeRequest == null) {
            for (String listType : batchChoiceListTypes) {
                populateUserChoiceMap(userId, ChoiceListType.valueOf(listType), category,
                    listChoices);
            }
        } else {
            List<String> categFilteredLists =
                Stream.of(categoryBasedFilteredLists).collect(Collectors.toList());
            List<String> batchModeLists = Stream.of(batchChoiceListTypes)
                .collect(Collectors.toList());
            List<ChoiceListType> requestedListTypes =
                choiceListTypeRequest.stream().map(x -> x.getChoiceListType())
                .collect(Collectors.toList());
            requestedListTypes.forEach(x -> {
                if (!listChoices.containsKey(ChoiceListType.CATEGORY_BASED)
                    && categFilteredLists.contains(x.name())) {
                    populateUserChoiceMap(userId, ChoiceListType.CATEGORY_BASED, category,
                        listChoices);
                } else if (batchModeLists.contains(x.name())) {
                    populateUserChoiceMap(userId, x, category, listChoices);
                }
            });
        }
        return listChoices;
    }

    private void populateUserChoiceMap(String userId, ChoiceListType listType,
        String category, Map<ChoiceListType, Map<String, UserChoice>> listChoices) {
        String key = DBConstants.asUserChoiceKey(userId, listType.name().toLowerCase());
        JsonDocument document = keyStoreDataAccessService.getDocument(key,
            DBConstants.USER_CHOICE_LIST_TYPE);
        if (document != null && document.getJson() != null) {
            JsonNode jsonNode = document.getJson();
            UserChoices userChoices = jsonUtils.getObject(jsonNode, UserChoices.class);
            Map<String, List<UserChoice>> categoryChoices = userChoices.getCategoryChoices();
            if (category == null || DBConstants.CATEGORY_ALL.equalsIgnoreCase(category)) {
                Map<String, UserChoice> idToChoices = new HashMap<>();
                for (List<UserChoice> values : categoryChoices.values()) {
                    Map<String, UserChoice> innerMap = values.stream()
                        .collect(Collectors.toMap(x -> x.getMerchantId(), x -> x, (x1, x2) -> x1));
                    idToChoices.putAll(innerMap);
                }
                listChoices.put(listType, idToChoices);
            } else {
                List<UserChoice> choices = categoryChoices.get(category);
                if (choices != null) {
                    Map<String, UserChoice> idToChoices = choices.stream()
                        .collect(Collectors.toMap(x -> x.getMerchantId(), x -> x, (x1, x2) -> x1));
                    listChoices.put(listType, idToChoices);
                }
            }
        }
    }
}
