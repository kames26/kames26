/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.maya.choice.recommender;

import com.crayondata.maya.choice.service.FilterService;
import com.crayondata.maya.choice.service.RandomItemService;
import com.crayondata.maya.data.entity.ItemService;
import com.crayondata.maya.data.model.config.ChoiceApiConfig;
import com.crayondata.maya.data.model.entity.Item;
import com.crayondata.maya.data.model.entity.ScoredItem;
import com.crayondata.maya.data.model.recommendation.RecommendRequest;
import com.crayondata.maya.data.model.recommendation.RecommenderType;

import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class RandomRecommender implements IRecommender {

    private static final Logger LOGGER = LoggerFactory.getLogger(RandomRecommender.class);

    @Autowired
    private FilterService filterService;

    @Autowired
    private ItemService itemService;

    @Autowired
    private ChoiceApiConfig choiceApiConfig;

    @Value("${constraint.location.random:true}")
    private boolean constraintLocation;

    @Override
    public RecommenderType getType() {
        return RecommenderType.RANDOM;
    }

    @Override
    public List<ScoredItem> recommend(RecommendRequest recommendRequest) {
        List<String> categories = recommendRequest.getCategories();
        List<Item> itemsNearBy = recommendRequest.getFilteredItems();
        int count = recommendRequest.getCount();
        List<ScoredItem> scoredItems = new ArrayList<>();
        Map<String, List<String>> filters = recommendRequest.getFilters();

        if (itemsNearBy != null && !itemsNearBy.isEmpty()) {
            List<String> itemsToReturnIds = itemsNearBy.stream().map(Item::getId).distinct()
                .collect(Collectors.toList());
            scoredItems.addAll(randomizeItems(itemsToReturnIds, count));
        }
        if (scoredItems.size() > count) {
            return scoredItems.subList(0, count);
        }

        Map<String, Boolean> locationConstraint = choiceApiConfig.getGlobalConfig()
            .getLocationConstraint();
        boolean constraintLocation = locationConstraint != null ? locationConstraint.get("random")
            : this.constraintLocation;
        if (!constraintLocation) {
            List<Item> items = new ArrayList<>();
            OffsetDateTime choiceServedAt = recommendRequest.getChoiceServedAt();
            for (String category : categories) {
                List<Item> categoryItems = filterService.filterExpiredOffers(
                    itemService.getAllItemsByCategoryAndTagFilter(category, filters),
                    choiceServedAt, true);
                LOGGER.info("Num of Items got for Category {} and filter {} is: {}", category,
                    filters, categoryItems.size());
                items.addAll(categoryItems);
            }

            List<String> itemIds = items.stream().map(Item::getId).collect(Collectors.toList());
            List<String> recommendedItems = scoredItems.stream().map(x -> x.getItemId())
                .collect(Collectors.toList());
            itemIds.removeAll(recommendedItems);
            scoredItems.addAll(randomizeItems(itemIds, count - scoredItems.size()));
        }
        return scoredItems;
    }

    private List<ScoredItem> randomizeItems(List<String> itemIds, int count) {
        long startTime = System.nanoTime();
        List<String> randomizedIds = RandomItemService.selectRandom(count, itemIds);
        List<ScoredItem> scoredItems = randomizedIds.stream()
            .map(item -> new ScoredItem(item, 0, RecommenderType.RANDOM))
            .collect(Collectors.toList());
        LOGGER.info("Time Taken : randomizeItems {} ms", (System.nanoTime() - startTime) / 1000000);
        return scoredItems;
    }

}
