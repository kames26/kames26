/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.maya.choice.recommender.list.impl;

import com.crayondata.maya.choice.ListAPI;
import com.crayondata.maya.choice.recommender.list.ChoiceListRecommender;
import com.crayondata.maya.choice.service.ChoiceItemScoreGenerator;
import com.crayondata.maya.choice.service.DistanceService;
import com.crayondata.maya.data.access.util.JsonUtils;
import com.crayondata.maya.data.list.DataListService;
import com.crayondata.maya.data.model.entity.Item;
import com.crayondata.maya.data.model.profile.CityList;
import com.crayondata.maya.data.model.profile.CityListItem;
import com.crayondata.maya.data.model.recommendation.ChoiceListRecommendRequest;
import com.crayondata.maya.model.api.ApiResponse;
import com.crayondata.maya.model.common.GeoCode;
import com.crayondata.maya.model.common.Location;
import com.crayondata.maya.model.enums.ChoiceListType;
import com.crayondata.maya.model.enums.Languages;
import com.crayondata.maya.model.rest.ChoiceListRequest;
import com.fasterxml.jackson.databind.JsonNode;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class NearbyList implements ChoiceListRecommender {

    @Autowired
    DistanceService distanceService;

    @Autowired
    ListAPI listApi;

    @Autowired
    JsonUtils jsonUtils;

    @Value("${distance.calculate.limit}")
    int distanceLimit;

    @Value("${distance.km}")
    int distanceKm;

    @Override
    public List<Item> generateChoices(ChoiceListRecommendRequest request) {
        ChoiceListRequest choiceRequest = request.getChoiceRequest();
        Location location = choiceRequest.getLocation();
        if (location == null) {
            return Collections.EMPTY_LIST;
        }
        GeoCode geocode = location.getGeocode();
        String city = location.getCity();
        boolean distanceToBeCalculated = isDistanceToBeCalculated(
            geocode, city, choiceRequest.getLang());
        if (distanceToBeCalculated) {
            Map<String, Item> items = getFilteredChoices(ChoiceListType.CATEGORY_BASED,
                request, choiceRequest.getLang());
            List<Item> nearbyItems = getNearbyItemList(geocode, city, request, items);
            if (isUserChoicePresent(ChoiceListType.CATEGORY_BASED, request)
                && nearbyItems.isEmpty()) {
                items = request.getLangToFilteredItems().get(Languages
                    .valueOf(choiceRequest.getLang()));
                nearbyItems = getNearbyItemList(geocode, city, request, items);
            }
            return nearbyItems;
        }
        return Collections.EMPTY_LIST;
    }

    @Override
    public ChoiceListType getListType() {
        return ChoiceListType.NEAR_BY;
    }

    @Override
    public ChoiceItemScoreGenerator getItemScoreGenerator() {
        return null;
    }

    private boolean isDistanceToBeCalculated(GeoCode geoCode, String city, String lang) {
        if (geoCode == null && city == null) {
            return false;
        }
        ApiResponse<JsonNode> cityResponse = listApi.getCityList(geoCode, lang);
        if (cityResponse != null) {
            CityListItem[] cityList = jsonUtils.getObject(cityResponse.getResponse(),
                CityListItem[].class);
            CityListItem userNearbyCity = cityList[0];
            if (geoCode != null) {
                double distance = geoCode.distanceFrom(userNearbyCity.getGeoCode());
                boolean isCityEqual =
                    city == null || city.equalsIgnoreCase(userNearbyCity.getLabel());
                return distance <= distanceKm && isCityEqual;
            }
        }
        return true;
    }

    private List<Item> getNearbyItemList(GeoCode geoCode, String city,
        ChoiceListRecommendRequest request, Map<String, Item> items) {
        Map<String, Item> clonedItems = items.values().stream()
            .collect(Collectors.toMap(item -> item.getId(), item -> item));
        distanceService.calculateDistanceAndUpdateItemList(geoCode,
            city, clonedItems);
        return getNearbyItems(request, clonedItems);
    }

    private List<Item> getNearbyItems(ChoiceListRecommendRequest request,
        Map<String, Item> items) {
        List<Item> nearbyItems = items.values().stream()
            .filter(x -> x.getProperties().get(DistanceService.DISTANCE_FIELD) != null
            && (double) x.getProperties().get(DistanceService.DISTANCE_FIELD) > 0
            && (double) x.getProperties().get(DistanceService.DISTANCE_FIELD) <= distanceLimit)
            .collect(Collectors.toList());
        if (!nearbyItems.isEmpty() && nearbyItems.size() >= 3) {
            int count = request.getChoiceRequest().getChoiceCount();
            request.setChoiceCount(ChoiceListType.NEAR_BY.name(), nearbyItems.size());
            Comparator<Item> comparator = Comparator.comparing(
                item -> (double) item.getProperties().get(DistanceService.DISTANCE_FIELD));
            Collections.sort(nearbyItems, comparator);
            int limit = Math.min(nearbyItems.size(), count);
            List<Item> nearbyFilteredItems = nearbyItems.stream().limit(limit)
                .collect(Collectors.toList());
            return nearbyFilteredItems;
        }
        return new ArrayList<>(0);
    }

}
