/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.maya.choice.service;

import static java.time.temporal.ChronoUnit.DAYS;

import com.crayondata.maya.data.entity.ItemService;
import com.crayondata.maya.data.model.entity.Item;
import com.crayondata.maya.data.model.profile.Interaction;
import com.crayondata.maya.data.model.profile.UserChoice;
import com.crayondata.maya.model.enums.ChoiceListType;
import com.crayondata.maya.model.enums.InteractionType;
import com.crayondata.maya.model.enums.ItemType;
import com.crayondata.maya.model.enums.ScoreType;
import java.time.OffsetDateTime;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

@Service
public class BaseScoreGenerator implements ChoiceItemScoreGenerator {
    private static final String SCORE_COEFFICIENT_PREFIX = "choice.list.score.coefficient.";
    private static final String SIMILAR_ITEM_INTERACTION_SCORE = "similar.item.interaction.score.";

    @Autowired
    protected Environment environment;

    @Autowired
    protected ItemService itemService;

    @Value("${norm.min.range}")
    int normMinRange;

    @Value("${norm.max.range}")
    int normMaxRange;

    /**
     * Generates scores based on category.
     *
     * @param choiceListType choice list type
     * @param items items
     * @param userChoices choices generated in batch mode
     * @param userInteractions interactions made by the user
     * @return
     */
    public Map<String, Double> generateScores(ChoiceListType choiceListType,
        List<Item> items, Map<String, UserChoice> userChoices,
        Map<ItemType, Map<InteractionType, List<Interaction>>> userInteractions,
        Map<String, List<String>> similarItems) {
        List<Double> trendScoreList = userChoices.values().stream()
            .filter(x -> x.getScores().get(ScoreType.TRENDING) != null)
            .map(x -> x.getScores().get(ScoreType.TRENDING)).collect(Collectors.toList());
        double minTrendScore = (!trendScoreList.isEmpty()) ? trendScoreList.stream()
            .min(Comparator.comparing(Double::valueOf)).get() : 0.0;
        double maxTrendScore = (!trendScoreList.isEmpty()) ? trendScoreList.stream()
            .max(Comparator.comparing(Double::valueOf)).get() : 0.0;
        Map<String, Double> itemScores = items.stream().filter(x -> userChoices
            .get(x.getId()) != null).collect(Collectors
            .toMap(x -> x.getId(), x -> getChoiceItemScore(choiceListType, x,
            userChoices.get(x.getId()), userInteractions, minTrendScore, maxTrendScore,
            similarItems)));

        return itemScores;
    }

    @Override
    public Map<String, Integer> generateTasteMatchScores(Map<String, Double> choiceScores) {
        if (choiceScores == null || choiceScores.isEmpty()) {
            return Collections.EMPTY_MAP;
        }
        double maxScore = choiceScores.values().stream().mapToDouble(x -> x)
            .max().getAsDouble();
        double minScore = choiceScores.values().stream().mapToDouble(x -> x)
            .min().getAsDouble();
        Map<String, Integer> normalizedScore =
            choiceScores.entrySet().stream().collect(Collectors.toMap(x ->
            x.getKey(), x -> {
                    // Normalized score between [0,1]
                    double score = ((x.getValue() - minScore)
                        / (maxScore - minScore));
                    // Get normalized score within range by applying range on top
                    // of normalized scores
                    int range = normMaxRange - normMinRange;
                    int normScore = (int)(score * range) + normMinRange;
                    return normScore;
                }));
        Map<String, Integer> sortedMap =
            normalizedScore.entrySet().stream().sorted(Collections
            .reverseOrder(Entry.comparingByValue()))
            .collect(Collectors.toMap(x -> x.getKey(), x -> x.getValue(), (x1, x2) -> x1,
            LinkedHashMap::new));
        return sortedMap;
    }

    /**
     * Sorts items based on scores.
     *
     * @param itemScores item score map
     * @param items items to be sorted
     * @return Sorted items
     */
    public List<Item> sortItemsBasedOnScores(Map<String, Double> itemScores,
        List<Item> items) {
        Map<String, Item> idItems = items.stream().collect(Collectors
            .toMap(x -> x.getId(), x -> x));
        Map<String, Double> sorted = itemScores.entrySet()
            .stream().sorted(Collections.reverseOrder(Entry.comparingByValue()))
            .collect(Collectors
            .toMap(e -> e.getKey(), e -> e.getValue(), (e1, e2) -> e2,
            LinkedHashMap::new));

        List<Item> sortedItems = sorted.entrySet().stream()
            .map(x -> idItems.get(x.getKey())).collect(Collectors.toList());
        return sortedItems;
    }

    private Double getChoiceItemScore(ChoiceListType choiceListType, Item item,
        UserChoice userChoice, Map<ItemType, Map<InteractionType, List<Interaction>>>
        userInteractions, double minTrendScore, double maxTrendScore,
        Map<String, List<String>> similarItems) {
        Map<ScoreType, Double> scores = userChoice.getScores();
        Double affinityScore = scores.get(ScoreType.AFFINITY) != null
            ? scores.get(ScoreType.AFFINITY) : 0.0;
        Double trendScore = scores.get(ScoreType.TRENDING) != null
            ? scores.get(ScoreType.TRENDING) : 0.0;
        Double popularityScore = scores.get(ScoreType.POPULAR) != null
            ? scores.get(ScoreType.POPULAR) : 0.0;
        Object[] interactionDetails = getInteractionScore(item, userInteractions);
        Double interactionScore =  (interactionDetails != null)
            ? (Double)interactionDetails[0]  : getScoreIfPresentInSimilarItems(item,
            userInteractions, similarItems);

        long days = (interactionDetails != null)
            ? DAYS.between((OffsetDateTime)interactionDetails[1], OffsetDateTime.now()) : 0;
        switch (choiceListType) {
            case DISCOVERY :
            case REPEAT:
            case CROSS_CATEGORY:
            case NEXT_BEST:
                return getScore(affinityScore, 0.0, 0.0, interactionScore,
                        days, minTrendScore, maxTrendScore);
            case TRENDING:
            case CATEGORY_BASED:
            default:
                return getScore(affinityScore, trendScore, popularityScore,
                        interactionScore, days, minTrendScore, maxTrendScore);
        }
    }

    private Double getScoreIfPresentInSimilarItems(Item item,
        Map<ItemType, Map<InteractionType, List<Interaction>>> userInteractions,
        Map<String, List<String>> similarItems) {
        String itemId = item.getId();
        Double score = 0.0;
        if (similarItems == null || similarItems.isEmpty()) {
            return score;
        }

        Map<String, String> interactions =
            similarItems.entrySet().stream().filter(x -> x.getValue().contains(itemId))
            .collect(Collectors.toMap(y -> y.getKey(), y -> itemId));
        if (interactions.isEmpty()) {
            return score;
        }
        String interactedItemId = interactions.entrySet().stream()
            .iterator().next().getKey();

        Item interactedItem = itemService.getItem(interactedItemId);
        Object[] interactionScore = getInteractionScore(interactedItem, userInteractions);
        if (interactionScore == null || interactionScore.length != 3) {
            return score;
        }

        InteractionType interactionType = (InteractionType) interactionScore[2];
        String value =
            environment.getProperty(SIMILAR_ITEM_INTERACTION_SCORE
            + interactionType.toString());
        return value != null ? Double.valueOf(value) : score;
    }

    private Double getScore(Double affinityScore,
        Double trendScore, Double popularityScore,
        Double interactionScore, long interactionDiffDays,
        double minTrendScore, double maxTrendScore) {
        double affCoefficient = Double.valueOf(
            environment.getProperty(SCORE_COEFFICIENT_PREFIX + ScoreType.AFFINITY.toString()
            .toLowerCase()));
        double intrCoefficient = Double.valueOf(
            environment.getProperty(SCORE_COEFFICIENT_PREFIX + ScoreType.INTERACTION.toString()
            .toLowerCase()));
        double popCoefficient = Double.valueOf(
            environment.getProperty(SCORE_COEFFICIENT_PREFIX + ScoreType.POPULAR.toString()
            .toLowerCase()));
        double tscore = 0.0;
        if (trendScore > 0.0 || minTrendScore > 0.0 || maxTrendScore > 0.0) {
            tscore = (trendScore - minTrendScore) / (maxTrendScore - minTrendScore);
        }
        double score = (affCoefficient * affinityScore)
            + ((intrCoefficient / (interactionDiffDays + 1))
            * (Math.log(Math.exp(interactionScore))))
            + (popCoefficient * popularityScore)
            + tscore;
        return score;
    }

    @Override
    public Double getIntensityForInteractionType(InteractionType interactionType) {
        String intensity = environment.getProperty(
            INTERACTION_SCORE_PREFIX + interactionType.toString());
        return  intensity != null ? Double.valueOf(intensity) : 0.0;
    }
}
