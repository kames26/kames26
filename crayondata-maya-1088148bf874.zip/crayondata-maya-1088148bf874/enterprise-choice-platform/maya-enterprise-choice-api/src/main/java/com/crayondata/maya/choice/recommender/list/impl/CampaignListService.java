/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.maya.choice.recommender.list.impl;

import com.crayondata.maya.data.access.util.DBConstants;
import com.crayondata.maya.data.campaign.UserCampaignService;
import com.crayondata.maya.data.entity.ItemService;
import com.crayondata.maya.data.model.campaign.UserCampaign;
import com.crayondata.maya.data.model.config.ChoiceApiConfig;
import com.crayondata.maya.data.model.entity.Item;
import com.crayondata.maya.data.model.entity.ScoredItem;
import com.crayondata.maya.data.model.profile.UserProfile;
import com.crayondata.maya.data.model.recommendation.ChoiceListRecommendRequest;
import com.crayondata.maya.model.common.GeoCode;
import com.crayondata.maya.model.common.Location;
import com.crayondata.maya.model.enums.ItemType;
import com.crayondata.maya.model.rest.ChoiceListRequest;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class CampaignListService {
    private static final Logger LOGGER = LoggerFactory.getLogger(CampaignListService.class);

    @Autowired
    UserCampaignService userCampaignService;

    @Autowired
    ItemService itemService;

    @Autowired
    ChoiceApiConfig choiceApiConfig;

    @Value("${constraint.location.campaign}")
    private boolean constraintCity;

    @Value("${distance.km}")
    int distance;

    /**
     * Generates choices for all user campaigns.
     *
     * @param request {@link ChoiceListRecommendRequest}
     * @return map of campaign name to choices if present, else empty map
     */
    public Map<String, List<Item>> generateChoices(ChoiceListRecommendRequest request) {
        ChoiceListRequest choiceRequest = request.getChoiceRequest();
        UserProfile userProfile = request.getUserProfile();
        Location location = choiceRequest.getLocation();
        String city = (location != null) ? location.getCity() : null;
        GeoCode geoCode = (location != null) ? location.getGeocode() : null;

        String usrCmpnId = userProfile.getKnownUserId();
        List<UserCampaign> userCampaignList = userCampaignService.getUserCampaignList(usrCmpnId);
        Map<String, List<Item>> campaignItems = new LinkedHashMap<>();
        String reqCmpnId = choiceRequest.getCampaignId();
        for (UserCampaign usercmpn : userCampaignList) {
            if (reqCmpnId != null && !usercmpn.getCampaign()
                .getId().equals(reqCmpnId)) {
                continue;
            }

            List<Item> items =
                getCampaignItems(usercmpn, geoCode, city, choiceRequest.getLang());
            String category = choiceRequest.getCategory();
            if (!items.isEmpty()) {
                List<Item> filteredItems = items.stream()
                    .filter(x -> DBConstants.CATEGORY_ALL.equalsIgnoreCase(category)
                    || x.getCategory().equals(category))
                    .filter(x -> {
                        if (location == null) {
                            return true;
                        } else if (x.getIsOnline() == true) {
                            return true;
                        } else if (location.getCity() != null) {
                            return x.getCities().contains(location.getCity());
                        } else if (location.getGeocode() != null) {
                            return location.getGeocode()
                                .getClosestGeoDistance(x.getGeoCodes()) <= distance;
                        }
                        return true;
                    }).collect(Collectors.toList());

                int limit =
                    Math.min(request.getChoiceRequest().getChoiceCount(), filteredItems.size());
                List<Item> itemsWithLimit = filteredItems.stream().limit(limit)
                    .collect(Collectors.toList());
                String cmpnName = usercmpn.getCampaign().getName();
                if (!itemsWithLimit.isEmpty()) {
                    campaignItems.put(cmpnName, itemsWithLimit);
                    request.setChoiceCount(cmpnName, filteredItems.size());
                }
            }
        }
        return campaignItems;
    }

    private List<Item> getCampaignItems(UserCampaign userCampaign, GeoCode geoCode,
        String city, String lang) {
        OffsetDateTime choiceServedAt = OffsetDateTime.now();
        OffsetDateTime campaignStartTime = userCampaign.getCampaign().getStartDateTime();
        OffsetDateTime campaignEndTime = userCampaign.getCampaign().getEndDateTime();
        boolean campaignActive = userCampaign.getCampaign().isActive();
        LOGGER.debug("Campaign Active: {}", campaignActive);

        List<ScoredItem> recommendations = new ArrayList<>();
        if (campaignActive) {
            // Apply the context filters only if they are present
            if (choiceServedAt != null && campaignStartTime != null && campaignEndTime != null) {
                if (choiceServedAt.isAfter(campaignStartTime)
                    && choiceServedAt.isBefore(campaignEndTime)) {
                    LOGGER.debug("Choice is being served when the campaign is active");
                    recommendations.addAll(userCampaign.getItems());
                }
            } else {
                recommendations.addAll(userCampaign.getItems());
            }
        }

        if (recommendations.isEmpty()) {
            return Collections.emptyList();
        }

        List<String> itemIds = recommendations.stream().map(ScoredItem::getItemId)
            .collect(Collectors.toList());
        List<Item> items = itemService
            .getItems(itemIds, ItemType.MERCHANT, lang);

        if (geoCode != null) {
            // filter expired offers from recommendations
            Set<String> filteredItemIDs = items.stream().map(Item::getId)
                .collect(Collectors.toSet());
            recommendations = recommendations.stream()
                .filter(item -> filteredItemIDs.contains(item.getItemId()))
                .collect(Collectors.toList());
            recommendations = ScoredItem
                .sortScoredItemsBasedOnGeo(geoCode, recommendations, items);
        } else if (city != null) {
            Map<String, Boolean> locationConstraint = choiceApiConfig.getGlobalConfig() != null
                ? choiceApiConfig.getGlobalConfig().getLocationConstraint() : null;
            boolean constraintCity = locationConstraint != null ? locationConstraint.get("campaign")
                : this.constraintCity;
            if (constraintCity) {
                LOGGER.debug("Filtering Campaign choices due to constraintCity={} based on city:{}",
                    constraintCity, city);
                recommendations = filterScoredItemsOnCity(city, recommendations, items);
            }
        }

        Map<String, Item> availableItems = items.stream().collect(Collectors
            .toMap(x -> x.getId(), x -> x));

        List<Item> recommendedItems = recommendations.stream()
            .filter(recommendation -> availableItems.containsKey(recommendation.getItemId()))
            .map(x -> availableItems.get(x.getItemId())).collect(Collectors.toList());

        return recommendedItems;
    }

    private static List<ScoredItem> filterScoredItemsOnCity(String city,
        List<ScoredItem> scoredItems, List<Item> items) {
        List<String> idsOfItemsInCity = new ArrayList<>();
        for (Item item : items) {
            List<String> cities = item.getCities();
            if (cities.contains(city)) {
                idsOfItemsInCity.add(item.getId());
            }
        }
        return scoredItems.stream().filter(x -> idsOfItemsInCity.contains(x.getItemId()))
            .collect(Collectors.toList());
    }
}

