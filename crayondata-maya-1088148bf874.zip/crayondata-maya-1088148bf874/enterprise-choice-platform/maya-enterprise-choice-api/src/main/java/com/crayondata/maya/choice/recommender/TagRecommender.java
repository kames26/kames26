/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.maya.choice.recommender;

import com.crayondata.maya.choice.service.FilterService;
import com.crayondata.maya.choice.utils.Constants;
import com.crayondata.maya.data.entity.ItemService;
import com.crayondata.maya.data.model.entity.Item;
import com.crayondata.maya.data.model.entity.ScoredItem;
import com.crayondata.maya.data.model.profile.TagScore;
import com.crayondata.maya.data.model.recommendation.RecommendRequest;
import com.crayondata.maya.data.model.recommendation.RecommenderType;
import com.crayondata.maya.data.profile.InteractionService;
import com.crayondata.maya.data.profile.UserTagService;
import com.crayondata.maya.model.common.GeoCode;
import com.crayondata.maya.model.explanator.IExplanator;
import com.crayondata.maya.model.explanator.TagExplanator;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class TagRecommender implements IRecommender {

    private static final Logger LOGGER = LoggerFactory.getLogger(TagRecommender.class);

    @Autowired
    private ItemService itemService;

    @Autowired
    private UserTagService userTagService;

    @Autowired
    private InteractionService interactionService;

    @Autowired
    private FilterService filterService;

    @Value("${recommender.explanator:false}")
    private boolean isExplanatorEnabled;

    @Value("${recommender.explanator.tag.count:5}")
    private Integer topTagCount;

    @Override
    public RecommenderType getType() {
        return RecommenderType.TAG;
    }

    @Override
    public List<ScoredItem> recommend(RecommendRequest recommendRequest) {
        List<ScoredItem> recommendations = new ArrayList<>(0);
        String sessionUserId = recommendRequest.getUserProfile().getId();
        String knownUserId = recommendRequest.getUserProfile().getKnownUserId();
        List<String> categories = recommendRequest.getCategories();
        OffsetDateTime timestamp = recommendRequest.getChoiceServedAt();
        boolean explain = recommendRequest.getFlags().get(Constants.KEY_EXPLAIN);
        boolean normalizeScoreByDistance = recommendRequest.getFlags()
            .get(Constants.KEY_NORMALIZE_SCORE);
        GeoCode choiceLoc = recommendRequest.getChoiceLoc();
        boolean isValidGeo = GeoCode.isValid(choiceLoc);
        LOGGER.info("Valid Geo: {}, Normalize Score By Distance: {}", isValidGeo,
            normalizeScoreByDistance);

        List<Item> filteredItems = recommendRequest.getFilteredItems();
        LOGGER.info(
            "Getting TAG recommendations for user: SessionId: {} KnownUserId: {} & category: {}",
            sessionUserId, knownUserId, categories);

        if (filteredItems == null || filteredItems.isEmpty()) {
            return recommendations; // 0 choices 
        }
        // TagVector
        final long startTime = System.nanoTime();
        String dynamicUserId;
        if (knownUserId == null) {
            dynamicUserId = sessionUserId;
        } else {
            dynamicUserId = knownUserId;
        }

        Map<String, TagScore> combinedUserFinalTagVector = null;
        for (String category : categories) {
            Map<String, TagScore> userBatchTagVector = userTagService
                .getUserTagVectorByCategory(knownUserId, category);
            Map<String, TagScore> userDynamicTagVector = userTagService
                .getDynamicUserTagVectorByCategory(dynamicUserId, category);
            Map<String, TagScore> userFinalTagVector = userTagService
                .combineUserTagVectors(userBatchTagVector, userDynamicTagVector);

            //combine tag vectors across categories
            combinedUserFinalTagVector = userTagService
                .combineUserTagVectors(combinedUserFinalTagVector, userFinalTagVector);
        }
        if (combinedUserFinalTagVector != null) {
            for (Item item : filteredItems) {
                float score = 0;
                List<String> tags = item.getTags();
                for (String tag : tags) {
                    if (combinedUserFinalTagVector.containsKey(tag)) {
                        score += combinedUserFinalTagVector.get(tag).getScore();
                    }
                }
                if (isValidGeo && normalizeScoreByDistance) {
                    double distance = choiceLoc.getClosestGeoDistance(item.offerGeoCodes());
                    score /= Math.sqrt(distance + 1);
                }
                if (score > 0) {
                    //If explanator enabled
                    if (isExplanatorEnabled && explain) {
                        Map<RecommenderType, IExplanator> explanation = new HashMap<>();
                        IExplanator tagExplanator = getTagExplanator(combinedUserFinalTagVector,
                            item);
                        explanation.put(RecommenderType.TAG, tagExplanator);
                        recommendations.add(new ScoredItem(item.getId(), score, RecommenderType.TAG,
                            explanation));
                    } else {
                        recommendations
                            .add(new ScoredItem(item.getId(), score, RecommenderType.TAG));
                    }
                }
            }
            // TODO: No of recommendations
            recommendations = filterService
                .filterInteractedItems(recommendations, dynamicUserId, timestamp);
            recommendations.sort(Comparator.naturalOrder());
        }
        LOGGER.info("Time Taken : recommend {} {}",
            (System.nanoTime() - startTime) / 1000000, "ms");
        return recommendations;
    }

    private IExplanator getTagExplanator(Map<String, TagScore> combinedTagVector, Item item) {
        IExplanator tagExplanator = new TagExplanator();
        //Collect common tags that have positive scores
        Map<String, Double> commonTags = new HashMap<>();
        for (String tag : item.getTags()) {
            if (combinedTagVector.containsKey(tag) && combinedTagVector.get(tag).getScore() > 0) {
                commonTags.put(tag, combinedTagVector.get(tag).getScore());
            }
        }

        //Sort tags based on tag scores and Take top tags
        Map<String, Double> sortedMap = new LinkedHashMap<String, Double>();
        commonTags.entrySet().stream()
            .sorted(Map.Entry.<String, Double>comparingByValue().reversed()).limit(topTagCount)
            .forEachOrdered(c -> sortedMap.put(c.getKey(), c.getValue()));

        tagExplanator.setContributingTags(sortedMap);
        return tagExplanator;
    }
}
