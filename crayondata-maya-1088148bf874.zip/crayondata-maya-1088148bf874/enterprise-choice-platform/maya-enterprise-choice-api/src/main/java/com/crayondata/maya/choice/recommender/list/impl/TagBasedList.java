/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.maya.choice.recommender.list.impl;

import com.crayondata.maya.choice.recommender.list.ChoiceListRecommender;
import com.crayondata.maya.choice.service.BaseScoreGenerator;
import com.crayondata.maya.choice.service.ChoiceItemScoreGenerator;
import com.crayondata.maya.data.access.util.DBConstants;
import com.crayondata.maya.data.list.DataListService;
import com.crayondata.maya.data.model.entity.Item;
import com.crayondata.maya.data.model.profile.TagScore;
import com.crayondata.maya.data.model.profile.UserTagVector;
import com.crayondata.maya.data.model.recommendation.ChoiceListRecommendRequest;
import com.crayondata.maya.data.profile.UserTagService;
import com.crayondata.maya.model.enums.ChoiceListType;
import com.crayondata.maya.model.enums.Languages;
import com.crayondata.maya.model.rest.ChoiceListRequest;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ArrayNode;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class TagBasedList implements ChoiceListRecommender {

    @Autowired
    DataListService dataListService;

    @Autowired
    UserTagService userTagService;

    @Autowired
    BaseScoreGenerator itemScoreGenerator;

    @Override
    public List<Item> generateChoices(ChoiceListRecommendRequest request) {
        ChoiceListRequest choiceRequest = request.getChoiceRequest();
        Map<String, Item> filteredItems = request.getLangToFilteredItems()
            .get(Languages.valueOf(choiceRequest.getLang()));
        Map<String, Double> idScoreMap = new HashMap<>();
        List<Item> scoredItems = new ArrayList<>(0);
        Map<String, TagScore> combinedUserFinalTagVector = request.getUserTagVectors();
        if (combinedUserFinalTagVector != null) {
            for (Item item : filteredItems.values()) {
                double score = 0;
                List<String> tags = item.getTags();
                for (String tag : tags) {
                    if (combinedUserFinalTagVector.containsKey(tag)) {
                        score += combinedUserFinalTagVector.get(tag).getScore();
                    }
                }
                if (score > 0) {
                    idScoreMap.put(item.getId(), score);
                }
            }
        }

        if (idScoreMap != null && !idScoreMap.isEmpty()) {
            Map<String, Double> sortedMap = idScoreMap.entrySet().stream()
                .sorted(Map.Entry.<String,Double>comparingByValue().reversed())
                .collect(Collectors
                .toMap(Entry::getKey, Entry::getValue, (oldValue, newValue) -> oldValue,
                LinkedHashMap::new));
            Map<String, Integer> tasteMatchScores =
                itemScoreGenerator.generateTasteMatchScores(sortedMap);
            request.setChoiceCount(ChoiceListType.TAG_BASED.name(), sortedMap.size());
            int count = Math.min(sortedMap.size(), choiceRequest.getChoiceCount());
            scoredItems = tasteMatchScores.entrySet().stream().limit(count)
                .map(x -> itemScoreGenerator
                .updateItemWithTasteMatchScore(x.getValue(), filteredItems.get(x.getKey())))
                .collect(Collectors.toList());
        }
        return scoredItems;
    }

    @Override
    public ChoiceListType getListType() {
        return ChoiceListType.TAG_BASED;
    }

    @Override
    public ChoiceItemScoreGenerator getItemScoreGenerator() {
        return itemScoreGenerator;
    }

    private List<String> getCategoryList(String givenCategory) {
        List<String> categoryList = new ArrayList<>();
        if (givenCategory == null || DBConstants.CATEGORY_ALL.equalsIgnoreCase(givenCategory)) {
            JsonNode jsonNode = dataListService.getDataList("categories", Languages.en.name());
            if (jsonNode != null) {
                ArrayNode categArrayNode = (ArrayNode) jsonNode;
                for (JsonNode categ : categArrayNode) {
                    categoryList.add(categ.get("value").asText());
                }
            }
        } else {
            categoryList.add(givenCategory);
        }
        return categoryList;
    }
}

