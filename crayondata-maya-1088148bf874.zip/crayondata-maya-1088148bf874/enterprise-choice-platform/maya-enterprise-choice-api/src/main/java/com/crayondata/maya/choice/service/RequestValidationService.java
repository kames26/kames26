/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.maya.choice.service;

import static com.crayondata.maya.data.utils.ObjectUtils.defaultIfNull;

import com.crayondata.maya.data.model.config.ChoiceApiConfig;
import com.crayondata.maya.model.rest.ChoiceRequest;

import java.time.OffsetDateTime;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class RequestValidationService {

    private static final Logger LOGGER = LoggerFactory.getLogger(RequestValidationService.class);

    private final Integer maxCount;
    private final Integer defaultCount;
    private final boolean paginate;
    private final int maxPaginatedChoices;
    private ChoiceApiConfig choiceApiConfig;

    /**
     * Instantiates a validator with the defined configuration.
     *
     * @param defaultCount        Default number of choices, if not/incorrectly provided in request
     * @param maxCount            Upper limit on the number of choices
     * @param paginate            Global switch to disable pagination support
     * @param maxPaginatedChoices Upper limit on the number of choices when pagination is enabled
     */
    @Autowired
    public RequestValidationService(
        @Value("${input.count.default}") Integer defaultCount,
        @Value("${input.count.max}") Integer maxCount,
        @Value("${pagination.enabled}") boolean paginate,
        @Value("${pagination.maxChoices}") int maxPaginatedChoices,
        ChoiceApiConfig choiceApiConfig) {
        this.defaultCount = defaultCount;
        this.maxCount = maxCount;
        this.paginate = paginate;
        this.maxPaginatedChoices = maxPaginatedChoices;
        this.choiceApiConfig = choiceApiConfig;
    }

    public Integer getMaxCount() {
        return defaultIfNull(choiceApiConfig.getGlobalConfig().getInputCountMax(), maxCount);
    }

    public Integer getDefaultCount() {
        return defaultIfNull(choiceApiConfig.getGlobalConfig().getInputCountDefault(),
            defaultCount);
    }

    public OffsetDateTime getServedAt() {
        return OffsetDateTime.now();
    }

    public int getMaxPaginatedChoices() {
        return defaultIfNull(choiceApiConfig.getGlobalConfig().getPaginationMaxChoices(),
            maxPaginatedChoices);
    }

    public boolean isPaginate() {
        return defaultIfNull(choiceApiConfig.getGlobalConfig().getPaginate(), paginate);
    }

    /**
     * Validates the choice request against correctness, handling invalid combinations
     * and defaulting as needed.
     *
     * @param request Request that is to be validated
     * @return
     */
    public ChoiceRequest validate(ChoiceRequest request) {
        if (request != null) {
            // Pagination validation
            if (!isPaginate() || request.getPaginate() == null) {
                request.setPaginate(false);
            }
            // Count validation
            Integer requestChoiceCount = request.getCount();
            if (request.getPaginate()) {
                // pagination request has a different default & max counts
                if (requestChoiceCount == null || requestChoiceCount <= 0
                    || requestChoiceCount > getMaxPaginatedChoices()) {
                    request.setCount(getMaxPaginatedChoices());
                }
            } else {
                if (requestChoiceCount == null || requestChoiceCount <= 0) {
                    request.setCount(getDefaultCount());
                } else if (requestChoiceCount > getMaxCount()) {
                    request.setCount(getMaxCount());
                }
            }
            // servedAt validation
            if (request.getServedAt() == null) {
                request.setServedAt(getServedAt());
            }
            // Explain validation
            if (request.getExplain() == null) {
                request.setExplain(false);
            }
            return request;
        } else {
            return getDefaultRequest();
        }
    }

    private ChoiceRequest getDefaultRequest() {
        ChoiceRequest request = new ChoiceRequest();
        request.setCount(getDefaultCount());
        request.setServedAt(getServedAt());
        request.setExplain(false);
        request.setPaginate(false);
        return request;
    }
}
