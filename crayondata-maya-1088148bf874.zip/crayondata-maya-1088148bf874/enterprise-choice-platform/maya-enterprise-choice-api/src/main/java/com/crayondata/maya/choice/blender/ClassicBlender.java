/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.maya.choice.blender;

import com.crayondata.maya.choice.recommender.factory.RecommenderFactory;
import com.crayondata.maya.data.entity.ItemService;
import com.crayondata.maya.data.model.entity.Item;
import com.crayondata.maya.data.model.entity.ScoredItem;
import com.crayondata.maya.data.model.recommendation.BlenderType;
import com.crayondata.maya.data.model.recommendation.RecommendRequest;
import com.crayondata.maya.data.model.recommendation.RecommenderType;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

/**
 * This is a re-implementation of the existing logic(before implementation of INTERLEAVED blender)
 * to blend the recommendations. Blends the recommendations by interleaving recommendations from
 * each recommender
 * based on configuration. Recommendations common in the recommenders
 * will be moved to top of the final mix.
 *
 * @author somin
 */
@Service
public class ClassicBlender implements IBlender {

    private static final Logger LOGGER = LoggerFactory.getLogger(ClassicBlender.class);

    private String recommenderRatio;
    private RecommenderFactory recommenderFactory;
    private ItemService itemService;

    @Autowired
    public ClassicBlender(@Value("${recommender.choiceratio:1:1}") String recommenderRatio,
        RecommenderFactory recommenderFactory, ItemService itemService) {
        this.recommenderRatio = recommenderRatio;
        this.recommenderFactory = recommenderFactory;
        this.itemService = itemService;
    }

    @Override
    public BlenderType getType() {
        return BlenderType.CLASSIC;
    }

    @Override
    public List<ScoredItem> blend(Map<RecommenderType, List<ScoredItem>> recommendations,
        List<Map<String, Object>> blendingConfig,
        RecommendRequest recommendRequest) {
        long startTime = System.nanoTime();

        List<ScoredItem> tagRecommendations = new ArrayList<>(
            recommendations.get(RecommenderType.TAG));
        List<ScoredItem> similarityRecommendations = new ArrayList<>(
            recommendations.get(RecommenderType.SIMILARITY));

        List<ScoredItem> resultRecommendations = mergeRecommendations(tagRecommendations,
            similarityRecommendations, recommenderRatio);
        int recReqCount = recommendRequest.getCount();
        if (resultRecommendations.size() < recReqCount) { //call top-rated
            Map<String, ScoredItem> itemIdToScoredItemMap = new HashMap<>(recReqCount);
            boolean padResults = false;
            if (resultRecommendations.isEmpty()) {
                // since similarity is empty, top rated may be used for padding with unconstrainted
                // results
                LOGGER.info("Tag and Similarity gave 0 recommendations, so enabling padding");
                padResults = true;
            } else {
                List<String> resultItemIds = resultRecommendations.stream()
                    .map(ScoredItem::getItemId).collect(Collectors.toList());
                List<Item> resultItems = itemService.getItems(resultItemIds);
                List<Item> offlineItems = resultItems.stream()
                    .filter(item -> !item.getIsOnline()).collect(Collectors.toList());
                if (offlineItems.isEmpty()) {
                    // since offline offers is empty, top rated may be used for padding with
                    // unconstrainted results
                    LOGGER.info(
                        "Tag and Similarity gave 0 offline recommendations, so enabling padding");
                    padResults = true;
                }
            }
            recommendRequest.getFlags().put("padResults", padResults);
            //add recommendations to map
            mergeScores(itemIdToScoredItemMap, new ArrayList<>(), resultRecommendations,
                resultRecommendations.size());
            //call toprated
            List<ScoredItem> recTopRated = recommenderFactory
                .getRecommender(RecommenderType.TOPRATED).recommend(recommendRequest);
            LOGGER.info("Got {} recommendations from TopRated Recommender", recTopRated.size());
            mergeScores(itemIdToScoredItemMap, resultRecommendations, recTopRated,
                recTopRated.size());
        }
        LOGGER.info("Blending using {} took {} ms", getType(),
            (System.nanoTime() - startTime) / 1000000);
        return resultRecommendations;
    }

    private Map<RecommenderType, Integer> parseConfig(List<Map<String, Object>> blendingConfig) {
        Map<RecommenderType, Integer> recommenderRatio = new LinkedHashMap<>();
        blendingConfig.forEach(config -> {
            RecommenderType recommender = RecommenderType.valueOf(
                (String) config.get("recommender"));
            Integer count = (Integer) config.get("count");
            recommenderRatio.put(recommender, count);
        });
        LOGGER.info("Using recommender ratio {}", recommenderRatio);
        return recommenderRatio;
    }

    private List<ScoredItem> mergeRecommendations(List<ScoredItem> tagRecommendations,
        List<ScoredItem> similarityRecommendations, String ratioString) {
        if (tagRecommendations == null || tagRecommendations.isEmpty()) {
            return similarityRecommendations;
        }
        if (similarityRecommendations == null || similarityRecommendations.isEmpty()) {
            return tagRecommendations;
        }
        //show choices from both recommender first followed by interleaved choices
        List<ScoredItem> resultantRecommendations = getCommonChoices(tagRecommendations,
            similarityRecommendations);
        resultantRecommendations.addAll(combineRecommendations(tagRecommendations,
            similarityRecommendations, ratioString));
        return resultantRecommendations;
    }

    private List<ScoredItem> getCommonChoices(List<ScoredItem> tagRecommendations,
        List<ScoredItem> similarityRecommendations) {
        List<ScoredItem> commonChoices = new ArrayList<>();
        Map<String, ScoredItem> itemMap = new HashMap<>();
        for (ScoredItem s : tagRecommendations) {
            itemMap.put(s.getItemId(), s);
        }
        for (int i = 0; i < similarityRecommendations.size(); i++) {
            ScoredItem s = similarityRecommendations.get(i);
            String itemId = s.getItemId();
            if (itemMap.containsKey(itemId)) {
                s.mergeScores(itemMap.get(itemId));
                commonChoices.add(s);
                tagRecommendations.remove(itemMap.get(itemId));
            }
        }
        similarityRecommendations.removeAll(commonChoices);
        return commonChoices;
    }

    private List<ScoredItem> combineRecommendations(List<ScoredItem> tagRecommendations,
        List<ScoredItem> similarityRecommendations, String ratioString) {
        List<ScoredItem> resultantRecommendations = new ArrayList<>();
        String[] ratio = ratioString.split(":");
        int tagRatio = Integer.parseInt(ratio[0]);
        int similarityRatio = Integer.parseInt(ratio[1]);
        //interleav
        int tagSize = tagRecommendations.size();
        int simlSize = similarityRecommendations.size();
        int index1 = 0;
        int index2 = 0;
        for (; index1 < tagSize && index2 < simlSize;
            index1 += tagRatio, index2 += similarityRatio) {
            resultantRecommendations.addAll(tagRecommendations.subList(index1,
                index1 + tagRatio > tagSize ? tagSize : index1 + tagRatio));
            resultantRecommendations.addAll(similarityRecommendations.subList(index2,
                index2 + similarityRatio > simlSize ? simlSize : index2 + similarityRatio));
        }
        if (index1 < tagSize) {
            resultantRecommendations.addAll(tagRecommendations.subList(index1, tagSize));
        }
        if (index2 < simlSize) {
            resultantRecommendations.addAll(similarityRecommendations.subList(index2, simlSize));
        }
        return resultantRecommendations;
    }

    private static void mergeScores(Map<String, ScoredItem> map, List<ScoredItem> cumulativeList,
        List<ScoredItem> newList, int maxNew) {
        // Side Effect: this function modifies the argument objects 'map' and 'cumulativeList'
        for (int i = 0; i < newList.size() && maxNew > 0; i++) {
            ScoredItem s = newList.get(i);
            String itemId = s.getItemId();
            if (map.containsKey(itemId)) {
                map.get(itemId).mergeScores(s);
            } else {
                map.put(itemId, s);
                cumulativeList.add(s);
                maxNew--;
            }
        }
    }

}
