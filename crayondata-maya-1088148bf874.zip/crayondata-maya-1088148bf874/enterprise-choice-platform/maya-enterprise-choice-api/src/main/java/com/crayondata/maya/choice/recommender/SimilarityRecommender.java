/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.maya.choice.recommender;

import com.crayondata.maya.choice.service.FilterService;
import com.crayondata.maya.choice.utils.Constants;
import com.crayondata.maya.data.access.util.DBConstants;
import com.crayondata.maya.data.choice.TGScoreService;
import com.crayondata.maya.data.entity.ItemService;
import com.crayondata.maya.data.model.choice.TGScore;
import com.crayondata.maya.data.model.choice.TGSimilarity;
import com.crayondata.maya.data.model.entity.Item;
import com.crayondata.maya.data.model.entity.ScoredItem;
import com.crayondata.maya.data.model.profile.Interaction;
import com.crayondata.maya.data.model.profile.Transaction;
import com.crayondata.maya.data.model.recommendation.RecommendRequest;
import com.crayondata.maya.data.model.recommendation.RecommenderType;
import com.crayondata.maya.data.profile.InteractionService;
import com.crayondata.maya.data.profile.TransactionService;
import com.crayondata.maya.data.profile.UserProfileService;
import com.crayondata.maya.model.common.GeoCode;
import com.crayondata.maya.model.enums.InteractionType;
import com.crayondata.maya.model.enums.TransactionType;
import com.crayondata.maya.model.explanator.ExplanationDetails;
import com.crayondata.maya.model.explanator.IExplanator;
import com.crayondata.maya.model.explanator.SimilarityExplanator;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

/**
 * Similarity based recommender.
 *
 * @author sundar
 */
@Service
public class SimilarityRecommender implements IRecommender {

    private static final Logger LOGGER = LoggerFactory.getLogger(SimilarityRecommender.class);

    @Autowired
    private InteractionService interactionService;

    @Autowired
    private TransactionService transactionService;

    @Autowired
    private TGScoreService tgScoreService;

    @Autowired
    private ItemService itemService;

    @Autowired
    private FilterService filterService;

    @Autowired
    private UserProfileService userProfileService;

    @Value("${recommender.explanator:false}")
    private boolean isExplanatorEnabled;

    @Value("${recommender.explanator.item.count:5}")
    private Integer topItemCount;

    @Override
    public RecommenderType getType() {
        return RecommenderType.SIMILARITY;
    }

    @Override
    public List<ScoredItem> recommend(RecommendRequest recommendRequest) {
        String userId = userProfileService.getUseableUserId(recommendRequest.getUserProfile());
        OffsetDateTime choiceServedAt = recommendRequest.getChoiceServedAt();
        long startTime = System.nanoTime();
        List<ScoredItem> recommendations = recommendSimilarityItems(recommendRequest);
        LOGGER.info("Time Taken : recommend {} ms", (System.nanoTime() - startTime) / 1000000);
        return filterService.filterInteractedItems(recommendations, userId, choiceServedAt);
    }

    private List<ScoredItem> recommendSimilarityItems(RecommendRequest recommendRequest) {
        String userId = userProfileService.getUseableUserId(recommendRequest.getUserProfile());
        String knownUserId = recommendRequest.getUserProfile().getKnownUserId();
        if (knownUserId != null) {
            knownUserId = DBConstants.stripUserKeyIfExists(knownUserId);
        }
        GeoCode choiceLoc = recommendRequest.getChoiceLoc();
        boolean normalizeScoreByDist = recommendRequest.getFlags()
            .get(Constants.KEY_NORMALIZE_SCORE);
        List<Item> nearbyItemIds = recommendRequest.getFilteredItems();
        final OffsetDateTime choiceServedAt = recommendRequest.getChoiceServedAt();
        boolean isValidGeo = GeoCode.isValid(choiceLoc);
        LOGGER.info("Valid Geo: {}, Normalize Score By Distance: {}", isValidGeo,
            normalizeScoreByDist);

        if (nearbyItemIds == null || nearbyItemIds.isEmpty()) {
            LOGGER.debug("Returning 0 choices due to 0 nearby items for user: {}", userId);
            return new ArrayList<>();
        }
        final long startTime1 = System.nanoTime();
        Map<InteractionType, List<Interaction>> userInteractions = interactionService
            .getInteractionsWithUserId(userId);
        List<Interaction> positiveInteractions = new ArrayList<>();
        // TODO: Apply interaction intensity to choices
        positiveInteractions.addAll(userInteractions
            .getOrDefault(InteractionType.LIKE, Collections.emptyList()));
        positiveInteractions.addAll(userInteractions
            .getOrDefault(InteractionType.VIEW, Collections.emptyList()));
        positiveInteractions.addAll(userInteractions
            .getOrDefault(InteractionType.SEARCH, Collections.emptyList()));
        positiveInteractions.addAll(userInteractions
            .getOrDefault(InteractionType.REDEEM, Collections.emptyList()));

        LOGGER.info("Got {} positive interactions for user: {}", positiveInteractions.size(),
            userId);
        LOGGER.info("Time Taken : getInteractionsWithUserIdAndInteractionType{} {}",
            (System.nanoTime() - startTime1) / 1000000, "ms");
        List<Transaction> buyTransactions = new ArrayList<>();
        long startTime2 = System.nanoTime();
        if (knownUserId != null) {
            buyTransactions = transactionService
                .getTransactionsWithUserIdAndTransactionType(knownUserId, TransactionType.BUY);
            LOGGER.info("Got {} transactions for user: {} knownuserid:{}", buyTransactions.size(),
                userId, knownUserId);
        }
        LOGGER.info("Time Taken : getTransactionsWithUserIdAndTransactionType{} {}",
            (System.nanoTime() - startTime2) / 1000000, "ms");
        if (positiveInteractions.isEmpty() && buyTransactions.isEmpty()) {
            return new ArrayList<>();
        }

        String itemType = null;
        if (recommendRequest.getItemType() != null) {
            itemType = recommendRequest.getItemType().toString();
        }
        long startTime3 = System.nanoTime();
        List<TGSimilarity> intrSimilarities = tgScoreService
            .getTGSimilaritiesInteractions(itemType, positiveInteractions, choiceServedAt);

        List<ScoredItem> intrAggregatedTgScores = aggregateTgScores(intrSimilarities,
            nearbyItemIds, normalizeScoreByDist, choiceLoc);
        LOGGER.debug("Choices from interaction TG: {}", intrAggregatedTgScores.size());
        LOGGER.info("Time Taken : getTGSimilaritiesInteractions{} {}",
            (System.nanoTime() - startTime3) / 1000000, "ms");

        long startTime4 = System.nanoTime();
        // repeat for transactions
        List<TGSimilarity> transSimilarities = tgScoreService.getTGSimilaritiesTransactions(
            itemType, buyTransactions, choiceServedAt);
        List<ScoredItem> transAggregatedTgScores = aggregateTgScores(transSimilarities,
            nearbyItemIds, normalizeScoreByDist, choiceLoc);
        LOGGER.debug("Choices after transaction TG: {}", transAggregatedTgScores.size());
        LOGGER.info("Time Taken : getTGSimilaritiesTransactions{} {}",
            (System.nanoTime() - startTime4) / 1000000, "ms");
        List<ScoredItem> blendedItems = blendRecommendations(intrAggregatedTgScores,
            transAggregatedTgScores);

        // Loop is commented out to avoid db call since retrieved items aren't used
        /*if (choiceLoc != null) {
            List<String> itemIds = blendedItems.stream().map(ScoredItem::getItemId)
                    .collect(Collectors.toList());
            if (itemIds != null) {
                List<Item> items = itemService.getItems(itemIds);
            }
            //ScoredItem.sortScoredItemsBasedOnGeo(choiceLocation, blendedItems, items);
        }
        */
        blendedItems.sort(Comparator.naturalOrder());

        if (isExplanatorEnabled && recommendRequest.getFlags().get(Constants.KEY_EXPLAIN)) {
            addExplanators(blendedItems, intrSimilarities, transSimilarities);
        }

        LOGGER.info("Time Taken : SimilarityRecommender{} ms",
            (System.nanoTime() - startTime4) / 1000000);
        return blendedItems;
    }

    private List<ScoredItem> aggregateTgScores(List<TGSimilarity> similarities,
        List<Item> nearbyItems, boolean normalizeScoreByDist, GeoCode geoCode) {
        // Irrespective of node1, collect TG Scores of the same TG Type
        Map<String, List<TGScore>> allTgScores = new HashMap<>();
        similarities.forEach(similar -> similar.getTgScores().forEach((k, v) -> {
            allTgScores.putIfAbsent(k, new ArrayList<>());
            allTgScores.get(k).addAll(v);
        }));

        Map<String, Float> allScores = new HashMap<>();
        for (Map.Entry<String, List<TGScore>> entry : allTgScores.entrySet()) {
            // Add scores for the same 'node2'
            Map<String, Integer> aggregatedScores = aggregateScoresForSameNode(entry.getValue());
            // Pick the highest score across various TG Type and store in Map
            aggregatedScores.forEach((k, v) -> allScores.merge(k, (float) v, Float::max));
        }
        LOGGER.debug("Items from TG: {}", allScores.size());
        LOGGER.debug("Items from Location: {}", nearbyItems.size());

        Set<String> nearByItemIds = nearbyItems.stream().map(Item::getId)
            .collect(Collectors.toSet());
        // keySet only returns a view of the keys in the map. hence, any operation on this key set
        // will reflect in the map
        allScores.keySet().retainAll(nearByItemIds);

        final List<ScoredItem> scoredItems = new ArrayList<>();
        if (normalizeScoreByDist && GeoCode.isValid(geoCode)) {
            Map<String, Double> itemDistanceMap = nearbyItems.stream()
                .collect(Collectors.toMap(
                Item::getId, x -> geoCode.getClosestGeoDistance(x.offerGeoCodes())));
            allScores.forEach((k, v) -> {
                double distance = itemDistanceMap.get(k);
                float normalizedScore = (float) (v / Math.sqrt(distance + 1));
                scoredItems.add(new ScoredItem(k, normalizedScore, RecommenderType.SIMILARITY));
            });
        } else {
            allScores.forEach(
                (k, v) -> scoredItems.add(new ScoredItem(k, v, RecommenderType.SIMILARITY)));
        }
        return scoredItems;
    }

    // List might contain TGScore of the same 'node2'. Add such scores.
    private Map<String, Integer> aggregateScoresForSameNode(List<TGScore> scores) {
        Map<String, Integer> aggregatedMap = new HashMap<>();
        scores.forEach(
            score -> aggregatedMap.merge(score.getNode2(), score.getStrength(), Integer::sum));
        return aggregatedMap;
    }

    private List<ScoredItem> blendRecommendations(List<ScoredItem> intrScoredItems,
        List<ScoredItem> transScoredItems) {
        // To blend equally from both lists, takes one item from each list starting from index 0
        // so there is more probability of getting equal items from both in case of final subList
        List<ScoredItem> scoredItems = new ArrayList<>();
        Set<String> uniqueItems = new HashSet<>();
        if (intrScoredItems.isEmpty()) {
            return transScoredItems;
        }
        if (transScoredItems.isEmpty()) {
            return intrScoredItems;
        }
        int maxSize = Math.max(intrScoredItems.size(), transScoredItems.size());
        for (int i = 0; i < maxSize; i++) {
            if (i < transScoredItems.size()) {
                ScoredItem scoredItem = transScoredItems.get(i);
                if (!uniqueItems.contains(scoredItem.getItemId())) {
                    uniqueItems.add(scoredItem.getItemId());
                    scoredItems.add(scoredItem);
                }
            }
            if (i < intrScoredItems.size()) {
                ScoredItem scoredItem = intrScoredItems.get(i);
                if (!uniqueItems.contains(scoredItem.getItemId())) {
                    uniqueItems.add(scoredItem.getItemId());
                    scoredItems.add(scoredItem);
                }
            }
        }
        return scoredItems;
    }

    private void addExplanators(List<ScoredItem> items, List<TGSimilarity> intrSiml,
        List<TGSimilarity> trxnSiml) {

        List<TGScore> allTgScores = new ArrayList<>();
        intrSiml.forEach(similar -> similar.getTgScores().forEach((k, v) -> {
            allTgScores.addAll(v);
        }));

        trxnSiml.forEach(similar -> similar.getTgScores().forEach((k, v) -> {
            allTgScores.addAll(v);
        }));

        for (ScoredItem item : items) {
            // Id, Score
            Map<String, Integer> matchedItems = allTgScores.stream()
                .filter(x -> x.getNode2().equals(item.getItemId()))
                .collect(Collectors.toMap(TGScore::getNode1, TGScore::getStrength));
            // Id, name
            Map<String, String> matchedItemName =
                itemService.getItems(new ArrayList<>(matchedItems.keySet()))
                .stream().collect(Collectors.toMap(Item::getId, Item::getName));

            List<ExplanationDetails> explanationDetails = matchedItems.entrySet().stream()
                .map(e -> new ExplanationDetails(e.getKey(), matchedItemName.get(e.getKey()),
                e.getValue())).collect(Collectors.toList());

            // Sort items based on item scores
            explanationDetails.sort((a, b) -> b.getScore() - a.getScore());

            Map<RecommenderType, IExplanator> explanation = new HashMap<>();
            IExplanator simlExplanator = new SimilarityExplanator();
            simlExplanator.setContributingItems(explanationDetails.subList(0,
                matchedItems.size() < topItemCount ? matchedItems.size() : topItemCount));
            explanation.put(RecommenderType.SIMILARITY, simlExplanator);
            item.setExplanation(explanation);
        }
    }
}
