/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.maya.choice.service;

import com.crayondata.maya.choice.config.JwtTokenProvider;
import com.crayondata.maya.data.model.security.UserPrincipal;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class UserResolutionService {

    @Value("${app.security.token.jwt}")
    private boolean jwtAuthentication;

    @Autowired
    JwtTokenProvider tokenProvider;

    /**
     * Resolves userId based on whether authentication security config is enabled or not.
     *
     * @param user {@link UserPrincipal} object contains user details if security is enabled
     * @param accessToken user access token of the user
     *
     */
    public String resolveUserIdViaSecurityConfig(UserPrincipal user, String accessToken) {
        String userId = null;
        if (user != null) {
            userId = user.getId();
        } else {
            userId = jwtAuthentication ? tokenProvider.getUserIdFromJWT(accessToken)
                : accessToken;
        }
        return userId;
    }
}
