/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.maya.choice.recommender.list.impl;

import com.crayondata.maya.choice.recommender.list.ChoiceListRecommender;
import com.crayondata.maya.choice.service.ChoiceItemScoreGenerator;
import com.crayondata.maya.data.access.key.KeyStoreDataAccessService;
import com.crayondata.maya.data.access.model.JsonDocument;
import com.crayondata.maya.data.access.util.DBConstants;
import com.crayondata.maya.data.entity.ItemService;
import com.crayondata.maya.data.model.entity.Item;
import com.crayondata.maya.data.model.profile.HistoryItem;
import com.crayondata.maya.data.model.recommendation.ChoiceListRecommendRequest;
import com.crayondata.maya.data.profile.InteractionService;
import com.crayondata.maya.model.enums.ChoiceListType;
import com.crayondata.maya.model.enums.InteractionType;
import com.crayondata.maya.model.enums.ItemType;
import com.crayondata.maya.model.enums.Languages;
import com.crayondata.maya.model.rest.ChoiceListRequest;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Predicate;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class ResumeList implements ChoiceListRecommender {

    @Autowired
    InteractionService interactionService;

    @Autowired
    ItemService itemService;

    @Autowired
    KeyStoreDataAccessService keyStoreDataAccessService;


    @Value("${resume.list.view.count}")
    private int viewCount;

    @Value("${resume.list.claim.count}")
    private int claimCount;

    @Value("${resume.list.offer.days}")
    private int offerDaysCount;

    @Value("${resume.list.filters}")
    private boolean locationCategoryFilter;

    public final String INTERACTION_HISTORY_KEY = "history";

    /**
     * Function to get the dynamic lists.
     * @param request request that was sent
     * @return set of matched ids
     */
    public Set<String> getDynamicList(ChoiceListRecommendRequest request) {
        String userId = request.getUserId();
        String interactionHistoryKey = DBConstants.asInteractionHistoryKey(userId);
        JsonDocument responseDocument = keyStoreDataAccessService
            .getDocument(interactionHistoryKey, DBConstants.INTERACTION_HISTORY_TYPE);
        if (responseDocument == null) {
            return Collections.emptySet();
        }
        JsonNode historyDocument =  responseDocument.getJson().get(INTERACTION_HISTORY_KEY);
        if (historyDocument == null) {
            return Collections.emptySet();
        }
        //Only filters the items which has OFFER as itemType
        List<HistoryItem> historyItems =  new ObjectMapper()
            .convertValue(historyDocument,new TypeReference<List<HistoryItem>>() {})
            .stream()
            .filter(v ->  v.getItemType() != null && v.getItemType().equals(ItemType.OFFER))
            .collect(Collectors.toList());
        OffsetDateTime currentDate = OffsetDateTime.now();
        // Gets only the items which are 'n' days less than the current date.
        historyItems = historyItems
            .stream()
            .filter(dates -> currentDate.minusDays(offerDaysCount)
            .isBefore(OffsetDateTime.parse(dates.getTime())))
            .collect(Collectors.toList());
        // Gets the redeemed ids and removes them from the list
        Set<String> redeemedIdSet =  historyItems.stream()
            .filter(v -> v.getType().equals(InteractionType.REDEEM))
            .map(entry -> entry.getItemId())
            .collect(Collectors.toSet());
        historyItems.removeIf(v -> redeemedIdSet.contains(v.getItemId()));
        // Groups by id and the interactionType and the corresponding count
        Map<String, Map<InteractionType, Long>> itemsGroupedById = historyItems
            .stream()
            .collect(Collectors.groupingBy(HistoryItem::getItemId,
            Collectors.groupingBy(HistoryItem::getType, Collectors.counting())));
        // Fetches the ids which have been viewed at least 'm' times and claimed at least 'n' time.
        Set<String> filteredItems = new HashSet<>();
        itemsGroupedById.forEach(
            (id, innerMap) -> {
                innerMap.forEach(
                    (type,count) -> {
                        if (((type == InteractionType.VIEW) && count >= viewCount)
                            || (type == InteractionType.CLAIM && count >= claimCount))  {
                            filteredItems.add(id);
                        }
                    }
                );
            }
        );

        return filteredItems;

    }

    @Override
    public List<Item> generateChoices(ChoiceListRecommendRequest request) {
        Set<String> dynamicSet = getDynamicList(request);
        List<Item> filteredItems;
        ChoiceListRequest choiceRequest = request.getChoiceRequest();
        if (locationCategoryFilter == false) {
            List<String> dynamicList = dynamicSet.stream()
                .map(s -> DBConstants.stripItemKeyIfExists(s))
                .collect(Collectors.toList());
            filteredItems = itemService
            .getItems(dynamicList, ItemType.OFFER, choiceRequest.getLang());
        } else {
            Map<String, Item> items = request.getLangToFilteredItems()
                .get(choiceRequest.getLang());
            List<Item> clonedItems = items.values().stream().map(item -> item.clone())
                .collect(Collectors.toList());
            filteredItems = clonedItems
                .stream()
                .filter(v -> dynamicSet.contains(DBConstants.asItemKey(v.getId())))
                .collect(Collectors.toList());
        }

        String category = request.getChoiceRequest().getCategory();
        Predicate<Item> categFilter = x -> "All".equalsIgnoreCase(category)
            || category.equalsIgnoreCase(x.getCategory());

        int limit = Math.min(choiceRequest.getChoiceCount(), filteredItems.size());
        request.setChoiceCount(ChoiceListType.RESUME.name(), filteredItems.size());
        List<Item> itemsWithLimit =  filteredItems
            .stream()
            .filter(categFilter)
            .limit(limit).collect(Collectors.toList());
        return itemsWithLimit;
    }

    @Override
    public ChoiceListType getListType() {
        return ChoiceListType.RESUME;
    }

    @Override
    public ChoiceItemScoreGenerator getItemScoreGenerator() {
        return null;
    }
}


