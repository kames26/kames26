/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.maya.choice;

import com.crayondata.maya.model.api.ApiResponse;
import com.crayondata.maya.model.api.AutoSuggestItemResponse;
import com.crayondata.maya.model.api.ItemSearchRequest;
import com.crayondata.maya.model.api.ItemSearchResponse;
import com.crayondata.maya.model.api.RecentSearchResponse;
import com.crayondata.maya.model.rest.SearchRequest;

/**
 * API abstraction for items search.
 */
public interface ItemApi {

    /**
     * Searches for items satisfying the given conditions. Since this isn't a search for a
     * particular item, we are not considering this as any interaction
     * @param request search request object
     * @return Items found
     */
    ApiResponse<ItemSearchResponse> searchItems(ItemSearchRequest request);

    /**
     * Searches for the item and tags with the given search word within the specified category.
     * @param accessToken id of the user
     * @param searchWord Pattern to search item for
     * @param category Category of the item
     * @param country Country in which items has to be retrieved
     * @param city city in which items has to be retrieved
     * @param searchTextLang Language used by user to search words
     * @param lang Language selected by the user
     * @return {@link AutoSuggestItemResponse}items or error message if user id is invalid
     */
    ApiResponse<AutoSuggestItemResponse> getSuggestedItems(String accessToken,
        String searchWord, String category, String country, String city,
        String searchTextLang, String lang);

    /**
     * Searches for the item and tags with the given search word within the specified category.
     * @param accessToken id of the user
     * @param searchRequest {@link SearchRequest}
     * @return {@link ItemSearchResponse}items or error message if user id is invalid
     */
    ApiResponse<ItemSearchResponse> getItemsForSearchWord(String accessToken,
        SearchRequest searchRequest);

    /**
     * Insert recent search keyword.
     * @param text text that the user used to search
     * @param userId id of the user
     * @param lang Language selected by the user
     * @return true or false
     */
    public boolean saveRecentSearchHistory(String text, String userId, String lang);

    /**
     * Get the recent search history of the user.
     *
     * @param userId id of the user
     * @param limit Number of search words to be retrieved
     * @param lang Language selected by the user
     * @return recent search response
     */
    public ApiResponse<RecentSearchResponse> getRecentSearchHistory(String userId, int limit,
        String lang);

    /**
     * Clear recent search history of the user.
     * @param accessToken Access token of the user.
     * @return
     */
    public ApiResponse<Boolean> clearRecentSearchHistory(String accessToken);

}
