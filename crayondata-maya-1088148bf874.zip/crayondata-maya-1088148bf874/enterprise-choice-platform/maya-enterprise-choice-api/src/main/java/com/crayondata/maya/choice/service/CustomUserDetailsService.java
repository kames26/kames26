/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.maya.choice.service;

import com.crayondata.maya.data.access.util.DBConstants;
import com.crayondata.maya.data.model.profile.PersonalDetails;
import com.crayondata.maya.data.model.profile.UserCredentials;
import com.crayondata.maya.data.model.profile.UserProfile;
import com.crayondata.maya.data.model.security.UserPrincipal;
import com.crayondata.maya.data.profile.UserProfileService;
import com.crayondata.maya.model.enums.AuthProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@ConditionalOnProperty(value = "app.security.basic.enabled", havingValue = "true")
@Service
public class CustomUserDetailsService implements UserDetailsService {

    @Autowired
    private UserProfileService userProfileService;

    @Override
    public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
        UserProfile user = userProfileService.findUserByEmail(email);
        if (user == null) {
            throw new UsernameNotFoundException("Invalid username or password.");
        }
        return create(user);
    }

    /**
     *  Get UserProfile for id.
     * @param id userId
     * @return {@link UserProfile}
     */
    public UserDetails loadUserById(String id) {
        UserProfile user = userProfileService.findUserById(id);
        if (user == null) {
            throw new UsernameNotFoundException("Invalid username or password.");
        }
        return create(user);
    }

    private UserPrincipal create(UserProfile user) {
        UserCredentials userCredentials = user.getUserCredentials();
        PersonalDetails personalDetails = user.getPersonalDetails();
        String userId = DBConstants.stripDynamicUserKeyIfExists(user.getId());
        return new UserPrincipal(userId, personalDetails.getName(),
            userCredentials.getEmail(), userCredentials.getPassword(),
            AuthProvider.LOCAL.name());
    }
}
