/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.maya.choice;

import com.crayondata.maya.data.entity.ItemService;
import com.crayondata.maya.data.model.entity.Item;
import com.crayondata.maya.data.model.entity.SearchItem;
import com.crayondata.maya.data.model.profile.Interaction;
import com.crayondata.maya.data.model.profile.UserProfile;
import com.crayondata.maya.data.model.search.RecentSearchItem;
import com.crayondata.maya.data.profile.InteractionService;
import com.crayondata.maya.data.profile.UserProfileService;
import com.crayondata.maya.model.api.ApiResponse;
import com.crayondata.maya.model.api.ApiResponse.Status;
import com.crayondata.maya.model.api.AutoSuggestItemResponse;
import com.crayondata.maya.model.api.ItemSearchRequest;
import com.crayondata.maya.model.api.ItemSearchResponse;
import com.crayondata.maya.model.api.RecentSearchResponse;
import com.crayondata.maya.model.common.GeoCode;
import com.crayondata.maya.model.enums.InteractionType;
import com.crayondata.maya.model.enums.ItemType;
import com.crayondata.maya.model.rest.SearchRequest;
import java.sql.Timestamp;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

@Service
public class ItemApiImpl implements ItemApi {
    @Value("${recentsearch.result.size}")
    int searchResultSize;
    private static final Logger LOGGER = LoggerFactory.getLogger(ItemApiImpl.class);

    private final ItemService itemService;
    private final UserProfileService userProfileService;
    private final InteractionService interactionService;

    @Autowired
    public ItemApiImpl(ItemService itemService, UserProfileService userProfileService,
        InteractionService interactionService) {
        this.itemService = itemService;
        this.userProfileService = userProfileService;
        this.interactionService = interactionService;
    }

    @Override
    public ApiResponse<ItemSearchResponse> searchItems(ItemSearchRequest request) {
        if (!GeoCode.isValid(request.getSearchGeo())) {
            return new ApiResponse<>(Status.BAD_REQUEST, "Invalid geo code");
        }

        UserProfile userProfile = userProfileService
            .getDynamicUserProfile(request.getAccessToken());
        if (userProfile == null) {
            return new ApiResponse<>(Status.BAD_REQUEST, "Invalid user");
        }

        // Get items within radius
        List<Item> items = itemService.getItemsNearBy(request.getSearchGeo(),
            request.getDistanceInKms());
        LOGGER.debug("Got {} items for Geocode {}", items.size(), request.getSearchGeo());

        // Filter items matching tags
        if (!CollectionUtils.isEmpty(request.getTags())) {
            items.removeIf(i -> {
                if (CollectionUtils.isEmpty(i.getTags())) {
                    return true;
                }
                return Collections.disjoint(i.getTags(), request.getTags());
            });
        }
        LOGGER.debug("After filtering tags: {} records", items.size());

        List<SearchItem> searchItems = items.stream().map(x -> SearchItem.from(x, false))
            .collect(Collectors.toList());

        if (!items.isEmpty()) {
            // Mark like items
            Set<String> itemIds = items.stream().map(Item::getId).collect(Collectors.toSet());
            String userId = userProfileService.getUseableUserId(userProfile);
            Set<String> liked = interactionService
                .getExistingInteractions(userId, itemIds, InteractionType.LIKE);
            searchItems.forEach(si -> si.setLiked(liked.contains(si.getId())));
        }

        return new ApiResponse<>(new ItemSearchResponse(searchItems, request.getTags()));
    }

    @Override
    public ApiResponse<AutoSuggestItemResponse> getSuggestedItems(String accessToken,
        String searchWord, String category, String country, String city,
        String searchTextLang, String lang) {
        UserProfile userProfile = userProfileService.getDynamicUserProfile(accessToken);
        if (userProfile == null) {
            return new ApiResponse<>(Status.BAD_REQUEST, "Invalid user");
        }

        AutoSuggestItemResponse autoSuggestItemResponse = itemService
            .suggestItems(searchWord, category, country, city, searchTextLang, lang);
        if (autoSuggestItemResponse.getItems().isEmpty()) {
            return new ApiResponse<>(Status.NOT_FOUND, "Items not found");
        }
        return new ApiResponse<>(autoSuggestItemResponse);
    }

    @Override
    public ApiResponse<ItemSearchResponse> getItemsForSearchWord(String accessToken,
        SearchRequest searchRequest) {
        UserProfile userProfile = userProfileService.getUnifiedUserProfile(accessToken);
        if (userProfile == null) {
            return new ApiResponse<>(Status.BAD_REQUEST, "Invalid user");
        }
        List<Item> items = itemService
            .getItemsForGivenSearchWord(searchRequest);
        if (items.isEmpty()) {
            return new ApiResponse<>(Status.NOT_FOUND, "Items not found");
        }

        List<SearchItem> searchItems = items.stream().map(x -> SearchItem.from(x, false))
            .collect(Collectors.toList());

        if (!items.isEmpty()) {
            // Mark like items
            String userId = userProfileService.getUseableUserId(userProfile);
            List<Interaction> interactions = interactionService
                .getInteractionsWithUserIdAndInteractionType(userId, ItemType.MERCHANT,
                InteractionType.WISHLIST);
            List<String> interactedItems =
                interactions.isEmpty() ? Collections.emptyList() : interactions.stream()
                .map(x -> x.getItemId()).collect(Collectors.toList());
            searchItems.forEach(si -> si.setWishlisted(interactedItems.contains(si.getId())));
        }
        saveRecentSearchHistory(searchRequest.getSearchWord(), accessToken,
            searchRequest.getLang());
        return new ApiResponse<>(new ItemSearchResponse(searchItems, null));

    }

    @Override
    public ApiResponse<Boolean> clearRecentSearchHistory(String accessToken) {
        UserProfile userProfile = userProfileService
            .getDynamicUserProfile(accessToken);
        if (userProfile == null) {
            return new ApiResponse<>(Status.NOT_FOUND,
                    "User not found");
        }
        String userId = userProfileService.getUseableUserId(userProfile);
        boolean response = itemService.clearRecentSearchHistory(userId);
        if (response == true) {
            return new ApiResponse<>(response);
        } else {
            return new ApiResponse<>(Status.NOT_FOUND,
                        "No search history document present for the given token");
        }
    }

    @Override
    public boolean saveRecentSearchHistory(String searchText, String userId, String lang) {
        boolean response = itemService.saveRecentSearchHistory(searchText,userId, lang);
        return response;
    }

    @Override
    public ApiResponse<RecentSearchResponse> getRecentSearchHistory(String userId, int limit,
        String lang) {
        UserProfile unifiedUserProfile = userProfileService.getUnifiedUserProfile(userId);
        if (unifiedUserProfile == null) {
            return new ApiResponse<>(Status.BAD_REQUEST, "Invalid user");
        }
        List<RecentSearchItem> recentSearchItemList = itemService.getRecentSearchHistory(userId,
            lang);
        if (recentSearchItemList == null) {
            return new ApiResponse<>(Status.NOT_FOUND,"Not found");

        }
        Map<String, Timestamp> distinctSearchItems = new HashMap<String, Timestamp>();
        for (RecentSearchItem item: recentSearchItemList) {
            if (distinctSearchItems.containsKey(item.getSearchText())) {
                Timestamp presentTimestamp = distinctSearchItems.get(item.getSearchText());
                if (item.getTimestamp().after(presentTimestamp)) {
                    distinctSearchItems.put(item.getSearchText(),item.getTimestamp());
                }


            }   else {
                distinctSearchItems.put(item.getSearchText(),item.getTimestamp());
            }
        }
        List<RecentSearchItem> distinctItems = distinctSearchItems.entrySet()
            .stream()
            .map(e -> new RecentSearchItem(e.getKey(),e.getValue()))
            .collect(Collectors.toList());

        Collections.sort(distinctItems, new Comparator<RecentSearchItem>() {
            @Override
            public int compare(RecentSearchItem item1, RecentSearchItem item2) {
                return item2.getTimestamp().compareTo(item1.getTimestamp());
            }
        });
        int searchResultSize = limit;
        if (searchResultSize > distinctItems.size()) {
            searchResultSize = distinctItems.size();
        }
        recentSearchItemList = distinctItems.subList(0,searchResultSize);
        RecentSearchResponse response = new RecentSearchResponse(recentSearchItemList);
        return new ApiResponse<>(response);
    }
}
