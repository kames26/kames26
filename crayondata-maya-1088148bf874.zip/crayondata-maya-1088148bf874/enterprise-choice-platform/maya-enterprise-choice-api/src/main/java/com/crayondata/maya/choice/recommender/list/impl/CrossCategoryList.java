/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.maya.choice.recommender.list.impl;

import com.crayondata.maya.choice.recommender.list.ChoiceListRecommender;
import com.crayondata.maya.choice.service.BaseScoreGenerator;
import com.crayondata.maya.choice.service.ChoiceItemScoreGenerator;
import com.crayondata.maya.data.model.entity.Item;
import com.crayondata.maya.data.model.recommendation.ChoiceListRecommendRequest;
import com.crayondata.maya.model.enums.ChoiceListType;

import com.crayondata.maya.model.rest.ChoiceListRequest;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CrossCategoryList implements ChoiceListRecommender {

    @Autowired
    BaseScoreGenerator itemScoreGenerator;

    @Override
    public List<Item> generateChoices(ChoiceListRecommendRequest request) {
        if (!isUserChoicePresent(ChoiceListType.CROSS_CATEGORY, request)) {
            return Collections.emptyList();
        }
        ChoiceListRequest choiceRequest = request.getChoiceRequest();
        Map<String, Item> items = getFilteredChoices(ChoiceListType.CROSS_CATEGORY, request,
            choiceRequest.getLang());
        if (items == null) {
            return Collections.emptyList();
        }
        List<Item> clonedItems = items.values().stream().map(item -> item.clone())
            .collect(Collectors.toList());
        List<Item> sortedItems = sortChoicesBasedOnScore(ChoiceListType.CROSS_CATEGORY, clonedItems,
            request.getListCategoryChoices(), request.getUserInteractions(),
            request.getSimilarItems());
        request.setChoiceCount(ChoiceListType.CROSS_CATEGORY.name(), sortedItems.size());
        int limit = Math.min(choiceRequest.getChoiceCount(), sortedItems.size());
        List<Item> itemsWithLimit = sortedItems.stream().limit(limit).collect(Collectors.toList());
        return itemsWithLimit;
    }

    @Override
    public ChoiceListType getListType() {
        return ChoiceListType.CROSS_CATEGORY;
    }

    @Override
    public ChoiceItemScoreGenerator getItemScoreGenerator() {
        return itemScoreGenerator;
    }
}
