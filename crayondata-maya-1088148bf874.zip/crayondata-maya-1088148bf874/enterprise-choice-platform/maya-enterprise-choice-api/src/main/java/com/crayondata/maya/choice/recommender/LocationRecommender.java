/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.maya.choice.recommender;

import static com.crayondata.maya.data.utils.ObjectUtils.defaultIfNull;

import com.crayondata.maya.data.entity.ItemService;
import com.crayondata.maya.data.model.config.ChoiceApiConfig;
import com.crayondata.maya.data.model.entity.Item;
import com.crayondata.maya.data.model.entity.ScoredItem;
import com.crayondata.maya.data.model.recommendation.RecommendRequest;
import com.crayondata.maya.data.model.recommendation.RecommenderType;
import com.crayondata.maya.model.common.GeoCode;
import java.util.ArrayList;
import java.util.List;
import org.locationtech.spatial4j.distance.DistanceUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

/**
 * Recommend items based on given location coordinates / city.
 *
 * @author somin
 */
@Service
public class LocationRecommender implements IRecommender {

    private static final Logger LOGGER = LoggerFactory.getLogger(LocationRecommender.class);

    @Value("${distance.km:100}")
    private int DEFAULT_DISTANCE_IN_KM;

    @Autowired
    private ItemService itemService;

    @Autowired
    private ChoiceApiConfig choiceApiConfig;

    @Override
    public RecommenderType getType() {
        return RecommenderType.LOCATION;
    }

    @Override
    public List<ScoredItem> recommend(RecommendRequest recommendRequest) {
        String userId = recommendRequest.getUserProfile().getId();
        String city = recommendRequest.getChoiceCity();
        GeoCode geoCode = recommendRequest.getChoiceLoc();
        if (geoCode != null) {
            LOGGER.info("Getting location recommendations for user: {} & geocode: {}", userId,
                geoCode);
            int defaultDistance = defaultIfNull(choiceApiConfig.getGlobalConfig().getDistanceKm(),
                DEFAULT_DISTANCE_IN_KM);
            List<Item> items = itemService.getItemsNearBy(geoCode, defaultDistance);
            List<ScoredItem> scoredItems = new ArrayList<>();
            for (Item item : items) {
                LOGGER.info("Calculate distance for item {} with Geo: {}", item.getId(),
                    item.getGeoCodes());
                double shortestDistance = geoCode.getClosestGeoDistance(item.getGeoCodes());
                if (shortestDistance < defaultDistance) {
                    double score = (DistanceUtils.EARTH_MEAN_RADIUS_KM - shortestDistance) * 1000
                        / DistanceUtils.EARTH_MEAN_RADIUS_KM;
                    scoredItems.add(new ScoredItem(item.getId(), (float) score,
                        RecommenderType.LOCATION));
                }
            }
            return scoredItems;
        } else if (city != null) {
            LOGGER.info("Getting location recommendations for user: {} & city: {}", userId, city);
            // TODO implement recommending based on city
            throw new UnsupportedOperationException("Not supported yet.");
        } else {
            LOGGER.info(
                "Unable to recommend based on location for user: {},"
                + "location information unavailable",
                userId);
            return new ArrayList<>();
        }
    }
}
