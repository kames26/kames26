/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.maya.choice.service;

import com.crayondata.maya.data.access.util.DBConstants;
import com.crayondata.maya.data.model.entity.Item;
import com.crayondata.maya.data.model.entity.OfferDetails;
import com.crayondata.maya.data.model.entity.TrackingInformation;
import com.crayondata.maya.data.model.entity.TrackingInformationItem;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

@Service
public class ItemPropertyModifier {
    private static final Logger LOGGER = LoggerFactory.getLogger(ItemPropertyModifier.class);


    /**
     * Modifies offer properties if given conditions are satisfied.
     *
     * @param offers Offers present in Item
     * @param clientName Name of the client to which offer belongs
     */
    public void modifyOfferProps(List<OfferDetails> offers, String clientName) {
        if (offers == null || offers.isEmpty()) {
            return;
        }

        offers.forEach(offer -> {
            String modifiedDesc = convertStrIntoNumberedListStr(offer.getDescription());
            offer.setDescription(modifiedDesc);
            Map<String, Object> properties = offer.getProperties();
            String redeemKey = (String) properties.get(DBConstants.OFFER_HOW_TO_REDEEM_KEY);
            String modifiedRedeemedKey = convertStrIntoNumberedListStr(redeemKey);
            properties.put(DBConstants.OFFER_HOW_TO_REDEEM_KEY, modifiedRedeemedKey);
            Object termsAndConditions = properties
                .get(DBConstants.OFFER_TERMS_CONDITION_KEY);
            if (termsAndConditions != null) {
                String termCondStr = termsAndConditions instanceof List
                    ? ((List<String>) termsAndConditions).get(0)
                    : termsAndConditions.toString();
                termCondStr = termCondStr.replace(DBConstants.BANK_NAME_PLACE_HOLDER,
                    clientName);
                termCondStr = termCondStr.replace(DBConstants.NETWORK_NAME_PLACE_HOLDER,
                    "card");
                String modifiedStr = convertStrIntoNumberedListStr(termCondStr);
                properties.put(DBConstants.OFFER_TERMS_CONDITION_KEY, modifiedStr);
            }
        });
    }

    /**
     * Generate tracking link.
     *
     * @param item Item that contains url
     * @param externalUserId id of the user
     * @return Item with changes
     */
    public Item generateTrackingLink(Item item, String externalUserId,
        TrackingInformation trackingInformation) {
        List<OfferDetails> offers = item.getOffers();
        Map<String, Object> itemProps = item.getProperties();
        String externalId  = (String)itemProps.get(DBConstants.ITEM_EXTERNALID_FIELD);
        offers.forEach(v -> {
            Map<String,Object> properties = v.getProperties();
            if (properties.get(DBConstants.URL_KEY) != null
                && !((String)properties.get(DBConstants.URL_KEY)).isEmpty()
                && properties.get(DBConstants.OFFER_SOURCE_KEY) != null) {
                String url = properties.get(DBConstants.URL_KEY).toString();
                String sourceName = properties.get(DBConstants.OFFER_SOURCE_KEY)
                    .toString().toLowerCase();
                TrackingInformationItem trackingInformationItems = trackingInformation.getPartners()
                    .stream()
                    .filter(value -> value.getName().equals(sourceName))
                    .findFirst()
                    .orElse(null);
                if (trackingInformationItems != null) {
                    String clientName = trackingInformation.getClient();
                    url = appendToUrl(trackingInformationItems, clientName, url, externalUserId,
                        externalId, v.getId());
                    properties.put(DBConstants.URL_KEY, url);
                    v.setProperties(properties);
                }
            }
        });
        item.setOffers(offers);
        return item;
    }

    /**
     * Appending tracking link to url.
     *
     * @param item Tracking link item
     * @param clientName name of the client
     * @param url Url to be concatenated
     * @param userId id of the user
     * @return concatenated url
     */
    private String appendToUrl(TrackingInformationItem item,
        String clientName,String url,String userId, String merchantId, String offerId) {
        String userIdKey = item.getUserIdKey();
        String queryParams = "";
        boolean queryStringPresent = (url.indexOf("?") > 0);
        if (userIdKey != null) {
            queryParams += queryStringPresent ? "&" : "?";
            queryParams += userIdKey + "=" + userId;
            queryStringPresent = true;
        }
        String merchantIdKey = item.getMerchantIdKey();
        if (merchantIdKey != null) {
            queryParams += queryStringPresent ? "&" : "?";
            queryParams += merchantIdKey + "=" + merchantId;
            queryStringPresent = true;
        }
        String offerIdKey = item.getOfferIdKey();
        if (offerIdKey != null) {
            queryParams += queryStringPresent ? "&" : "?";
            queryParams += offerIdKey + "=" + offerId;
            queryStringPresent = true;
        }
        String clientKey = item.getClientKey();
        if (clientKey != null) {
            queryParams += queryStringPresent ? "&" : "?";
            queryParams += clientKey + "=" + clientName;
            queryStringPresent = true;
        }
        String commonKey = item.getCommonKey();
        if (commonKey != null) {
            queryParams += queryStringPresent ? "&" : "?";
            queryParams += commonKey + "=" + userId + "|" + merchantId + "|"
                + offerId + "|" + clientName;
            queryStringPresent = true;
        }
        url = url.concat(queryParams);
        return url;
    }

    private String convertStrIntoNumberedListStr(String str) {
        final StringBuilder modifiedStr = new StringBuilder();
        if (str != null && str.indexOf("\n") != -1) {
            String[] str1 = str.split("\n");
            AtomicInteger i = new AtomicInteger(1);
            Arrays.stream(str1).forEach(s -> {
                modifiedStr.append(i.get()).append(". ").append(s).append("\n\n");
                i.getAndIncrement();
            });
            return modifiedStr.toString();
        }
        return str;
    }
}
