/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.maya.choice.recommender.list.factory;

import com.crayondata.maya.choice.recommender.list.ChoiceListRecommender;
import com.crayondata.maya.model.enums.ChoiceListType;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.PostConstruct;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class ChoiceListFactory {

    private static final Logger LOGGER = LoggerFactory.getLogger(ChoiceListFactory.class);

    private final Map<ChoiceListType, ChoiceListRecommender> choiceListCache = new HashMap<>();

    private List<ChoiceListRecommender> choiceListRecommenders;

    private String[] choiceListTypes;

    @Autowired
    public ChoiceListFactory(List<ChoiceListRecommender> choiceListRecommenders,
        @Value("${choice.list.types}") String[] choiceListTypes) {
        this.choiceListRecommenders = choiceListRecommenders;
        this.choiceListTypes = choiceListTypes;
    }

    /**
     * Initialize choicelist cache.
     */
    @PostConstruct
    public void init() {
        choiceListRecommenders.forEach(recommender -> {
            choiceListCache.put(recommender.getListType(), recommender);
        });
    }

    /**
     * Get choice list recommender for choice list type.
     * @param listType list type for which choicelist recommender instance has to be retrieved.
     * @return
     */
    public ChoiceListRecommender getChoiceList(ChoiceListType listType) {
        ChoiceListRecommender choiceListRecommender = choiceListCache.get(listType);
        if (choiceListRecommender == null) {
            LOGGER.info("Given list type not supported : {}", listType);
            return null;
        }
        return choiceListRecommender;
    }

    public String[] getChoiceListTypes() {
        return choiceListTypes;
    }
}
