/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.maya.choice.service;

import com.crayondata.maya.model.common.GeoCode;
import com.crayondata.maya.model.common.Location;
import com.maxmind.db.CHMCache;
import com.maxmind.geoip2.DatabaseReader;
import com.maxmind.geoip2.exception.GeoIp2Exception;
import com.maxmind.geoip2.model.CityResponse;
import com.maxmind.geoip2.record.City;

import java.io.File;
import java.io.IOException;
import java.net.InetAddress;
import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

/**
 * Resolve geo-location using MaxMind GeoLite2 database.
 *
 * @author somin
 * @see <a href="http://dev.maxmind.com/geoip/geoip2/geolite2/">MaxMind
 * GeoLite2</a>
 */
@Service
public class MaxMindGeoIPService implements GeoIPService {

    private static final Logger LOGGER = LoggerFactory.getLogger(MaxMindGeoIPService.class);

    private DatabaseReader maxMindResolver;

    @Value(value = "${maxmind.db.file:null}")
    private String maxMindDbPath;

    @Value("${ip2geo.enabled:false}")
    private boolean resolveIPtoGeo;

    /**
     * Initialize the service.
     * @throws IOException if there is an error reading the database
     */
    @PostConstruct
    public void init() throws IOException {
        if (resolveIPtoGeo) {
            File database = new File(maxMindDbPath);
            maxMindResolver = new DatabaseReader.Builder(database).withCache(new CHMCache())
                    .build();
        }
    }

    @Override
    public Location getLocation(String ip) {
        try {
            InetAddress ipAddress = InetAddress.getByName(ip);
            CityResponse cityResponse = maxMindResolver.city(ipAddress);
            com.maxmind.geoip2.record.Location resolvedLocation = cityResponse.getLocation();
            GeoCode geoCode = null;
            if (resolvedLocation != null) {
                Double latitude = resolvedLocation.getLatitude();
                Double longitude = resolvedLocation.getLongitude();
                if (latitude != null && longitude != null) {
                    geoCode = new GeoCode(latitude.toString(), longitude.toString());
                }
            }
            City resolvedCity = cityResponse.getCity();
            String cityName = null;
            if (resolvedCity != null) {
                cityName = resolvedCity.getName();
            }
            if (geoCode != null || cityName != null) {
                Location location = new Location(ip, cityResponse.getCountry().getName(),
                    cityName, geoCode);
                LOGGER.debug("Resolved location for {} -> {}", ip, location);
                return location;
            }
        } catch (IOException | GeoIp2Exception e) {
            LOGGER.debug("Encountered exception {} while resolving location", e.getMessage());
        }
        LOGGER.debug("Unable to resolve location for IP -> {}", ip);
        return null;
    }

}
