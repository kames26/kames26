/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.maya.choice.service;

import com.crayondata.maya.data.model.config.ChoiceApiConfig;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * Service to support handling user segment based configurations
 * and for segmenting new anonymous users.
 *
 * @author somin
 */
@Service
public class UserSegmentationService {

    private static final int DEFAULT_SEGMENT = 0;

    private ChoiceApiConfig choiceApiConfig;

    @Autowired
    public UserSegmentationService(ChoiceApiConfig choiceApiConfig) {
        this.choiceApiConfig = choiceApiConfig;
    }

    public static int getDefaultSegment() {
        return DEFAULT_SEGMENT;
    }

    public boolean isSegmentationEnabled() {
        return choiceApiConfig.getSegmentConfiguration().isEnabled();
    }

    public boolean isSegmentEnabled(int segmentNo) {
        return isSegmentationEnabled()
            && choiceApiConfig.getSegmentRatio().containsKey(segmentNo);
    }

}
