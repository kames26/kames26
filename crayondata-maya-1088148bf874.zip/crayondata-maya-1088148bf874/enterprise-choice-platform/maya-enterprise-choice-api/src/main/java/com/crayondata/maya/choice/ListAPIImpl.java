/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.maya.choice;

import com.crayondata.maya.data.access.util.DBConstants;
import com.crayondata.maya.data.access.util.JsonUtils;
import com.crayondata.maya.data.list.DataListService;
import com.crayondata.maya.data.model.entity.DataListItem;
import com.crayondata.maya.data.model.profile.CityList;
import com.crayondata.maya.data.model.profile.CityListItem;
import com.crayondata.maya.model.api.ApiResponse;
import com.crayondata.maya.model.api.ApiResponse.Status;
import com.crayondata.maya.model.common.GeoCode;
import com.crayondata.maya.model.common.Location;
import com.crayondata.maya.model.enums.Languages;
import com.crayondata.maya.model.rest.CityRequest;
import com.fasterxml.jackson.databind.JsonNode;

import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ListAPIImpl implements ListAPI {

    private static final Logger LOGGER = LoggerFactory.getLogger(ListAPIImpl.class);

    @Autowired
    private DataListService dataListService;

    @Autowired
    private JsonUtils jsonUtils;

    @Override
    public ApiResponse<JsonNode> getDataList(String id, String lang) {
        try {
            JsonNode dataList = dataListService.getDataList(id, lang);
            if (dataList != null) {
                if (id.equalsIgnoreCase(DBConstants.CITIES)) {
                    setCountryInfoInCityList(lang, dataList);
                }
                return new ApiResponse<>(dataList);
            } else {
                return new ApiResponse<>(Status.NOT_FOUND, "Request list id:" + id + " not found");
            }
        } catch (Exception e) {
            LOGGER.error("Failed retrieve list for id:{}", id, e);
            return new ApiResponse<>(Status.ERROR, e.getMessage());
        }
    }

    @Override
    public ApiResponse<JsonNode> getCityList(GeoCode geoCode, String lang) {
        ApiResponse<JsonNode> cities = getDataList("cities", lang);
        if (cities.getStatus() != Status.SUCCESS) {
            return cities;
        }

        CityListItem[] cityList = jsonUtils.getObject(cities.getResponse(), CityListItem[].class);
        List<CityListItem> cityItemList = Stream.of(cityList).collect(Collectors.toList());
        List<CityListItem> sortedCityList = orderBasedonCurrentLocation(geoCode, cityItemList);
        JsonNode jsonNode = jsonUtils.asJsonNode(sortedCityList);
        return new ApiResponse<>(jsonNode);
    }

    @Override
    public ApiResponse<JsonNode> getCountryList(String resolvedLocFromIp, String lang) {
        ApiResponse<JsonNode> countries = getDataList("countries", lang);
        if (countries.getStatus() != Status.SUCCESS) {
            return countries;
        }

        DataListItem[] countryList = jsonUtils.getObject(countries.getResponse(),
            DataListItem[].class);
        List<DataListItem> countryItemList = Stream.of(countryList).collect(Collectors.toList());
        List<DataListItem> sortedCountryList = orderBasedOnResolvedCountry(resolvedLocFromIp,
            countryItemList);
        JsonNode jsonNode = jsonUtils.asJsonNode(sortedCountryList);
        return new ApiResponse<>(jsonNode);
    }

    @Override
    public ApiResponse<JsonNode> getTagListForCategory(String category, String lang) {
        try {
            JsonNode tagList = dataListService.getTagListForCategory(category, lang);
            if (tagList != null) {
                return new ApiResponse<>(tagList);
            } else {
                return new ApiResponse<>(Status.NOT_FOUND, "Tags not found for category : "
                    + category);
            }
        } catch (Exception e) {
            LOGGER.error("Failed retrieve tag list for category:{}", category, e);
            return new ApiResponse<>(Status.ERROR, e.getMessage());
        }
    }

    @Override
    public ApiResponse<Map<String, JsonNode>> getTagListForAllCategories(String lang) {
        try {
            Map<String, JsonNode> tagListForAllCategories = dataListService
                .getTagListForAllCategories(lang);
            if (tagListForAllCategories != null) {
                return new ApiResponse<>(tagListForAllCategories);
            } else {
                return new ApiResponse<>(Status.NOT_FOUND, "Tags not found for "
                    + "all categories");
            }
        } catch (Exception e) {
            LOGGER.error("Failed to retrieve tag list for all categories: {} ",  e);
            return new ApiResponse<>(Status.ERROR, e.getMessage());
        }
    }

    private List<DataListItem> orderBasedOnResolvedCountry(String country,
        List<DataListItem> countryList) {
        List<DataListItem> countries = countryList;
        Comparator<DataListItem> comparator = Comparator.comparing(x -> x.getLabel());
        Collections.sort(countries, comparator);
        if (country != null) {
            LOGGER.debug("Country list before ordering based on current "
                + "resolved country : {}", countries);
            String finalCountry = country;
            List<DataListItem> currentCountry = countries.stream()
                .filter(x -> x.getLabel().equalsIgnoreCase(finalCountry))
                .collect(Collectors.toList());
            //Removing current country from list and adding it as first element in the list
            countries.removeAll(currentCountry);
            countries.addAll(0, currentCountry);
            LOGGER.debug("CountryList after ordering based on current"
                + " resolved country : {}", countries);
        }
        return countries;
    }

    private List<CityListItem> orderBasedonCurrentLocation(GeoCode geoCode,
        List<CityListItem> cityList) {

        String city = null;
        List<CityListItem> cities = cityList;
        Comparator<CityListItem> comparator = Comparator.comparing(x -> x.getLabel());
        Collections.sort(cities, comparator);
        if (geoCode != null && geoCode.getLatitude() != null
            && geoCode.getLongitude() != null) {
            Map<String, Double> cityGeo = cityList.stream().collect(
                Collectors.toMap(x -> x.getLabel(), x ->
                geoCode.distanceFrom(x.getGeoCode()), (x1, x2) -> x1));
            Map<String, Double> sortedMap = cityGeo.entrySet().stream()
                .sorted(Map.Entry.comparingByValue()).collect(Collectors
                .toMap(Map.Entry::getKey, Map.Entry::getValue, (e1, e2) -> e1,
                LinkedHashMap::new));
            city = sortedMap.entrySet().iterator().next().getKey();

        } else {
            return cities;
        }
        LOGGER.debug("City list before ordering based on current location: {}", cities);
        String finalCity = city;
        List<CityListItem> currentCity = cities.stream()
            .filter(x -> x.getLabel().equalsIgnoreCase(finalCity)).collect(Collectors.toList());
        //Removing current city from list and adding it as first element in the list
        cities.removeAll(currentCity);
        cities.addAll(0, currentCity);
        LOGGER.debug("CityList after ordering based on current location : {}", cities);
        return cities;

    }

    private void setCountryInfoInCityList(String lang, JsonNode cities) {
        JsonNode countries = dataListService.getDataList(DBConstants.COUNTRIES);
        Map<String, JsonNode> countryMap = new HashMap<>();
        if (countries != null) {
            for (JsonNode country : countries) {
                final String key = country.get("value_en").asText();
                ObjectNode objNode = (ObjectNode) country;
                JsonNode label = objNode.get("label_" + lang);
                JsonNode value = objNode.get("value_" + lang);
                Stream.of(Languages.values()).forEach(x -> {
                        objNode.remove("label_" + x);
                        objNode.remove("value_" + x);
                    }
                );
                objNode.set("countryLabel", label);
                objNode.set("countryValue", value);
                countryMap.put(key,country);
            }
            for (JsonNode city : cities) {
                String country = city.get(DBConstants.COUNTRY).asText();
                ObjectNode objNode = (ObjectNode)city;
                objNode.remove(DBConstants.COUNTRY);
                objNode.setAll((ObjectNode) countryMap.get(country));
            }
        }
    }
}
