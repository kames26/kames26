/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.maya.choice.recommender.factory;

import com.crayondata.maya.choice.recommender.IRecommender;
import com.crayondata.maya.data.model.recommendation.RecommenderType;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.PostConstruct;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * Factory for creating instances of {@link com.crayondata.maya.choice.recommender.IRecommender}.
 *
 * @author somin
 */
@Component
public class RecommenderFactory {

    private static final Logger LOGGER = LoggerFactory.getLogger(RecommenderFactory.class);

    private final Map<RecommenderType, IRecommender> recommenderCache = new HashMap<>();

    private List<IRecommender> recommenders;

    @Autowired
    public RecommenderFactory(List<IRecommender> recommenders) {
        this.recommenders = recommenders;
    }

    @PostConstruct
    public void init() {
        recommenders.forEach(recommender ->
            recommenderCache.put(recommender.getType(), recommender));
    }

    /**
     * Get a pre-created instance of the given recommender.
     *
     * @param recommenderType An enum constant representing the recommender to get
     * @return An instance of the requested recommender if it exists, null otherwise.
     */
    public IRecommender getRecommender(RecommenderType recommenderType) {
        IRecommender recommender = recommenderCache.get(recommenderType);
        if (recommender == null) {
            LOGGER.error("Unknown recommender: {}", recommenderType);
        }
        return recommender;
    }

    /**
     * Get a pre-created instance of the given recommender by name.
     *
     * @param recommenderName Name/type of the recommender,
     *     exactly as defined in {@link RecommenderType}
     * @return An instance of the requested recommender if it exists, null otherwise.
     */
    public IRecommender getRecommender(String recommenderName) {
        IRecommender recommender = null;
        try {
            RecommenderType recommenderType = RecommenderType.valueOf(recommenderName);
            recommender = getRecommender(recommenderType);
        } catch (IllegalArgumentException e) {
            LOGGER.error("Unknown recommender enum: {}", recommenderName);
        }
        return recommender;
    }
}
