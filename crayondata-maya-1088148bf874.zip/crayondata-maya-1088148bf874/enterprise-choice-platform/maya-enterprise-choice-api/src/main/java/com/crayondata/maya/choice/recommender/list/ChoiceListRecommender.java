/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.maya.choice.recommender.list;

import com.crayondata.maya.choice.service.ChoiceItemScoreGenerator;
import com.crayondata.maya.data.model.entity.Item;
import com.crayondata.maya.data.model.profile.Interaction;
import com.crayondata.maya.data.model.profile.UserChoice;
import com.crayondata.maya.data.model.recommendation.ChoiceListRecommendRequest;
import com.crayondata.maya.model.enums.ChoiceListType;
import com.crayondata.maya.model.enums.InteractionType;
import com.crayondata.maya.model.enums.ItemType;
import com.crayondata.maya.model.enums.Languages;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;


public interface ChoiceListRecommender {

    List<Item> generateChoices(ChoiceListRecommendRequest request);

    ChoiceListType getListType();

    ChoiceItemScoreGenerator getItemScoreGenerator();

    /**
     * Checks if user choices present for given choiceListType.
     * @param listType {@link ChoiceListType}
     * @param request {@link ChoiceListRecommendRequest}
     * @return boolean value indicating the presence of user choices for given choice list type
     */
    default boolean isUserChoicePresent(ChoiceListType listType,
        ChoiceListRecommendRequest request) {
        Map<ChoiceListType, Map<String, UserChoice>> listCategoryChoices = request
            .getListCategoryChoices();
        Map<String, UserChoice> categChoiceMap = listCategoryChoices
            .get(listType);
        return categChoiceMap != null && !categChoiceMap.isEmpty();
    }

    /**
     * Get filtered choice list.
     *
     * @param listType {@link ChoiceListType}
     * @param request {@link ChoiceListRecommendRequest}
     * @param lang Language selected by the user
     * @return Filtered choice list
     */
    default Map<String, Item> getFilteredChoices(ChoiceListType listType,
        ChoiceListRecommendRequest request, String lang) {
        Map<String, Item> items = request.getLangToFilteredItems().get(Languages.valueOf(lang));
        Map<ChoiceListType, Map<String, UserChoice>> listCategoryChoices = request
            .getListCategoryChoices();
        Map<String, UserChoice> categChoiceMap = listCategoryChoices
            .get(listType);
        if (categChoiceMap != null && !categChoiceMap.isEmpty()) {
            Map<String, Item> filteredChoiceMap = categChoiceMap.keySet().stream()
                .filter(id -> items.get(id) != null)
                .collect(Collectors.toMap(x -> x, x -> items.get(x)));
            return filteredChoiceMap;
        }
        return items;
    }

    /**
     * Sorts items based on scores generated.
     *
     * @param choiceListType {@link ChoiceListType}
     * @param items items to be sorted based on scores
     * @param userChoices userchoices for each list
     * @param userInteractions user interactions
     * @return sorted items
     */
    default List<Item> sortChoicesBasedOnScore(ChoiceListType choiceListType,
        List<Item> items, Map<ChoiceListType, Map<String, UserChoice>> userChoices,
        Map<ItemType, Map<InteractionType, List<Interaction>>> userInteractions,
        Map<String, List<String>> similarItems) {
        Map<String, UserChoice> listChoices = userChoices.get(choiceListType);
        if (listChoices == null) {
            return items;
        }
        Map<String, Double> itemScores = getItemScoreGenerator()
            .generateScores(choiceListType, items, listChoices, userInteractions,
            similarItems);
        Map<String, Item> itemMap =
            items.stream().collect(Collectors.toMap(x -> x.getId(), x -> x));
        Map<String, Integer> tasteMatchScores =
            getItemScoreGenerator().generateTasteMatchScores(itemScores);

        List<Item> sortedItems = tasteMatchScores.entrySet().stream().map(x ->
            getItemScoreGenerator()
            .updateItemWithTasteMatchScore(x.getValue(), itemMap.get(x.getKey())))
            .collect(Collectors.toList());
        return sortedItems;
    }
}
