/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.maya.choice.service;

import static com.crayondata.maya.model.api.ApiResponse.Status.NOT_FOUND;

import com.crayondata.maya.choice.ChoiceAPI;
import com.crayondata.maya.choice.utils.Constants;
import com.crayondata.maya.data.model.entity.Choices;
import com.crayondata.maya.data.model.profile.UserProfile;
import com.crayondata.maya.data.model.recommendation.RecommenderType;
import com.crayondata.maya.data.profile.UserProfileService;
import com.crayondata.maya.model.api.ApiResponse;
import com.crayondata.maya.model.api.LocationResolverResponse;
import com.crayondata.maya.model.enums.UserType;
import com.crayondata.maya.model.rest.ChoiceRequest;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.MultiValueMap;

@Service
public class ChoiceControllerService {

    private static final Logger LOGGER = LoggerFactory.getLogger(ChoiceControllerService.class);

    @Autowired
    private UserProfileService userProfileService;

    @Autowired
    private LocationResolutionService locationResolutionService;

    @Autowired
    private ChoiceAPI choiceAPI;

    /**
     * Generates choices from the given request.
     *
     * @param request Choice request from user
     * @param accessToken Session ID representing the user
     * @param headers HTTP headers present in the request
     * @return
     */
    public ApiResponse<Choices> formChoiceRequest(
        ChoiceRequest request, String accessToken, MultiValueMap<String, String> headers) {
        ApiResponse<Choices> choices;

        String knownUserId = userProfileService.resolveKnownUserIdViaMapping(
            request.getCampaignUserId());
        request.setCampaignUserId(knownUserId);
        if (userProfileService.processSessionAndKnownUserId(accessToken,
            request.getCampaignUserId()) == null) {
            LOGGER.info("Could not find user profile with id: {}", accessToken);
            choices = new ApiResponse<>(NOT_FOUND, "Requested user id not found");
        } else {
            UserProfile dynamicUserProfile = userProfileService.getDynamicUserProfile(accessToken);
            String ipFromHeaders = locationResolutionService.extractIPFromHeaders(headers);
            LOGGER.debug("IP extracted from headers for user(known id): {} = {}",
                request.getCampaignUserId(), ipFromHeaders);
            knownUserId = dynamicUserProfile.getKnownUserId();
            // update correct knownUserId from DB
            request.setCampaignUserId(knownUserId);
            LocationResolverResponse locationResolverResponse = locationResolutionService
                .resolve(knownUserId, request.getLocation(), ipFromHeaders);
            LOGGER.debug("LocationResolverResponse for user(known id): {} = {}",
                request.getCampaignUserId(), locationResolverResponse);

            Map<String, Boolean> flags = locationResolverResponse.getFlags();
            flags.put(Constants.KEY_EXPLAIN, request.getExplain());
            flags.put(Constants.FLAG_PAGINATE, request.getPaginate());
            UserType userType = dynamicUserProfile.getUserType();
            com.crayondata.maya.model.api.ChoiceRequest choiceRequest
                = new com.crayondata.maya.model.api.ChoiceRequest(request.getClientId(),
                accessToken, request.getCampaignToken(), request.getCampaignUserId(), userType,
                request.getPrecededBy(), request.getItemType(), request.getCategory(),
                locationResolverResponse.getLocation(), request.getServedAt(),
                request.getFilterBy(), request.getCount(), flags, headers.toSingleValueMap());

            choices = choiceAPI.choices(choiceRequest, headers);
        }
        return choices;
    }
}
