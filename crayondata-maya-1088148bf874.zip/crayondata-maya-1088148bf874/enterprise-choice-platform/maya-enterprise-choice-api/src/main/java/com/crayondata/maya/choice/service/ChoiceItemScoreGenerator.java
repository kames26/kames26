/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.maya.choice.service;

import static java.time.temporal.ChronoUnit.DAYS;

import com.crayondata.maya.data.model.entity.Item;
import com.crayondata.maya.data.model.profile.Interaction;
import com.crayondata.maya.data.model.profile.UserChoice;
import com.crayondata.maya.model.enums.ChoiceListType;
import com.crayondata.maya.model.enums.InteractionType;
import com.crayondata.maya.model.enums.ItemType;

import java.time.OffsetDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public interface ChoiceItemScoreGenerator {
    String INTERACTION_SCORE_PREFIX = "interaction.score.";
    String TASTE_MATCH_SCORE_FIELD = "tasteMatchScore";

    Map<String, Double> generateScores(ChoiceListType choiceListType,
        List<Item> items, Map<String, UserChoice> userChoices,
        Map<ItemType, Map<InteractionType, List<Interaction>>> userInteractions,
        Map<String, List<String>> similarItems);

    Map<String, Integer> generateTasteMatchScores(Map<String, Double> choiceScores);

    List<Item> sortItemsBasedOnScores(Map<String, Double> itemScores,
        List<Item> items);

    Double getIntensityForInteractionType(InteractionType interactionType);

    /**
     * Get interactionScore for given item.
     *
     * @param item item for which interaction score has to be generated.
     * @param userInteractions interactions done by user
     * @return An array containing intensity for interactionType and interaction time.
     */
    default Object[] getInteractionScore(Item item, Map<ItemType,
        Map<InteractionType, List<Interaction>>> userInteractions) {
        if (item == null || userInteractions == null || userInteractions.isEmpty()) {
            return null;
        }
        List<String> offerIds = item.getOffers().stream().map(x -> x.getId())
            .collect(Collectors.toList());
        Map<InteractionType, OffsetDateTime> interactions = new HashMap<>();
        Map<InteractionType, List<Interaction>> itemInteractions = userInteractions
            .get(ItemType.MERCHANT);
        if (itemInteractions != null) {
            populateInteractionMap(ItemType.MERCHANT, item.getId(), offerIds, itemInteractions,
                interactions);
        }

        Map<InteractionType, List<Interaction>> offerInteractions = userInteractions
            .get(ItemType.OFFER);
        if (offerInteractions != null) {
            populateInteractionMap(ItemType.OFFER, item.getId(), offerIds,
                offerInteractions, interactions);
        }
        if (!interactions.isEmpty()) {
            OffsetDateTime claimedDate = interactions.get(InteractionType.CLAIM);
            if (claimedDate != null) {
                Object[] values = {(getIntensityForInteractionType(InteractionType.CLAIM)),
                    claimedDate, InteractionType.CLAIM};
                return values;
            }

            OffsetDateTime wishlistedDate = interactions.get(InteractionType.WISHLIST);
            if (wishlistedDate != null) {
                Object[] values = {getIntensityForInteractionType(InteractionType.WISHLIST),
                    wishlistedDate, InteractionType.WISHLIST};
                return values;
            }

            OffsetDateTime likedDate = interactions.get(InteractionType.LIKE);
            if (likedDate != null) {
                Object[] values = {getIntensityForInteractionType(InteractionType.LIKE),
                    likedDate, InteractionType.LIKE};
                return values;
            }

            OffsetDateTime viewedDate = interactions.get(InteractionType.VIEW);

            if (viewedDate != null) {
                int days = (int)DAYS.between(viewedDate, OffsetDateTime.now());
                Double intensity = 0.0;
                if (days < 7) {
                    intensity = getIntensityForInteractionType(InteractionType.VIEW);
                }
                Object[] values = {intensity,
                    viewedDate, InteractionType.VIEW};
                return values;
            }
        }
        return null;
    }

    /**
     * Populates interaction map.
     *
     * @param itemType {@link ItemType}
     * @param itemId id of the item
     * @param offerIds list of offerIds
     * @param itemInteractions itemInteractions
     * @param interactions interactionType
     */
    default void populateInteractionMap(ItemType itemType, String itemId,
        List<String> offerIds, Map<InteractionType,
        List<Interaction>> itemInteractions,
        Map<InteractionType, OffsetDateTime> interactions) {
        if (itemInteractions != null) {
            for (Map.Entry<InteractionType, List<Interaction>> itmInteractions :
                itemInteractions.entrySet()) {
                Predicate<Interaction> isPresent = intr -> (itemType == ItemType.MERCHANT)
                    ? intr.getItemId().equals(itemId) : offerIds.contains(intr.getItemId());
                Optional<Interaction> interaction = itmInteractions.getValue().stream()
                    .filter(isPresent).findFirst();
                if (interaction.isPresent()) {
                    interactions.put(itmInteractions.getKey(), interaction.get().getTimestamp());
                }
            }
        }
    }

    /**
     * Get updated item with TasteMatchScore.
     * @param score taste match score of the item
     * @param item Item for which score has to be updated
     * @return {@link Item} with property added for tasteMatchScore
     */
    default Item updateItemWithTasteMatchScore(int score, Item item) {
        Map<String, Object> properties = item.getProperties();
        if (properties == null) {
            properties = new HashMap<>();
            item.setProperties(properties);
        }
        properties.put(TASTE_MATCH_SCORE_FIELD, score);
        return item;
    }
}
