/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.maya.choice.service;

import com.crayondata.maya.choice.ListAPI;
import com.crayondata.maya.data.access.util.JsonUtils;
import com.crayondata.maya.data.list.DataListService;
import com.crayondata.maya.data.model.entity.Item;
import com.crayondata.maya.data.model.profile.CityListItem;
import com.crayondata.maya.model.api.ApiResponse;
import com.crayondata.maya.model.common.GeoCode;
import com.crayondata.maya.model.enums.Languages;
import com.fasterxml.jackson.databind.JsonNode;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class DistanceService {

    public static final String DISTANCE_FIELD = "distance";

    @Autowired
    ListAPI listAPI;

    @Autowired
    JsonUtils jsonUtils;

    /**
     * Calculates distance if the given request meets the condition
     * and updates item list with distance.
     * @param geoCode location of the user
     * @param city  city for which choices to be recommended
     * @param items item list for which distance has to be updated
     */
    public void calculateDistanceAndUpdateItemList(GeoCode geoCode, String city,
        Map<String, Item> items) {
        if (geoCode == null && city != null) {
            geoCode = getGeoCode(city);
        }
        Map<String, Double> itemDistanceMap =
            calculateItemDistanceFromUserLocation(geoCode, items);
        updateItemListWithDistance(itemDistanceMap, items);
    }

    /**
     * Get geoCode for given city.
     *
     * @param city city given in request
     * @return geoCode of given city
     */
    public GeoCode getGeoCode(String city) {
        ApiResponse<JsonNode> result = listAPI
            .getCityList(null, Languages.en.toString());
        CityListItem[] cityList = jsonUtils
            .getObject(result.getResponse(), CityListItem[].class);
        List<CityListItem> cityListItem = Stream.of(cityList).filter(x -> x.getValue()
            .equalsIgnoreCase(city))
            .collect(Collectors.toList());
        return cityListItem.get(0).getGeoCode();
    }

    /**
     * Updates item with given distance.
     *
     * @param score distance
     * @param item item for which distance has to be updated
     */
    public void setItemWithDistance(Object score, Item item) {
        Map<String, Object> properties = item.getProperties();
        if (properties == null) {
            properties = new HashMap<>();
            item.setProperties(properties);
        }
        properties.put(DISTANCE_FIELD, score);
    }

    private static Map<String, Double> calculateItemDistanceFromUserLocation(GeoCode geoCode,
        Map<String, Item> items) {

        Map<String, Double> itemDistanceMap = items.entrySet().stream().collect(Collectors
            .toMap(x -> x.getKey(), x -> geoCode
            .getClosestGeoDistance(x.getValue().getGeoCodes())));

        Map<String, Double> filteredItems = itemDistanceMap.entrySet().stream()
            .filter(x -> x.getValue() <= 1000)
            .collect(Collectors.toMap(x -> x.getKey(), x -> x.getValue()));
        return filteredItems;
    }

    private void updateItemListWithDistance(Map<String, Double> itemDistance,
        Map<String, Item> items) {
        if (itemDistance.isEmpty() || items.isEmpty()) {
            return;
        }
        items.forEach((k,v) -> {
            Double score = itemDistance.get(k);
            score = score != null ? round(score, 1) : 0.0;
            setItemWithDistance(score, v);
        });
    }

    private double round(double value, int precision) {
        int scale = (int) Math.pow(10, precision);
        return (double) Math.round(value * scale) / scale;
    }
}
