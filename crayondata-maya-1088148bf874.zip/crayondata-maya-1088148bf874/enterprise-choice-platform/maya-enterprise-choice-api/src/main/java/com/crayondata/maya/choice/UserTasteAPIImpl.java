/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.maya.choice;

import com.crayondata.maya.data.access.util.DBConstants;
import com.crayondata.maya.data.access.util.TasteScoreUtils;
import com.crayondata.maya.data.entity.ItemService;
import com.crayondata.maya.data.model.entity.FavouritePlace;
import com.crayondata.maya.data.model.entity.Item;
import com.crayondata.maya.data.model.entity.UserFavourites;
import com.crayondata.maya.data.model.profile.TagScore;
import com.crayondata.maya.data.profile.UserTagService;
import com.crayondata.maya.data.profile.UserTasteService;
import com.crayondata.maya.model.api.ApiResponse;
import com.crayondata.maya.model.api.ApiResponse.Status;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserTasteAPIImpl implements UserTasteAPI {

    @Autowired
    UserTasteService userTasteService;

    @Autowired
    UserTagService userTagService;

    @Autowired
    TasteScoreUtils tasteScoreUtils;

    @Autowired
    ItemService itemService;

    @Override
    public ApiResponse<Boolean> saveUserFavouriteItems(String userId, String category,
        List<FavouritePlace> favouritePlaces) {

        UserFavourites userFavourites = userTasteService.getUserFavourites(userId);
        if (userFavourites == null) {
            Map<String, Object> preferredItems = new HashMap<>();
            preferredItems.put(DBConstants.USER_PREFERRED_ITEM_FIELD, favouritePlaces);
            Map<String, Map<String, Object>> categoryItems = new HashMap<>();
            categoryItems.put(category, preferredItems);
            userFavourites = new UserFavourites(userId, categoryItems);
        } else {
            Map<String, Map<String, Object>> preferredCategories = userFavourites
                .getPreferredCategories();
            Map<String, Object> preferredItems = preferredCategories.get(category);
            if (preferredItems == null) {
                preferredItems = new HashMap<>();
                preferredCategories.put(category, preferredItems);
            }
            preferredItems.put(DBConstants.USER_PREFERRED_ITEM_FIELD, favouritePlaces);
        }

        boolean status = userTasteService.saveUserFavourites(userFavourites);
        return status ? new ApiResponse<>(true) : new ApiResponse<>(Status.ERROR,
        "Error while storing Favourite Places");
    }

    @Override
    public ApiResponse<Boolean> saveUserFavouriteTags(String userId,
        String category, List<String> likedTags) {
        UserFavourites userFavourites = userTasteService.getUserFavourites(userId);
        if (userFavourites == null) {
            Map<String, Object> preferredTags = new HashMap<>();
            preferredTags.put(DBConstants.USER_PREFERRED_TAG_FIELD, likedTags);
            Map<String, Map<String, Object>> categoryItems = new HashMap<>();
            categoryItems.put(category, preferredTags);
            userFavourites = new UserFavourites(userId, categoryItems);
        } else {
            Map<String, Map<String, Object>> preferredCategories = userFavourites
                .getPreferredCategories();
            Map<String, Object> preferredItemOrTags = preferredCategories.get(category);
            if (preferredItemOrTags == null) {
                preferredItemOrTags = new HashMap<>();
                preferredCategories.put(category, preferredItemOrTags);
            }
            preferredItemOrTags.put(DBConstants.USER_PREFERRED_TAG_FIELD, likedTags);

        }

        boolean status = userTasteService.saveUserFavourites(userFavourites);
        return status ? new ApiResponse<>(true) : new ApiResponse<>(Status.ERROR,
            "Error while storing Favourite Offers");

    }

    @Override
    public ApiResponse<Map<String, Object>> getUserOnboardedInfo(String userId, String category) {
        Map<String, Object> favoritePlaces = userTasteService
            .getUserFavourites(userId, category);
        ApiResponse<Map<String, Object>> response = favoritePlaces != null
            ? new ApiResponse<>(favoritePlaces)
            : new ApiResponse<>(Status.NOT_FOUND, "Onboarded info not found for given user");
        return response;
    }
}



