/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.maya.choice.service;

import com.crayondata.maya.data.model.config.ChoiceApiConfig;
import com.crayondata.maya.data.model.config.GlobalConfig;
import com.crayondata.maya.data.model.config.recommender.RecommenderConfig;
import com.crayondata.maya.data.model.config.recommender.RecommenderSegmentConfig;
import com.crayondata.maya.data.model.config.recommender.RecommenderSegmentConfig.NonOfferRecommendationConfig;
import com.crayondata.maya.data.model.config.recommender.SegmentConfig;
import com.crayondata.maya.data.model.config.recommender.SegmentConfiguration;
import com.crayondata.maya.data.model.recommendation.BlenderType;
import com.crayondata.maya.data.model.recommendation.RecommenderType;
import com.crayondata.maya.model.api.ConfigValidationResponse;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ConfigValidator {

    private static final Logger LOGGER = LoggerFactory.getLogger(ConfigValidator.class);

    private static final Pattern OFFER_CHOICE_RATIO_PATTERN = Pattern.compile("\\d+:\\d+");

    /**
     * Validates the choice config against correctness, missing fields, handling invalid
     * combinations and defaulting as needed.
     *
     * @param config Config that is to be validated
     * @return Response containing the validity and message indicating the reason.
     */
    public static ConfigValidationResponse validate(ChoiceApiConfig config) {
        String validationError = null;

        if (config == null) {
            validationError = "No configuration found";
        }

        if (validationError == null) {
            validationError = validateSegmentConfiguration(config);
        }
        if (validationError == null) {
            validationError = validateRecommenderConfiguration(config);
        }
        if (validationError == null && config.getGlobalConfig() == null) {
            // set a dummy config, so we can avoid checking for null at multiple places
            config.setGlobalConfig(new GlobalConfig());
        }
        return new ConfigValidationResponse(validationError == null, validationError);
    }

    private static String validateSegmentConfiguration(ChoiceApiConfig config) {
        SegmentConfiguration segmentConfiguration = config.getSegmentConfiguration();
        String validationError = null;
        if (validationError == null) {
            validationError = validateMissingSegmentConfig(segmentConfiguration);
        }
        if (validationError == null) {
            validationError = validateMissingSegmentDefinition(segmentConfiguration);
        }
        if (validationError == null) {
            validationError = validateSegmentDefinition(segmentConfiguration);
        }
        return validationError;
    }

    private static String validateRecommenderConfiguration(ChoiceApiConfig config) {
        RecommenderConfig recommenderConfig = config.getRecommenderConfig();
        String validationError = null;
        if (validationError == null) {
            validationError = validateMissingRecommenderConfig(recommenderConfig);
        }
        if (validationError == null) {
            validationError = validateRecommenderSegmentConfigs(recommenderConfig);
        }
        if (validationError == null) {
            validationError = validateDefaultRecommenderConfig(recommenderConfig);
        }
        return validationError;
    }

    private static String validateMissingSegmentConfig(SegmentConfiguration config) {
        String response = null;
        if (config == null) {
            response = "Segment definition is missing";
        }
        return response;
    }

    private static String validateMissingSegmentDefinition(SegmentConfiguration config) {
        String response = null;
        if (config.getSegmentConfig() == null) {
            response = "Segment definition property segmentConfig is null";
        }
        return response;
    }

    private static String validateSegmentDefinition(SegmentConfiguration config) {
        String response = null;
        Set<Integer> segmentNumbers = new HashSet<>();
        List<SegmentConfig> segmentConfigs = config.getSegmentConfig();
        for (SegmentConfig segmentConfig : segmentConfigs) {
            int segmentNo = segmentConfig.getSegmentNo();
            if (segmentNo == 0) {
                return "segmentNo is missing in definition or default segment 0 being redefined";
            }
            if (segmentNumbers.contains(segmentNo)) {
                return "segmentNo is missing in definition or duplicate definition of segmentNo="
                    + segmentNo;
            } else {
                segmentNumbers.add(segmentNo);
            }
        }
        return response;
    }

    private static String validateMissingRecommenderConfig(RecommenderConfig config) {
        String response = null;
        if (config == null) {
            response = "Recommender configuration is missing";
        }
        if (response == null) {
            List<RecommenderSegmentConfig> segmentConfig = config.getSegmentConfig();
            if (segmentConfig == null || segmentConfig.isEmpty()) {
                response = "Recommender segmentConfig is missing/empty";
            }
        }
        return response;
    }

    private static String validateRecommenderSegmentConfigs(RecommenderConfig config) {
        String response = null;
        for (RecommenderSegmentConfig segmentConfig : config.getSegmentConfig()) {
            response = validateRecommenderSegmentConfig(segmentConfig);
            if (response != null) {
                break;
            }
        }
        return response;
    }

    private static String validateRecommenderSegmentConfig(RecommenderSegmentConfig config) {
        int segmentNo = config.getSegmentNo();
        List<RecommenderType> recommenders = config.getRecommenders();
        if (recommenders == null) {
            return "Property recommenders is not set for segment " + segmentNo;
        }
        if (recommenders.isEmpty()) {
            return "Property recommenders is empty for segment " + segmentNo;
        }
        BlenderType blender = config.getBlender();
        if (blender == null) {
            return "Property blender is not set for segment " + segmentNo;
        }
        List<Map<String, Object>> blendingConfig = config.getBlendingConfig();
        if (blendingConfig == null || blendingConfig.isEmpty()) {
            return "Property blendingConfig is not set or is empty for segment " + segmentNo;
        }
        /* // disabled this check, since this may not be valid at times
        if (recommenders.size() != blendingConfig.size()) {
            return String.format(
                "Recommender count is %d, but %d blendingConfig found for segment %d",
                recommenders.size(), blendingConfig.size(), segmentNo);
        }
        */

        Set<String> definedRecommenders = recommenders.stream().map(Enum::name)
            .collect(Collectors.toSet());
        for (Map<String, Object> blendingConfigMap : blendingConfig) {
            Object recommender = blendingConfigMap.get("recommender");
            if (recommender == null) {
                return "Recommender not set in property blendingConfig for segment " + segmentNo;
            } else if (!definedRecommenders.contains(recommender)) {
                return "Recommender in property blendingConfig differs from recommender list"
                    + " for segment " + segmentNo;
            }
            Object weight;
            if (blender == BlenderType.WEIGHTED_AGGREGATION) {
                weight = blendingConfigMap.get("weight");
                if (weight == null) {
                    return "weight not set in property blendingConfig for segment " + segmentNo;
                }
            } else {
                weight = blendingConfigMap.get("count");
                if (weight == null) {
                    return "count not set in property blendingConfig for segment " + segmentNo;
                }
            }
            if (!(weight instanceof Integer)) {
                return "weight of property blendingConfig should be integer for segment "
                    + segmentNo;
            }
        }
        if (config.getNonOfferRecommendation() != null) {
            NonOfferRecommendationConfig nonOfferRec = config
                .getNonOfferRecommendation();
            if (nonOfferRec.isEnabled()) {
                String ratio = nonOfferRec.getRatio();
                if (ratio == null) {
                    return "ratio for offer:non-offer recommendation should be provided";
                }
                if (!OFFER_CHOICE_RATIO_PATTERN.matcher(ratio).matches()) {
                    return "ratio for offer:non-offer is not provided in the right format";
                }
            }
        }
        return null;
    }

    private static String validateDefaultRecommenderConfig(RecommenderConfig config) {
        Set<Integer> segmentNumbers = new HashSet<>();
        for (RecommenderSegmentConfig segmentConfig : config.getSegmentConfig()) {
            int segmentNo = segmentConfig.getSegmentNo();
            if (segmentNumbers.contains(segmentNo)) {
                return "Duplicate recommender-segment configuration for segment " + segmentNo;
            }
            segmentNumbers.add(segmentNo);
        }
        if (!segmentNumbers.contains(0)) {
            return "No recommender configuration found for default segment 0";
        }
        return null;
    }
}
