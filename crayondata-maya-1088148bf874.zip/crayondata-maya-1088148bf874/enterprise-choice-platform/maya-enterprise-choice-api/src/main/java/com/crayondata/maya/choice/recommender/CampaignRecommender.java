/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.maya.choice.recommender;

import com.crayondata.maya.choice.service.FilterService;
import com.crayondata.maya.data.access.util.DBConstants;
import com.crayondata.maya.data.campaign.CampaignService;
import com.crayondata.maya.data.campaign.UserCampaignService;
import com.crayondata.maya.data.entity.ItemService;
import com.crayondata.maya.data.model.campaign.UserCampaign;
import com.crayondata.maya.data.model.config.ChoiceApiConfig;
import com.crayondata.maya.data.model.entity.Item;
import com.crayondata.maya.data.model.entity.ScoredItem;
import com.crayondata.maya.data.model.recommendation.RecommendRequest;
import com.crayondata.maya.data.model.recommendation.RecommenderType;
import com.crayondata.maya.data.profile.UserProfileService;
import com.crayondata.maya.model.common.GeoCode;

import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;


/**
 * Provides recommedations based on predefined campaigns.
 *
 * @author sundar
 */
@Service
public class CampaignRecommender implements IRecommender {

    private static final Logger LOGGER = LoggerFactory.getLogger(CampaignRecommender.class);

    @Autowired
    private CampaignService campaignService;

    @Autowired
    private UserProfileService userProfileService;

    @Autowired
    private UserCampaignService userCampaignService;

    @Autowired
    private ItemService itemService;

    @Autowired
    private FilterService filterService;

    @Value("${constraint.location.campaign}")
    private boolean constraintCity;

    @Autowired
    private ChoiceApiConfig choiceApiConfig;

    @Override
    public RecommenderType getType() {
        return RecommenderType.CAMPAIGN;
    }

    @Override
    public List<ScoredItem> recommend(RecommendRequest recommendRequest) {
        String userId = userProfileService.getUseableUserId(recommendRequest.getUserProfile());
        OffsetDateTime choiceServedAt = recommendRequest.getChoiceServedAt();

        long startTime = System.nanoTime();
        List<ScoredItem> recommendations = recommendCampaignItems(recommendRequest);
        LOGGER.debug("TimeTaken : recommendCampaignItems {} ms",
            (System.nanoTime() - startTime) / 1000000);
        return filterService.filterInteractedItems(recommendations, userId, choiceServedAt);
    }


    private List<ScoredItem> recommendCampaignItems(RecommendRequest recommendRequest) {
        String knownUserId = recommendRequest.getUserProfile().getKnownUserId();
        if (knownUserId == null) {
            return new ArrayList<>(0);
        }
        String userId = DBConstants.stripUserKeyIfExists(recommendRequest.getUserProfile().getId());
        String campaignId = recommendRequest.getCampaignId();
        LOGGER.info("Getting campaign recommendations for sessionid:{} knownuserid:{} campaign:{}",
            userId, knownUserId, campaignId);
        UserCampaign userCampaign = userCampaignService.getUserCampaign(knownUserId, campaignId);
        List<ScoredItem> recommendations = new ArrayList<>(0);
        if (userCampaign == null) {
            return recommendations;
        }

        OffsetDateTime choiceServedAt = recommendRequest.getChoiceServedAt();
        OffsetDateTime campaignStartTime = userCampaign.getCampaign().getStartDateTime();
        OffsetDateTime campaignEndTime = userCampaign.getCampaign().getEndDateTime();

        boolean campaignActive = userCampaign.getCampaign().isActive();
        LOGGER.debug("Campaign Active: {}", campaignActive);

        if (campaignActive) {
            // Apply the context filters only if they are present
            if (choiceServedAt != null && campaignStartTime != null && campaignEndTime != null) {
                if (choiceServedAt.isAfter(campaignStartTime)
                    && choiceServedAt.isBefore(campaignEndTime)) {
                    LOGGER.debug("Choice is being served when the campaign is active");
                    recommendations.addAll(userCampaign.getItems());
                } else {
                    LOGGER.debug("Choice is being served when the campaign is inactive");
                    return new ArrayList<>(0);
                }
            } else {
                recommendations.addAll(userCampaign.getItems());
            }
        }

        List<String> itemIds = recommendations.stream().map(ScoredItem::getItemId)
            .collect(Collectors.toList());
        List<Item> items = filterService.filterExpiredOffers(itemService.getItems(itemIds),
            choiceServedAt, true);
        GeoCode choiceLocation = recommendRequest.getChoiceLoc();
        String choiceCity = recommendRequest.getChoiceCity();
        if (choiceLocation != null) {
            // filter expired offers from recommendations
            Set<String> filteredItemIDs = items.stream().map(Item::getId)
                .collect(Collectors.toSet());
            recommendations = recommendations.stream()
                .filter(item -> filteredItemIDs.contains(item.getItemId()))
                .collect(Collectors.toList());
            recommendations = ScoredItem
                .sortScoredItemsBasedOnGeo(choiceLocation, recommendations, items);
        } else if (choiceCity != null) {
            /*List<ScoredItem> filteredRec = filterScoredItemsOnCity(choiceCity, recommendations,
                items);
            if (filteredRec != null && !filteredRec.isEmpty())
                recommendations = filteredRec;*/
            Map<String, Boolean> locationConstraint = choiceApiConfig.getGlobalConfig() != null
                ? choiceApiConfig.getGlobalConfig().getLocationConstraint() : null;
            boolean constraintCity = locationConstraint != null ? locationConstraint.get("campaign")
                : this.constraintCity;
            if (constraintCity) {
                LOGGER.debug("Filtering Campaign choices due to constraintCity={} based on city:{}",
                    constraintCity, choiceCity);
                recommendations = filterScoredItemsOnCity(choiceCity, recommendations, items);
            }
        }

        Set<String> availableItemIds = items.stream().map(Item::getId).collect(Collectors.toSet());
        recommendations = recommendations.stream()
            .filter(recommendation -> availableItemIds.contains(recommendation.getItemId()))
            .collect(Collectors.toList());

        return recommendations;
    }

    private static List<ScoredItem> filterScoredItemsOnCity(String city,
        List<ScoredItem> scoredItems, List<Item> items) {
        List<String> idsOfItemsInCity = new ArrayList<>();
        for (Item item : items) {
            List<String> cities = item.getCities();
            if (cities.contains(city)) {
                idsOfItemsInCity.add(item.getId());
            }
        }
        return scoredItems.stream().filter(x -> idsOfItemsInCity.contains(x.getItemId()))
            .collect(Collectors.toList());
    }
}
