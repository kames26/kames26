/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.maya.choice.blender;

import com.crayondata.maya.data.model.entity.ScoredItem;
import com.crayondata.maya.data.model.recommendation.BlenderType;
import com.crayondata.maya.data.model.recommendation.RecommendRequest;
import com.crayondata.maya.data.model.recommendation.RecommenderType;

import java.util.List;
import java.util.Map;

/**
 * Blender interface for supporting blending of recommendations.
 * The blender implementations will be stateless, and any configuration has to be supplied in
 * for each and every blending request.
 *
 * @author somin
 * @since 0.2.0
 */
public interface IBlender {

    /**
     * Blends the given set of recommendations and creates final mix.
     *
     * @param recommendations  Collection of recommendations from recommenders
     * @param blendingConfig   Configuration for the blender
     * @param recommendRequest Request for which the recommendations are generated
     * @return Final list of choices. List might be empty, never <tt>null</tt>
     */
    List<ScoredItem> blend(Map<RecommenderType, List<ScoredItem>> recommendations,
        List<Map<String, Object>> blendingConfig, RecommendRequest recommendRequest);

    /**
     * Get type of the blender.
     *
     * @return {@link BlenderType} instance representing this blender.
     */
    BlenderType getType();
}
