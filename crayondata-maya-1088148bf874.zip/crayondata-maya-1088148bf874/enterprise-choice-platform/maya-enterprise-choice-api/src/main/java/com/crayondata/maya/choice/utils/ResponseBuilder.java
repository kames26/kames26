/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.maya.choice.utils;

import com.crayondata.maya.data.access.util.JsonUtils;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class ResponseBuilder {

    @Autowired
    private JsonUtils json;

    public void movePropertiesOut(ArrayNode items) {
        items.iterator().forEachRemaining(item -> movePropertiesOut((ObjectNode) item));
    }

    public void movePropertiesOut(ObjectNode item) {
        mapLocationsToOffers(json, item);
        movePropertiesOut(json, item);
    }

    private static void movePropertiesOut(JsonUtils json, ObjectNode item) {
        json.moveObjectPropertiesUp(item);
        JsonNode offers = item.get("offers");
        if (offers != null && !offers.isEmpty() && offers instanceof ArrayNode) {
            json.moveArrayPropertiesUp((ArrayNode) offers);
        }
    }

    private static void mapLocationsToOffers(JsonUtils json, ObjectNode item) {
        Map<String, JsonNode> locMap = new HashMap<>();
        JsonNode locations = item.get("locations");
        if (locations != null && !locations.isEmpty() && locations.isArray()) {
            locations.forEach(loc -> {
                JsonNode id = loc.get("id");
                if (id != null) {
                    locMap.put(id.asText(), loc);
                }
            });
            for (JsonNode location : locations) {
                ObjectNode loc = (ObjectNode) location;
                loc.remove("offers");
                JsonNode id = loc.get("id");
                if (id != null) {
                    String key = id.asText();
                    loc.remove("id");
                    locMap.put(key, loc);
                }
            }
        }

        JsonNode offers = item.get("offers");
        ArrayNode newOffers = json.newArrayNode();
        if (offers != null && !offers.isEmpty() && offers.isArray()) {
            for (JsonNode offer : offers) {
                if (offer.get("locations") != null && !offer.get("locations").isNull()) {
                    ArrayNode offerLoc = (ArrayNode) offer.get("locations");
                    ArrayNode newOfferLoc = json.newArrayNode();
                    offerLoc.forEach(locStr -> newOfferLoc.add(locMap.get(locStr.asText())));
                    ObjectNode newOffer = json.newObjectNode();
                    newOffer.setAll((ObjectNode) offer);
                    newOffer.set("locations", newOfferLoc);
                    newOffers.add(newOffer);
                } else {
                    newOffers.add(offer);
                }
            }
            item.set("offers", newOffers);
        }

        if (item.has("locations")) {
            item.remove("locations");
        }
    }
}
