/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.maya.choice.blender;

import com.crayondata.maya.choice.recommender.factory.RecommenderFactory;
import com.crayondata.maya.data.model.entity.ScoredItem;
import com.crayondata.maya.data.model.recommendation.BlenderType;
import com.crayondata.maya.data.model.recommendation.RecommendRequest;
import com.crayondata.maya.data.model.recommendation.RecommenderType;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * Blends the recommendations by applying weightages to recommendations from each recommender
 * and aggregating them.
 *
 * @author somin
 */
@Service
public class WeightedAggregationBlender implements IBlender {

    private static final Logger LOGGER = LoggerFactory.getLogger(WeightedAggregationBlender.class);

    private RecommenderFactory recommenderFactory;

    @Autowired
    public WeightedAggregationBlender(RecommenderFactory recommenderFactory) {
        this.recommenderFactory = recommenderFactory;
    }

    @Override
    public BlenderType getType() {
        return BlenderType.WEIGHTED_AGGREGATION;
    }

    @Override
    public List<ScoredItem> blend(Map<RecommenderType, List<ScoredItem>> recommendations,
        List<Map<String, Object>> blendingConfig,
        RecommendRequest recommendRequest) {
        long startTime = System.nanoTime();
        //get weights from config
        EnumMap<RecommenderType, Integer> recommenderWeights = parseConfig(blendingConfig);

        List<ScoredItem> resultRecommendations = mergeRecommendations(recommendations,
            recommenderWeights);
        LOGGER.info("Blending using {} took {} ms", getType(),
            (System.nanoTime() - startTime) / 1000000);
        return resultRecommendations;
    }

    private EnumMap<RecommenderType, Integer> parseConfig(
        List<Map<String, Object>> blendingConfig) {
        EnumMap<RecommenderType, Integer> recommenderWeights = new EnumMap<>(RecommenderType.class);
        blendingConfig.forEach(config -> {
            RecommenderType recommender = RecommenderType.valueOf(
                (String) config.get("recommender"));
            Integer count = (Integer) config.get("weight");
            recommenderWeights.put(recommender, count);
        });
        return recommenderWeights;
    }

    private List<ScoredItem> mergeRecommendations(Map<RecommenderType,
        List<ScoredItem>> recommendations, EnumMap<RecommenderType, Integer> recommenderWeights) {
        HashMap<String, ScoredItem> processedItems = new HashMap<>();

        recommendations.entrySet().forEach(e -> {
            RecommenderType recommender = e.getKey();
            Integer weight = recommenderWeights.get(recommender);
            List<ScoredItem> scoredItems = e.getValue();
            for (int i = 0; i < scoredItems.size(); i++) {
                int rank = i + 1;
                ScoredItem scoredItem = scoredItems.get(i);
                String itemId = scoredItem.getItemId();
                float score = (float) calculateScore(weight, rank);
                ScoredItem rescoredItem = new ScoredItem(itemId, score, recommender,
                    scoredItem.getExplanation());
                if (processedItems.containsKey(itemId)) {
                    processedItems.get(itemId).mergeScores(rescoredItem);
                } else {
                    processedItems.put(itemId, rescoredItem);
                }
            }
        });

        List<ScoredItem> finalRecommendations = new ArrayList<>(processedItems.values());
        finalRecommendations.sort(ScoredItem::compareTo);

        return finalRecommendations;
    }

    private double calculateScore(int weight, int rank) {
        return weight / (1 + Math.log10(rank));
    }
}
