/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/


package com.crayondata.maya.choice.service;

import com.crayondata.maya.data.access.key.KeyStoreDataAccessService;
import com.crayondata.maya.data.access.model.JsonDocument;
import com.crayondata.maya.data.access.util.DBConstants;
import com.crayondata.maya.data.profile.UserProfileService;
import com.fasterxml.jackson.databind.JsonNode;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * Service for serving UI configurations.
 *
 * @author Somin
 */
@Service
public class UiConfigService {

    private static final Logger LOGGER = LoggerFactory.getLogger(UiConfigService.class);

    /**
     * Prefix of the UI configuration document key.
     */
    private static final String UI_CONFIG_KEY = "theme";
    private static final String DEFAULT_THEME_KEY = "theme-default";
    private static final String CONFIG_SUBDOC_KEY = "config";
    /*
    private static final String UI_THEME_USER_MAP_TYPE = "themeuser";
    private static final String Q_THEME_ID_BY_USER = "#type = :xxx and (contains(#users, :yyy))";
    private static final String Q_DEFAULT_THEME = "#default = :xxx";
    private static final String TYPE_INDEX = "type-index";
     */
    @Autowired
    private KeyStoreDataAccessService dataAccessService;

    @Autowired
    private UserProfileService profileService;

    /**
     * Get UI configuration by user ID. If not available for the user, get default theme.
     *
     * @param userId ID representing the user for whom configuration is needed.
     * @return Theme document if it exists, null otherwise
     */
    public JsonNode getUiConfigurationForUser(String userId) {
        LOGGER.debug("Fetching theme for user {}", userId);
        JsonNode response;

        /** TODO Fix fetching UI configuration for a user.
         *  This is disabled now since some of the backend DBs do not allow querying
         *  and we have to switch between query or key backends for doing this simple search.
         */
        /*
        String profileId;
        UserProfile userProfile = profileService.getUnifiedUserProfile(userId);
        if (userProfile != null && userProfile.getKnownUserId() != null) {
            profileId = userProfile.getKnownUserId();
        } else {
            profileId = userId;
        }

        String themeId = getThemeIdForUser(profileId);
        if (themeId != null) {
            response = getUiConfiguration(themeId);
        } else {
         */
        response = getDefaultUiConfiguration();

        return response;
    }

    /**
     * Get UI configuration by theme ID.
     *
     * @param themeId ID representing the theme selected
     * @return Theme document if it exists, null otherwise
     */
    private JsonNode getUiConfiguration(String themeId) {
        LOGGER.debug("Fetching theme {}", themeId);
        JsonNode jsonData = null;
        if (themeId != null) {
            String documentKey = DBConstants.asCustomPrefixedKey(UI_CONFIG_KEY, themeId);
            JsonDocument document = dataAccessService.getDocument(
                documentKey, DBConstants.THEME_TYPE);
            if (document == null) {
                LOGGER.info("Theme {} not found", themeId);
            } else {
                jsonData = document.getJson();
                jsonData = extractConfigEntry(jsonData);
            }
        }
        return jsonData;
    }

    /**
     * Extract config sub-document.
     *
     * @return Config document if it exists, null otherwise
     */
    private JsonNode extractConfigEntry(JsonNode jsonData) {
        JsonNode response = null;
        if (jsonData != null && jsonData.hasNonNull(CONFIG_SUBDOC_KEY)) {
            response = jsonData.get(CONFIG_SUBDOC_KEY);
        }
        return response;
    }

    /**
     * Get default UI configuration.
     *
     * @return Theme document if it exists, null otherwise
     */
    private JsonNode getDefaultUiConfiguration() {
        LOGGER.debug("Fetching default theme");
        JsonNode response = null;
        JsonDocument document = dataAccessService.getDocument(
            DEFAULT_THEME_KEY, DBConstants.THEME_TYPE);
        if (document != null && document.getJson() != null) {
            String themeId = document.getJson().get("themeId").textValue();
            if (themeId != null) {
                response = getUiConfiguration(themeId);
            }
        }
        return response;
    }

    /**
     * Get theme ID for the specified user.
     *
     * @param userId User for whom theme has to be fetched
     * @return Theme ID if available, null otherwise
     */
    private String getThemeIdForUser(String userId) {
        String themeId = null;
        /* Map<String, Object> params = null;
        Collections.singletonMap("userId", userId);

        List<JsonNode> themeIds = dataAccessService.runQueryAndConvertResult(Q_THEME_ID_BY_USER,
            params, JsonNode.class);
        List<JsonNode> themeIds = null;
        if (!themeIds.isEmpty()) {
            themeId = themeIds.get(0).get("themeId").asText();
        }
        */
        return themeId;
    }

}
