/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.maya.choice;

import com.crayondata.maya.data.model.profile.RedeemedOffers;
import com.crayondata.maya.model.api.ApiResponse;
import com.crayondata.maya.model.api.ApiResponse;
import com.crayondata.maya.model.api.CampaignResponse;
import com.crayondata.maya.model.api.ChoiceResponse;
import com.crayondata.maya.model.api.InteractRequest;
import com.crayondata.maya.model.api.InteractionResponse;
import com.crayondata.maya.model.api.UserProfileResponse;
import com.crayondata.maya.model.api.UserTagPreferenceResponse;
import com.crayondata.maya.model.enums.CampaignType;
import com.crayondata.maya.model.enums.InteractionType;
import com.crayondata.maya.model.enums.ItemType;
import com.crayondata.maya.model.rest.OfferRedemptionHistory;
import com.crayondata.maya.model.rest.UserProfileRequest;
import java.util.List;

/**
 * API abstraction for user and campaign search.
 */
public interface UserAPI {

    /**
     * Return list of applicable campaigns for the given userId and campaignType.
     *
     * @param userId Session Id of the user
     * @param campaignUserId Known Id of the user
     * @param campaignType Type of campaign
     * @return a {@link CampaignResponse} response
     */
    CampaignResponse getCampaigns(String userId, String campaignUserId, CampaignType campaignType);

    /**
     * Return items liked by the given userId.
     *
     * @param userId Id of the user
     * @return a {@link ChoiceResponse} response
     */
    ChoiceResponse getLikes(String userId);

    /**
     * Get the user profile based on the given user id.
     *
     * @param userId Id of the user
     * @return a {@link UserProfileResponse} response
     */
    UserProfileResponse getUserProfile(String userId);

    /**
     * Get the user tag preference vector based on the given user id.
     * @param userId Id of the user
     * @return a {@link UserTagPreferenceResponse} response
     */
    UserTagPreferenceResponse getUserTagPreferenceVector(String userId);

    ApiResponse<Boolean> updateUserProfile(String userId, UserProfileRequest userProfileRequest);

    /**
     * Records an interaction.
     *
     * @param request Interaction made
     * @return Response status of the operation
     */
    ApiResponse<Boolean> interact(InteractRequest request);

    /**
     * Get interaction details.
     * @param userId Id of the user
     * @param itemType type of Item. See {@link ItemType}
     * @param interactionType type of Interaction. See {@link InteractionType}
     * @param lang Language selected by the user
     * @return Response containing interacted items for given interaction type
     */
    ApiResponse<InteractionResponse> getUserInteractions(String userId,
        String itemType, String interactionType, String lang);

    /**
     * Get redeemedOffers.
     * @param userId Id of the user
     * @param lang Language selected by the user
     * @return Response containing offers redeemed by an user
     */
    ApiResponse<OfferRedemptionHistory> getRedeemedOffers(String userId, String lang);
}
