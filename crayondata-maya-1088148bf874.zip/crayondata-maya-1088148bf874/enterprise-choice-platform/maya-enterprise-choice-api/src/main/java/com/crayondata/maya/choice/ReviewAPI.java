/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.maya.choice;

import com.crayondata.maya.model.api.ApiResponse;
import com.crayondata.maya.model.api.AppFeedbackRequest;
import com.crayondata.maya.model.api.AppFeedbackResponse;
import com.crayondata.maya.model.api.ReviewItemRequest;
import com.crayondata.maya.model.api.ReviewMerchantResponse;

public interface ReviewAPI {
    /**
     * Save the merchant review to the DB.
     *
     * @param reviewItemsRequest request containing  merchantId,rating,review
     * @param userId userId of user
     * @return true or false
     */
    public ApiResponse<Boolean> saveReview(ReviewItemRequest reviewItemsRequest, String userId);

    /**
     * Save the feedback of the application.
     *
     * @param appFeedbackRequest containing review, rating,attachment
     * @param userId  userId id of the user
     * @return true if inserted successfully or false if not.
     */
    public ApiResponse<Boolean> saveFeedback(AppFeedbackRequest appFeedbackRequest, String userId);

    /**
     * Get feedback of the application.
     *
     * @param userId id of the user
     * @return Application feedback response
     */
    public ApiResponse<AppFeedbackResponse> getFeedback(String userId);

    /**
     * Get review of the merchant.
     *
     * @param merchantId id of the merchant
     * @return Review merchant response
     */
    public ApiResponse<ReviewMerchantResponse> getReviewDetails(String merchantId);
}
