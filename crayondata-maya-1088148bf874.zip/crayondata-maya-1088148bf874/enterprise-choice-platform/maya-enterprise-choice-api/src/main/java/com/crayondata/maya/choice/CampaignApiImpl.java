/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.maya.choice;

import com.crayondata.maya.data.campaign.CampaignService;
import com.crayondata.maya.data.model.campaign.Campaign;
import com.crayondata.maya.model.api.ApiResponse;
import com.crayondata.maya.model.api.ApiResponse.Status;
import com.crayondata.maya.model.api.CampaignUpdateRequest;
import java.time.OffsetDateTime;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CampaignApiImpl implements CampaignApi {

    @Autowired
    private CampaignService campaignService;

    @Override
    public Campaign getCampaign(String id) {
        if (id == null) {
            return null;
        }
        return campaignService.getCampaign(id);
    }

    @Override
    public List<Campaign> getCampaigns(List<String> ids) {
        if (ids == null) {
            return null;
        }
        return campaignService
            .getCampaigns(ids);
    }

    @Override
    public ApiResponse<Boolean> updateCampaign(CampaignUpdateRequest request) {
        String id = request.getId();
        Campaign campaign = campaignService.getCampaign(id);
        if (campaign == null) {
            return new ApiResponse<>(Status.NOT_FOUND, "Campaign not found");
        }
        Campaign updatedCampaign = updateCampaignData(campaign, request);
        boolean status = campaignService.updateCampaign(updatedCampaign);
        return new ApiResponse<>(status);
    }

    private static Campaign updateCampaignData(Campaign campaign, CampaignUpdateRequest update) {
        if (update == null) {
            return campaign;
        }

        // Select the right value for the fields
        String name = firstIfNonNull(update.getName(), campaign.getName());
        String desc = firstIfNonNull(update.getDescription(), campaign.getDescription());
        Map<String, String> images = firstIfNonNull(update.getImages(), campaign.getImages());
        OffsetDateTime startDateTime = firstIfNonNull(update.getStartDateTime(),
            campaign.getStartDateTime());
        OffsetDateTime endDateTime = firstIfNonNull(update.getEndDateTime(),
            campaign.getEndDateTime());
        boolean active = firstIfNonNull(update.isActive(), campaign.isActive());

        // Return a new Campaign object
        return new Campaign(campaign.getId(), name, desc, null, images, campaign.getCampaignType(),
            campaign.getCampaignCategory(), campaign.getExternalId(), campaign.getCities(),
            startDateTime, endDateTime, active, campaign.getCreated());
    }

    private static <T> T firstIfNonNull(T o1, T o2) {
        return (o1 != null) ? o1 : o2;
    }
}
