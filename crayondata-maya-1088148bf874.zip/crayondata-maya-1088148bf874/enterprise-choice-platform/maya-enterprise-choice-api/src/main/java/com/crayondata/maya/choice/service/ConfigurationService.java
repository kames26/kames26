/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.maya.choice.service;

import com.crayondata.maya.choice.utils.Uuid;
import com.crayondata.maya.data.config.ConfigDataService;
import com.crayondata.maya.data.model.config.ChoiceApiConfig;
import com.crayondata.maya.data.model.config.ConfigHistory;
import com.crayondata.maya.data.model.config.recommender.RecommenderConfig;
import com.crayondata.maya.data.model.config.recommender.RecommenderSegmentConfig;
import com.crayondata.maya.data.model.config.recommender.SegmentConfig;
import com.crayondata.maya.data.model.config.recommender.SegmentConfiguration;
import com.crayondata.maya.model.api.ConfigValidationResponse;
import com.crayondata.maya.model.api.ConfigurationResponse;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.time.OffsetDateTime;
import java.util.AbstractMap;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * Service to manage dynamic application configuration.
 */
@Service
public class ConfigurationService {

    private static final Logger LOGGER = LoggerFactory.getLogger(ConfigurationService.class);
    private final ConfigDataService configDataService;
    private final Uuid uuid;

    private ChoiceApiConfig choiceApiConfig;
    private String nodeName = null;


    @Autowired
    public ConfigurationService(ConfigDataService configDataService, Uuid uuid) {
        this.configDataService = configDataService;
        this.uuid = uuid;
    }

    /**
     * Initializes the service and load the current configuration.
     */
    @PostConstruct
    public void init() {
        try {
            nodeName = InetAddress.getLocalHost().getHostName();
        } catch (UnknownHostException e) {
            LOGGER.warn("Unable to get hostname on server, defaulting to null");
        }
        ConfigHistory configHistory = getConfigHistory();
        if (configHistory != null && configHistory.getCurrentConfig() != null) {
            loadConfiguration(configHistory.getCurrentConfig(), false);
        } else {
            LOGGER.error("Unable to find any configuration to load. Running in maintenance mode.");
            LOGGER.info("Please create and/or load a valid configuration to restore normal mode");
        }
    }

    /**
     * Gets the current Choice API configuration as a {@link ChoiceApiConfig} object.
     *
     * @return {@link ChoiceApiConfig} if found, <tt>null</tt> otherwise
     */
    public ChoiceApiConfig getChoiceApiConfig() {
        return choiceApiConfig;
    }

    /**
     * Loads the configuration from the backend data store.
     *
     * @param configId ID of the configuration to be loaded
     * @param recordHistory Whether to record history of the load in DB
     * @throws ConfigurationException if the configuration is not valid
     */
    public void loadConfiguration(String configId, boolean recordHistory)
        throws ConfigurationException {
        LOGGER.info("Loading configuration {}", configId);
        // fetch the configs from DB first, process, validate and then reset.
        ChoiceApiConfig newChoiceApiConfig = getConfigurationById(configId);
        ConfigValidationResponse validationResponse = validateConfiguration(newChoiceApiConfig);
        if (validationResponse.isValid()) {
            newChoiceApiConfig.processAndCacheConfigs();
            //replace the instance, do not modify it as other requests may be in progress
            choiceApiConfig = newChoiceApiConfig;
            LOGGER.info("Loaded configuration {}", configId);
            if (recordHistory) {
                updateConfigHistory(configId, OffsetDateTime.now().toString(), nodeName);
            }
        } else {
            LOGGER.info("Unable to load configuration {}", configId);
            throw new ConfigurationException(validationResponse.getMessage());
        }
    }

    /**
     * Validates the set of configurations from the backend data store.
     *
     * @param choiceApiConfig Configuration to be validated
     * @return ConfigurationResponse indicating status of the operation
     */
    public ConfigValidationResponse validateConfiguration(ChoiceApiConfig choiceApiConfig) {
        // include all possible validations, to prevent an incorrect configuration bringing down
        //  a live API server
        ConfigValidationResponse validationResponse = ConfigValidator.validate(choiceApiConfig);
        if (validationResponse.isValid()) {
            if (choiceApiConfig.getChecksum() == null
                || choiceApiConfig.getChecksum() != choiceApiConfig.hashCode()) {
                validationResponse = new ConfigValidationResponse(false,
                    "Alert!!! Configuration has been tampered with; can't load.");
            }
        }
        return validationResponse;
    }

    /**
     * Creates a new configuration entry in the underlying DB based on the specified configuration.
     *
     * @param choiceApiConfig Configuration to be created
     * @return Status of the response, with message containing configuration ID if success,
     *     or describing the error.
     */
    public ConfigurationResponse createConfiguration(ChoiceApiConfig choiceApiConfig) {
        ConfigValidationResponse configValidationResponse = ConfigValidator
            .validate(choiceApiConfig);
        ConfigurationResponse response;
        if (configValidationResponse.isValid()) {
            // override the dynamic field values
            String configId = uuid.nextId();
            choiceApiConfig.setId(configId);
            choiceApiConfig.setCreated(OffsetDateTime.now().toString());
            choiceApiConfig.setChecksum(choiceApiConfig.hashCode());

            // persist the component configurations
            boolean isSuccess = configDataService.persistConfiguration(choiceApiConfig);
            if (isSuccess) {
                isSuccess = updateConfigHistory(configId);
            }
            if (isSuccess) {
                response = new ConfigurationResponse(isSuccess, configId);
            } else {
                response = new ConfigurationResponse(isSuccess,
                    "Unknown error while persisting to DB");
            }
        } else {
            response = new ConfigurationResponse(false, configValidationResponse.getMessage());
        }
        return response;
    }

    /**
     * Clears cache content.
     *
     * @return Boolean value indicating status of the operation
     */
    public boolean clearCache() {
        return configDataService.clearCache();
    }

    public ChoiceApiConfig getConfigurationById(String id) {
        return configDataService.fetchConfiguration(id);
    }

    public ConfigHistory getConfigHistory() {
        return configDataService.fetchConfigHistory();
    }

    /**
     * Update the config history document with the newly created config ID.
     *
     * @param configId ID of the newly created configuration
     * @return Status of the operation. True if success, false otherwise.
     */
    private boolean updateConfigHistory(String configId) {
        ConfigHistory configHistory = getConfigHistory();
        boolean create = false;
        if (configHistory == null) {
            create = true;
            configHistory = configDataService.newConfigHistory();
            if (choiceApiConfig != null) {
                configHistory.setCurrentConfig(choiceApiConfig.getId());
            }
        }
        configHistory.getConfigs().add(configId);
        return configDataService.persistConfigHistory(configHistory, create);
    }

    /**
     * Update the config history document with the newly loaded config details.
     *
     * @param configId ID of the configuration loaded
     * @param timestamp Timestamp when the configuration was loaded
     * @param nodeName Host name of the node where configuration was loaded
     * @return Status of the operation. True if success, false otherwise.
     */
    private boolean updateConfigHistory(String configId, String timestamp, String nodeName) {
        ConfigHistory configHistory = getConfigHistory();
        boolean create = false;
        if (configHistory == null) {
            create = true;
            configHistory = configDataService.newConfigHistory();
        }
        configHistory.setCurrentConfig(choiceApiConfig.getId());
        // TODO history may grow beyond limit, so need to include a limit to prune oldest entries
        configHistory.getHistory().add(
            new ConfigHistory.HistoryEntry(configId, timestamp, nodeName));
        return configDataService.persistConfigHistory(configHistory, create);
    }

    public class ConfigurationException extends RuntimeException {

        public ConfigurationException(String message) {
            super(message);
        }

    }

}
