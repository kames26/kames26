/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.maya.choice.blender.factory;

import com.crayondata.maya.choice.blender.IBlender;
import com.crayondata.maya.data.model.recommendation.BlenderType;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.PostConstruct;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * Factory for creating instances of {@link IBlender}.
 *
 * @author somin
 */
@Component
public class BlenderFactory {

    private static final Logger LOGGER = LoggerFactory.getLogger(BlenderFactory.class);

    private final Map<BlenderType, IBlender> blenderCache = new HashMap<>();

    private List<IBlender> blenders;

    @Autowired
    public BlenderFactory(List<IBlender> blenders) {
        this.blenders = blenders;
    }

    @PostConstruct
    public void init() {
        blenders.forEach(blender ->
            blenderCache.put(blender.getType(), blender));
    }

    /**
     * Get a pre-created instance of the given blender.
     *
     * @param blenderType An enum constant representing the blender to get
     * @return An instance of the requested blender if it exists, null otherwise.
     */
    public IBlender getBlender(BlenderType blenderType) {
        IBlender blender = blenderCache.get(blenderType);
        if (blender == null) {
            LOGGER.error("Unknown blender: {}", blenderType);
        }
        return blender;
    }

    /**
     * Get a pre-created instance of the given blender by name.
     *
     * @param blenderName Name/type of the blender, exactly as defined in {@link BlenderType}
     * @return An instance of the requested blender if it exists, null otherwise.
     */
    public IBlender getBlender(String blenderName) {
        IBlender blender = null;
        try {
            BlenderType blenderType = BlenderType.valueOf(blenderName);
            blender = getBlender(blenderType);
        } catch (IllegalArgumentException e) {
            LOGGER.error("Unknown blender enum: {}", blenderName);
        }
        return blender;
    }
}
