/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.maya.choice.service;

import static com.crayondata.maya.data.utils.ObjectUtils.defaultIfNull;

import com.crayondata.maya.data.entity.ItemService;
import com.crayondata.maya.data.model.config.ChoiceApiConfig;
import com.crayondata.maya.data.model.entity.Item;
import com.crayondata.maya.data.model.entity.OfferDetails;
import com.crayondata.maya.data.model.entity.OfferLocation;
import com.crayondata.maya.data.model.entity.ScoredItem;
import com.crayondata.maya.data.model.profile.Interaction;
import com.crayondata.maya.data.profile.InteractionService;
import com.crayondata.maya.model.common.GeoCode;
import com.crayondata.maya.model.common.Location;
import com.crayondata.maya.model.enums.InteractionType;

import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

@Service
public class FilterService {

    private static final Logger LOGGER = LoggerFactory.getLogger(FilterService.class);

    @Value("${distance.km:100}")
    private int DEFAULT_DISTANCE_IN_KM;

    @Autowired
    private InteractionService interactionService;

    @Autowired
    private Environment environment;

    @Autowired
    private ItemService itemService;

    @Autowired
    private ChoiceApiConfig choiceApiConfig;

    private static final String PREFIX_INTERACTION_DECAY = "interaction.decay.";

    /**
     * Get the list of item ids that should be excluded from the choices based
     * on user's past interactions.
     *
     * @param userId         Id of the user for whom choices are generated
     * @param choiceServedAt Time at which choices are generated for. User's
     *                       past transactions are filtered based on this timestamp as reference.
     * @return Set of item IDs
     */
    public Set<String> getDoNotShowItems(String userId, OffsetDateTime choiceServedAt) {
        Set<String> exclusionSet = new HashSet<>();
        Map<InteractionType,
            List<com.crayondata.maya.data.model.profile.Interaction>> userInteractions
            = interactionService.getInteractionsWithUserId(userId);
        userInteractions.forEach((interactionType, interactions) -> {
            String decayString = environment
                .getProperty(PREFIX_INTERACTION_DECAY + interactionType);
            // don't process if configuration entry not present
            if (decayString != null) {
                int decayDays = Integer.parseInt(decayString);
                if (decayDays < 0) {
                    // negative value - skip all permanently
                    LOGGER.debug("Skipping items permanently for {}", interactionType);
                    List<String> itemIds = interactions.stream().map(Interaction::getItemId)
                        .collect(Collectors.toList());
                    LOGGER.debug("Items {} filtered for {}", itemIds, interactionType);
                    exclusionSet.addAll(itemIds);
                } else {
                    LOGGER.debug("Skipping items from past {} days for {}", decayDays,
                        interactionType);
                    OffsetDateTime minusDays = choiceServedAt.minusDays(decayDays);
                    List<String> itemIds = interactions.stream()
                        .filter(interaction -> minusDays.isBefore(interaction.getTimestamp()))
                        .map(Interaction::getItemId).collect(Collectors.toList());
                    LOGGER.debug("Items {} filtered for {}", itemIds, interactionType);
                    exclusionSet.addAll(itemIds);
                }
            }
        });
        return exclusionSet;
    }

    /**
     * Filters out the interacted items by the user from the given list of choices.
     * For each interaction, the condition of removal is dependent on time elapsed from the
     * interaction time and the choices delivery time.
     *
     * @param scoredItems Choices list
     * @param userId Id of the user
     * @param choiceServedAt Choices serving timestamp
     * @return Filtered list of choices
     */
    // Filter Interacted/DoNotShow Items
    public List<ScoredItem> filterInteractedItems(List<ScoredItem> scoredItems, String userId,
        OffsetDateTime choiceServedAt) {
        Set<String> doNotShowItemIds = getDoNotShowItems(userId, choiceServedAt);
        LOGGER.debug("Choices before DoNotShow filter {}", scoredItems.size());
        List<ScoredItem> filteredScoredItems = scoredItems.stream()
            .filter(scoredItem -> !doNotShowItemIds.contains(scoredItem.getItemId()))
            .collect(Collectors.toList());
        LOGGER.debug("Choices after DoNotShow filter {}", filteredScoredItems.size());
        return filteredScoredItems;
    }

    /**
     * Filters out the interacted items from the given list identified by the matching ids.
     *
     * @param scoredItems List from which elements are to be removed
     * @param itemsToBeFilteredOut Elements to be removed
     * @return Filtered list of elements
     */
    public List<ScoredItem> filterInteractedItems(List<ScoredItem> scoredItems,
        Collection<String> itemsToBeFilteredOut) {
        LOGGER.debug("Choices before DoNotShow filter {}", scoredItems.size());
        List<ScoredItem> filteredScoredItems = scoredItems.stream()
            .filter(scoredItem -> !itemsToBeFilteredOut.contains(scoredItem.getItemId()))
            .collect(Collectors.toList());
        LOGGER.debug("Choices after DoNotShow filter {}", filteredScoredItems.size());
        return filteredScoredItems;
    }

    /**
     * Filters out the interacted items from the given list identified by the matching ids.
     *
     * @param items List from which elements are to be removed
     * @param itemsToBeFilteredOut Elements to be removed
     * @return Filtered list of elements
     */
    public List<Item> filterDislikedItems(List<Item> items,
        Collection<String> itemsToBeFilteredOut) {
        if (itemsToBeFilteredOut == null || itemsToBeFilteredOut.isEmpty()) {
            return items;
        }
        LOGGER.debug("Choices before DoNotShow filter {}", items.size());
        List<Item> filteredScoredItems = items.stream()
            .filter(item -> !itemsToBeFilteredOut.contains(item.getId()))
            .collect(Collectors.toList());
        LOGGER.debug("Choices after DoNotShow filter {}", filteredScoredItems.size());
        return filteredScoredItems;
    }

    /**
     * Filter merchants that have expired offers. If a merchant does not have any valid offers,
     * then it may be filtered too.
     *
     * @param items           The set of items to filter on
     * @param servedAt        Time when the recommendations are requested for, used
     *                        to filter expired offers.
     * @param filterNonOffers Whether to filter out choices that have no valid offers.
     * @return
     */
    public List<Item> filterExpiredOffers(List<Item> items, OffsetDateTime servedAt,
        boolean filterNonOffers) {
        LOGGER.debug("Choices before ExpiredOffers filter {}", items.size());
        List<Item> filteredItems = new ArrayList<>();
        for (Item item : items) {
            List<OfferDetails> offers = item.getOffers();
            if (offers == null) {
                if (!filterNonOffers) {
                    filteredItems.add(item);
                }
                continue;
            }
            List<OfferDetails> filteredOffers = new ArrayList<>();
            Set<String> filteredLocations = new HashSet<>();
            for (OfferDetails offer : offers) {
                if (offer.isValid(servedAt)) {
                    filteredOffers.add(offer);
                    filteredLocations.addAll(offer.getLocations());
                }
            }
            if (!filterNonOffers || !filteredOffers.isEmpty()) {
                item.setOffers(filteredOffers);
                item.getLocations().removeIf(x -> !filteredLocations.contains(x.getId()));
                filteredItems.add(item);
            }
        }
        LOGGER.debug("Choices after ExpiredOffers filter {}", filteredItems.size());
        return filteredItems;
    }

    /**
     * Gets the items that are either close to the given geo coordinates or in the city.
     *
     * <p>If both geo coordinates and city parameters are provided, search is made only with geo
     * codes.</p>
     *
     * <p>The distance is provided via configuration only.</p>
     *
     * @param geoCode  Geo coordinates for search
     * @param city City in which the offer should be applicable
     * @return List of {@link Item}s matching the criteria.
     */
    public List<Item> getItemsBasedOnGeoOrCity(GeoCode geoCode, String city, String lang) {
        if (geoCode != null) {
            LOGGER.info("Getting items based on GeoCode: {}", geoCode);
            int defaultDistance = defaultIfNull(choiceApiConfig.getGlobalConfig().getDistanceKm(),
                DEFAULT_DISTANCE_IN_KM);
            return itemService.getItemsNearBy(geoCode, defaultDistance, lang);
        }

        if (city != null) {
            LOGGER.info("Getting items based on City: {}", city);
            return itemService.getItemsInCity(city, lang);
        }

        LOGGER.info("Returning empty list as both GeoCode & City are not provided");
        return new ArrayList<>();
    }

    /**
     * Get language specific items based on location parameter provided in request.
     *
     * @param location Location give in request
     * @param lang Language selected by the user
     * @return List of {@link Item} matching the criteria
     */
    public List<Item> getItemsBasedOnLocation(Location location, String lang) {
        if (location == null) {
            return null;
        }
        GeoCode geoCode = location.getGeocode();
        if (geoCode != null) {
            LOGGER.info("Getting items based on GeoCode: {}", geoCode);
            int defaultDistance = defaultIfNull(choiceApiConfig.getGlobalConfig()
                .getDistanceKm(), DEFAULT_DISTANCE_IN_KM);
            return itemService.getItemsNearBy(geoCode, defaultDistance, lang);
        }

        String city = location.getCity();
        String country = location.getCountry();
        if (city != null && country != null) {
            LOGGER.info("Getting items based on City : {} in Country {}", city, country);
            return itemService.getItemsBasedOnCityAndCountry(city, country, lang);
        }

        if (city != null) {
            LOGGER.info("Getting items based on City: {}", city);
            return itemService.getItemsInCity(city, lang);
        }

        if (country != null) {
            LOGGER.info("Getting items based on Country: {}", country);
            return itemService.getItemsInCountry(country, lang);
        }
        return null;
    }

    /**
     * Gets the items that are either close to the given geo coordinates or in the city or has an
     * offer that is applicable online.
     *
     * <p>If both geo coordinates and city parameters are provided, search is made only with geo
     * codes.</p>
     *
     * <p>The distance is provided via configuration only.</p>
     *
     * @param geoCode Geo coordinates for search
     * @param city City in which the offer should be applicable
     * @return List of {@link Item}s matching the criteria
     */
    public List<Item> getItemsNearbyOrWithOnlineOffer(GeoCode geoCode, String city) {
        List<Item> items = new ArrayList<>();
        if (geoCode != null) {
            LOGGER.info("Getting items based on GeoCode: {}", geoCode);
            int defaultDistance = defaultIfNull(choiceApiConfig.getGlobalConfig().getDistanceKm(),
                DEFAULT_DISTANCE_IN_KM);
            items.addAll(itemService.getItemsNearBy(geoCode, defaultDistance));
        } else if (city != null) {
            LOGGER.info("Getting items based on City: {}", city);
            items.addAll(itemService.getItemsInCity(city));
        }
        LOGGER.info("Got {} items based on geoCode: {} or city: {}", items.size(), geoCode, city);

        List<Item> itemsWithOnlineOffers = itemService.getAllItemsWithOnlineOffers();
        LOGGER.info("Got {} online offers", itemsWithOnlineOffers.size());
        if (!itemsWithOnlineOffers.isEmpty()) {
            Set<String> nearbyItemIds = items.stream().map(Item::getId).collect(Collectors.toSet());
            itemsWithOnlineOffers.stream()
                .filter(item -> !nearbyItemIds.contains(item.getId()))
                .forEach(item -> items.add(item));
        }
        LOGGER.info("Items size after adding items with online offers: {}", items.size());
        return items;
    }

    /**
     * Creates a predicate to enable filtering items by tags. Supports filtering
     * by multiple attributes and values using AND and OR conditions
     * respectively.
     *
     * @param tagsFilters Map of attributes and their values to be filtered on
     * @return A predicate which can be used to filter items matching the
     *     tagsFilters.
     */
    public Predicate<Item> filterByTags(Map<String, List<String>> tagsFilters) {
        Predicate<Item> superPredicate = item -> (item.getFilterTags() != null && !item
            .getFilterTags().isEmpty());
        for (Map.Entry<String, List<String>> entry : tagsFilters.entrySet()) {
            String key = entry.getKey();
            Predicate<Item> subPredicate = item -> false;
            for (String value : entry.getValue()) {
                // tags are in key-value format in data
                subPredicate = subPredicate.or(tagContains(key + "-" + value));
            }
            superPredicate = superPredicate.and(subPredicate);
        }
        return superPredicate;
    }

    /**
     * Get items based on location and category for given language.
     *
     * @param location Location selected by user
     * @param category category selected by user
     * @param lang language selected by user
     * @return
     */
    public List<Item> getItemsByLocAndCategoryForLang(Location location,
        String category, String lang) {

        if (location == null && category == null) {
            LOGGER.info("GeoCode, city or country and category not found, hence "
                + "returning without processing");
            return null;
        }

        if (location == null && category != null) {
            return itemService.getAllItemsByCategory(category, lang);
        }

        String city = location.getCity();
        String country = location.getCountry();
        GeoCode geoCode = location.getGeocode();
        if (geoCode != null && category != null) {
            List<Item> itemsBasedOnGeo = getItemsBasedOnGeoOrCity(geoCode, null, lang);
            if (itemsBasedOnGeo != null) {
                List<Item> items = itemsBasedOnGeo.stream()
                    .filter(x -> x.getCategory().equalsIgnoreCase(category))
                    .collect(Collectors.toList());
                return items;
            }
        }

        if ((city != null || country != null) && category != null) {
            return itemService.getItemsByCategoryAndLocation(category, location, lang);
        }

        if (category == null && (geoCode != null || city != null || country != null)) {
            return getItemsBasedOnLocation(location, lang);
        }

        return null;
    }

    private static Predicate<Item> tagContains(String tag) {
        return p -> p.getFilterTags().contains(tag);
    }
}
