/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.maya.choice.service;

import static com.crayondata.maya.data.utils.ObjectUtils.defaultIfNull;

import com.crayondata.maya.data.access.util.DBConstants;
import com.crayondata.maya.data.list.DataListService;
import com.crayondata.maya.data.model.config.ChoiceApiConfig;
import com.crayondata.maya.data.model.profile.UserProfile;
import com.crayondata.maya.data.profile.UserProfileService;
import com.crayondata.maya.model.api.LocationResolverResponse;
import com.crayondata.maya.model.common.GeoCode;
import com.crayondata.maya.model.common.Location;
import com.crayondata.maya.model.enums.Languages;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ArrayNode;

//import io.swagger.util.Json;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;
import javax.annotation.PostConstruct;

import javax.servlet.http.HttpServletRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.MultiValueMap;

/**
 * To resolve geo-location details from users' request, profile or IP based on
 * priority and fallback scenarios.
 *
 * @author somin
 */
@Service
public class LocationResolutionService {

    private static final String CITIES_LIST_ID = "cities";

    private static final String IPADDRESS_REGEX =
        "^([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\." + "([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\."
        + "([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\." + "([01]?\\d\\d?|2[0-4]\\d|25[0-5])$";

    private static final Logger LOGGER = LoggerFactory.getLogger(LocationResolutionService.class);

    @Value("${ip2geo.enabled:false}")
    private boolean resolveIPtoGeo;

    @Value("${geoResolutionOrder}")
    private String[] geoResolutionOrder;

    @Value("${geoLocationPriority}")
    private String[] geoLocationPriority;

    @Value("${profileLocationPriority}")
    private String[] profileLocationPriority;

    @Value("${toprated.return.location.results}")
    private boolean constraintLocationGlobal;

    @Value("${constraint.location.city}")
    private boolean constraintCity;

    @Value("${constraint.location.html5}")
    private boolean constraintGeoCode;

    @Value("${constraint.location.geoip}")
    private boolean constraintGeoIp;

    @Value("${constraint.location.userprofile}")
    private boolean constraintUserProfile;

    @Value("${ip.extraction.headerslist:}")
    private String[] ipExtractionHeaders;

    @Autowired
    private GeoIPService geoIpService;

    @Autowired
    private UserProfileService profileService;

    @Autowired
    private DataListService dataListService;

    @Autowired
    private ChoiceApiConfig choiceApiConfig;

    private Pattern ipAddressPattern;

    public LocationResolutionService() {
    }

    @PostConstruct
    public void init() {
        ipAddressPattern = Pattern.compile(IPADDRESS_REGEX);
    }

    /**
     * Resolve geo-location details from users' request, profile or IP based on
     * priority and fallback scenarios.
     *
     * @param userId          ID of the user
     * @param requestLocation Location as received in API request
     * @param requestIP       IP of the HTTP client from which request originated
     * @return
     */
    public LocationResolverResponse resolve(String userId, Location requestLocation,
        String requestIP) {
        Map<String, Boolean> locationConstraints = choiceApiConfig.getGlobalConfig()
            .getLocationConstraint();
        Map<String, Boolean> flags = new HashMap<>();
        String city = null;
        String ip = null;
        GeoCode geoCode = null;
        if (requestLocation != null) {
            city = requestLocation.getCity();
            geoCode = requestLocation.getGeocode();
            ip = requestLocation.getIp();
        }
        if (ip == null && requestIP != null) {
            /* For now, if both are enabled header IP has lower priority
               However, both would not be supported in real scenario, based on config
             */
            ip = requestIP;
            LOGGER.debug("Using IP extracted from headers {} for user: {}", ip, userId);
        }
        boolean cityIsValid = isValidCity(city);
        boolean geoCodeIsValid = isValidGeoCode(geoCode);

        if (!cityIsValid && !geoCodeIsValid) {
            // request location not present, resolve location based on priority
            for (String resolutionType : geoResolutionOrder) {
                if (resolutionType.equals("IP")) {
                    Location resolvedFromIP = resolveFromIP(ip);
                    if (resolvedFromIP != null) {
                        boolean constraintGeoIp = locationConstraints != null
                            ? locationConstraints.get("geoip") : this.constraintGeoIp;
                        flags.put("locationConstraint", constraintGeoIp);
                        return createResponse(resolvedFromIP, flags, "IP");
                    }
                } else if (resolutionType.equals("PROFILE")) {
                    Location resolvedFromProfile = resolveFromProfile(userId);
                    if (resolvedFromProfile != null) {
                        boolean constraintUserProfile = locationConstraints != null
                            ? locationConstraints.get("userprofile") : this.constraintUserProfile;
                        flags.put("locationConstraint", constraintUserProfile);
                        return createResponse(resolvedFromProfile, flags, "PROFILE");
                    }
                }
            }
        } else {
            if (cityIsValid && geoCodeIsValid) {
                requestLocation = createLocationWithCityXorGeoCode(requestLocation);
            }
            if (isValidCity(city)) {
                boolean constraintCity = locationConstraints != null
                    ? locationConstraints.get("city") : this.constraintCity;
                flags.put("locationConstraint", constraintCity);
            } else {
                boolean constraintGeoCode = locationConstraints != null
                    ? locationConstraints.get("html5") : this.constraintGeoCode;
                flags.put("locationConstraint", constraintGeoCode);
            }
            return createResponse(requestLocation, flags, "REQUEST");
        }
        // can't resolve location :-(
        boolean constraintLocationGlobal = defaultIfNull(choiceApiConfig.getGlobalConfig()
            .getTopratedReturnLocationResults(), this.constraintLocationGlobal);
        flags.put("locationConstraint", constraintLocationGlobal);
        return createResponse(null, flags, "DEFAULT");
    }

    private Location resolveFromProfile(String userId) {
        // user profile -> Geo resolution
        if (userId == null) {
            return null;
        }
        UserProfile userProfile = profileService.getUserProfile(userId);
        if (userProfile != null) {
            List<String> preferredCities = userProfile.getPreferredCities();
            List<GeoCode> preferredLocations = userProfile.getPreferredLocations();
            // select either city or geocode based on priority
            for (String locationType : profileLocationPriority) {
                if (locationType.equals("CITY") && preferredCities != null && !preferredCities
                    .isEmpty()) {
                    String preferredCity = preferredCities.get(0);
                    if (isValidCity(preferredCity)) {
                        return new Location(null, null, preferredCity, null);
                    }
                } else if (locationType.equals("GEOCODE") && preferredLocations != null
                    && !preferredLocations.isEmpty()) {
                    GeoCode preferredLocation = preferredLocations.get(0);
                    if (isValidGeoCode(preferredLocation)) {
                        return new Location(null, null, null, preferredLocation);
                    }
                }
            }
        }
        return null;
    }

    private boolean isValidCity(String cityName) {
        return !(cityName == null || cityName.trim().isEmpty());
    }

    private boolean isValidGeoCode(GeoCode geoCode) {
        return !(geoCode == null || geoCode.getLatitude() == null || geoCode.getLongitude() == null
            || geoCode.getLatitude().trim().isEmpty() || geoCode.getLongitude().trim()
            .isEmpty());
    }

    private Location createLocationWithCityXorGeoCode(Location location) {
        // send either city or geocode based on priority
        for (String locationType : geoLocationPriority) {
            if (locationType.equals("CITY") && isValidCity(location.getCity())) {
                return new Location(null, null, location.getCity(), null);
            } else if (locationType.equals("GEOCODE") && isValidGeoCode(location.getGeocode())) {
                return new Location(null, null, null, location.getGeocode());
            }
        }
        return location;
    }

    private LocationResolverResponse createResponse(Location location, Map<String, Boolean> flags,
        String explanator) {
        return new LocationResolverResponse(location, flags, explanator);
    }

    /**
     * Extract IP address from the request headers.
     *
     * @param headers HTTP request headers
     * @return A string representing the IP address extracted from the headers.
     *     Returns null if no such IP address can be extracted from the headers
     */
    public String extractIPFromHeaders(MultiValueMap<String, String> headers) {
        if (ipExtractionHeaders == null || ipExtractionHeaders.length == 0) {
            LOGGER.debug("IP extraction from headers is disabled by config.");
            return null;
        }
        for (String ipExtractionHeader : ipExtractionHeaders) {
            List<String> values = headers.get(ipExtractionHeader);
            if (values != null && !values.isEmpty()) {
                // IP address can come either as single value, or concatenated string.
                // So only first is enough.
                String ipValue = values.get(0);
                String ip = validateHeaderIP(ipValue);
                if (ip != null) {
                    return ip;
                }
            }
        }
        return null;
    }

    /**
     * Extract IP address from the request.
     *
     * @param request HTTP request
     * @return A string representing the IP address extracted from the headers.
     *     Returns null if no such IP address can be extracted from the headers
     */
    public String extractIPFromRequest(HttpServletRequest request) {
        String ip = null;
        if (request != null) {
            ip = request.getRemoteAddr();
            if (ip == null && ipExtractionHeaders != null) {
                for (String ipExtractionHeader : ipExtractionHeaders) {
                    Enumeration headerValues = request.getHeaders(ipExtractionHeader);
                    while (headerValues.hasMoreElements()) {
                        ip = (String) headerValues.nextElement();
                        break;
                    }
                }
            }
            LOGGER.info("Resolved IP Address from request : {}", ip);
        }
        return ip;
    }

    /**
     * Resolves location from IP present in headers.
     *
     * @param ip IP present in header
     * @return Resolved location
     */
    public Location resolveFromIP(String ip) {
        Location resolvedLocation = geoIpService.getLocation(ip);
        if (resolvedLocation != null) {
            GeoCode geocode = resolvedLocation.getGeocode();
            String country = resolvedLocation.getCountry();
            String city = resolvedLocation.getCity();
            resolvedLocation = new Location(null, country, city, geocode);
        }
        return resolvedLocation;
    }

    private String validateHeaderIP(String ipString) {
        if (ipString != null) {
            ipString = ipString.trim();
            boolean validIP = ipAddressPattern.matcher(ipString).matches();
            if (validIP) {
                return ipString;
            }
            // string may be a list of IP addresses separated by ", "
            if (ipString.contains(", ")) {
                // then we need only first IP
                ipString = ipString.split(", ", 2)[0];
                validIP = ipAddressPattern.matcher(ipString).matches();
                if (validIP) {
                    return ipString;
                }
            }
        }
        return null;
    }

}
