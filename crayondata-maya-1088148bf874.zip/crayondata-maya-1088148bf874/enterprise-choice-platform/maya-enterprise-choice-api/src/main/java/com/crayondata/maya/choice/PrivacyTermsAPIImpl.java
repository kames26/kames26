/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.maya.choice;

import com.crayondata.maya.data.privacyterms.PrivacyTermsService;
import com.crayondata.maya.model.api.ApiResponse;
import com.crayondata.maya.model.api.PrivacyTermsResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class PrivacyTermsAPIImpl implements PrivacyTermsAPI {

    private static final Logger LOGGER = LoggerFactory.getLogger(UserAPIImpl.class);

    @Autowired
    public PrivacyTermsService privacyTermsService;

    @Override
    public ApiResponse<PrivacyTermsResponse> getPrivacyTerms(String type) {
        if (type == null || type.trim().isEmpty()) {
            LOGGER.info("type not present in request");
            return new ApiResponse<>(ApiResponse.Status.BAD_REQUEST,"Invalid input");
        }
        PrivacyTermsResponse privacyTerms = privacyTermsService.getPrivacyTerms(type);
        if (privacyTerms == null) {
            return new ApiResponse<>(ApiResponse.Status.BAD_REQUEST,"Invalid input");
        }
        return new ApiResponse<>(privacyTerms);
    }
}
