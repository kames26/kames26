/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.maya.choice.blender;

import com.crayondata.maya.choice.recommender.factory.RecommenderFactory;
import com.crayondata.maya.data.entity.ItemService;
import com.crayondata.maya.data.model.entity.Item;
import com.crayondata.maya.data.model.entity.ScoredItem;
import com.crayondata.maya.data.model.recommendation.BlenderType;
import com.crayondata.maya.data.model.recommendation.RecommendRequest;
import com.crayondata.maya.data.model.recommendation.RecommenderType;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * Blends the recommendations by interleaving recommendations from each recommender
 * based on configuration. The final mix should conform with the configured ratio unless there is
 * a shortage of recommendations from one of the recommenders.
 *
 * @author somin
 */
@Service
public class InterleavedBlender implements IBlender {

    private static final Logger LOGGER = LoggerFactory.getLogger(InterleavedBlender.class);

    private RecommenderFactory recommenderFactory;

    private ItemService itemService;

    @Autowired
    public InterleavedBlender(RecommenderFactory recommenderFactory, ItemService itemService) {
        this.recommenderFactory = recommenderFactory;
        this.itemService = itemService;
    }

    @Override
    public BlenderType getType() {
        return BlenderType.INTERLEAVED;
    }

    @Override
    public List<ScoredItem> blend(Map<RecommenderType, List<ScoredItem>> recommendations,
        List<Map<String, Object>> blendingConfig,
        RecommendRequest recommendRequest) {
        long startTime = System.nanoTime();
        //get ratio from config
        Map<RecommenderType, Integer> recommenderRatio = parseConfig(blendingConfig);

        int recReqCount = recommendRequest.getCount();
        List<ScoredItem> resultRecommendations = mergeRecommendations(recommendations,
            recommenderRatio);
        if (resultRecommendations.size() < recReqCount) {
            // do padding
            boolean padResults = false;
            if (resultRecommendations.isEmpty()) {
                // since similarity is empty, top rated may be used for padding with
                // unconstrained results
                LOGGER.info("Primary recommenders gave 0 recommendations, so enabling padding");
                padResults = true;
            } else {
                List<String> resultItemIds = resultRecommendations.stream()
                    .map(ScoredItem::getItemId).collect(Collectors.toList());
                List<Item> resultItems = itemService.getItems(resultItemIds);
                List<Item> offlineItems = resultItems.stream().filter(item -> !item.getIsOnline())
                    .collect(Collectors.toList());
                if (offlineItems.isEmpty()) {
                    // since offline offers is empty, top rated may be used for padding with
                    // unconstrainted results
                    LOGGER.info(
                        "Primary recommenders gave 0 offline recommendations, so enabling padding");
                    padResults = true;
                }
            }
            //call toprated
            recommendRequest.getFlags().put("padResults", padResults);
            List<ScoredItem> paddingRecommendations = recommenderFactory
                .getRecommender(RecommenderType.TOPRATED).recommend(recommendRequest);
            LOGGER.info("Got {} recommendations from TopRated Recommender",
                paddingRecommendations.size());
            resultRecommendations = mergePaddingRecommendations(resultRecommendations,
                paddingRecommendations);
        }
        LOGGER.info("Blending using {} took {} ms", getType(),
            (System.nanoTime() - startTime) / 1000000);
        return resultRecommendations;
    }

    private Map<RecommenderType, Integer> parseConfig(List<Map<String, Object>> blendingConfig) {
        Map<RecommenderType, Integer> recommenderRatio = new LinkedHashMap<>();
        blendingConfig.forEach(config -> {
            RecommenderType recommender = RecommenderType.valueOf(
                (String) config.get("recommender"));
            Integer count = (Integer) config.get("count");
            recommenderRatio.put(recommender, count);
        });
        LOGGER.info("Using recommender ratio {}", recommenderRatio);
        return recommenderRatio;
    }

    private List<ScoredItem> mergeRecommendations(Map<RecommenderType,
        List<ScoredItem>> recommendations, Map<RecommenderType, Integer> recommenderRatio) {
        List<ScoredItem> finalRecommendations = new ArrayList<>();
        HashMap<String, ScoredItem> processedItems = new HashMap<>();
        boolean recommendationsExhausted = false;

        while (!recommendationsExhausted) {
            recommendationsExhausted = true;
            for (Map.Entry<RecommenderType, Integer> entry : recommenderRatio.entrySet()) {
                RecommenderType k = entry.getKey();
                Integer v = entry.getValue();
                List<ScoredItem> scoredItems = recommendations.get(k);
                if (!scoredItems.isEmpty()) {
                    int i = 0;
                    while (i < v && !scoredItems.isEmpty()) {
                        ScoredItem item = scoredItems.remove(0);
                        if (processedItems.containsKey(item.getItemId())) {
                            // common item, merge the scores and explanation
                            ScoredItem scoredItem = processedItems.get(item.getItemId());
                            scoredItem.mergeScores(item);
                        } else {
                            i++;
                            processedItems.put(item.getItemId(), item);
                            finalRecommendations.add(item);
                        }
                    }
                }
                if (!scoredItems.isEmpty()) {
                    recommendationsExhausted = false;
                }
            }
        }
        return finalRecommendations;
    }

    private List<ScoredItem> mergePaddingRecommendations(List<ScoredItem> primaryRecommendations,
        List<ScoredItem> paddingRecommendations) {
        List<ScoredItem> mergedRecommendations = new ArrayList<>();
        Map<String, ScoredItem> itemMap = new HashMap<>();
        for (ScoredItem s : primaryRecommendations) {
            itemMap.put(s.getItemId(), s);
            mergedRecommendations.add(s);
        }
        for (int i = 0; i < paddingRecommendations.size(); i++) {
            ScoredItem s = paddingRecommendations.get(i);
            String itemId = s.getItemId();
            if (!itemMap.containsKey(itemId)) {
                mergedRecommendations.add(s);
            }
        }
        return mergedRecommendations;
    }
}
