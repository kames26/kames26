/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.maya.choice.recommender.list.impl;

import com.crayondata.maya.choice.recommender.list.ChoiceListRecommender;
import com.crayondata.maya.choice.service.BaseScoreGenerator;
import com.crayondata.maya.choice.service.ChoiceItemScoreGenerator;
import com.crayondata.maya.data.model.entity.Item;
import com.crayondata.maya.data.model.entity.OfferDetails;
import com.crayondata.maya.data.model.recommendation.ChoiceListRecommendRequest;
import com.crayondata.maya.model.enums.ChoiceListType;
import com.crayondata.maya.model.enums.Languages;
import com.crayondata.maya.model.rest.ChoiceListRequest;
import com.crayondata.maya.model.rest.ChoiceListRequest;
import java.time.OffsetDateTime;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class ExpiringSoonOffersList implements ChoiceListRecommender {

    @Value("${expiring.offer.validity.days}")
    private int days;

    @Autowired
    private BaseScoreGenerator itemScoreGenerator;

    @Override
    public List<Item> generateChoices(ChoiceListRecommendRequest request) {
        ChoiceListRequest choiceRequest = request.getChoiceRequest();
        Map<String, Item> items = getFilteredChoices(ChoiceListType.CATEGORY_BASED, request,
            choiceRequest.getLang());
        List<Item> expiringSoonOfferItems = getExpiringSoonOfferList(items);
        List<Item> sortedItems = sortChoicesBasedOnScore(ChoiceListType.CATEGORY_BASED,
            expiringSoonOfferItems, request.getListCategoryChoices(),
            request.getUserInteractions(), request.getSimilarItems());

        if (isUserChoicePresent(ChoiceListType.CATEGORY_BASED, request)
            && sortedItems.isEmpty()) {
            items = request.getLangToFilteredItems().get(Languages
                .valueOf(choiceRequest.getLang()));
            sortedItems = getExpiringSoonOfferList(items);
        }
        request.setChoiceCount(ChoiceListType.EXPIRING_SOON.name(), sortedItems.size());
        int limit = Math.min(request.getChoiceRequest().getChoiceCount(), sortedItems.size());
        List<Item> itemsWithLimit =  sortedItems.stream().limit(limit).collect(Collectors.toList());
        return itemsWithLimit;
    }

    @Override
    public ChoiceListType getListType() {
        return ChoiceListType.EXPIRING_SOON;
    }

    @Override
    public ChoiceItemScoreGenerator getItemScoreGenerator() {
        return itemScoreGenerator;
    }

    private List<Item> getExpiringSoonOfferList(Map<String, Item> items) {
        List<Item> clonedItems = items.values().stream().map(item -> item.clone())
            .collect(Collectors.toList());

        OffsetDateTime currentDate = OffsetDateTime.now();
        Predicate<OfferDetails> isOfferExpiringSoon = offer -> (offer.isValid(currentDate))
            && offer.isExpiringSoon(currentDate, days);

        for (Item item : clonedItems) {
            List<OfferDetails> expiringSoonOffers = item.getOffers().stream()
                .filter(isOfferExpiringSoon).collect(Collectors.toList());
            item.setOffers(expiringSoonOffers);
        }

        List<Item> expiringSoonOfferItems = clonedItems.stream().filter(x -> x.getOffers() != null
            && !x.getOffers().isEmpty()).collect(Collectors.toList());

        expiringSoonOfferItems.stream().forEach(item -> item.getOffers()
            .stream().sorted(Comparator.comparing(offer -> offer
            .getDiffBtwnDates(currentDate,
            offer.getValidTo()))));
        return expiringSoonOfferItems;
    }
}
