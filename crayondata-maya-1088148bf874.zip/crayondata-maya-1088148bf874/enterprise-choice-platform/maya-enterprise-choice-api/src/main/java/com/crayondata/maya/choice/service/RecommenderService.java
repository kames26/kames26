/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.maya.choice.service;

import static com.crayondata.maya.data.utils.ObjectUtils.defaultIfNull;

import com.crayondata.maya.choice.blender.IBlender;
import com.crayondata.maya.choice.blender.factory.BlenderFactory;
import com.crayondata.maya.choice.recommender.factory.RecommenderFactory;
import com.crayondata.maya.choice.utils.Constants;
import com.crayondata.maya.data.access.util.JsonUtils;
import com.crayondata.maya.data.model.config.ChoiceApiConfig;
import com.crayondata.maya.data.model.config.recommender.RecommenderSegmentConfig;
import com.crayondata.maya.data.model.entity.Item;
import com.crayondata.maya.data.model.entity.ScoredItem;
import com.crayondata.maya.data.model.profile.Interaction;
import com.crayondata.maya.data.model.profile.UserProfile;
import com.crayondata.maya.data.model.recommendation.BlenderType;
import com.crayondata.maya.data.model.recommendation.RecommendRequest;
import com.crayondata.maya.data.model.recommendation.RecommenderType;
import com.crayondata.maya.data.profile.InteractionService;
import com.crayondata.maya.data.profile.UserProfileService;
import com.crayondata.maya.model.common.GeoCode;
import com.crayondata.maya.model.enums.InteractionType;
import com.crayondata.maya.model.enums.UserType;
import java.time.OffsetDateTime;
import java.util.AbstractMap.SimpleEntry;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class RecommenderService {

    private static final Logger LOGGER = LoggerFactory.getLogger(RecommenderService.class);

    @Autowired
    private RecommenderFactory recommenderFactory;

    @Autowired
    private BlenderFactory blenderFactory;

    @Autowired
    private InteractionService interactionService;

    @Autowired
    private FilterService filterService;

    @Autowired
    private UserProfileService userProfileService;

    @Autowired
    private ChoiceApiConfig choiceApiConfig;

    @Autowired
    private UserSegmentationService userSegmentationService;

    @Value("${testcontrol.enable:false}")
    private boolean isTestControlEnabled;

    @Value("${blender.offerRatio:4:2}")
    private String offerRatio;

    @Value("${distance.normalization}")
    private boolean normalizeScoreByDistance;

    @Autowired
    private JsonUtils jsonUtils;

    /**
     * Generate recommendations / choices based on the given request.
     *
     * @param recommendRequest a {@link RecommendRequest} object, not <tt>null</tt>
     * @return List of choices
     */
    public List<ScoredItem> recommend(RecommendRequest recommendRequest) {
        long startTime = System.nanoTime();
        List<ScoredItem> returnList;
        returnList = recommendTopLevel(recommendRequest);
        LOGGER.debug("TimeTaken : recommendTopLevel took {} ms",
            (System.nanoTime() - startTime) / 1000000);
        LOGGER.info("Got {} choices", returnList.size());
        return returnList;
    }

    /**
     * Generate recommendations / choices based on the given request.
     *
     * @param recommendRequest a {@link RecommendRequest} object, not <tt>null</tt>
     * @return List of choices
     */
    public List<ScoredItem> recommendTopLevel(RecommendRequest recommendRequest) {
        UserProfile userProfile = recommendRequest.getUserProfile();
        LOGGER.info("User Id: {}", userProfile.getId());
        LOGGER.info("User known: {}", userProfile.isKnownUser());
        LOGGER.info("User segment: {}", userProfile.getSegment());

        Integer userSegment = userProfile.getSegment();
        RecommenderSegmentConfig segmentConfig;
        if (userSegment != null && userSegmentationService.isSegmentEnabled(userSegment)) {
            segmentConfig = choiceApiConfig.getRecommenderSegmentConfigs().get(userSegment);
            LOGGER.info("User {} assigned to segment {}",
                userProfile.getId(), segmentConfig.getSegmentNo());
        } else {
            // TODO handle segmenting anonymous users
            // get the default segment
            int defaultSegment = UserSegmentationService.getDefaultSegment();
            LOGGER.info("Cannot determine segment for user {}, defaulting to segment {}",
                userProfile.getId(), defaultSegment);
            segmentConfig = choiceApiConfig.getRecommenderSegmentConfigs().get(defaultSegment);
        }

        // override non-offer recommendation config from segment config
        if (segmentConfig.getNonOfferRecommendation() != null
            && segmentConfig.getNonOfferRecommendation().isEnabled() != null) {
            boolean filterNonOffers = !segmentConfig.getNonOfferRecommendation().isEnabled();
            LOGGER.debug("Setting {} to {} as per segment config", Constants.FLAG_FILTER_NON_OFFERS,
                filterNonOffers);
            recommendRequest.getFlags().put(Constants.FLAG_FILTER_NON_OFFERS,
                filterNonOffers);
        }

        // We might need this only for few cases. But retrieve them anyway.
        // Refactor later (Sundar: 9-1-2017)
        // @formatter:off
        Map<InteractionType, List<Interaction>> userInteractionMap = interactionService
            .getInteractionsWithUserId(userProfileService.getUseableUserId(userProfile));
        final List<Interaction> userInteractions = userInteractionMap.values().stream()
            .flatMap(Collection::stream).collect(Collectors.toList());
        // @formatter:on

        // Process only Type 1 user, others are generic cases.
        // Type 1: User is known & Campaign Id is given
        if (userProfile.isKnownUser() && recommendRequest.getCampaignId() != null) {
            // TODO: Check if the User's location is the same as that of Campaign's
            LOGGER.info(
                "Calling Campaign Recommender for known user id: {} with campaign-id: {}",
                userProfile.getKnownUserId(), recommendRequest.getCampaignId());
            return recommenderFactory.getRecommender(
                RecommenderType.CAMPAIGN).recommend(recommendRequest);
        }

        // Prefetch superset of recommendable items
        List<Item> nearbyItemIds = getFilteredItemsByLocCategoryActiveDate(recommendRequest);
        recommendRequest.setFilteredItems(nearbyItemIds);

        // Special treatment for control users
        UserType userType = userProfile.getUserType();
        if (isTestControlEnabled && userType != null && userType.equals(UserType.CONTROL)) {
            LOGGER.info("Calling Random Recommender for control user id: {}", userProfile.getId());
            return recommenderFactory.getRecommender(
                RecommenderType.RANDOM).recommend(recommendRequest);
        }

        // We are not differentiating between known and anonymous users at this point
        // User can either be
        // Type 2: Anonymous user without interactions
        // Type 3: Anonymous user with interactions
        // Type 4: Both transactions(since the user is known) & interactions
        // Type 5: Only transactions
        LOGGER.info(
            "Calling primary recommenders with{} interactions for {}known user",
            userInteractions.isEmpty() ? "out" : "", userProfile.isKnownUser() ? "" : "un");
        return callRecommenders(recommendRequest, segmentConfig);
    }

    private List<ScoredItem> blendOfferNonOffers(RecommendRequest recommendRequest,
        List<ScoredItem> resultRecommendations,
        RecommenderSegmentConfig segmentConfig) {
        // no-op if non-offers are already filtered
        if (recommendRequest.getFlags().get(Constants.FLAG_FILTER_NON_OFFERS)) {
            LOGGER.debug("Skipping non-offer blending as per config");
            return resultRecommendations;
        }

        // custom blending logic for offers+choices
        Map<String, Item> allFilteredItemsById = recommendRequest.getFilteredItems().stream()
            .collect(Collectors.toMap(Item::getId, Function.identity()));
        Map<String, List<ScoredItem>> recommendationsByType = resultRecommendations.stream()
            .collect(Collectors.groupingBy(x -> {
                Item item = allFilteredItemsById.get(x.getItemId());
                if (item != null) {
                    if (item.getOffers() == null || item.getOffers().isEmpty()) {
                        return "choice";
                    } else {
                        return "offer";
                    }
                }
                return "unknown";
            }));

        // get ratio from segment config, fallback to global config
        String ratio = null;
        if (segmentConfig.getNonOfferRecommendation() != null) {
            ratio = segmentConfig.getNonOfferRecommendation().getRatio();
            LOGGER.debug("Got offer:non-offer ratio {} from segment config", ratio);
        }
        if (ratio == null) {
            ratio = defaultIfNull(choiceApiConfig.getGlobalConfig().getBlenderOfferRatio(),
                offerRatio);
            LOGGER.debug("Using offer:non-offer ratio {} from global config", ratio);
        }

        resultRecommendations = combineNonOfferRecommendations(
            recommendationsByType.getOrDefault("offer", Collections.emptyList()),
            recommendationsByType.getOrDefault("choice", Collections.emptyList()),
            recommendationsByType.getOrDefault("unknown", Collections.emptyList()), ratio);
        return resultRecommendations;
    }

    private List<ScoredItem> callRecommenders(RecommendRequest recommendRequest,
        RecommenderSegmentConfig segmentConfig) {
        List<RecommenderType> recommenders = segmentConfig.getRecommenders();
        LOGGER.info("Calling recommenders: {}", recommenders);
        setDistanceNormalizationFlag(recommendRequest.getFlags(),
            segmentConfig.isNormalizeScoreByDistance());
        Map<RecommenderType, List<ScoredItem>> initialRecommendations =
            recommenders.stream().map(r -> recommenderFactory.getRecommender(r))
            .map(r -> new SimpleEntry<>(r.getType(), r.recommend(recommendRequest)))
            .collect(Collectors.toMap(SimpleEntry::getKey, SimpleEntry::getValue));

        //consider ratio from config
        BlenderType blenderType = segmentConfig.getBlender();
        IBlender blender = blenderFactory.getBlender(blenderType);
        List<Map<String, Object>> blendingConfig = segmentConfig.getBlendingConfig();
        LOGGER.info("Calling blender: {}", blender.getType());
        List<ScoredItem> finalRecommendations = blender
            .blend(initialRecommendations, blendingConfig, recommendRequest);
        finalRecommendations = blendOfferNonOffers(
            recommendRequest, finalRecommendations, segmentConfig);
        int recReqCount = recommendRequest.getCount();
        if (finalRecommendations.size() > recReqCount) {
            finalRecommendations = finalRecommendations.subList(0, recReqCount);
        }
        return finalRecommendations;
    }

    private void setDistanceNormalizationFlag(Map<String, Boolean> flags,
        Boolean normalizeScoreByDistancePerSegment) {
        boolean normalizeScoreByDistance = defaultIfNull(choiceApiConfig.getGlobalConfig()
            .getDistanceNormalization(), this.normalizeScoreByDistance);
        normalizeScoreByDistance = (normalizeScoreByDistancePerSegment && !normalizeScoreByDistance)
            ? normalizeScoreByDistance : normalizeScoreByDistancePerSegment;
        flags.put(Constants.KEY_NORMALIZE_SCORE, normalizeScoreByDistance);
        LOGGER.info("Normalize score : {}", normalizeScoreByDistance);
    }

    private List<ScoredItem> combineNonOfferRecommendations(List<ScoredItem> offerRecommendations,
        List<ScoredItem> nonOfferRecommendations, List<ScoredItem> otherRecommendations,
        String ratioString) {
        List<ScoredItem> resultantRecommendations = new ArrayList<>();
        String[] ratio = ratioString.split(":");
        int offerRatio = Integer.parseInt(ratio[0]);
        int choiceRatio = Integer.parseInt(ratio[1]);
        int offerSize = offerRecommendations.size();
        int nonOfferSize = nonOfferRecommendations.size();
        int index1 = 0;
        int index2 = 0;
        for (; index1 < offerSize && index2 < nonOfferSize;
            index1 += offerRatio, index2 += choiceRatio) {
            resultantRecommendations.addAll(offerRecommendations.subList(index1,
                index1 + offerRatio > offerSize ? offerSize : index1 + offerRatio));
            resultantRecommendations.addAll(nonOfferRecommendations.subList(index2,
                index2 + choiceRatio > nonOfferSize ? nonOfferSize : index2 + choiceRatio));
        }
        if (index1 < offerSize) {
            resultantRecommendations.addAll(offerRecommendations.subList(index1, offerSize));
        }
        if (index2 < nonOfferSize) {
            resultantRecommendations.addAll(nonOfferRecommendations.subList(index2, nonOfferSize));
        }
        resultantRecommendations.addAll(otherRecommendations);
        return resultantRecommendations;
    }

    List<Item> getFilteredItemsByLocCategoryActiveDate(RecommendRequest recommendRequest) {
        // TODO Review and fix below Geo filter implementation - Somin
        GeoCode choiceLocation = recommendRequest.getChoiceLoc();
        String choiceCity = recommendRequest.getChoiceCity();
        Map<String, List<String>> filters = recommendRequest.getFilters();
        // ItemVector
        final long startTime = System.nanoTime();
        List<Item> itemsBasedOnGeoOrCity = filterService
            .getItemsNearbyOrWithOnlineOffer(choiceLocation, choiceCity);
        if (filters != null && !filters.isEmpty()) {
            final long filterByTagsStartTime = System.nanoTime();
            Predicate<Item> filterByTags = filterService.filterByTags(filters);
            LOGGER.debug("Count before tags filter: {} = {}",
                filters, itemsBasedOnGeoOrCity.size());
            itemsBasedOnGeoOrCity = itemsBasedOnGeoOrCity.stream().filter(filterByTags)
                .collect(Collectors.toList());
            LOGGER.debug("Count after tags filter: {} = {}", filters, itemsBasedOnGeoOrCity.size());
            LOGGER.debug("filterByTags: {} ms",
                (System.nanoTime() - filterByTagsStartTime) / 1000000);
        }
        boolean filterNonOffers = recommendRequest.getFlags()
            .getOrDefault(Constants.FLAG_FILTER_NON_OFFERS, true);
        LOGGER.info("Flag Filter Non Offers: {}", filterNonOffers);
        OffsetDateTime choiceServedAt = recommendRequest.getChoiceServedAt();
        List<Item> itemsFilteredByValidDate = filterService.filterExpiredOffers(
            itemsBasedOnGeoOrCity, choiceServedAt, filterNonOffers);
        List<String> categories = recommendRequest.getCategories();
        List<Item> nearbyItemIds = itemsFilteredByValidDate.stream()
            .filter(item -> (categories != null && categories.contains(item.getCategory())))
            .collect(Collectors.toList());
        LOGGER.info("getFilteredItemsByLocCategoryActiveDate: {} ms",
            (System.nanoTime() - startTime) / 1000000);
        return nearbyItemIds;
    }
}
