/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.maya.choice.config;

import com.crayondata.maya.choice.service.CustomUserDetailsService;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.security.web.authentication.www.BasicAuthenticationFilter;
import org.springframework.util.StringUtils;

@ConditionalOnProperty(value = "app.security.basic.enabled", havingValue = "true")
public class JwtAuthenticationFilter extends BasicAuthenticationFilter {

    @Autowired
    private JwtTokenProvider tokenProvider;

    @Autowired
    private CustomUserDetailsService userDetailsService;

    @Value("${allowedOrigins:}")
    private String[] allowedOrigins;

    public JwtAuthenticationFilter(
        AuthenticationManager authenticationManager) {
        super(authenticationManager);
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response,
        FilterChain filterChain) throws ServletException, IOException {
        String jwt = getJwtFromRequest(request);
        try {
            if (StringUtils.hasText(jwt) && tokenProvider.validateToken(jwt)) {
                String userId = tokenProvider.getUserIdFromJWT(jwt);
                UserDetails userDetails = userDetailsService.loadUserById(userId);
                UsernamePasswordAuthenticationToken authentication = new
                    UsernamePasswordAuthenticationToken(userDetails, null,
                    userDetails.getAuthorities());
                authentication
                    .setDetails(new WebAuthenticationDetailsSource().buildDetails(request));

                SecurityContextHolder.getContext().setAuthentication(authentication);
            }
        } catch (Exception e) {
            logger.error("Could not set user authentication in security context", e);
        }
        addCorsHeaders(request, response);
        filterChain.doFilter(request, response);
    }


    private void addCorsHeaders(HttpServletRequest httpRequest,
        HttpServletResponse httpResponse) {
        // add headers to support CORS
        String origin = httpRequest.getHeader("origin");
        String originToAllow = null;
        List<String> allowedOriginList = Arrays.asList(allowedOrigins);
        if (allowedOriginList.contains("*")) {
            originToAllow = "*";
        } else if (origin != null && allowedOriginList.contains(origin)) {
            originToAllow = origin;
        }
        if (originToAllow != null) {
            httpResponse.setHeader("Access-Control-Allow-Origin", originToAllow);
            httpResponse.setHeader("access-control-allow-credentials", "true");
            httpResponse.setHeader("access-control-allow-headers",
                "X-Requested-With, Content-Type, Authorization, User-Access-Token");
            httpResponse.setHeader("access-control-allow-methods", "GET, POST, PATCH, "
                + "DELETE, OPTIONS");
            httpResponse.setHeader("Access-Control-Max-Age", "600");
        }
    }

    private String getJwtFromRequest(HttpServletRequest request) {
        String accessToken = request.getHeader("user-access-token");
        if (StringUtils.hasText(accessToken)) {
            return accessToken;
        }
        return null;
    }
}
