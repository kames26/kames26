/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.maya.choice;

import static com.crayondata.maya.data.utils.ObjectUtils.defaultIfNull;

import com.crayondata.maya.choice.utils.ResponseBuilder;
import com.crayondata.maya.data.access.key.KeyStoreDataAccessService;
import com.crayondata.maya.data.access.model.JsonDocument;
import com.crayondata.maya.data.access.util.DBConstants;
import com.crayondata.maya.data.access.util.JsonUtils;
import com.crayondata.maya.data.campaign.CampaignService;
import com.crayondata.maya.data.campaign.UserCampaignService;
import com.crayondata.maya.data.currency.CurrencyConversionService;
import com.crayondata.maya.data.entity.ItemService;
import com.crayondata.maya.data.model.campaign.Campaign;
import com.crayondata.maya.data.model.config.ChoiceApiConfig;
import com.crayondata.maya.data.model.currency.CurrencyConversion;
import com.crayondata.maya.data.model.entity.Item;
import com.crayondata.maya.data.model.entity.OfferDetails;
import com.crayondata.maya.data.model.profile.Interaction;
import com.crayondata.maya.data.model.profile.RedeemedOffers;
import com.crayondata.maya.data.model.profile.UserProfile;
import com.crayondata.maya.data.model.profile.UserTagVector;
import com.crayondata.maya.data.profile.InteractionService;
import com.crayondata.maya.data.profile.UserProfileService;
import com.crayondata.maya.data.profile.UserTagService;
import com.crayondata.maya.model.api.ApiResponse;
import com.crayondata.maya.model.api.ApiResponse.Status;
import com.crayondata.maya.model.api.CampaignResponse;
import com.crayondata.maya.model.api.ChoiceResponse;
import com.crayondata.maya.model.api.InteractRequest;
import com.crayondata.maya.model.api.InteractionResponse;
import com.crayondata.maya.model.api.UserProfileResponse;
import com.crayondata.maya.model.api.UserTagPreferenceResponse;
import com.crayondata.maya.model.enums.CampaignType;
import com.crayondata.maya.model.enums.InteractionType;
import com.crayondata.maya.model.enums.ItemType;
import com.crayondata.maya.model.rest.OfferRedemptionHistory;
import com.crayondata.maya.model.rest.UserProfileRequest;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import java.io.IOException;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class UserAPIImpl implements UserAPI {

    private static final Logger LOGGER = LoggerFactory.getLogger(UserAPIImpl.class);

    @Autowired
    private InteractionService interactionService;

    @Autowired
    private UserProfileService userProfileService;

    @Autowired
    private UserTagService userTagService;

    @Autowired
    private ItemService itemService;

    @Autowired
    private UserCampaignService userCampaignService;

    @Autowired
    private CampaignService campaignService;

    @Autowired
    private JsonUtils json;

    @Autowired
    private ResponseBuilder responseBuilder;

    @Value("${user.enable.anonymous:false}")
    private boolean enableAnonUser;

    @Value("${save.interactions.history}")
    private boolean saveIntrHistory;

    @Value("${base.currency}")
    private String baseCurrency;

    @Value("${currency.conversion.enable}")
    private boolean conversionEnabled;

    @Autowired
    private ChoiceApiConfig choiceApiConfig;

    @Autowired
    private KeyStoreDataAccessService dataAccessService;

    @Autowired
    private CurrencyConversionService currencyConversionService;

    @Override
    public CampaignResponse getCampaigns(String userId, String campaignUserId,
        CampaignType campaignType) {

        campaignUserId = userProfileService.resolveKnownUserIdViaMapping(campaignUserId);
        if (userProfileService.processSessionAndKnownUserId(userId, campaignUserId) == null) {
            return new CampaignResponse();
        }

        UserProfile userProfile = userProfileService.getUnifiedUserProfile(userId);
        LOGGER.debug("Retrieved user-profile {}", userProfile);

        //known user
        if (userProfile != null && userProfile.isKnownUser()) {
            if (campaignType != null) {
                List<Campaign> campaigns;
                //sorting
                if (CampaignType.EVENT.equals(campaignType)) {
                    campaigns = getCampaignsForExistingUser(userProfile.getKnownUserId(),
                            campaignType);
                    campaigns = sortCampaignsByDate(campaigns);
                } else { //campaignTye = CATEGORY
                    campaigns = campaignService.getActiveCategoryCampaigns();
                    campaigns = sortCampaignsByExternalId(campaigns);
                }
                return constructResponse(campaigns);
            } else {
                List<Campaign> eventCampaigns = getCampaignsForExistingUser(
                    userProfile.getKnownUserId(), CampaignType.EVENT);
                List<Campaign> categoryCampaigns = campaignService.getActiveCategoryCampaigns();
                List<Campaign> campaigns = new ArrayList<>();
                eventCampaigns = sortCampaignsByDate(eventCampaigns);
                categoryCampaigns = sortCampaignsByExternalId(categoryCampaigns);
                campaigns.addAll(eventCampaigns);
                campaigns.addAll(categoryCampaigns);
                return constructResponse(campaigns);
            }
        }
        //anonymous user
        if (enableAnonUser) {
            if (campaignType == null || CampaignType.CATEGORY.equals(campaignType)) {
                List<Campaign> campaigns = campaignService.getActiveCategoryCampaigns();
                campaigns = sortCampaignsByExternalId(campaigns);
                return constructResponse(campaigns);
            }
        }
        return new CampaignResponse();
    }

    private List<Campaign> sortCampaignsByCategory(List<Campaign> campaigns,
        List<String> preferredCategories) {
        // preferredCategories is already sorted
        List<Campaign> returnList = new ArrayList<>();
        for (String category : preferredCategories) {
            List<Campaign> filteredCampaigns = campaigns.stream()
                .filter(campaign -> (campaign.getCampaignCategory() == null) || campaign
                .getCampaignCategory().equals(category)).collect(Collectors.toList());
            returnList.addAll(filteredCampaigns);
            campaigns.removeAll(filteredCampaigns);
        }
        // add remaining categories at last
        returnList.addAll(campaigns);
        return returnList;
    }

    private List<Campaign> sortCampaignsByDate(List<Campaign> campaigns) {
        campaigns.sort(new Comparator<Campaign>() {
            @Override
            public int compare(Campaign o1, Campaign o2) {
                if (o1.getCreated().isAfter(o2.getCreated())) {
                    return -1;
                } else if (o1.getCreated().isAfter(o2.getCreated())) {
                    return 1;
                } else {
                    return 0;
                }
            }
        });
        return campaigns;
    }

    private List<Campaign> sortCampaignsByExternalId(List<Campaign> campaigns) {
        campaigns.sort(new Comparator<Campaign>() {
            @Override
            public int compare(Campaign o1, Campaign o2) {
                if (o1.getExternalId() < o2.getExternalId()) {
                    return -1;
                } else if (o1.getExternalId() > o2.getExternalId()) {
                    return 1;
                } else {
                    return 0;
                }
            }
        });
        return campaigns;
    }

    private CampaignResponse constructResponse(List<Campaign> campaigns) {

        if (!campaigns.isEmpty()) {
            return new CampaignResponse(campaigns);
        } else {
            return new CampaignResponse();
        }
    }

    private List<Campaign> getCampaignsForExistingUser(String userId, CampaignType campaignType) {
        List<String> campaignIds = userCampaignService.getUserCampaignIds(userId);
        List<Campaign> campaigns = campaignService.getCampaigns(campaignIds);
        OffsetDateTime currentDate = OffsetDateTime.now();
        return campaigns.stream()
                .filter(campaign -> campaign.isActive() && campaign.getCampaignType()
                        .equals(campaignType) && campaign.getStartDateTime().isBefore(currentDate)
                        && campaign.getEndDateTime().isAfter(currentDate))
                .collect(Collectors.toList());
    }

    @Override
    public ChoiceResponse getLikes(String userId) {

        UserProfile dynamicUserProfile = userProfileService.getDynamicUserProfile(userId);
        if (dynamicUserProfile == null) {
            return new ChoiceResponse();
        }
        userId = userProfileService.getUseableUserId(dynamicUserProfile);
        List<Interaction> interactions = interactionService
            .getInteractionsWithUserIdAndInteractionType(userId, ItemType.MERCHANT,
            InteractionType.LIKE);

        Map<String, OffsetDateTime> interactionTimestamp = interactions.stream()
            .collect(Collectors.toMap(Interaction::getItemId, Interaction::getTimestamp));
        List<String> itemIds = new ArrayList<>(interactionTimestamp.keySet());

        List<Item> items = itemService.getItems(itemIds);

        items.sort((o1, o2) -> {
            return interactionTimestamp.get(o2.getId())
                    .compareTo(interactionTimestamp.get(o1.getId()));
        });

        JsonNode node = json.toJsonNode(items);
        responseBuilder.movePropertiesOut((ArrayNode) node);
        ((ArrayNode) node).forEach(item -> ((ObjectNode) item).put("liked", true));
        ObjectNode object = json.newObjectNode();
        object.set("items", node);
        return new ChoiceResponse(object);
    }

    @Override
    public UserProfileResponse getUserProfile(String userId) {
        UserProfile userProfile = userProfileService.getUnifiedUserProfile(userId);

        if (userProfile == null) {
            return new UserProfileResponse();
        }
        JsonNode responseObject = json.asJsonNode(userProfile);
        responseBuilder.movePropertiesOut((ObjectNode) responseObject);
        ObjectNode object = (ObjectNode) responseObject;
        object.remove("knownUserId");
        object.remove("knownUser");
        return new UserProfileResponse(object);
    }

    @Override
    public UserTagPreferenceResponse getUserTagPreferenceVector(String userId) {
        UserProfile userProfile = userProfileService.getUnifiedUserProfile(userId);
        if (userProfile == null) {
            return new UserTagPreferenceResponse();
        }
        String knownUserId = userProfile.getKnownUserId();
        String dynamicUserId = knownUserId == null ? userProfile.getId() : knownUserId;

        UserTagVector staticUserTag = userTagService.getUserTagVector(userId);
        UserTagVector dynamicUserTag = userTagService.getDynamicUserTagVector(dynamicUserId);
        return new UserTagPreferenceResponse(staticUserTag, dynamicUserTag);
    }

    @Override
    public ApiResponse<Boolean> updateUserProfile(String userId,
        UserProfileRequest userProfileRequest) {
        // get proper user ID based on profile
        UserProfile dynamicUserProfile = userProfileService.processSessionAndKnownUserId(userId,
            null);
        if (dynamicUserProfile == null) {
            return new ApiResponse<>(Status.ERROR, "UserProfile not found for user");
        }
        userId = userProfileService.getUseableUserId(dynamicUserProfile);
        boolean status = userProfileService
            .updateUserProfile(userId, userProfileRequest.getPersonalDetails(),
            userProfileRequest.getNotifications(), userProfileRequest.getMessages(),
            userProfileRequest.getProperties());
        if (status) {
            return new ApiResponse<>(true);
        } else {
            return new ApiResponse<>(Status.ERROR,
                "User profile not updated due to some error");
        }
    }

    @Override
    public ApiResponse<Boolean> interact(InteractRequest request) {
        String userId = request.getUserId();
        com.crayondata.maya.model.common.Interaction interaction = request.getInteraction();
        String itemId = interaction.getValue();
        ApiResponse.Status validationResponse = validateInteractRequest(itemId, userId,
            request.getInteraction().getItemType());
        if (ApiResponse.Status.SUCCESS != validationResponse) {
            return new ApiResponse<>(validationResponse, false, "");
        }

        // get proper user ID based on profile
        UserProfile dynamicUserProfile = userProfileService.getDynamicUserProfile(userId);
        userId = userProfileService.getUseableUserId(dynamicUserProfile);

        InteractionType interactionType = interaction.getInteractionType();
        String id = interaction.getItemType() == ItemType.MERCHANT
            ? DBConstants.asItemKey(itemId) : itemId;
        com.crayondata.maya.data.model.profile.Interaction userInteraction
            = new com.crayondata.maya.data.model.profile.Interaction(
            id, OffsetDateTime.now());
        ItemType itemType = interaction.getItemType();
        boolean success;
        if (InteractionType.UNDO_LIKE == interactionType) {
            success = interactionService.removeInteraction(userId, itemType,
                InteractionType.LIKE, userInteraction);
        } else if (InteractionType.UNDO_WISHLIST == interactionType) {
            success = interactionService.removeInteraction(userId, itemType,
                InteractionType.WISHLIST, userInteraction);
        } else {
            success = interactionService.saveInteraction(userId, itemType,
                interactionType, userInteraction);
            if (success) {
                // Like and Dislike are mutually exclusive, so remove one when adding the other
                if (InteractionType.LIKE == interactionType) {
                    interactionService.removeInteraction(userId, itemType, InteractionType.DISLIKE,
                        userInteraction);
                } else if (InteractionType.DISLIKE == interactionType) {
                    interactionService.removeInteraction(userId, itemType, InteractionType.LIKE,
                        userInteraction);
                }
            }
        }
        if (success) {
            boolean saveIntrHistory = defaultIfNull(choiceApiConfig.getGlobalConfig()
                .getSaveInteractionsHistory(), this.saveIntrHistory);
            if (saveIntrHistory) {
                interactionService.saveInteractionHistory(userId, itemType,
                    interactionType, userInteraction);
            }
            userTagService.updateUserTagVector(userId, itemId, interactionType, itemType);
            Double score = 1.0; //to be updated later
            userProfileService.updatePreferredCategories(userId, itemId, score, itemType);
            if (itemType == ItemType.MERCHANT) {
                interactionService.recordItemInteraction(itemId, interactionType,
                    userInteraction.getTimestamp());
            }
            return new ApiResponse<>(ApiResponse.Status.SUCCESS, success, "");
        } else {
            return new ApiResponse<>(ApiResponse.Status.ERROR, success, "");
        }
    }

    @Override
    public ApiResponse<InteractionResponse> getUserInteractions(String userId,
        String itemType, String interactionType, String lang) {
        UserProfile dynamicUserProfile = userProfileService.getDynamicUserProfile(userId);
        if (dynamicUserProfile == null) {
            return new ApiResponse<>(Status.NOT_FOUND, "User details not found");
        }
        userId = userProfileService.getUseableUserId(dynamicUserProfile);
        List<Interaction> interactions = interactionService
            .getInteractionsWithUserIdAndInteractionType(userId, ItemType.valueOf(itemType),
            InteractionType.valueOf(interactionType));
        if (!interactions.isEmpty()) {
            Map<String, OffsetDateTime> interactionTimestamp = interactions.stream()
                .collect(Collectors.toMap(Interaction::getItemId, Interaction::getTimestamp));
            List<String> itemIds = new ArrayList<>(interactionTimestamp.keySet());
            List<Item> items = itemService.getItems(itemIds, ItemType.valueOf(itemType), lang);
            if (items != null && !items.isEmpty()) {
                if (ItemType.valueOf(itemType) == ItemType.MERCHANT) {
                    items.sort((o1, o2) -> {
                        return interactionTimestamp.get(o2.getId())
                            .compareTo(interactionTimestamp.get(o1.getId()));
                    });
                } else {
                    Predicate<OfferDetails> isOfferInteracted = i -> (interactionTimestamp
                        .containsKey(i.getId()));
                    for (Item item : items) {
                        List<OfferDetails> interactedOffers = item.getOffers().stream()
                            .filter(isOfferInteracted).collect(Collectors.toList());
                        item.setOffers(interactedOffers);
                    }
                }

                Map<String, List<Item>> categoryItems = items.stream()
                    .collect(Collectors.groupingBy(Item::getCategory));

                return new ApiResponse<>(new InteractionResponse(categoryItems));
            }
        }

        return new ApiResponse<>(Status.NOT_FOUND, "Interaction details not found");

    }

    @Override
    public ApiResponse<OfferRedemptionHistory> getRedeemedOffers(String userId, String lang) {
        List<RedeemedOffers> redeemedOffers = interactionService.getRedeemedOffers(userId, lang);
        if (redeemedOffers != null) {
            if (conversionEnabled) {
                updateOfferValuesToBaseCurrency(redeemedOffers);
            }
            int totalSpent = redeemedOffers.stream()
                .map(x -> x.getSpent()).mapToInt(Integer::intValue).sum();
            int totalSavings = redeemedOffers.stream()
                .map(x -> x.getSaving()).mapToInt(Integer::intValue).sum();
            OfferRedemptionHistory offerRedemption = new OfferRedemptionHistory(
                redeemedOffers.size(), totalSpent, totalSavings, redeemedOffers);
            return new ApiResponse<>(offerRedemption);
        }
        return new ApiResponse<>(Status.NOT_FOUND, "Redeemed offers not found for user");
    }

    private void updateOfferValuesToBaseCurrency(
        List<RedeemedOffers> redeemedOffers) {
        Map<String, Map<String, Double>> currencies = new HashMap<>();
        for (RedeemedOffers offer : redeemedOffers) {
            String currency = String.join("_", offer.getCurrency()
                .toLowerCase(), baseCurrency.toLowerCase());
            Map<String, Double> trxnDateExchangeRates = currencies.get(currency);
            if (trxnDateExchangeRates == null) {
                trxnDateExchangeRates = new HashMap<>();
                currencies.put(currency, trxnDateExchangeRates);
            }
            String trxnDate = offer.getTransactionDate();
            try {
                if (!trxnDateExchangeRates.containsKey(trxnDate)) {
                    JsonDocument document = dataAccessService.getDocument(currency,
                        CurrencyConversion.TYPE);
                    Double rate;
                    CurrencyConversion currencyConversion = null;
                    if (document != null) {
                        currencyConversion = json.getObject(
                            document.getJson(), CurrencyConversion.class);
                        Map<String, Double> exchangeRates = currencyConversion.getExchangeRates();
                        rate = exchangeRates.get(trxnDate);
                        if (rate == null) {
                            rate = upsertCurrencyDocInDB(currencyConversion, currency, trxnDate);
                        }
                    } else {
                        rate = upsertCurrencyDocInDB(currencyConversion, currency, trxnDate);
                    }
                    trxnDateExchangeRates.put(trxnDate, rate);
                }
            } catch (Exception e) {
                LOGGER.error("Exception : " + e.getMessage());
            }
            int spent = (int) (offer.getSpent() * trxnDateExchangeRates.get(trxnDate));
            offer.setSpent(spent);
            int saving = (int) (offer.getSaving() * trxnDateExchangeRates.get(trxnDate));
            offer.setSaving(saving);
            offer.setCurrency(baseCurrency);
        }
    }

    private Double upsertCurrencyDocInDB(CurrencyConversion currencyConversion,
        String currency, String trxnDate) throws IOException {
        String[] curr = currency.split("_");
        Double rate = currencyConversionService.getRate(curr[0],
            curr[1], trxnDate);
        boolean replace = true;
        if (currencyConversion == null) {
            Map<String, Double> exchangeRates = new HashMap<>();
            exchangeRates.put(trxnDate, rate);
            currencyConversion = new CurrencyConversion(currency, exchangeRates);
            replace = false;
        } else {
            currencyConversion.getExchangeRates().put(trxnDate, rate);
        }
        JsonNode jsonNode = json.asJsonNode(currencyConversion);
        JsonDocument jsonDocument = new JsonDocument(currency, jsonNode);
        if (replace) {
            dataAccessService.replace(jsonDocument);
        } else {
            dataAccessService.insert(jsonDocument);
        }
        return rate;
    }

    private ApiResponse.Status validateInteractRequest(String itemId, String userId,
        ItemType itemType) {
        if (userId == null || userId.trim().isEmpty()) {
            LOGGER.info("User Id not present in interaction request");
            return ApiResponse.Status.BAD_REQUEST;
        }
        if (itemId == null || itemId.trim().isEmpty()) {
            LOGGER.info("Item Id not present in interaction request for user: {}", userId);
            return ApiResponse.Status.BAD_REQUEST;
        }
        if (!userProfileService.isDynamicUserExists(userId)) {
            LOGGER.info("User Id {} not found in DB", userId);
            return ApiResponse.Status.BAD_REQUEST;
        }
        if (!itemService.isItemExists(itemId, itemType)) {
            LOGGER.info("Item Id {} not found in DB", itemId);
            return ApiResponse.Status.NOT_FOUND;
        }
        return ApiResponse.Status.SUCCESS;
    }

}
