# Maya

## Documentation
[Link](https://crayon.atlassian.net/wiki/spaces/engineering/pages/96370690/Maya+2.X+Documents) to confluence documentations.

## Building from source
### Requirements
* Java JDK 8+
* Maven 3.x+

```
mvn clean package
```
## Code Formatting
Use `crayon-java-code-formatter.xml` specified at the root of this project to format all Java code.  
In Eclipse Mars, Windows > Preferences > Java > Code > Formatter > Import 
In Intellij IDEA 2018.3, File > Settings > Editor > Code Style > Scheme: Import Scheme

## Repository Workflow
We will be using **feature branch workflow**

Refer, [Crayon Confluence](https://crayon.atlassian.net/wiki/spaces/engineering/pages/96829448/Git+Work+Flow) 
- Ignore the Illustration or [Atlassian Tutorials](https://www.atlassian.com/git/tutorials/comparing-workflows/feature-branch-workflow)
Purpose of this document to explain various `git` commands need to be used.

