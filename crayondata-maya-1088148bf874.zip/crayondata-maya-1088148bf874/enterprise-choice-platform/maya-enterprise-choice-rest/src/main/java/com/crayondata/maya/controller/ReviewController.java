/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.maya.controller;

import com.crayondata.maya.choice.ReviewAPI;
import com.crayondata.maya.choice.UserAPI;
import com.crayondata.maya.choice.config.CurrentUser;
import com.crayondata.maya.choice.service.UserResolutionService;
import com.crayondata.maya.data.model.security.UserPrincipal;
import com.crayondata.maya.model.api.AppFeedbackRequest;
import com.crayondata.maya.model.api.AppFeedbackResponse;
import com.crayondata.maya.model.api.ReviewItemRequest;
import com.crayondata.maya.model.api.ReviewItemResponse;
import com.crayondata.maya.model.api.ReviewMerchantResponse;
import com.crayondata.maya.model.rest.Response;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import io.swagger.annotations.Authorization;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import springfox.documentation.annotations.ApiIgnore;

@RestController
@RequestMapping("/api/v3/")
@Api(tags = "Review API", description = "To store and retrieve app level "
    + "and merchant level reviews")
public class ReviewController {
    @Autowired
    private ReviewAPI reviewAPI;

    @Autowired
    private UserAPI userApi;

    @Autowired
    private UserResolutionService userResolutionService;

    @ApiResponses({
        @ApiResponse(code = 200,message = "Feedback returned",
        response = AppFeedbackResponse.class),
        @ApiResponse(code = 404, message = "Not found", response = Response.class)})
    @RequestMapping(value = "user/feedback", produces = "application/json",
        method = RequestMethod.GET)
    @ApiOperation(value = "API to get feedback given by the user for App", authorizations = {
        @Authorization(value = "Authorization")})
    public ResponseEntity<?> getAppFeedback(
        @ApiIgnore @CurrentUser UserPrincipal currentUser,
        @RequestHeader(value = "User-Access-Token") String accessToken) {
        String userId = userResolutionService.resolveUserIdViaSecurityConfig(currentUser,
            accessToken);
        com.crayondata.maya.model.api.ApiResponse<AppFeedbackResponse> response = reviewAPI
            .getFeedback(userId);
        switch (response.getStatus()) {
            case SUCCESS:
                return new ResponseEntity<>(response.getResponse(), HttpStatus.OK);
            case BAD_REQUEST:
                return new ResponseEntity<>(Response.BAD_REQUEST, HttpStatus.BAD_REQUEST);
            case NOT_FOUND:
                return new ResponseEntity<>(Response.NOT_FOUND, HttpStatus.NOT_FOUND);
            case ERROR:
            default:
                return new ResponseEntity<>(Response.FAILURE, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }


    @ApiResponses({
        @ApiResponse(code = 200, message = "true",
        response = ReviewItemResponse.class),
        @ApiResponse(code = 404, message = "Not found", response = Response.class)})
    @RequestMapping(value = "user/feedback", produces = "application/json",
        method = RequestMethod.POST)
    @ApiOperation(value = "API to save feedback given by the user for App", authorizations = {
        @Authorization(value = "Authorization")})

    public ResponseEntity<?> saveAppFeedback(@RequestBody(required = true)
        AppFeedbackRequest request,
        @ApiIgnore @CurrentUser UserPrincipal currentUser,
        @RequestHeader(value = "User-Access-Token")
        String accessToken) {
        String userId = userResolutionService.resolveUserIdViaSecurityConfig(currentUser,
            accessToken);
        com.crayondata.maya.model.api.UserProfileResponse userProfileResponse = userApi
            .getUserProfile(userId);
        if (userProfileResponse.hasUserProfile()) {
            com.crayondata.maya.model.api.ApiResponse<Boolean> response = reviewAPI
                .saveFeedback(request, currentUser.getId());
            switch (response.getStatus()) {
                case SUCCESS:
                    return new ResponseEntity<>(response.getResponse(), HttpStatus.OK);
                case BAD_REQUEST:
                    return new ResponseEntity<>(Response.BAD_REQUEST, HttpStatus.BAD_REQUEST);
                case NOT_FOUND:
                    return new ResponseEntity<>(Response.NOT_FOUND, HttpStatus.NOT_FOUND);
                case ERROR:
                default:
                    return new ResponseEntity<>(Response.FAILURE, HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }
        return new ResponseEntity<>(Response.NOT_FOUND, HttpStatus.NOT_FOUND);

    }
    /**
     * API end point to  store the review given by user for merchant.
     *
     * @param request contains merchantId,rating and review
     * @return
     */

    @ApiResponses({
        @ApiResponse(code = 200, message = "Inserted Successfully",
        response = ReviewItemResponse.class),
        @ApiResponse(code = 404, message = "Not found", response = Response.class)})
    @RequestMapping(value = "merchant/review", produces = "application/json",
        method = RequestMethod.POST)
    @ApiOperation(value = "Store the review given by the user for merchant", authorizations = {
        @Authorization(value = "Authorization")})
    public ResponseEntity<?> getReviewItems(@RequestBody ReviewItemRequest request,
        @ApiIgnore @CurrentUser UserPrincipal currentUser,
        @RequestHeader(value = "User-Access-Token") String accessToken) {
        String userId = userResolutionService.resolveUserIdViaSecurityConfig(currentUser,
            accessToken);
        com.crayondata.maya.model.api.UserProfileResponse userProfileResponse = userApi
            .getUserProfile(userId);
        if (userProfileResponse.hasUserProfile()) {
            com.crayondata.maya.model.api.ApiResponse<Boolean> response = reviewAPI
                .saveReview(request, userId);
            switch (response.getStatus()) {
                case SUCCESS:
                    return new ResponseEntity<>(response.getResponse(), HttpStatus.OK);
                case BAD_REQUEST:
                    return new ResponseEntity<>(Response.BAD_REQUEST, HttpStatus.BAD_REQUEST);
                case NOT_FOUND:
                    return new ResponseEntity<>(Response.NOT_FOUND, HttpStatus.NOT_FOUND);
                case ERROR:
                default:
                    return new ResponseEntity<>(Response.FAILURE, HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<>(Response.NOT_FOUND, HttpStatus.NOT_FOUND);
    }

    @ApiResponses({
        @ApiResponse(code = 200, message = "Retrieved Successfully",
        response = ReviewItemResponse.class),
        @ApiResponse(code = 404, message = "Not found", response = Response.class)})
    @RequestMapping(value = "merchant/review/details", produces = "application/json",
        method = RequestMethod.GET)
    @ApiOperation(value = "Get the review details for merchant", authorizations = {
        @Authorization(value = "Authorization")})
    public ResponseEntity<?> getMerchantReview(@RequestParam(value = "merchantId")
        String merchantId) {
        com.crayondata.maya.model.api.ApiResponse<ReviewMerchantResponse> response = reviewAPI
            .getReviewDetails(merchantId);
        switch (response.getStatus()) {
            case SUCCESS:
                return new ResponseEntity<>(response.getResponse(), HttpStatus.OK);
            case NOT_FOUND:
                return new ResponseEntity<>(Response.NOT_FOUND,HttpStatus.NOT_FOUND);
            case ERROR:
            default:
                return new ResponseEntity<>(Response.FAILURE, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}



