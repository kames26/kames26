/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.maya.controller;

import com.crayondata.maya.choice.PrivacyTermsAPI;
import com.crayondata.maya.model.api.PrivacyTermsResponse;
import com.crayondata.maya.model.rest.Response;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import io.swagger.annotations.Authorization;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v3/")
@Api(tags = "Privacy Policy and Terms of Service API", description = "To get the privacy"
    + " and terms of service")

public class PrivacyAndTermsController {
    @Autowired
    private PrivacyTermsAPI privacyTermsApi;

    @ApiResponses({
        @ApiResponse(code = 200,message = "Response returned",
        response = PrivacyTermsResponse.class),
        @ApiResponse(code = 400,message = "Invalid input value"),
        @ApiResponse(code = 404, message = "Not found", response = Response.class)})
    @RequestMapping(value = "privacy/docs", produces = "application/json",
        method = RequestMethod.GET)
    @ApiOperation(value = "API to get privacy and terms of service for App", authorizations = {
        @Authorization(value = "Authorization")})
    public ResponseEntity<?> getPrivacyAndTerms(
        @ApiParam(required = true, value = "Get Privacy policy or Terms of service",
        example = "privacy_policy or terms_of_service")
        @RequestParam(value = "type") String type) {
        type = type.replaceAll("[_]", "-");
        com.crayondata.maya.model.api.ApiResponse<PrivacyTermsResponse> response = privacyTermsApi
            .getPrivacyTerms(type);
        switch (response.getStatus()) {
            case SUCCESS:
                return new ResponseEntity<>(response.getResponse(), HttpStatus.OK);
            case BAD_REQUEST:
                return new ResponseEntity<>(Response.BAD_REQUEST, HttpStatus.BAD_REQUEST);
            case NOT_FOUND:
                return new ResponseEntity<>(Response.NOT_FOUND, HttpStatus.NOT_FOUND);
            case ERROR:
            default:
                return new ResponseEntity<>(Response.FAILURE, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

}
