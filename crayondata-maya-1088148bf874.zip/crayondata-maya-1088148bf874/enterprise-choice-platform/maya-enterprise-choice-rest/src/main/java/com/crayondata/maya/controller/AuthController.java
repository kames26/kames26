/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.maya.controller;

import com.crayondata.maya.choice.config.JwtTokenProvider;
import com.crayondata.maya.data.model.security.UserInfo;
import com.crayondata.maya.data.model.security.UserPrincipal;
import com.crayondata.maya.model.rest.LoginRequest;
import com.crayondata.maya.model.rest.LoginResponse;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import java.util.Collections;
import javax.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@ConditionalOnProperty(value = "app.security.basic.enabled", havingValue = "true")
@RequestMapping("/api/v3/auth")
@Api(tags = "Authentication APIs", description = "To authenticate user")
public class AuthController {

    private static final Logger LOGGER = LoggerFactory.getLogger(AuthController.class);

    @Autowired
    AuthenticationManager authenticationManager;

    @Autowired
    JwtTokenProvider tokenProvider;

    /**
     * API to authenticate user.
     * @param loginRequest contains credentials used to login
     * @return {@link LoginResponse}
     */
    @ApiOperation(value = "API for login")
    @PostMapping(value = "/login", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> authenticateUser(
        @Valid @RequestBody LoginRequest loginRequest) {
        long startTime = System.currentTimeMillis();
        Authentication authentication = authenticationManager.authenticate(
            new UsernamePasswordAuthenticationToken(
            loginRequest.getEmail(), loginRequest.getPassword()));
        SecurityContextHolder.getContext().setAuthentication(authentication);
        UserPrincipal userPrincipal = (UserPrincipal) authentication.getPrincipal();
        UserInfo userInfo = new UserInfo(userPrincipal.getUsername(), Collections.emptyMap());
        String accessToken = tokenProvider.generateToken(authentication);
        LOGGER.info("Time taken to login : {} ms", (System.currentTimeMillis() - startTime));
        return ResponseEntity.ok(new LoginResponse(accessToken, userInfo));
    }
}
