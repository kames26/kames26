/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.maya.controller;

import com.crayondata.maya.choice.ChoiceAPI;
import com.crayondata.maya.choice.config.CurrentUser;
import com.crayondata.maya.choice.service.ChoiceControllerService;
import com.crayondata.maya.choice.service.LocationResolutionService;
import com.crayondata.maya.choice.service.RequestValidationService;
import com.crayondata.maya.choice.service.UserResolutionService;
import com.crayondata.maya.data.access.util.JsonUtils;
import com.crayondata.maya.data.model.entity.ChoiceList;
import com.crayondata.maya.data.model.entity.Choices;
import com.crayondata.maya.data.model.entity.Item;
import com.crayondata.maya.data.model.security.UserPrincipal;
import com.crayondata.maya.model.api.ItemRequest;
import com.crayondata.maya.model.api.ItemResponse;
import com.crayondata.maya.model.rest.ChoiceListRequest;
import com.crayondata.maya.model.rest.ChoiceRequest;
import com.crayondata.maya.model.rest.Response;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import io.swagger.annotations.Authorization;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import springfox.documentation.annotations.ApiIgnore;

@RestController
@RequestMapping("/api/v3/")
@Api(tags = "Choice API", description = "To retrieve choices and to interact with it")
public class ChoiceController {

    private static final Logger LOGGER = LoggerFactory.getLogger(ChoiceController.class);

    @Autowired
    private ChoiceAPI choiceApi;

    @Autowired
    private JsonUtils json;

    @Autowired
    private RequestValidationService requestValidationService;

    @Autowired
    private LocationResolutionService locationResolutionService;

    @Autowired
    private UserResolutionService userResolutionService;

    @Autowired
    private ChoiceControllerService choiceControllerService;

    @ApiResponses({
        @ApiResponse(code = 200, message = "Choices returned", response = Choices.class),
        @ApiResponse(code = 404, message = "Not Found", response = Response.class)})
    @RequestMapping(value = "choices", method = RequestMethod.POST, produces = "application/json",
        consumes = "application/json")
    @ApiOperation(value = "Get choices for a user based on context and filters",
        authorizations = {@Authorization(value = "Authorization")})
    public ResponseEntity<?> getChoices(
        @CurrentUser UserPrincipal currentUser,
        @RequestHeader(value = "User-Access-Token", required = true) String accessToken,
        @RequestBody(required = true) ChoiceRequest request,
        @ApiIgnore(value = "This parameter will be auto populated with header details."
        + "Should not expose in Swagger")
        @RequestHeader MultiValueMap<String, String> headers) {

        final long startTime = System.nanoTime();
        LOGGER.debug("Choice request for user: {} before Validation: {}", accessToken, request);
        request = requestValidationService.validate(request);
        LOGGER.debug("Choice request for user: {} after Validation: {}", accessToken, request);
        String userId = userResolutionService.resolveUserIdViaSecurityConfig(currentUser,
            accessToken);
        com.crayondata.maya.model.api.ApiResponse<Choices> choices = choiceControllerService
            .formChoiceRequest(request, userId, headers);

        long endTime = System.nanoTime();
        LOGGER.debug("getChoices() : Time Taken : {} ms", (endTime - startTime) / 1000000);

        switch (choices.getStatus()) {
            case SUCCESS:
                return new ResponseEntity<>(asChoicesJson(choices.getResponse()), HttpStatus.OK);
            case NOT_FOUND:
                return new ResponseEntity<>(new Response(404, choices.getMessage()),
                    HttpStatus.NOT_FOUND);
            case BAD_REQUEST:
                return new ResponseEntity<>(Response.BAD_REQUEST, HttpStatus.NOT_FOUND);
            case ERROR:
            default:
                return new ResponseEntity<>(Response.FAILURE, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @ApiResponses({
        @ApiResponse(code = 200, message = "Choice list returned", response = ChoiceList.class),
        @ApiResponse(code = 404, message = "Not Found", response = Response.class)})
    @RequestMapping(value = "choice/list", method = RequestMethod.POST,
        produces = "application/json", consumes = "application/json")
    @ApiOperation(value = "Get choice list for a user based on context and filters",
        authorizations = {@Authorization(value = "Authorization")})
    public ResponseEntity<?> getChoiceList(
        @ApiIgnore @CurrentUser UserPrincipal currentUser,
        @RequestHeader(value = "User-Access-Token", required = true) String accessToken,
        @RequestBody(required = true) ChoiceListRequest choiceRequest,
        @ApiIgnore(value = "This parameter will be auto populated with header details."
        + "Should not expose in Swagger")
        @RequestHeader MultiValueMap<String, String> headers) {
        String userId = userResolutionService.resolveUserIdViaSecurityConfig(currentUser,
            accessToken);
        choiceRequest.setKnownUserId(userId);
        com.crayondata.maya.model.api.ApiResponse<?> choiceList = choiceApi
            .getChoiceList(userId, userId, choiceRequest, headers);

        switch (choiceList.getStatus()) {
            case SUCCESS:
                return new ResponseEntity<>(choiceList.getResponse(), HttpStatus.OK);
            case NOT_FOUND:
                return new ResponseEntity<>(new Response(404, choiceList.getMessage()),
                    HttpStatus.NOT_FOUND);
            case BAD_REQUEST:
                return new ResponseEntity<>(Response.BAD_REQUEST, HttpStatus.NOT_FOUND);
            case ERROR:
            default:
                return new ResponseEntity<>(Response.FAILURE, HttpStatus.INTERNAL_SERVER_ERROR);
        }

    }

    @ApiResponses({
        @ApiResponse(code = 200, message = "Similar items returned", response = Choices.class),
        @ApiResponse(code = 404, message = "Not Found", response = Response.class)})
    @RequestMapping(value = "items/similar/{itemId}/{count}", produces = "application/json",
        method = RequestMethod.GET)
    @ApiOperation(value = "Get similar items for a given item",
        authorizations = {@Authorization(value = "Authorization")})
    public ResponseEntity<?> getSimilarItems(
        @ApiIgnore @CurrentUser UserPrincipal currentUser,
        @PathVariable(required = true) String itemId, @PathVariable int count,
        @RequestParam(defaultValue = "en") String lang,
        @RequestHeader(value = "User-Access-Token", required = true) String accessToken) {
        String userId = userResolutionService.resolveUserIdViaSecurityConfig(currentUser,
            accessToken);
        if (userId == null || userId.trim().isEmpty()) {
            return new ResponseEntity<>(
                new Response(400, "Invalid value for Header:User-Access-Token"),
                HttpStatus.BAD_REQUEST);
        }
        if (itemId == null || itemId.trim().isEmpty()) {
            return new ResponseEntity<>(new Response(400, "Invalid value for choiceId"),
                HttpStatus.BAD_REQUEST);
        }

        com.crayondata.maya.model.api.ApiResponse<List<Item>> similarItemResponse
            = choiceApi.getSimilarItems(userId, itemId, count, lang);
        switch (similarItemResponse.getStatus()) {
            case SUCCESS:
                return new ResponseEntity<>(json.asJsonNode(similarItemResponse.getResponse()),
                    HttpStatus.OK);
            case NOT_FOUND:
                return new ResponseEntity<>(new Response(404, similarItemResponse.getMessage()),
                    HttpStatus.NOT_FOUND);
            case ERROR:
            case BAD_REQUEST:
            default:
                return new ResponseEntity<>(Response.FAILURE, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @ApiResponses({
        @ApiResponse(code = 200, message = "Choices returned", response = Choices.class),
        @ApiResponse(code = 404, message = "Not Found", response = Response.class)})
    @RequestMapping(value = "choices/{choiceId}", produces = "application/json",
        method = RequestMethod.GET)
    @ApiOperation(value = "Get a pre-generated choice by ID and page number",
        authorizations = {@Authorization(value = "Authorization")})
    public ResponseEntity<?> getChoicesById(
        @PathVariable(required = true) String choiceId,
        @RequestHeader(value = "User-Access-Token", required = true) String accessToken,
        @RequestParam(required = false) Integer pageNo) {
        if (accessToken == null || accessToken.trim().isEmpty()) {
            return new ResponseEntity<>(
                new Response(400, "Invalid value for Header:User-Access-Token"),
                HttpStatus.BAD_REQUEST);
        }
        if (choiceId == null || choiceId.trim().isEmpty()) {
            return new ResponseEntity<>(new Response(400, "Invalid value for choiceId"),
                HttpStatus.BAD_REQUEST);
        }

        com.crayondata.maya.model.api.ApiResponse<Choices> choices;
        if (pageNo == null) {
            // this is old request, without pagination support
            choices = choiceApi.getChoicesById(accessToken, choiceId);
        } else {
            choices = choiceApi.getChoicesByPage(accessToken, choiceId, pageNo);
        }

        switch (choices.getStatus()) {
            case SUCCESS:
                return new ResponseEntity<>(asChoicesJson(choices.getResponse()), HttpStatus.OK);
            case NOT_FOUND:
                return new ResponseEntity<>(new Response(404, choices.getMessage()),
                    HttpStatus.NOT_FOUND);
            case BAD_REQUEST:
                return new ResponseEntity<>(new Response(400, choices.getMessage()),
                    HttpStatus.BAD_REQUEST);
            case ERROR:
            default:
                return new ResponseEntity<>(Response.FAILURE, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @ApiResponses({
        @ApiResponse(code = 200, message = "Get Item", response = Item.class)})
    @RequestMapping(value = "items/{itemId}", produces = "application/json",
        method = RequestMethod.GET)
    @ApiOperation(value = "Get details of an item recommended in choice",
        authorizations = {@Authorization(value = "Authorization")})
    public ResponseEntity<?> getItems(
        @ApiIgnore @CurrentUser UserPrincipal currentUser,
        @PathVariable(required = true) String itemId,
        @RequestParam(defaultValue = "en") String lang,
        @RequestHeader(value = "User-Access-Token", required = true) String accessToken) {

        String userId = userResolutionService.resolveUserIdViaSecurityConfig(currentUser,
            accessToken);
        ItemRequest itemRequest = new ItemRequest(userId,
            userId, itemId, lang);
        ItemResponse itemResponse = choiceApi.getItem(itemRequest);

        if (itemResponse.hasItem()) {
            return new ResponseEntity<>(itemResponse.getItem(), HttpStatus.OK);
        }

        if (itemResponse.isError()) {
            return new ResponseEntity<>(Response.FAILURE, HttpStatus.INTERNAL_SERVER_ERROR);
        }

        return new ResponseEntity<>(Response.NOT_FOUND, HttpStatus.NOT_FOUND);

    }

    private JsonNode asChoicesJson(Choices choices) {
        ObjectNode node = (ObjectNode) json.asJsonNode(choices);
        ArrayNode items = (ArrayNode) node.get("items");
        for (JsonNode item : items) {
            ObjectNode objectNode = (ObjectNode) item;
            ObjectNode itemJson = (ObjectNode) objectNode.remove("item");
            ObjectNode scoredItemJson = (ObjectNode) objectNode.remove("scoredItem");
            objectNode.setAll(itemJson);
            objectNode.setAll(scoredItemJson);
            objectNode.remove("itemId");
            objectNode.set("liked", objectNode.remove("liked"));
        }
        movePropertiesOut(json, items);
        return node;
    }

    private static void movePropertiesOut(JsonUtils json, ArrayNode items) {
        // items.iterator().forEachRemaining(item -> movePropertiesOut((ObjectNode) item));
        items.forEach(item -> mapLocationsToOffers(json, (ObjectNode) item));
        items.forEach(item -> movePropertiesOut(json, (ObjectNode) item));
    }

    private static void movePropertiesOut(JsonUtils json, ObjectNode item) {
        json.moveObjectPropertiesUp(item);
        JsonNode offers = item.get("offers");
        if (offers != null && offers instanceof ArrayNode) {
            json.moveArrayPropertiesUp((ArrayNode) offers);
        }
    }

    private static void mapLocationsToOffers(JsonUtils json, ObjectNode item) {
        Map<String, JsonNode> locMap = new HashMap<>();
        JsonNode locations = item.get("locations");
        if (locations != null && locations.isArray()) {
            locations.forEach(loc -> locMap.put(loc.get("id").asText(), loc));
            for (JsonNode location : locations) {
                ObjectNode loc = (ObjectNode) location;
                loc.remove("offers");
                String key = loc.get("id").asText();
                loc.remove("id");
                locMap.put(key, loc);
            }
        }

        JsonNode offers = item.get("offers");
        ArrayNode newOffers = json.newArrayNode();
        if (offers != null && offers.isArray()) {
            for (JsonNode offer : offers) {
                if (offer.get("locations") != null && !offer.get("locations").isNull()) {
                    ArrayNode offerLoc = (ArrayNode) offer.get("locations");
                    ArrayNode newOfferLoc = json.newArrayNode();
                    offerLoc.forEach(locStr -> newOfferLoc.add(locMap.get(locStr.asText())));
                    ObjectNode newOffer = json.newObjectNode();
                    newOffer.setAll((ObjectNode) offer);
                    newOffer.set("locations", newOfferLoc);
                    newOffers.add(newOffer);
                } else {
                    newOffers.add(offer);
                }
            }
        }
        item.set("offers", newOffers);
        item.remove("locations");
    }
}
