/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.maya.controller;

import com.crayondata.maya.choice.ListAPI;
import com.crayondata.maya.choice.service.LocationResolutionService;
import com.crayondata.maya.data.access.util.DBConstants;
import com.crayondata.maya.data.model.entity.DataList;
import com.crayondata.maya.data.model.profile.CityList;
import com.crayondata.maya.model.common.GeoCode;
import com.crayondata.maya.model.common.Location;
import com.crayondata.maya.model.rest.CityRequest;
import com.crayondata.maya.model.rest.Response;
import com.crayondata.maya.utils.HttpResponseBuilder;
import com.fasterxml.jackson.databind.JsonNode;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import io.swagger.annotations.Authorization;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v3/list")
@Api(tags = "Data List API", description = "To retrieve values of a predefined list of data")
public class ListController {

    @Autowired
    private ListAPI listApi;

    @Autowired
    private LocationResolutionService locationResolutionService;

    @Autowired
    private HttpResponseBuilder builder;

    @ApiResponses({
        @ApiResponse(code = 200, message = "List returned", response = DataList.class)})
    @RequestMapping(value = "/{id}", produces = "application/json", method = RequestMethod.GET)
    @ApiOperation(value = "Get list data", authorizations = {
        @Authorization(value = "Authorization")})
    public ResponseEntity<?> getList(HttpServletRequest httpServletRequest,
        @PathVariable String id, @RequestParam(defaultValue = "en") String lang) {
        com.crayondata.maya.model.api.ApiResponse<JsonNode> dataList = null;
        if (DBConstants.COUNTRIES.equalsIgnoreCase(id)
            || DBConstants.CITIES.equalsIgnoreCase(id)) {
            String ip = locationResolutionService.extractIPFromRequest(httpServletRequest);
            Location location = locationResolutionService.resolveFromIP(ip);
            GeoCode geoCode = location != null ? location.getGeocode() : null;
            String country = location != null ? location.getCountry() : null;
            dataList = DBConstants.CITIES.equalsIgnoreCase(id)
                ? listApi.getCityList(geoCode, lang)
                : listApi.getCountryList(country, lang);
        } else {
            dataList = listApi.getDataList(id, lang);
        }
        return builder.buildResponseEntity(dataList, (data, utils) -> data);
    }

    @ApiResponses({
        @ApiResponse(code = 200, message = "Tag list returned for category",
        response = DataList.class)})
    @RequestMapping(value = "/category/{category}/tags", produces = "application/json",
        method = RequestMethod.GET)
    @ApiOperation(value = "Get tag list for category", authorizations = {
        @Authorization(value = "Authorization")})
    public ResponseEntity<?> getTagListForCategory(@PathVariable String category,
        @RequestParam(defaultValue = "en") String lang) {
        com.crayondata.maya.model.api.ApiResponse<JsonNode> tagList = listApi
            .getTagListForCategory(category, lang);
        return builder.buildResponseEntity(tagList, (data, utils) -> data);
    }

    /**
     * Get list of cities sorted based on current location if geocode is given in request.
     * @param cityRequest geocode of user location
     * @return
     */
    @RequestMapping(value = "cities", produces = "application/json", method = RequestMethod.POST)
    @ApiOperation(value = "Get city details sorted based on current location", authorizations = {
        @Authorization(value = "Authorization")})
    public ResponseEntity<?> getCityList(@RequestParam(defaultValue = "en") String lang,
        @RequestBody CityRequest cityRequest) {
        com.crayondata.maya.model.api.ApiResponse<JsonNode> cityList =
            listApi.getCityList(cityRequest.getGeoCode(), lang);
        if (cityList == null) {
            return new ResponseEntity<>(Response.NOT_FOUND, HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<>(cityList.getResponse(), HttpStatus.OK);
    }

    @ApiResponses({
        @ApiResponse(code = 200, message = "Tag list returned for all categories",
        response = DataList.class)})
    @RequestMapping(value = "category/tags", produces = "application/json",
        method = RequestMethod.GET)
    @ApiOperation(value = "Get tag list for all categories", authorizations = {
        @Authorization(value = "Authorization")})
    public ResponseEntity<?> getTagListForAllCategories(@RequestParam(defaultValue = "en")
        String lang) {
        com.crayondata.maya.model.api.ApiResponse<Map<String, JsonNode>> status = listApi
            .getTagListForAllCategories(lang);
        switch (status.getStatus()) {
            case SUCCESS:
                return new ResponseEntity<>(status.getResponse(), HttpStatus.OK);
            case NOT_FOUND:
                return new ResponseEntity<>(new Response(404, status.getMessage()),
                    HttpStatus.NOT_FOUND);
            default:
                return new ResponseEntity<>(Response.FAILURE, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

}
