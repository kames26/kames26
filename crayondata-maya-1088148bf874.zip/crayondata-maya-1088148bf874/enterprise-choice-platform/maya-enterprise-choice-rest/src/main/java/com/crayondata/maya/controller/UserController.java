/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.maya.controller;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import com.crayondata.maya.choice.UserAPI;
import com.crayondata.maya.choice.UserTasteAPI;
import com.crayondata.maya.choice.config.CurrentUser;
import com.crayondata.maya.choice.service.UserResolutionService;
import com.crayondata.maya.data.access.util.JsonUtils;
import com.crayondata.maya.data.model.campaign.Campaign;
import com.crayondata.maya.data.model.entity.Item;
import com.crayondata.maya.data.model.security.UserPrincipal;
import com.crayondata.maya.model.api.InteractRequest;
import com.crayondata.maya.model.api.InteractionResponse;
import com.crayondata.maya.model.api.ItemOnboardRequest;
import com.crayondata.maya.model.api.TagOnboardRequest;
import com.crayondata.maya.model.api.UserTagPreferenceResponse;
import com.crayondata.maya.model.common.Interaction;
import com.crayondata.maya.model.enums.CampaignType;
import com.crayondata.maya.model.rest.CampaignResponse;
import com.crayondata.maya.model.rest.OfferRedemptionHistory;
import com.crayondata.maya.model.rest.Response;
import com.crayondata.maya.model.rest.UserProfileRequest;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import io.swagger.annotations.Authorization;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import springfox.documentation.annotations.ApiIgnore;

@RestController
@RequestMapping("/api/v3/user")
@Api(tags = "User Profile and Campaigns",
    description = "To retrieve the user profile, taste profile, "
    + "likes and campaigns for a particular user")
public class UserController {

    @Autowired
    private UserAPI userApi;

    @Autowired
    private JsonUtils json;

    @Autowired
    private UserResolutionService userResolutionService;

    @Autowired
    private UserTasteAPI userTasteApi;

    @ApiResponses({
        @ApiResponse(code = 200, message = "User Campaigns", response = Campaign.class)})
    @RequestMapping(value = "campaigns", produces = "application/json", method = RequestMethod.GET)
    @ApiOperation(value = "Get campaigns for user", authorizations = {
        @Authorization(value = "Authorization")})
    public ResponseEntity<?> userCampaigns(
        @ApiIgnore @CurrentUser UserPrincipal currentUser,
        @RequestHeader(value = "User-Access-Token") String accessToken,
        @RequestParam(value = "knownUserId", required = false) String knownUserId,
        @RequestParam(value = "campaignType", required = false) CampaignType campaignType) {

        String userId = userResolutionService.resolveUserIdViaSecurityConfig(currentUser,
            accessToken);
        com.crayondata.maya.model.api.CampaignResponse response = userApi
            .getCampaigns(userId, knownUserId, campaignType);
        if (response.hasCampaigns()) {
            CampaignResponse response2 = new CampaignResponse(response.getCampaigns());
            return new ResponseEntity<>(response2, HttpStatus.OK);
        }

        if (response.isError()) {
            return new ResponseEntity<>(Response.FAILURE, HttpStatus.INTERNAL_SERVER_ERROR);
        }

        return new ResponseEntity<>(Response.NOT_FOUND, HttpStatus.NOT_FOUND);
    }

    @ApiResponses({
        @ApiResponse(code = 200, message = "Likes returned", response = Item.class)})
    @RequestMapping(value = "likes", produces = "application/json", method = RequestMethod.GET)
    @ApiOperation(value = "Get likes for user", authorizations = {
        @Authorization(value = "Authorization")}
    )
    public ResponseEntity<?> userLikes(@ApiIgnore @CurrentUser UserPrincipal currentUser,
        @RequestHeader(value = "User-Access-Token") String accessToken) {

        String userId = userResolutionService.resolveUserIdViaSecurityConfig(currentUser,
            accessToken);
        com.crayondata.maya.model.api.ChoiceResponse response = userApi.getLikes(userId);

        if (response.hasChoices()) {
            return new ResponseEntity<>(response.getChoices(), HttpStatus.OK);
        }

        if (response.isError()) {
            return new ResponseEntity<>(Response.FAILURE, HttpStatus.INTERNAL_SERVER_ERROR);
        }

        return new ResponseEntity<>(Response.NOT_FOUND, HttpStatus.NOT_FOUND);
    }

    @ApiResponses({
        @ApiResponse(code = 200, message = "User profile returned", response = Response.class)})
    @RequestMapping(value = "profile", produces = "application/json",
        method = RequestMethod.GET)
    @ApiOperation(value = "Get user profile", authorizations = {
        @Authorization(value = "Authorization")})
    public ResponseEntity<?> userProfile(
        @ApiIgnore @CurrentUser UserPrincipal currentUser,
        @RequestHeader(value = "User-Access-Token") String accessToken) {

        String userId = userResolutionService.resolveUserIdViaSecurityConfig(currentUser,
            accessToken);
        com.crayondata.maya.model.api.UserProfileResponse response = userApi
            .getUserProfile(userId);

        if (response.hasUserProfile()) {
            return new ResponseEntity<>(response.getUserProfile(), HttpStatus.OK);
        }

        if (response.isError()) {
            return new ResponseEntity<>(Response.FAILURE, HttpStatus.INTERNAL_SERVER_ERROR);
        }

        return new ResponseEntity<>(Response.NOT_FOUND, HttpStatus.NOT_FOUND);
    }

    @ApiResponses({
        @ApiResponse(code = 200, message = "User profile updated", response = Response.class)})
    @RequestMapping(value = "profile", produces = "application/json",
        method = RequestMethod.PATCH)
    @ApiOperation(value = "Updates user profile", authorizations = {
        @Authorization(value = "Authorization")})
    public ResponseEntity<?> updateUserProfile(
        @ApiIgnore @CurrentUser UserPrincipal currentUser,
        @RequestHeader(value = "User-Access-Token") String accessToken,
        @RequestBody UserProfileRequest userProfileRequest) {

        String userId = userResolutionService.resolveUserIdViaSecurityConfig(currentUser,
            accessToken);
        com.crayondata.maya.model.api.ApiResponse<Boolean> status = userApi
            .updateUserProfile(userId, userProfileRequest);
        switch (status.getStatus()) {
            case SUCCESS:
                return new ResponseEntity<>(status.getResponse(), HttpStatus.OK);
            case ERROR:
            default:
                return new ResponseEntity<>(Response.FAILURE, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * Get the User's Tag Preference Vector.
     * @param userId Id of the user
     * @return response
     */
    @ApiResponses({
        @ApiResponse(code = 200, message = "Get the User's Tag Preferences",
        response = UserTagPreferenceResponse.class)})
    @GetMapping(value = "preferences", produces = APPLICATION_JSON_VALUE)
    @ApiOperation(value = "Get user tag preferences", authorizations = {
        @Authorization(value = "Authorization")})
    public ResponseEntity<?> userPreferences(
        @RequestHeader(value = "User-Access-Token") String userId) {
        UserTagPreferenceResponse response = userApi.getUserTagPreferenceVector(userId);

        if (response.hasResponse()) {
            return new ResponseEntity<>(response, HttpStatus.OK);
        }

        if (response.isError()) {
            return new ResponseEntity<>(Response.FAILURE, HttpStatus.INTERNAL_SERVER_ERROR);
        }

        return new ResponseEntity<>(Response.NOT_FOUND, HttpStatus.NOT_FOUND);

    }

    /**
     * Persists user onboarded information.
     * @param userId  id of the user
     * @param userOnboardRequest user onboarded data
     * @return
     */
    @ApiOperation(value = "Store the user's favourite places list", authorizations = {
        @Authorization(value = "Authorization")})
    @PostMapping(value = "onboard/items", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> storeFavoritePlaces(
        @RequestHeader(value = "User-Access-Token") String userId,
        @RequestBody ItemOnboardRequest userOnboardRequest) {

        com.crayondata.maya.model.api.ApiResponse<Boolean> status = userTasteApi
            .saveUserFavouriteItems(userId,
            userOnboardRequest.getCategory(),
            userOnboardRequest.getFavouritePlaces());
        switch (status.getStatus()) {
            case SUCCESS:
                return new ResponseEntity<>(status.getResponse(), HttpStatus.OK);
            case ERROR:
            default:
                return new ResponseEntity<>(Response.FAILURE, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * Persists user onboarded information.
     * @param userId  id of the user
     * @param offerOnboardRequest onboarded data
     * @return
     */
    @ApiOperation(value = "Store the user's liked tags", authorizations = {
        @Authorization(value = "Authorization")})
    @PostMapping(value = "onboard/tags", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> storeFavouriteTags(
        @RequestHeader(value = "User-Access-Token") String userId,
        @RequestBody TagOnboardRequest offerOnboardRequest) {

        com.crayondata.maya.model.api.ApiResponse<Boolean> status = userTasteApi
            .saveUserFavouriteTags(userId,
            offerOnboardRequest.getCategory(),
            offerOnboardRequest.getLikedTags());
        switch (status.getStatus()) {
            case SUCCESS:
                return new ResponseEntity<>(status.getResponse(), HttpStatus.OK);
            case ERROR:
            default:
                return new ResponseEntity<>(Response.FAILURE, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }



    /**
     * Get user's favourite places.
     * @param userId id of the user
     * @param category category selected by the user
     * @return
     */
    @ApiOperation(value = "Get user's favorite places", authorizations = {
        @Authorization(value = "Authorization")})
    @GetMapping(value = "favourites", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> getUserOnboardedInfo(
        @RequestHeader(value = "User-Access-Token") String userId,
        @RequestParam String category) {
        com.crayondata.maya.model.api.ApiResponse<Map<String, Object>> status = userTasteApi
            .getUserOnboardedInfo(userId, category);
        switch (status.getStatus()) {
            case SUCCESS:
                return new ResponseEntity<>(status.getResponse(), HttpStatus.OK);
            case NOT_FOUND:
                return new ResponseEntity<>(new Response(404, status.getMessage()),
                    HttpStatus.NOT_FOUND);
            default:
                return new ResponseEntity<>(Response.FAILURE, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @ApiResponses({@ApiResponse(code = 200, message = "Interact")})
    @ApiOperation(value = "Interact on an item recommended in choice",
        authorizations = {@Authorization(value = "Authorization")})
    @RequestMapping(value = "interact", produces = "application/json",
        consumes = "application/json", method = RequestMethod.POST)
    public ResponseEntity<Response> userInteraction(
        @ApiIgnore @CurrentUser UserPrincipal currentUser,
        @RequestHeader(value = "User-Access-Token", required = true) String accessToken,
        @RequestBody(required = true) Interaction interaction) {

        String userId = userResolutionService.resolveUserIdViaSecurityConfig(currentUser,
            accessToken);
        InteractRequest request = new InteractRequest(userId, interaction);
        com.crayondata.maya.model.api.ApiResponse<Boolean> response = userApi.interact(request);
        switch (response.getStatus()) {
            case SUCCESS:
                return new ResponseEntity<>(Response.SUCCESS, HttpStatus.OK);
            case BAD_REQUEST:
                return new ResponseEntity<>(Response.BAD_REQUEST, HttpStatus.BAD_REQUEST);
            case NOT_FOUND:
                return new ResponseEntity<>(Response.NOT_FOUND, HttpStatus.NOT_FOUND);
            case ERROR:
            default:
                return new ResponseEntity<>(Response.FAILURE, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * Get interaction details for given interaction type.
     * @param accessToken id of the user
     * @param itemType type of item
     * @param interactionType type of interaction
     * @param lang selected language by the user
     * @return
     */
    @ApiOperation(value = "Get interaction details for given interaction type",
        authorizations = {@Authorization(value = "Authorization")})
    @GetMapping(value = "interaction", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> getUserInteraction(
        @ApiIgnore @CurrentUser UserPrincipal currentUser,
        @RequestHeader(value = "User-Access-Token", required = true) String accessToken,
        @RequestParam String itemType, @RequestParam String interactionType,
        @RequestParam(defaultValue = "en") String lang) {

        String userId = userResolutionService.resolveUserIdViaSecurityConfig(currentUser,
            accessToken);
        com.crayondata.maya.model.api.ApiResponse<InteractionResponse> response = userApi
            .getUserInteractions(userId, itemType, interactionType, lang);
        switch (response.getStatus()) {
            case SUCCESS:
                return new ResponseEntity<>(response.getResponse(), HttpStatus.OK);
            case BAD_REQUEST:
                return new ResponseEntity<>(Response.BAD_REQUEST, HttpStatus.BAD_REQUEST);
            case NOT_FOUND:
                return new ResponseEntity<>(Response.NOT_FOUND, HttpStatus.NOT_FOUND);
            case ERROR:
            default:
                return new ResponseEntity<>(Response.FAILURE, HttpStatus.INTERNAL_SERVER_ERROR);

        }
    }

    /**
     * Get user's redeemed offers.
     * @param accessToken id of the user
     * @param lang selected language by the user
     * @return
     */
    @ApiOperation(value = "Get redeemed offers",
        authorizations = {@Authorization(value = "Authorization")})
    @GetMapping(value = "redeemed/offers", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> getRedeemedOffers(
        @ApiIgnore @CurrentUser UserPrincipal currentUser,
        @RequestHeader(value = "User-Access-Token", required = true) String accessToken,
        @RequestParam(defaultValue = "en") String lang) {

        String userId = userResolutionService.resolveUserIdViaSecurityConfig(currentUser,
            accessToken);
        com.crayondata.maya.model.api.ApiResponse<OfferRedemptionHistory> response = userApi
            .getRedeemedOffers(userId, lang);
        switch (response.getStatus()) {
            case SUCCESS:
                return new ResponseEntity<>(response.getResponse(), HttpStatus.OK);
            case BAD_REQUEST:
                return new ResponseEntity<>(Response.BAD_REQUEST, HttpStatus.BAD_REQUEST);
            case NOT_FOUND:
                return new ResponseEntity<>(Response.NOT_FOUND, HttpStatus.NOT_FOUND);
            case ERROR:
            default:
                return new ResponseEntity<>(Response.FAILURE, HttpStatus.INTERNAL_SERVER_ERROR);

        }
    }
}
