/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.maya;

import com.crayondata.maya.choice.service.ConfigurationService;
import com.crayondata.maya.data.access.util.JsonUtils;
import com.crayondata.maya.data.model.config.ChoiceApiConfig;
import com.crayondata.maya.filters.AccessLogFilter;
import com.crayondata.maya.filters.AuthorizationFilter;
import com.crayondata.maya.filters.CorsFilter;
import com.crayondata.maya.filters.HeaderFilter;
import com.crayondata.maya.filters.InternalApiAuthorizationFilter;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.boot.web.servlet.error.DefaultErrorAttributes;
import org.springframework.boot.web.servlet.error.ErrorAttributes;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Primary;
import org.springframework.http.converter.json.Jackson2ObjectMapperBuilder;
import org.springframework.web.context.annotation.RequestScope;
import org.springframework.web.context.request.WebRequest;

@SpringBootApplication
public class Application {

    @Value(value = "${application.api.key}")
    private String apiKey;

    @Value(value = "${application.api.key.internal}")
    private String internalApiKey;

    @Value("${allowedOrigins:}")
    private String[] allowedOrigins;

    @Autowired
    private JsonUtils json;

    @Autowired
    private ConfigurationService configurationService;

    public static void main(String[] args) throws Exception {
        SpringApplication.run(Application.class, args);
    }

    @Bean
    public FilterRegistrationBean corsFilterRegistrationBean() {
        FilterRegistrationBean registration = new FilterRegistrationBean();
        registration.setFilter(new CorsFilter(json, allowedOrigins));
        registration.addUrlPatterns("/api/*");
        registration.setName("corsFilter");
        registration.setOrder(2);
        return registration;
    }

    @Bean
    public FilterRegistrationBean authFilterRegistrationBean() {
        FilterRegistrationBean registration = new FilterRegistrationBean();
        registration.setFilter(new AuthorizationFilter(apiKey, json));
        registration.addUrlPatterns("/api/*");
        registration.setEnabled(false);
        registration.setName("authFilter");
        registration.setOrder(4);
        return registration;
    }

    @Bean
    public FilterRegistrationBean internalApiAuthFilterRegistrationBean() {
        FilterRegistrationBean registration = new FilterRegistrationBean();
        registration.setFilter(new InternalApiAuthorizationFilter(internalApiKey, json));
        registration.addUrlPatterns("/api/v2/internal/*");
        registration.setName("internalApiAuthFilter");
        registration.setOrder(3);
        return registration;
    }

    @Bean
    public FilterRegistrationBean logFilterRegistrationBean() {
        FilterRegistrationBean registration = new FilterRegistrationBean();
        registration.setFilter(new AccessLogFilter());
        registration.addUrlPatterns("/api/*");
        registration.setName("logFilter");
        registration.setOrder(1);
        return registration;
    }

    @Bean
    public FilterRegistrationBean headersFilterRegistrationBean() {
        FilterRegistrationBean registration = new FilterRegistrationBean();
        registration.setFilter(new HeaderFilter());
        registration.addUrlPatterns("/swagger-ui.html");
        registration.setName("headerFilter");
        //        registration.setOrder(1);
        return registration;
    }

    @Bean
    @Primary
    public ObjectMapper objectMapper(Jackson2ObjectMapperBuilder builder) {
        ObjectMapper objectMapper = builder.createXmlMapper(false)
            .featuresToDisable(DeserializationFeature.ADJUST_DATES_TO_CONTEXT_TIME_ZONE,
            DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES,
            SerializationFeature.WRITE_DATES_AS_TIMESTAMPS).build();
        objectMapper.findAndRegisterModules();
        return objectMapper;
    }

    @Bean
    public ErrorAttributes errorAttributes() {
        return new DefaultErrorAttributes() {
            @Override
            public Map<String, Object> getErrorAttributes(WebRequest webRequest,
                boolean includeStackTrace) {
                Map<String, Object> errorAttributes = super
                    .getErrorAttributes(webRequest, includeStackTrace);
                errorAttributes.remove("error");
                errorAttributes.remove("exception");
                errorAttributes.remove("path");
                errorAttributes.remove("timestamp");
                return errorAttributes;
            }
        };
    }

    @Bean
    @RequestScope
    public ChoiceApiConfig choiceApiConfig() {
        // inject configuration at request level, so it can change between requests but not within
        return configurationService.getChoiceApiConfig();
    }

}
