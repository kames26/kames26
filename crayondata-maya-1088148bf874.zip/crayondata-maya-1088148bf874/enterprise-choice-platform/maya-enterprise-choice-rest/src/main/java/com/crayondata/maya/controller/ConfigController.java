/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.maya.controller;

import com.crayondata.maya.choice.service.ConfigValidator;
import com.crayondata.maya.choice.service.ConfigurationService;
import com.crayondata.maya.data.access.util.JsonUtils;
import com.crayondata.maya.data.model.config.ChoiceApiConfig;
import com.crayondata.maya.data.model.config.ConfigHistory;
import com.crayondata.maya.model.api.ConfigValidationResponse;
import com.crayondata.maya.model.api.ConfigurationResponse;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import io.swagger.annotations.Authorization;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * Controller for supporting configuration management.
 *
 * @author Somin
 */
@RestController
@RequestMapping("/api/v2/internal/config")
@Api(tags = "Configuration APIs")
public class ConfigController {

    @Autowired
    private ConfigurationService configurationService;

    @Autowired
    private JsonUtils jsonUtils;

    public ConfigController() {
    }

    /**
     * Create new configuration in DB.
     *
     * @return Status of the operation. Will return status and config ID on success,
     *     error message otherwise.
     */
    @ApiResponses({
        @ApiResponse(code = 200, message = "Configuration Response",
        response = ConfigurationResponse.class)
    })
    @ApiOperation(value = "Create a new configuration", authorizations = {
        @Authorization(value = "Authorization")})
    @PostMapping(value = "create",
        produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> createConfiguration(
        @RequestBody ChoiceApiConfig config) {
        ConfigurationResponse response = configurationService.createConfiguration(config);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    /**
     * Validates the given configuration.
     *
     * @return Status of the operation. Will return success status and error message if applicable.
     */
    @ApiResponses({
        @ApiResponse(code = 200, message = "Configuration Validation Response",
        response = ConfigValidationResponse.class)
    })
    @ApiOperation(value = "Validates the given configuration", authorizations = {
        @Authorization(value = "Authorization")})
    @PostMapping(value = "validate",
        produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> validateConfiguration(
        @RequestBody ChoiceApiConfig config) {
        ConfigValidationResponse response = ConfigValidator.validate(config);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    /**
     * Validate configuration from DB.
     *
     * @param id ID of the configuration.
     * @return Status of the operation. Will return success status and error message if applicable.
     */
    @ApiResponses({
        @ApiResponse(code = 200, message = "Configuration Validation Response",
        response = ConfigValidationResponse.class)
    })
    @ApiOperation(value = "Validates the configuration identified by id", authorizations = {
        @Authorization(value = "Authorization")})
    @GetMapping(value = "validate", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> validateConfigurationById(@RequestParam String id) {
        ChoiceApiConfig configuration = configurationService.getConfigurationById(id);
        ConfigValidationResponse response = ConfigValidator.validate(configuration);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    /**
     * Loads the given configuration, or schedules it for load.
     *
     * @return Status of the operation. Will return status
     *     and timestamp when configuration is loaded on success, error message otherwise.
     */
    @ApiResponses({
        @ApiResponse(code = 200, message = "Configuration Load Response",
        response = ConfigurationResponse.class)
    })
    @ApiOperation(value = "Loads the given configuration", authorizations = {
        @Authorization(value = "Authorization")})
    @PostMapping(value = "load",
        produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> loadConfiguration(
        @RequestBody Map<String, String> params) {
        ConfigurationResponse configResponse;
        try {
            String configId = params.get("configId");
            if (configId == null) {
                configId = configurationService.getConfigHistory().getCurrentConfig();
            }
            // TODO add support for timestamp based config load
            configurationService.loadConfiguration(configId, true);
            configResponse = new ConfigurationResponse(true, configId);
        } catch (ConfigurationService.ConfigurationException ex) {
            configResponse = new ConfigurationResponse(false, ex.getMessage());
        }
        return new ResponseEntity<>(configResponse, HttpStatus.OK);
    }

    /**
     * Get configuration of the given ID from DB.
     *
     * @param id ID of the configuration. Can be passed as null to get current configuration.
     * @return The requested configuration if found.
     */
    @ApiResponses({
        @ApiResponse(code = 200, message = "Configuration details",
        response = ChoiceApiConfig.class)
    })
    @ApiOperation(value = "Get the configuration identified by id", authorizations = {
        @Authorization(value = "Authorization")})
    @GetMapping(value = "view", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> getConfiguration(@RequestParam(required = false) String id) {
        ResponseEntity<?> result;
        ChoiceApiConfig config = id != null ? configurationService.getConfigurationById(id)
            : configurationService.getChoiceApiConfig();
        if (config != null) {
            result = new ResponseEntity<>(config, HttpStatus.OK);
        } else {
            result = new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        return result;
    }

    /**
     * Get history of configuration created/loaded from DB.
     *
     * @return History of the created/loaded configurations.
     */
    @ApiResponses({
        @ApiResponse(code = 200, message = "Details of configurations loaded",
        response = ConfigHistory.class)
    })
    @ApiOperation(value = "View the history of configurations loaded", authorizations = {
        @Authorization(value = "Authorization")})
    @GetMapping(value = "history", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> getConfigLoadHistory() {
        ConfigHistory configHistory = configurationService.getConfigHistory();
        if (configHistory != null) {
            return new ResponseEntity<>(configHistory, HttpStatus.OK);
        }
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    /**
     * Clears content of the cache.
     *
     * @return Status of the operation. Will return success status and error message if applicable.
     */
    @ApiResponses({
        @ApiResponse(code = 200, message = "Cache clear status",
        response = ConfigurationResponse.class)
    })
    @ApiOperation(value = "Clears the cache", authorizations = {
        @Authorization(value = "Authorization")})
    @GetMapping(value = "cache/clear", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> clearCache() {
        ConfigurationResponse configResponse = configurationService.clearCache()
            ? new ConfigurationResponse(true)
            : new ConfigurationResponse(false,
            "Caching not supported by data access service");
        return new ResponseEntity<>(configResponse, HttpStatus.OK);
    }

}
