/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.maya.controller;

import com.crayondata.maya.choice.service.FilterService;
import com.crayondata.maya.data.entity.ItemService;
import com.crayondata.maya.data.model.entity.Item;
import com.crayondata.maya.model.common.GeoCode;
import com.crayondata.maya.model.rest.DistanceCalcRequest;
import com.crayondata.maya.model.rest.Response;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import io.swagger.annotations.Authorization;
import java.time.OffsetDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v2/internal/item")
@Api(tags = "Debug APIs")
public class DebugController {

    @Autowired
    private ItemService itemService;

    @Autowired
    private FilterService filterService;

    /**
     * Calculates the distance of the items from the given location.
     * @param request Distance calculation request
     * @return
     */
    @ApiResponses({@ApiResponse(code = 200, message = "Distances", response = Map.class)})
    @ApiOperation(value = "Calculates the distance of the items from the given location",
        authorizations = {@Authorization(value = "Authorization")})
    @PostMapping(value = "calcDist",
        produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> calculateDistances(@RequestBody DistanceCalcRequest request) {
        if (CollectionUtils.isEmpty(request.getItemIds())) {
            return new ResponseEntity<>(Response.BAD_REQUEST, HttpStatus.BAD_REQUEST);
        }
        List<Item> items = itemService.getItems(request.getItemIds());
        Map<String, Double> itemDist = new HashMap<>();

        if (request.isOnlyActiveOffers()) {
            OffsetDateTime servedAt = OffsetDateTime.now();
            List<Item> validOffers = filterService.filterExpiredOffers(items, servedAt, true);
            validOffers.forEach(item -> {
                double distance = request.getLocation().getClosestGeoDistance(item.offerGeoCodes());
                itemDist.put(item.getId(), distance);
            });
        } else {
            items.forEach(item -> {
                double distance = request.getLocation().getClosestGeoDistance(item.getGeoCodes());
                itemDist.put(item.getId(), distance);
            });
        }
        return new ResponseEntity<>(itemDist, HttpStatus.OK);
    }
}
