/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.maya.controller;

import com.crayondata.maya.choice.service.UiConfigService;
import com.fasterxml.jackson.databind.JsonNode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import springfox.documentation.annotations.ApiIgnore;

/**
 * Controller for serving UI configurations.
 *
 * @author Somin
 *
 */
@RestController
@RequestMapping("/api/v2/ui")
@ApiIgnore
public class UiConfigController {

    @Autowired
    private UiConfigService uiConfigService;

    /**
     * Get UI theme configuration based on user.
     *
     * @param userId Known ID for user for whom theme is requested
     * @param accessToken Token uniquely representing the user
     * @return Theme configuration
     */
    @Deprecated
    @RequestMapping(value = "theme", produces = "application/json",
        method = RequestMethod.GET)
    public ResponseEntity<?> getUiConfigForUser(
        @RequestParam(value = "userId", required = false) String userId,
        @RequestHeader(value = "User-Access-Token", required = true) String accessToken) {
        ResponseEntity response;
        // get the available user ID
        String profileId = userId != null ? userId : accessToken;
        JsonNode uiConfiguration = uiConfigService.getUiConfigurationForUser(profileId);
        if (uiConfiguration != null) {
            response = new ResponseEntity<>(uiConfiguration, HttpStatus.OK);
        } else {
            response = new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        return response;
    }

}
