/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.maya.controller;

import com.crayondata.maya.choice.ItemApiImpl;
import com.crayondata.maya.choice.config.CurrentUser;
import com.crayondata.maya.choice.service.UserResolutionService;
import com.crayondata.maya.data.access.util.JsonUtils;
import com.crayondata.maya.data.model.security.UserPrincipal;
import com.crayondata.maya.model.api.AutoSuggestItemResponse;
import com.crayondata.maya.model.api.ItemSearchResponse;
import com.crayondata.maya.model.api.RecentSearchResponse;
import com.crayondata.maya.model.rest.Response;
import com.crayondata.maya.model.rest.SearchRequest;
import com.crayondata.maya.utils.HttpResponseBuilder;
import com.crayondata.maya.utils.ResponseJsonUtil;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import io.swagger.annotations.Authorization;
import java.util.function.BiFunction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import springfox.documentation.annotations.ApiIgnore;

@RestController
@CrossOrigin
@RequestMapping("/api/v3/merchant/")
@Api(tags = "Search API", description = "To search for items")
public class SearchController {

    private static final Logger LOGGER = LoggerFactory.getLogger(SearchController.class);

    @Autowired
    private ItemApiImpl itemApi;

    @Autowired
    private UserResolutionService userResolutionService;

    @Value("${item.search.count.max}")
    private int maxCount;

    @Value("${recentsearch.result.size}")
    private int searchResultSize;

    @Autowired
    private HttpResponseBuilder responseBuilder;

    private static BiFunction<ItemSearchResponse, JsonUtils, JsonNode> CONVERT_JSON_FN =
        (response, jsonUtils) -> {
            ObjectNode rootNode = (ObjectNode) jsonUtils.asJsonNode(response);
            ArrayNode elements = (ArrayNode) rootNode.get("items");
            for (JsonNode item : elements) {
                ObjectNode objectNode = (ObjectNode) item;
                ResponseJsonUtil.reformatItemJson(jsonUtils, objectNode);
            }
            return rootNode;
        };

    /**
     * API end point to fetch the items for given tags.
     * @param accessToken Token representing the User for whom items are requested
     * @return list of items
     */
    @ApiResponses({
        @ApiResponse(code = 200, message = "Items itemSearch", response = ItemSearchResponse.class),
        @ApiResponse(code = 404, message = "Not found", response = Response.class)})
    @PostMapping(value = "search", produces = MediaType.APPLICATION_JSON_VALUE)
    @ApiOperation(value = "Search items", authorizations = {
        @Authorization(value = "Authorization")})
    public ResponseEntity<?> searchItems(
        @ApiIgnore @CurrentUser UserPrincipal currentUser,
        @RequestHeader(value = "User-Access-Token") String accessToken,
        @RequestBody SearchRequest searchRequest) {
        String userId = userResolutionService.resolveUserIdViaSecurityConfig(currentUser,
            accessToken);
        com.crayondata.maya.model.api.ApiResponse<ItemSearchResponse> response = itemApi
            .getItemsForSearchWord(userId, searchRequest);
        switch (response.getStatus()) {
            case SUCCESS:
                return new ResponseEntity<>(response, HttpStatus.OK);
            case NOT_FOUND:
                return new ResponseEntity<>(new Response(404, response.getMessage()),
                    HttpStatus.NOT_FOUND);
            case ERROR:
            default:
                return new ResponseEntity<>(Response.FAILURE, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * API end point to get the auto suggested merchants for given merchant name .
     *
     * @param searchWord word searched by the user
     * @param city city from which items has to be fetched
     * @param category category from which items has to be fetched
     * @return
     */
    @ApiResponses({
        @ApiResponse(code = 200, message = "Auto Suggest Items by name",
        response = AutoSuggestItemResponse.class),
        @ApiResponse(code = 404, message = "Not found", response = Response.class)})
    @ApiOperation(value = "Auto-suggest Items by name", authorizations = {
        @Authorization(value = "Authorization")})
    @GetMapping(value = "typeAhead", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> autoSuggestItems(
        @ApiIgnore @CurrentUser UserPrincipal currentUser,
        @RequestHeader(value = "User-Access-Token") String accessToken,
        @RequestParam(defaultValue = "en") String searchTextLang,
        @RequestParam(defaultValue = "en") String lang,
        @RequestParam(value = "searchWord") String searchWord,
        @RequestParam(value = "country", required = false) String country,
        @RequestParam(value = "city", required = false) String city,
        @RequestParam(value = "category", required = false) String category) {

        String userId = userResolutionService.resolveUserIdViaSecurityConfig(currentUser,
            accessToken);
        com.crayondata.maya.model.api.ApiResponse<AutoSuggestItemResponse> response = itemApi
            .getSuggestedItems(userId, searchWord, category, country,
            city, searchTextLang, lang);

        switch (response.getStatus()) {
            case SUCCESS:
                return new ResponseEntity<>(response, HttpStatus.OK);
            case NOT_FOUND:
                return new ResponseEntity<>(new Response(404, response.getMessage()),
                    HttpStatus.NOT_FOUND);
            case ERROR:
            default:
                return new ResponseEntity<>(Response.FAILURE, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * API end point to get the auto suggested merchants for given merchant name .
     *
     * @param accessToken id of the user
     * @param limit optional parameter for restricting the limit of responses
     * @return
     */
    @ApiResponses({
        @ApiResponse(code = 200, message = "Get recent search history of the user",
        response = RecentSearchResponse.class),
        @ApiResponse(code = 404, message = "Not found", response = Response.class)})
    @ApiOperation(value = "Get recent search history", authorizations = {
        @Authorization(value = "Authorization")})
    @GetMapping(value = "search/recent", produces = MediaType.APPLICATION_JSON_VALUE)

    public ResponseEntity<?> getRecentSearchHistory(
        @ApiIgnore @CurrentUser UserPrincipal currentUser,
        @RequestHeader(value = "User-Access-Token") String accessToken,
        @RequestParam(value = "limit",required = false) Integer limit,
        @RequestParam(defaultValue = "en") String lang
    ) {

        String userId = userResolutionService.resolveUserIdViaSecurityConfig(currentUser,
            accessToken);
        if (limit == null) {
            limit = searchResultSize;
        }
        com.crayondata.maya.model.api.ApiResponse<RecentSearchResponse> response = itemApi
            .getRecentSearchHistory(userId, limit, lang);

        switch (response.getStatus()) {
            case SUCCESS:
                return new ResponseEntity<>(response.getResponse(), HttpStatus.OK);
            case BAD_REQUEST:
                return new ResponseEntity<>(new Response(400, response.getMessage()),
                        HttpStatus.BAD_REQUEST);
            case NOT_FOUND:
                return new ResponseEntity<>(new Response(404, response.getMessage()),
                        HttpStatus.NOT_FOUND);
            case ERROR:
            default:
                return new ResponseEntity<>(Response.FAILURE, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * API end point to get clear the recent search history of the user.
     *
     * @param accessToken user-AccessToken

     * @return
     */
    @ApiResponses({
        @ApiResponse(code = 200, message = "true",
        response = Response.class),
        @ApiResponse(code = 404, message = "Not found", response = Response.class)})
    @ApiOperation(value = "Clear Recent Search History by name", authorizations = {
        @Authorization(value = "Authorization")})
    @DeleteMapping(value = "search", produces = MediaType.APPLICATION_JSON_VALUE)

    public ResponseEntity<?> clearRecentSearch(
        @ApiIgnore @CurrentUser UserPrincipal currentUser,
        @RequestHeader(value = "User-Access-Token") String accessToken) {

        String userId = userResolutionService.resolveUserIdViaSecurityConfig(currentUser,
            accessToken);
        com.crayondata.maya.model.api.ApiResponse<Boolean> response = itemApi
            .clearRecentSearchHistory(userId);
        switch (response.getStatus()) {
            case SUCCESS:
                return new ResponseEntity<>(response.getResponse(), HttpStatus.OK);
            case NOT_FOUND:
                return new ResponseEntity<>(new Response(404, response.getMessage()),
                        HttpStatus.NOT_FOUND);
            case ERROR:
            default:
                return new ResponseEntity<>(Response.FAILURE, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

}
