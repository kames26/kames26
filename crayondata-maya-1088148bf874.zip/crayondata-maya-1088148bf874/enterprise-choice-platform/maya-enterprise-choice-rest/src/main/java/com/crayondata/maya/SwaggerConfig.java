/**
* Disclaimer: Source code mentioned below is(are) Intellectual Property of
* Crayon Data Holdings Limited (including its subsidiaries and affiliates).
* Crayon Data Holdings Limited reserves right to own and control it the way
* it may deem fit. You must refrain from use, access, read, modify, add or
* delete, sell or use in any other package or programme pertaining to such
* source code without explicit prior written approval of
* Crayon Data Holding Limited. Breach of the same shall attract penalty as
* applicable.
*
*/

package com.crayondata.maya;

import static com.google.common.base.Predicates.not;
import static springfox.documentation.builders.PathSelectors.regex;

import java.util.Arrays;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.info.BuildProperties;
import org.springframework.boot.info.GitProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.bind.annotation.RequestMethod;
import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.builders.ResponseMessageBuilder;
import springfox.documentation.schema.ModelRef;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.ApiKey;
import springfox.documentation.service.Contact;
import springfox.documentation.service.ResponseMessage;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger.web.SecurityConfiguration;
import springfox.documentation.swagger.web.SecurityConfigurationBuilder;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@Configuration
@EnableSwagger2
public class SwaggerConfig {
    @Autowired
    private GitProperties gitProperties;

    @Autowired
    private BuildProperties buildProperties;

    private static final Contact CONTACT_INFO = new Contact("crayondata",
        "http://www.crayondata.com/", "info@crayondata.com");

    @Bean
    public Docket api() {
        return new Docket(DocumentationType.SWAGGER_2)
            .apiInfo(apiInfo())
            .useDefaultResponseMessages(false)
            .select().apis(RequestHandlerSelectors.basePackage("com.crayondata.maya"))
            .paths(not(regex(".*/internal/.*"))).build()
            .securitySchemes(Arrays.asList(apiKey()))
            .globalResponseMessage(RequestMethod.GET, responseMessages())
            .globalResponseMessage(RequestMethod.PUT, responseMessages())
            .globalResponseMessage(RequestMethod.POST, responseMessages());
    }

    @Bean
    public Docket internalApi() {
        return new Docket(DocumentationType.SWAGGER_2)
            .apiInfo(apiInfo())
            .groupName("internal")
            .useDefaultResponseMessages(false)
            .select().apis(RequestHandlerSelectors.basePackage("com.crayondata.maya"))
            .paths(regex(".*/internal/.*")).build()
            .securitySchemes(Arrays.asList(apiKey()))
            .globalResponseMessage(RequestMethod.GET, responseMessages())
            .globalResponseMessage(RequestMethod.PUT, responseMessages())
            .globalResponseMessage(RequestMethod.POST, responseMessages());
    }

    @Bean
    public SecurityConfiguration security() {
        return SecurityConfigurationBuilder.builder().scopeSeparator(",").build();
    }

    private ApiInfo apiInfo() {
        final String description = String
            .format("Built @ \'%s\' by \'%s\' using code (%s) committed @ \'%s\' to branch \'%s\'.",
            buildProperties.getTime(), gitProperties.get("build.user.name"),
            gitProperties.getShortCommitId(), gitProperties.getCommitTime().toString(),
            gitProperties.getBranch());
        return new ApiInfoBuilder().title(buildProperties.getName()).description(description)
            .version("v2").contact(CONTACT_INFO).license("Crayondata proprietary license").build();
    }

    private ApiKey apiKey() {
        return new ApiKey("Authorization", "Authorization", "header");
    }

    private static List<ResponseMessage> responseMessages() {
        ResponseMessageBuilder builder = new ResponseMessageBuilder()
            .responseModel(new ModelRef("Response"));
        ResponseMessage forbidden = builder.code(403).message("forbidden").build();
        ResponseMessage notFound = builder.code(404).message("Not Found").build();
        ResponseMessage serverError = builder.code(500).message("Internal Server Error").build();
        return Arrays.asList(forbidden, notFound, serverError);
    }
}
