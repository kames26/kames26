#!/bin/bash

java -jar -Dcouchbase.server.host=$COUCHBASE_SERVER $MAYA_HOME/maya-enterprise-choice-rest-0.1.0-SNAPSHOT.jar > $LOG_FILE 2>&1
