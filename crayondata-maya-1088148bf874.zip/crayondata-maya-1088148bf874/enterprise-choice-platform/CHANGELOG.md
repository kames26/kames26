# CHANGELOG
All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/) and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [2.2.0-SNAPSHOT] - 2021-03-22
### Added

### Changed

## [2.1.0-SNAPSHOT] - 2021-02-11
### Added
-- [ADB-906](https://crayon.atlassian.net/browse/ADB-906) `Feature` Multi-language support for implemented APIs
-- [ADB-986](https://crayon.atlassian.net/browse/ADB-986) `Feature` Multi-language support for redeemed offers
-- [ADB-1065](https://crayon.atlassian.net/browse/ADB-1065) `Feature` Added support to filter based on country in location filter supported APIs

### Changed
-- [ADB-1006](https://crayon.atlassian.net/browse/ADB-1006) Modified Maya developer guide to include Bazaar APIs
-- [ADB-1019](https://crayon.atlassian.net/browse/ADB-1019) Added new field 'searchTextLang' in Search and TypeAhead APIs

## [2.0.0-SNAPSHOT] - 2020-10-05
### Added
-- [ADB-394](https://crayon.atlassian.net/browse/ADB-394) `Feature` API to update UserProfile
-- [ADB-395](https://crayon.atlassian.net/browse/ADB-395) `Feature` API to get redeemed Offers
-- [ADB-560](https://crayon.atlassian.net/browse/ADB-560) `Feature` API to save review 
-- [ADB-492](https://crayon.atlassian.net/browse/ADB-492) `Feature` Implemented base version of Nearby, Favourites and Expiring Soon Offer list
-- [ADB-550](https://crayon.atlassian.net/browse/ADB-550) `Feature` Implemented base version of NewOffers and Tag based list
-- [ADB-551](https://crayon.atlassian.net/browse/ADB-551) `Feature` Implemented data model to get user choices in batch mode
-- [ADB-560](https://crayon.atlassian.net/browse/ADB-560) `Feature` API to save review 
-- [ADB-693](https://crayon.atlassian.net/browse/ADB-693) `Feature` API to get merchant review details
-- [ADB-670](https://crayon.atlassian.net/browse/ADB-670) `Feature` Implemented base version of scoring mechanism.
-- [ADB-694](https://crayon.atlassian.net/browse/ADB-694) `Feature` API to save and get feedback reviews of the application
-- [ADB-716](https://crayon.atlassian.net/browse/ADB-716) `Feature` API to get recent search history and implemented method to save recent search history
-- [ADB-714](https://crayon.atlassian.net/browse/ADB-714) `Feature` Added filter and sort functionalities in Search API
-- [ADB-805](https://crayon.atlassian.net/browse/ADB-805) `Feature` Added Itemtype to save interaction history method
-- [ADB-719](https://crayon.atlassian.net/browse/ADB-719) `Feature` API to get the resume list
-- [ADB-723](https://crayon.atlassian.net/browse/ADB-723) `Feature` Implemented tracking link generation for items
-- [ADB-828](https://crayon.atlassian.net/browse/ADB-828) `Feature` Implemented Cross Category List
-- [ADB-873](https://crayon.atlassian.net/browse/ADB-873) `Feature` Implemented Clear recent search history
`
### Changed
-- [ADB-696](https://crayon.atlassian.net/browse/ADB-696) `Feature` HTTPS Configuration fix - Upgrade springboot version
-- `Feature` Modified UserProfile data model to include personal details and user settings
--  Added Partition Key in request options on all CosmosDB method implementation
-- `Feature` Support for both merchant and offer level interactions in Interaction API
--  Added null validation in getItem of itemService implementation

### Deprecated
-- Deprecated for soon-to-be removed features.

### Removed
-- Removed for now removed features.

### Fixed
-- `Fix` Object modification is prevented by creating new object to change property of an object

## [1.3.0-SNAPSHOT] - 2019-11-22
### Added
-- [COP-188](https://crayon.atlassian.net/browse/COP-188) `Feature` API to retrieve and update campaign details
-- [COP-80](https://crayon.atlassian.net/browse/COP-80) Added configId in delivered choices and clientId in choice request
-- [COP-555](https://crayon.atlassian.net/browse/COP-555) `Feature` API to autosuggest items
-- [COP-556](https://crayon.atlassian.net/browse/COP-556) `Feature` API to search items
-- [COP-560](https://crayon.atlassian.net/browse/COP-560) `Feature` API to collect and persist user taste
-- [COP-593](https://crayon.atlassian.net/browse/COP-593) `Feature` API to store favourite item and tags for different categories

### Changed
- [RE-837](https://crayon.atlassian.net/browse/RE-837) `Feature` Replace empty valued header with null for storing delivered choices in DynamoDB.
- [RE-902](https://crayon.atlassian.net/browse/RE-902) `Feature` Populate userType in delivered choices document.

### Deprecated
-- Deprecated for soon-to-be removed features.

### Removed
-- Removed for now removed features.

### Fixed
- [QUAL-1706](https://crayon.atlassian.net/browse/QUAL-1706) `Fix` Validate for offer:choice ratio configuration
- `Fix` Model name squishing in swagger doc that is also used in Swagger UI
- [QUAL-1746](https://crayon.atlassian.net/browse/QUAL-1746) `Fix` Issues in distance based score normalization
- `Fix` Enable passing in authorization information via headers in Swagger UI 
- [COP-396](https://crayon.atlassian.net/browse/QUAL-396) `Fix` Issues in considering offer location for distance based score normalization
- [COP-396](https://crayon.atlassian.net/browse/QUAL-396) `Fix` Issue in computing tag score for the first time

### Security
-- Security in case of vulnerabilities.


## [1.2.0] - 2019-10-22
### Added
- [RE-477](https://crayon.atlassian.net/browse/RE-477) `Feature` Support for hot-reloading segment & recommender configurations.
- [RE-480](https://crayon.atlassian.net/browse/RE-480) `Feature` Support for modifying Choice API configuration via DB.
- [RE-511](https://crayon.atlassian.net/browse/RE-511) `Feature` Validations for dynamic segment configurations.
- [RE-674](https://crayon.atlassian.net/browse/RE-674) `Feature` Support to cache the results of key-value and query data access service for read only documents
- [RE-673](https://crayon.atlassian.net/browse/RE-673) `Feature` Added new DynamoDB async implementation for DynamoDB using SDK 2.x.
- [RE-554](https://crayon.atlassian.net/browse/RE-554) `Feature` Implemented Configuration API.
- `Feature` Implemented CORS handling and separate authorization for internal APIs(configuration & clearing cache).

### Changed
- [RE-462](https://crayon.atlassian.net/browse/RE-462) `Feature` Persist campaignUserId always in delivered choices.
- Upgraded Spring Boot and ElasticSearch library versions.


### Removed
- Removed `normalizeScoreByDistance` field from choice request.

### Fixed
- [QUAL-1416](https://crayon.atlassian.net/browse/QUAL-1416) Modified normalize score by distance calculation to handle infinity value
- [IESD-203](https://crayon.atlassian.net/browse/IESD-203) Sort offer locations even for a single offer

### Security
- Mitigated 16 known vulnerabilities(CVE-2019-10072, CVE-2019-0199, CVE-2019-9518, CVE-2019-9515, CVE-2019-9512, CVE-2019-9514, CVE-2019-0232, CVE-2019-0221, CVE-2018-1000873 and more) by upgrading dependencies.

## [1.1.0] - 2019-06-24
### Added
- [RE-347](https://crayon.atlassian.net/browse/RE-347) `Feature` Support to configure distance based recommendations
- [RE-346](https://crayon.atlassian.net/browse/RE-346) `Feature` Support to configure non-offer ratio by segment
- `BUILD` Added support to build & deploy hotfix and release-candidate branches to s3
- [RE-313](https://crayon.atlassian.net/browse/RE-313) `Feature` Added support for pagination

### Fixed
- Fixed unimplemented methods in Couchbase DAL that impacted campaigns

## [1.0.0] - 2019-05-30
### Added
- [RE-123](https://crayon.atlassian.net/browse/RE-123) `BUILD` Added support to deploy the choice api binary to s3
- [RE-156](https://crayon.atlassian.net/browse/RE-156) `Feature` Added support to store user-item interaction history
- [RE-230](https://crayon.atlassian.net/browse/RE-230) `Feature` Added the capability to normalize the recommendation scores by distance
- [RE-305](https://crayon.atlassian.net/browse/RE-305) `Feature` Configurable DAL with support for Couchbase, Dynamo, Elastic, Cosmos
- [RE-304](https://crayon.atlassian.net/browse/RE-304) `Feature` Standardized DAL interface with multi bucket/table/collection/index support
- [RE-304](https://crayon.atlassian.net/browse/RE-304) `Feature` Merged Engage API into Choice API project
- [RE-188](https://crayon.atlassian.net/browse/RE-188) `Feature` Implemented configurable recommender and blenders(Classic, Interleaved & Weighted Aggregation)
- [RE-316](https://crayon.atlassian.net/browse/RE-316) `Feature` Added support for non-offer choices
- `Feature` Added request headers to access log

### Changed
- `Feature` Support disabling authorization filter via config

## [0.1.0-SNAPSHOT] - 2019-02-21
This is the first release of the Maya Choice Api artifact. We did not track the features so far because of which there isn't any particular feature list in this changelog

